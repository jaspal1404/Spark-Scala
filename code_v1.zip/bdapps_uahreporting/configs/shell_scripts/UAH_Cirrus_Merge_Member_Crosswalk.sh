#!/bin/bash
export HIVE_CONF_DIR=$1
export SPARK_CONF_DIR=$2

echo "*****Submitting job1 to the cluster*****"

$3/spark-submit --class com.optum.uah.merge_layer.member.MemberCrosswalk \
--master yarn \
--queue $4 \
--properties-file $8/uah.conf \
--deploy-mode client \
--conf spark.serializer='org.apache.spark.serializer.KryoSerializer' \
--driver-memory 6G --executor-memory 8G --num-executors 4 --executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$7/mergelayer/member_crosswalk $8/mergeMember.json
 
echo "Job1 completed successfully"


echo "*****Submitting job2 to the cluster*****"

$3/spark-submit --class com.optum.uah.function_library.ParquetToPipeDelimited \
--master yarn \
--deploy-mode cluster \
--queue $4 \
--properties-file $8/uah.conf \
--driver-memory 6g --executor-memory 8g --num-executors 4 --executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$7/mergelayer/member_crosswalk/source_cd=PUL $9/hce_extracts Member_Crosswalk

echo "Job2 completed successfully"

exit 0