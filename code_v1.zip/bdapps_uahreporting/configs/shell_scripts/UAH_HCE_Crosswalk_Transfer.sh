#!/bin/bash

export HIVE_CONF_DIR=/mapr/datalake/optum/optuminsight/p_uah/hive/conf
export SPARK_CONF_DIR=/mapr/datalake/optum/optuminsight/p_uah/spark/conf


echo "*****Submitting Child Group Crosswalk job to the cluster*****"

spark-submit \
--class com.optum.uah.function_library.ParquetToPipeDelimited \
--master yarn \
--deploy-mode client \
--queue uahgpprd_q1  \
--driver-memory 6G \
--executor-memory 8G \
--num-executors 2 \
--executor-cores 2 \
/mapr/datalake/optum/optuminsight/p_uah/prd/p_jars/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
/datalake/optum/optuminsight/p_uah/prd/p_hdfs/mergelayer/groupcontractplanopt_lookup_std/ \
/datalake/optum/optuminsight/p_uah/prd/p_outbound/hce_extracts/  HCE_Group_Contract_Plan_Crosswalk

echo "Child Group Crosswalk job completed successfully"


echo "*****Submitting Parent Group Crosswalk job to the cluster*****"

spark-submit \
--class com.optum.uah.function_library.ParquetToPipeDelimited \
--master yarn \
--deploy-mode client \
--queue uahgpprd_q1  \
--driver-memory 6G \
--executor-memory 8G \
--num-executors 2 \
--executor-cores 2 \
/mapr/datalake/optum/optuminsight/p_uah/prd/p_jars/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
/datalake/optum/optuminsight/p_uah/prd/p_hdfs/mergelayer/groupcontract_lookup_std/ \
/datalake/optum/optuminsight/p_uah/prd/p_outbound/hce_extracts/  HCE_Customer_Crosswalk

echo "Parent Group Crosswalk job completed successfully"

echo "*****Submitting Broker Crosswalk job to the cluster*****"

spark-submit --class com.optum.uah.function_library.ParquetToPipeDelimited --master yarn --deploy-mode client --queue uahgpprd_q1  --driver-memory 6G --executor-memory 8G --num-executors 2 --executor-cores 2 /mapr/datalake/optum/optuminsight/p_uah/prd/p_jars/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar /datalake/optum/optuminsight/p_uah/prd/p_hdfs/mergelayer/broker_lookup_std/ /datalake/optum/optuminsight/p_uah/prd/p_outbound/hce_extracts/ HCE_Broker_Crosswalk

echo "Broker Crosswalk job completed successfully"

echo "*****Submitting Provider Crosswalk job to the cluster*****"
spark-submit --class com.optum.uah.function_library.ParquetToPipeDelimited --master yarn --deploy-mode client --queue uahgpprd_q1  --driver-memory 6G --executor-memory 8G --num-executors 2 --executor-cores 2 /mapr/datalake/optum/optuminsight/p_uah/prd/p_jars/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar /datalake/optum/optuminsight/p_uah/prd/p_hdfs/mergelayer/provider_lookup_std/ /datalake/optum/optuminsight/p_uah/prd/p_outbound/hce_extracts/ HCE_Provider_Crosswalk
echo "Provider Crosswalk job completed successfully"

echo "*****Submitting Network Crosswalk job to the cluster*****"
spark-submit --class com.optum.uah.function_library.ParquetToPipeDelimited --master yarn --deploy-mode client --queue uahgpprd_q1  --driver-memory 6G --executor-memory 8G --num-executors 2 --executor-cores 2 /mapr/datalake/optum/optuminsight/p_uah/prd/p_jars/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar /datalake/optum/optuminsight/p_uah/prd/p_hdfs/mergelayer/network_lookup_std/ /datalake/optum/optuminsight/p_uah/prd/p_outbound/hce_extracts/ HCE_Network_Crosswalk
echo "Network Crosswalk job completed successfully"

status=$?
if [[ !$status -eq 0 ]];then
        status=49
        exit 49
		
fi

echo "job completed successfully"

exit 0
