#!/bin/bash
export HIVE_CONF_DIR=$1
export SPARK_CONF_DIR=$2


echo "*****Submitting job 1 to the cluster*****"
$3/spark-submit \
--class com.optum.uah.merge_layer.benefits.UAHCirrusBenefits \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode cluster \
--driver-memory 6g \
--executor-memory 19g \
--num-executors 10 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$8/mergeBenefits.json $7/mergelayer/productbenefitandtype_std productbenefitandtype_std


echo "*****Submitting job 2 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.benefits.UAHCirrusBenefits \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode cluster \
--driver-memory 6g \
--executor-memory 19g \
--num-executors 10 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$8/mergeBenefits.json $7/mergelayer/beneplansettings_std beneplansettings_std


echo "*****Submitting job 3 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.benefits.UAHCirrusBenefits \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode cluster \
--driver-memory 6g \
--executor-memory 19g \
--num-executors 10 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$8/mergeBenefits.json $7/mergelayer/benecodeadj_std benecodeadj_std


echo "*****Submitting job 4 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.benefits.UAHCirrusBenefits \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode cluster \
--driver-memory 6g \
--executor-memory 19g \
--num-executors 10 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$8/mergeBenefits.json $7/mergelayer/benetiernetworkandprov_std benetiernetworkandprov_std

echo "*****Submitting job 5 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.benefits.UAHCirrusBenefits \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode cluster \
--driver-memory 6g \
--executor-memory 19g \
--num-executors 10 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$8/mergeBenefits.json $7/mergelayer/benedeductibleperiod_view benedeductibleperiod_view

echo "*****Submitting job 6 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.benefits.UAHCirrusBenefits \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode cluster \
--driver-memory 6g \
--executor-memory 19g \
--num-executors 10 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$8/mergeBenefits.json $7/mergelayer/benetier_view benetier_view


echo "*****Submitting job 7 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.benefits.UAHCirrusBenefits \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode cluster \
--driver-memory 6g \
--executor-memory 19g \
--num-executors 10 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$8/mergeBenefits.json $7/mergelayer/benemaxref_view benemaxref_view

echo "*****Submitting job 8 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.benefits.UAHCirrusBenefits \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode cluster \
--driver-memory 6g \
--executor-memory 19g \
--num-executors 10 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$8/mergeBenefits.json $7/mergelayer/benemax_std benemax_std

echo "*****Submitting job 9 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.benefits.UAHCirrusBenefits \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode cluster \
--driver-memory 6g \
--executor-memory 19g \
--num-executors 10 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$8/mergeBenefits.json $7/mergelayer/benestoplossoop_std benestoplossoop_std

echo "*****Submitting job 10 to the cluster*****"
$3/spark-submit \
--class com.optum.uah.merge_layer.benefits.UAHCirrusBenefits \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode cluster \
--driver-memory 6g \
--executor-memory 19g \
--num-executors 10 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$8/mergeBenefits.json $7/mergelayer/accumdeductindivplanview_std accumdeductindivplanview_std


echo "*****Submitting job 11 to the cluster*****"
$3/spark-submit \
--class com.optum.uah.merge_layer.benefits.UAHCirrusBenefits \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode cluster \
--driver-memory 6g \
--executor-memory 19g \
--num-executors 10 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$8/mergeBenefits.json $7/mergelayer/benefitbundleplan_std benefitbundleplan_std

echo "*****Submitting job 12 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.benefits.UAHCirrusBenefits \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode cluster \
--driver-memory 6g \
--executor-memory 19g \
--num-executors 10 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$8/mergeMember.json $7/mergelayer/memgroupcontractoptview_std memgroupcontractoptview_std

echo "*****Submitting job 13 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.benefits.UAHCirrusBenefits \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode cluster \
--driver-memory 6g \
--executor-memory 19g \
--num-executors 10 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$8/mergeCustomer.json $7/mergelayer/memgroupcontractoptinsruleview_std memgroupcontractoptinsruleview_std


echo "*****Submitting job 14 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.benefits.UAHCirrusBenefits \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode cluster \
--driver-memory 6g \
--executor-memory 19g \
--num-executors 10 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$8/mergeMember.json $7/mergelayer/memgroupemployeecount_view memgroupemployeecount_view


echo "*****Submitting job 15 to the cluster*****"
$3/spark-submit \
--class com.optum.uah.merge_layer.benefits.UAHCirrusBenefits \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode cluster \
--driver-memory 6g \
--executor-memory 19g \
--num-executors 10 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$8/mergeBenefits.json $7/mergelayer/benefitbundleplanproduct_std benefitbundleplanproduct_std

echo "*****Submitting job 16 to the cluster*****"


$3/spark-submit \
--class com.optum.uah.merge_layer.benefits.UAHCirrusBenefits \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode cluster \
--driver-memory 6g \
--executor-memory 19g \
--num-executors 10 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$8/mergeBenefits.json $7/mergelayer/benecodeservicetypecode_view benecodeservicetypecode_view



echo "*****Submitting job 17 to the cluster*****"
$3/spark-submit \
--class com.optum.uah.merge_layer.benefits.UAHCirrusBenefits \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode cluster \
--driver-memory 6g \
--executor-memory 19g \
--num-executors 10 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$8/mergeBenefits.json $7/mergelayer/memgroupcontractplanyrbillrt_view memgroupcontractplanyrbillrt_view

echo "*****Submitting job 18 to the cluster*****"
$3/spark-submit \
--class com.optum.uah.merge_layer.benefits.UAHCirrusBenefits \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode cluster \
--driver-memory 6g \
--executor-memory 19g \
--num-executors 10 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$8/mergeBenefits.json $7/mergelayer/billingsched_view billingsched_view


echo "*****Submitting job 19 for carrierlobplanview_std to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.benefits.UAHCirrusBenefits \
--master yarn \
--queue $4 \
--deploy-mode cluster \
--properties-file $8/uah.conf \
--driver-memory 6g \
--executor-memory 19g \
--num-executors 4 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$8/mergeBenefits.json $7/mergelayer/carrierlobplanview_std carrierlobplanview_std
echo "Job 19 carrierlobplanview_std completed successfully"

echo "*****Submitting job 20 to the client*****"
$3/spark-submit \
--class com.optum.uah.merge_layer.benefits.UAHCirrusBenefits \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode client \
--driver-memory 6g \
--executor-memory 19g \
--num-executors 2 \
--executor-cores 5 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$8/mergeBenefits.json $7/mergelayer/memgroupcontractplanyear_view memgroupcontractplanyear_view

echo "*****Submitting job 21 to the client*****"
$3/spark-submit \
--class com.optum.uah.merge_layer.benefits.UAHCirrusBenefits \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode client \
--driver-memory 6g \
--executor-memory 19g \
--num-executors 2 \
--executor-cores 5 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$8/mergeBenefits.json $7/mergelayer/benefitbundleriderplan_std benefitbundleriderplan_std

echo "Job 20 carrierlobplanview_std completed successfully"
status=$?
if [[ !$status -eq 0 ]];then
        status=49
        exit 49
                
fi

echo "job Benifits completed successfully"

exit 0