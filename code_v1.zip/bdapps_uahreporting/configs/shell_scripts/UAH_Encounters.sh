#!/bin/bash

export HIVE_CONF_DIR=$1
export SPARK_CONF_DIR=$2

echo "*****Submitting job1 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.aggregate_layer.EncountersCustomer \
--master yarn \
--queue $4 \
--deploy-mode client \
--properties-file $8/uah.conf \
--driver-memory 12g \
--executor-memory 8g \
--num-executors 5 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$7/aggregate_layer/encounters_customer $8/encountersCustomer.json \$9/encounters_extract/customer

echo "Job1 completed successfully"

exit 0
