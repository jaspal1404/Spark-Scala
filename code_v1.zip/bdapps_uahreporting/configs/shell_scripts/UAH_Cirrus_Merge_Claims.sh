#!/bin/bash

export HIVE_CONF_DIR=$1
export SPARK_CONF_DIR=$2


echo "*****Submitting job1 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.claims.UAHCirClaims \
--master yarn \
--queue $4 \
--deploy-mode client \
--properties-file $8/uah.conf \
--driver-memory 6g \
--executor-memory 6g \
--num-executors 4 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
"$7/mergelayer/clabenefit_std" $8/mergeClaims.json "claclaimid,cbclaimlinenum" "run_id,uah_timestamp,cbchangedatetime"

echo "Job1 completed successfully"


echo "*****Submitting job2 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.claims.UAHCirClaims \
--master yarn \
--queue $4 \
--deploy-mode client \
--properties-file $8/uah.conf \
--driver-memory 6g \
--executor-memory 6g \
--num-executors 4 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
"$7/mergelayer/claimprovideraddress_std" $8/mergeClaims.json "cpclaimid,cpclaimlinenum" "run_id,uah_timestamp,cpachangedatetime"

echo "Job2 completed successfully"


echo "*****Submitting job3 to the cluster*****"


$3/spark-submit \
--class com.optum.uah.merge_layer.claims.UAHCirClaims \
--master yarn \
--queue $4 \
--deploy-mode client \
--properties-file $8/uah.conf \
--driver-memory 6g \
--executor-memory 6g \
--num-executors 4 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
"$7/mergelayer/claimcobadjustment_std" $8/mergeClaims.json "claimcobadjustmentclaimid,claimlinenum" "run_id,uah_timestamp,changedatetime,claimcobadjustmentid"

echo "Job3 completed successfully"


echo "*****Submitting job4 to the cluster*****"


$3/spark-submit \
--class com.optum.uah.merge_layer.history.UAHCirHistory \
--master yarn \
--queue $4 \
--deploy-mode client \
--properties-file $8/uah.conf \
--driver-memory 6g \
--executor-memory 6g \
--num-executors 4 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
"$7/mergelayer/claimdiagnosisview_std" $8/mergeClaims.json "run_id,uah_timestamp,claimdiagnosischangedatetime"

echo "Job4 completed successfully"


echo "*****Submitting job5 to the cluster*****"


$3/spark-submit \
--class com.optum.uah.merge_layer.claims.UAHCirClaims \
--master yarn \
--queue $4 \
--deploy-mode client \
--properties-file $8/uah.conf \
--driver-memory 6g \
--executor-memory 6g \
--num-executors 4 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
"$7/mergelayer/claimheader_std" $8/mergeClaims.json "chclaimid" "run_id,uah_timestamp,chchangedatetime"

echo "Job5 completed successfully"


echo "*****Submitting job6 to the cluster*****"


$3/spark-submit \
--class com.optum.uah.merge_layer.claims.UAHCirClaims \
--master yarn \
--queue $4 \
--deploy-mode client \
--properties-file $8/uah.conf \
--driver-memory 6g \
--executor-memory 6g \
--num-executors 4 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
"$7/mergelayer/claimlineadjudication_std" $8/mergeClaims.json "claimid,claimlinenum" "run_id,uah_timestamp,clachangedatetime"

echo "Job6 completed successfully"


echo "*****Submitting job7 to the cluster*****"


$3/spark-submit \
--class com.optum.uah.merge_layer.claims.UAHCirClaims \
--master yarn \
--queue $4 \
--deploy-mode client \
--properties-file $8/uah.conf \
--driver-memory 6g \
--executor-memory 6g \
--num-executors 4 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
"$7/mergelayer/claimlineprof_std" $8/mergeClaims.json "claimid,claimlinenum" "run_id,uah_timestamp"

echo "Job7 completed successfully"


echo "*****Submitting job8 to the cluster*****"


$3/spark-submit \
--class com.optum.uah.merge_layer.claims.UAHCirClaims \
--master yarn \
--queue $4 \
--deploy-mode client \
--properties-file $8/uah.conf \
--driver-memory 6g \
--executor-memory 6g \
--num-executors 4 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
"$7/mergelayer/claimlineinst_std" $8/mergeClaims.json "claimid,claimlinenum" "run_id,uah_timestamp"

echo "Job8 completed successfully"


echo "*****Submitting job9 to the cluster*****"


$3/spark-submit \
--class com.optum.uah.merge_layer.claims.UAHCirClaims \
--master yarn \
--queue $4 \
--deploy-mode client \
--properties-file $8/uah.conf \
--driver-memory 6g \
--executor-memory 6g \
--num-executors 4 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
"$7/mergelayer/claimnote_std" $8/mergeClaims.json "claimid,claimlinenum" "run_id,uah_timestamp,changedatetime,claimnoteid"

echo "Job9 completed successfully"


echo "*****Submitting job10 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.claims.UAHCirClaims \
--master yarn \
--queue $4 \
--deploy-mode client \
--properties-file $8/uah.conf \
--driver-memory 6g \
--executor-memory 6g \
--num-executors 4 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
"$7/mergelayer/claimpricinginputdetailview_std" $8/mergeClaims.json "cpihclaimid" "run_id,uah_timestamp,cpihchangedatetime"

echo "Job10 completed successfully"


echo "*****Submitting job11 to the cluster*****"


$3/spark-submit \
--class com.optum.uah.merge_layer.claims.UAHCirClaims \
--master yarn \
--queue $4 \
--deploy-mode client \
--properties-file $8/uah.conf \
--driver-memory 6g \
--executor-memory 6g \
--num-executors 4 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
"$7/mergelayer/umauthview_std" $8/mergeClaims.json "memberid" "run_id,uah_timestamp,uachangedatetime"

echo "Job11 completed successfully"

echo "*****Submitting job12 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.history.UAHCirHistory \
--master yarn \
--queue $4 \
--deploy-mode client \
--properties-file $8/uah.conf \
--driver-memory 6g \
--executor-memory 4g \
--num-executors 5 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
"$7/mergelayer/cladeny_std" $8/mergeClaims.json "run_id,uah_timestamp,cdchangedatetime"

echo "Job12 completed successfully"


echo "*****Submitting job13 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.claims.UAHCirClaims \
--master yarn \
--queue $4 \
--deploy-mode client \
--properties-file $8/uah.conf \
--driver-memory 6g \
--executor-memory 4g \
--num-executors 5 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
"$7/mergelayer/dofrsched_view" $8/mergeClaims.json

echo "Job 13 completed successfully"


echo "*****Submitting job 14 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.claims.UAHCirClaims \
--master yarn \
--queue $4 \
--deploy-mode client \
--properties-file $8/uah.conf \
--driver-memory 6g \
--executor-memory 4g \
--num-executors 5 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
"$7/mergelayer/cladofr_view" $8/mergeClaims.json "claimLineadjudicationid" "run_id,uah_timestamp,changedatetime"

echo "Job 14 completed successfully"

echo "*****Submitting job 15 to the cluster*****"
$3/spark-submit \
--class com.optum.uah.merge_layer.claims.UAHCirClaims \
--master yarn \
--queue $4 \
--deploy-mode client \
--properties-file $8/uah.conf \
--driver-memory 6g \
--executor-memory 4g \
--num-executors 5 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
"$7/mergelayer/clabenefitprovider_std" $8/mergeClaims.json
echo "Job 15 completed successfully"


echo "*****Submitting job 16 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.claims.UAHCirClaims \
--master yarn \
--queue $4 \
--deploy-mode client \
--properties-file $8/uah.conf \
--driver-memory 6g \
--executor-memory 4g \
--num-executors 5 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master-Claims.jar \
"$7/mergelayer/aptransactiondetailview_std" $8/mergeClaims.json "ataptransactionid,claimid" "run_id,uah_timestamp,atdchangedatetime"
echo "Job 18 completed successfully"

echo "*****Submitting job 17 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.claims.UAHCirClaims \
--master yarn \
--queue $4 \
--deploy-mode client \
--properties-file $8/uah.conf \
--driver-memory 6g \
--executor-memory 4g \
--num-executors 5 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master-Claims.jar \
"$7/mergelayer/apgenerationresponseview_std" $8/mergeClaims.json "aptransactionid" "run_id,uah_timestamp,apgrchangedatetime"

echo "Job 17 completed successfully"
echo "*****Submitting job 18 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.claims.UAHCirClaims \
--master yarn \
--queue $4 \
--deploy-mode client \
--properties-file $8/uah.conf \
--driver-memory 6g \
--executor-memory 4g \
--num-executors 5 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master-Claims.jar \
"$7/mergelayer/claimevent_std" $8/mergeClaims.json "claimid" "run_id,uah_timestamp,changedatetime"

echo "Job 18 completed successfully"
echo "*****Submitting job 19 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.claims.UAHCirClaims \
--master yarn \
--queue $4 \
--deploy-mode client \
--properties-file $8/uah.conf \
--driver-memory 6g \
--executor-memory 4g \
--num-executors 5 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master-Claims.jar \
"$7/mergelayer/aptransactionattribsetglstring_view" $8/mergeClaims.json "aptransactiondetailid" "run_id,uah_timestamp,changedatetime"

echo "Job 19 completed successfully"

exit 0