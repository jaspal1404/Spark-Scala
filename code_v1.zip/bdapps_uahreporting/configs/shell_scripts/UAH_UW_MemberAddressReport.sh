#!/bin/bash
export HIVE_CONF_DIR=$1
export SPARK_CONF_DIR=$2

rm -r /mapr$7/aggregate_layer/uwr/MemberAddressReport

echo "*****Submitting job to the cluster *****"

echo"$3/spark-submit \
--class com.optum.uah.aggregate_layer.MemberAddressReport \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode client \
--driver-memory 6g \
--executor-memory 4g \
--num-executors 2 \
--executor-cores 4 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$7/aggregate_layer/uwr/MemberAddressReport memberaddressreport $8/uwMemberAddressReport.json"

echo ""

$3/spark-submit \
--class com.optum.uah.aggregate_layer.MemberAddressReport \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode client \
--driver-memory 6g \
--executor-memory 4g \
--num-executors 2 \
--executor-cores 4 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$7/aggregate_layer/uwr/MemberAddressReport memberaddressreport $8/uwMemberAddressReport.json

status=$?
if [[ !$status -eq 0 ]];then
        status=49
        exit 49

fi

echo "job completed successfully"