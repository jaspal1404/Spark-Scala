#!/bin/bash

export HIVE_CONF_DIR=$1
export SPARK_CONF_DIR=$2

echo "*****Submitting job to the cluster*****"

$3/spark-submit \
--class com.optum.uah.aggregate_layer.HceMemberEligibility \
--master yarn \
--queue $4 \
--properties-file $8/uah.conf \
--deploy-mode client \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar hce_member_eligibility $8/hceMember.json $7/aggregate_layer/hce/memberElig "uah_memgroupid,uah_memberid,benplaneffdate,benplanexpdate" "run_id,uah_timestamp,changedatetime"


echo "Job completed successfully"


exit 0