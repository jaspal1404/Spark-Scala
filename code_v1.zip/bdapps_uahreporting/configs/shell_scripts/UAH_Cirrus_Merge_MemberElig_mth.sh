export HIVE_CONF_DIR=$1
export SPARK_CONF_DIR=$2

#rm /mapr/datalake/optum/optuminsight/d_uah/dev/d_hdfs/mergelayer/memberbenefitcovlevelcode_std/source_cd=CRS/*
#rm /mapr/datalake/optum/optuminsight/t_uah/tst/t_hdfs/mergelayer/memberbenefitcovlevelcode_std/source_cd=CRS/*

$3/spark-submit \
--class com.optum.uah.merge_layer.membereligibility.UahCirrusMemberEligibility \
--master yarn \
--queue $4 \
--properties-file $8/uah.conf \
--deploy-mode client \
--driver-memory 6g \
--executor-memory 4g \
--num-executors 4 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
"$7/mergelayer_mth/memberbenefit_std" $8/mergeMember.json "monthly"

echo "Job1 completed successfully"



#echo "*****Submitting job2 to the cluster*****"



echo "*****Submitting job2 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.membereligibility.UahCirrusMemberEligibility \
--master yarn \
--queue $4 \
--properties-file $8/uah.conf \
--deploy-mode client \
--driver-memory 6g \
--executor-memory 4g \
--num-executors 4 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
"$7/mergelayer_mth/membercobverification_std" $8/mergeMember.json "monthly"

echo "Job2 completed successfully"


echo "*****Submitting job 3 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.membereligibility.UahCirrusMemberEligibility \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode client \
--driver-memory 6g \
--executor-memory 4g \
--num-executors 4 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
"$7/mergelayer_mth/memberbenefitcovlevelcode_std" $8/mergeMember.json "monthly"

echo "Job3 completed successfully"

status=$?
if [[ !$status -eq 0 ]];then
        status=49
        exit 49
fi
echo "Job completed successfully"
