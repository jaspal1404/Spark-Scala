export HIVE_CONF_DIR=$1
export SPARK_CONF_DIR=$2

echo "*****Submitting job1 to the client*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.broker.BrokerCroswalk \
--master yarn \
--queue $4 \
--deploy-mode client \
--properties-file $8/uah.conf \
--driver-memory 6g \
--executor-memory 4g \
--num-executors 2 \
--executor-cores 4 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$7/mergelayer $8/mergeBroker.json

status=$?
if [[ !$status -eq 0 ]];then
        status=49
        exit 49

fi

echo "job completed successfully"
