#!/bin/bash

export HIVE_CONF_DIR=$1
export SPARK_CONF_DIR=$2

echo "*****Submitting job to the cluster*****"

$3/spark-submit \
--class com.optum.uah.aggregate_layer.HCEOptumRx \
--master yarn \
--queue $4 \
--properties-file $8/uah.conf \
--deploy-mode client \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar hce_optumRx $8/hceOptumRx.json $7/aggregate_layer/hce/optumrx


echo "Job completed successfully"


exit 0