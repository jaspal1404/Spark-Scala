#!/bin/bash
export HIVE_CONF_DIR=$1
export SPARK_CONF_DIR=$2

echo "*****Submitting job to the cluster*****"

$3/spark-submit --class com.optum.uah.merge_layer.member.UAHCirrusMember  --master yarn --queue $4 --properties-file $8/uah.conf  --deploy-mode client \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$7/mergelayer/memberdemographic_std $8/mergeMember.json

echo "Job completed successfully"

echo "*****Submitting job 2 to the cluster*****"
$3/spark-submit \
--class com.optum.uah.merge_layer.member.UAHCirrusMember \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode client \
--driver-memory 6g \
--executor-memory 4g \
--num-executors 10 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
"$7/mergelayer/subsaffiliation_std" $8/mergeMember.json
echo "Job 2 completed successfully"

exit 0
