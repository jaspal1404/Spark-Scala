#!/bin/bash
export HIVE_CONF_DIR=$1
export SPARK_CONF_DIR=$2



echo "*****Submitting job1 to the cluster*****"

$3/spark-submit --class com.optum.uah.merge_layer.membereligibility.UahGroupContractLookUp  \
--master yarn \
--queue $4 \
--properties-file $8/uah.conf  \
--deploy-mode client \
--conf spark.serializer='org.apache.spark.serializer.KryoSerializer'  \
  $6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
  $7/mergelayer/groupcontract_lookup_std \
  $8/mergeMember.json 


echo "Job1 completed successfully"

echo "*****Submitting job2 to the cluster*****"

$3/spark-submit --class com.optum.uah.function_library.ParquetToPipeDelimited \
--master yarn \
--deploy-mode cluster \
--queue $4 \
--properties-file $8/uah.conf \
--driver-memory 6g --executor-memory 8g --num-executors 4 --executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$7/mergelayer/groupcontract_lookup_std/source_cd=PUL $9/hce_extracts GroupContract_Crosswalk

echo "Job2 completed successfully"

exit 0
