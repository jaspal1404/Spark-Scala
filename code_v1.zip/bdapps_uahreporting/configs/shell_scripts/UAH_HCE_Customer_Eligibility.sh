#!/bin/bash
export HIVE_CONF_DIR=$1
export SPARK_CONF_DIR=$2



echo "*****Submitting job to the cluster*****"


$3/spark-submit \
--class com.optum.uah.aggregate_layer.HCE200CustomerEligibilty \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode client \
--driver-memory 6g \
--executor-memory 4g \
--num-executors 10 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$8/hceCustomerEligibility.json $7/aggregate_layer/hce/customer_eligibility hce_customer_eligibility

 #--driver-memory 6g --executor-memory 4g --num-executors 20



status=$?
if [[ !$status -eq 0 ]];then
        status=49
        exit 49
		
fi

echo "job completed successfully"
