export HIVE_CONF_DIR=$1
export SPARK_CONF_DIR=$2

echo "*****Submitting job1 to the cluster*****"

echo "$3/spark-submit \
--class com.optum.uah.aggregate_layer.HCE200Provider \
--master yarn \
--queue $4 \
--deploy-mode client \
--properties-file $8/uah.conf \
--driver-memory 6g \
--executor-memory 19g \
--num-executors 29 \
--executor-cores 5 \
--conf spark.sql.shuffle.partitions=800 \
--conf spark.default.parallelism=800 \
$6/UAH_REPORT-4.1.0-SNAPSHOT-Master.jar \
$7/aggregate_layer/hce/provider provider $8/hceProvider.json"

echo ""

$3/spark-submit \
--class com.optum.uah.aggregate_layer.HCE200Provider \
--master yarn \
--queue $4 \
--deploy-mode client \
--properties-file $8/uah.conf \
--driver-memory 6g \
--executor-memory 19g \
--num-executors 5 \
--executor-cores 5 \
--conf spark.sql.shuffle.partitions=1000 \
--conf spark.default.parallelism=1000 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$7/aggregate_layer/hce/provider $8/hceProvider.json
echo "Job 1 completed successfully"
status=$?
if [[ !$status -eq 0 ]];then
        status=49
        exit 49
		
fi
exit 0
