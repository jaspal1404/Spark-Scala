#!/bin/bash

export HIVE_CONF_DIR=$1
export SPARK_CONF_DIR=$2

echo "*****Submitting job1 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.aggregate_layer.HCEMedicalClaims \
--name hceMemberClaims \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode client \
--driver-memory 12g \
--executor-memory 8g \
--num-executors 10 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$7/aggregate_layer/hce_medical_claims $8/hceMedicalClaims.json $9/hce_extracts/claims

echo "Job1 completed successfully for HCE Claims aggregate layer"



