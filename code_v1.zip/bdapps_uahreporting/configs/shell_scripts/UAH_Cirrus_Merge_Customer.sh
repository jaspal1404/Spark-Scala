#!/bin/bash

export HIVE_CONF_DIR=$1
export SPARK_CONF_DIR=$2

echo "*****Submitting job 1 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.customer.UAHCirCustomer \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode client \
--driver-memory 6g \
--executor-memory 6g \
--num-executors 4 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
"$7/mergelayer/memgroupcontractplanoptextview_std" $8/mergeCustomer.json

echo "Job 1 completed successfully"


echo "*****Submitting job2 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.customer.UAHCirCustomer \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode client \
--driver-memory 6g \
--executor-memory 6g \
--num-executors 4 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
"$7/mergelayer/memgroupcontractview_std" $8/mergeCustomer.json

echo "Job 2 completed successfully"


echo "*****Submitting job 3 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.customer.UAHCirCustomer \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode client \
--driver-memory 6g \
--executor-memory 6g \
--num-executors 4 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
"$7/mergelayer/memgroupid_std" $8/mergeCustomer.json

echo "Job 3 completed successfully"


echo "*****Submitting job 4 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.customer.UAHCirCustomer \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode client \
--driver-memory 6g \
--executor-memory 6g \
--num-executors 4 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
"$7/mergelayer/memgroupaddress_std" $8/mergeCustomer.json

echo "Job 4 completed successfully"


echo "*****Submitting job 6 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.customer.UAHCirCustomer \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode client \
--driver-memory 6g \
--executor-memory 6g \
--num-executors 4 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
"$7/mergelayer/memgroupreportingcode_view" $8/mergeCustomer.json

echo "Job 6 completed successfully"


echo "*****Submitting job 7 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.customer.UAHCirCustomer \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode client \
--driver-memory 6g \
--executor-memory 6g \
--num-executors 4 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
"$7/mergelayer/reference_view" $8/mergeCustomer.json

echo "Job 7 completed successfully"


echo "*****Submitting job 8 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.customer.UAHCirCustomer \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode client \
--driver-memory 6g \
--executor-memory 6g \
--num-executors 4 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
"$7/mergelayer/memgroupinsuringrule_view" $8/mergeCustomer.json

echo "Job 8 completed successfully"


echo "*****Submitting job 9 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.customer.UAHCirCustomer \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode client \
--driver-memory 6g \
--executor-memory 4g \
--num-executors 2 \
--executor-cores 4 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
"$7/mergelayer/memgroupcontractplanoptionvw_std" $8/mergeCustomer.json

echo "Job 9 completed successfully"

echo "*****Submitting job 10 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.customer.UAHCirCustomer \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode client \
--driver-memory 6g \
--executor-memory 4g \
--num-executors 2 \
--executor-cores 4 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
"$7/mergelayer/memgroupcontractplanoptionview_std" $8/mergeCustomer.json

echo "Job 10 completed successfully"

echo "*****Submitting job 11 to the client*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.customer.UAHCirCustomer \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode client \
--driver-memory 6g \
--executor-memory 4g \
--num-executors 2 \
--executor-cores 4 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
"$7/mergelayer/memgroupcontractplanattrsetvw_std" $8/mergeCustomer.json

echo "Job 11 completed successfully"


echo "*****Submitting job 12 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.customer.UAHCirCustomer \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode client \
--driver-memory 6g \
--executor-memory 6g \
--num-executors 4 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
"$7/mergelayer/memgroupsettings_std" $8/mergeCustomer.json

echo "Job 12 completed successfully"


echo "*****Submitting job 13 to the cluster*****"

$3/spark-submit \
--class com.optum.uah.merge_layer.customer.UAHCirCustomer \
--master yarn \
--properties-file $8/uah.conf \
--queue $4 \
--deploy-mode client \
--driver-memory 6g \
--executor-memory 6g \
--num-executors 4 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
"$7/mergelayer/memgroupcontactrole_std" $8/mergeCustomer.json

echo "Job 13 completed successfully"

status=$?
if [[ !$status -eq 0 ]];then
        status=49
        exit 49
                
fi

exit 0
