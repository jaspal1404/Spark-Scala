#!/bin/bash

export HIVE_CONF_DIR=$1
export SPARK_CONF_DIR=$2

echo "*****Submitting job to the cluster*****"

$3/spark-submit \
--class com.optum.uah.aggregate_layer.ACTStepWise \
--properties-file $8/uah.conf \
--master yarn \
--queue $4 \
--deploy-mode client \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar $8/actStepWise.json $7/aggregate_layer/act/stepwise "customerRate" "uah_memberid" "run_id,uah_timestamp"

echo "Job completed successfully"

exit 0