#!/bin/bash
export HIVE_CONF_DIR=$1
export SPARK_CONF_DIR=$2

echo "*****Submitting job to the cluster*****"

$3/spark-submit --class com.optum.uah.merge_layer.optumrx.UahOptumRx \
--master yarn \
--queue $4 \
--executor-memory 8g \
--driver-memory 5g \
--num-executors 4 \
--executor-cores 5 \
--properties-file $8/uah.conf \
--deploy-mode client \
--conf spark.serializer='org.apache.spark.serializer.KryoSerializer'  \
  $6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
  $7/mergelayer/clmp02extg_rcex1p \
  $8/mergeOptumRx.json "optumRx"

echo "Job completed successfully"

exit 0