export HIVE_CONF_DIR=$1
export SPARK_CONF_DIR=$2

echo "*****Submitting job1 to the cluster*****"

echo "$3/spark-submit \
--class com.optum.uah.aggregate_layer.Hce200Broker \
--master yarn \
--queue $4 \
--deploy-mode client \
--properties-file $8/uah.conf \
--driver-memory 6g \
--executor-memory 4g \
--num-executors 10 \
--executor-cores 2 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$7/aggregate_layer/hce $8/hceBroker.json"

$3/spark-submit \
--class com.optum.uah.aggregate_layer.Hce200Broker \
--master yarn \
--queue $4 \
--deploy-mode client \
--properties-file $8/uah.conf \
--driver-memory 6g \
--executor-memory 4g \
--num-executors 5 \
--executor-cores 3 \
$6/UAH_REPORT-1.1.0-SNAPSHOT-Master.jar \
$7/aggregate_layer/hce $8/hceBroker.json
# chmod -R 770 $7/mergelayer/produceraddressview_std

echo "Job 1 completed successfully"
status=$?
if [[ !$status -eq 0 ]];then
        status=49
        exit 49
		
fi

exit 0
