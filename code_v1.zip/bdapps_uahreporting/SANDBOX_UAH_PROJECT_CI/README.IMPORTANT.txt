during build and deployment execution, jenkins will use branch version of these files, which corresponds to the same branch of talend source code
please make sure any changes made in trunk get merged into the appropriate branch, if necessary.

current branch is "UAH_UAH-BR100"

the general idea is each branch will have specific build list in case there is specific jobs that exist only in specific branch.
by splitting the master build list in the branch, it will simplify maintenance for continous integration