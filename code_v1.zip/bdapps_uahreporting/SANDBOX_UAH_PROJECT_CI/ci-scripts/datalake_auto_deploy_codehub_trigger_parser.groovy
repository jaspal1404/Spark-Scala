/**
 * Created by Jesen on 04/20/2016
 */
//@Grab('org.apache.ivy:ivy:2.4.0')
//@Grab('com.github.groovy-wslite:groovy-wslite:1.1.0')
//import wslite.rest.*
//import wslite.http.auth.*
//import wslite.util.*
@Grab('org.apache.commons:commons-csv:1.2')
import org.apache.commons.csv.*;
import static org.apache.commons.csv.CSVFormat.*

import java.nio.file.*;
import java.nio.charset.*;
import java.nio.*;

import groovy.transform.Sortable;
import groovy.transform.ToString;

import groovy.json.*
import groovy.xml.*
import groovy.util.*

import java.util.Map;
import java.util.Map.Entry;

import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

def env                 = System.getenv()
buildListPath           = env['BUILD_LIST_PATH']
masterBuildList         = env['MASTER_BUILD_LIST_FILE']
buildUrl                = env['BUILD_URL']
branchNameRegexPattern  = env["BRANCH_NAME_REGEX_PATTERN"]

def xpathString = "api/xml?wrapper=changeSet&xpath=//changeSet//item&exclude=//changeSet//item//*[((self::commitId)or(self::timestamp)or(self::date)or(self::path)or(self::revision)or(self::user))]"

def changeSetText = (buildUrl + xpathString).toURL().text

def changeSetXML = new XmlSlurper().parseText(changeSetText)

//assert changeSetXML instanceof groovy.util.slurpersupport.GPathResult 

//println XmlUtil.serialize(changeSetXML)

List derivedJobsList = new ArrayList()
Map<String, Set> buildListPerBranch = new TreeMap<String, Set>()

changeSetXML.item.each{ eachItem ->
   msg = eachItem.msg.text()
   //println "msg: ${msg}"
   affectedPath = eachItem.affectedPath.text()
   //println "affectedPath: ${affectedPath}"
   userURL = eachItem.author.absoluteUrl.text()
   //println "userURL: ${userURL}"
   
   userURLapi = userURL + "/api/xml?wrapper=userEmail&xpath=//user//property//address"
   //println "userURLapi: ${userURLapi}"
   userEmail = userURLapi.toURL().text
   //println "userEmail: ${userEmail}"
   def userEmailXml = new XmlSlurper().parseText(userEmail)
   userEmailAddress = userEmailXml.address.text()
   println "userEmailAddress: ${userEmailAddress}"
   
   //println "msg: $msg"
   //println "affectedPath: $affectedPath"
   try{
      indexPath = affectedPath.indexOf(FileSystems.getDefault().getSeparator().toString())
      branch = affectedPath.substring(0, indexPath)
   }
   catch(StringIndexOutOfBoundsException sioe){
      branch = affectedPath
   }
   println "branch: $branch"
   
   
   if(branch.matches(branchNameRegexPattern.toString())){
      if(!Files.exists(Paths.get(buildListPath))){
         Files.createDirectory(Paths.get(buildListPath))
      }
      FileWriter fileWriter = null;
      try{
         fileWriter = new FileWriter(buildListPath + FileSystems.getDefault().getSeparator().toString() + branch, true);
         fileWriter.write("BRANCH_NAME=" + branch);
         fileWriter.write("USER_EMAIL=" + userEmailAddress);
         println  "${branch} file was created successfully !!!"
      }
      catch(all){
         println all
      }
      finally{
         try{
            fileWriter.flush();
            fileWriter.close();
         }
         catch(IOException ioe){
            println ioe
         }
      }
   }
}