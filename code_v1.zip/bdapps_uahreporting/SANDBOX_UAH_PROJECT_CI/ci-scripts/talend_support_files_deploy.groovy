/**
 * Created by Jesen on 04/20/2016
 */

@Grab('org.apache.commons:commons-csv:1.2')
import org.apache.commons.csv.CSVParser
import static org.apache.commons.csv.CSVFormat.*

import java.nio.file.*
import java.nio.charset.*
import java.util.*;

import groovy.transform.Sortable;
import groovy.transform.ToString;
import groovy.time.*;

import groovyx.gpars.*;

def env = System.getenv()

//////////////////////////////////////////////////////////////////////////////
//these properties should be contained in the common.server.properties file in svn
project                          = env['PROJECT_NAME']
deployEnv                        = env['DEPLOY_ENVIRONMENT']

cmdLineHost                      = env['CMDLINE_HOST']
cmdLinePort                      = env['CMDLINE_PORT']

nexusUrl                         = env['ARTIFACT_REPO_URL']
nexusSnapshotRepository          = env['SNAPSHOT_ARTIFACT_REPO_NAME']
nexusReleaseRepository           = env['RELEASE_ARTIFACT_REPO_NAME']

landingDir                       = env["ARTIFACT_LANDING_DIR"]
branchNameRegexPattern           = env["BRANCH_NAME_REGEX_PATTERN"]
branchNameUnusedPattern          = env["BRANCH_NAME_UNUSED_PATTERN"]
//////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////
//these properties should be contained in the env.server.properties file in svn
tacUrl                           = env['TAC_URL']
jobExecServer                    = env['JOB_EXEC_SERVER']
defaultTaskNamePrefix            = env['TASK_NAME_PREFIX']
defaultTaskNamePostfix           = env['TASK_NAME_POSTFIX']
defaultEnvContext                = env['DEFAULT_ENVIRONMENT_CONTEXT']
//////////////////////////////////////////////////////////////////////////////

deployEnv                        = env['DEPLOY_ENVIRONMENT']

//////////////////////////////////////////////////////////////////////
//these properties should be part of jenkins credential injector
sshUser                          = env['SSH_USER']
sshPassword                      = env[sshUser]

tacUser                          = env['TAC_USER']
tacPassword                      = env['TAC_PASSWORD']
//////////////////////////////////////////////////////////////////////////

debug                            = "true".equalsIgnoreCase(env['CI_DEBUG'])

buildReportFile                  = env['BUILD_REPORT_FILE']

notificationEmailFile            = env['NOTIFICATION_EMAIL_FILE']

nonTalendDeployListOverride      = env['NON_TALEND_DEPLOY_LIST_OVERRIDE']

envPropFileName                  = env['ENVIRONMENT_PROPERTIES_FILE_NAME']

branchName                       = env['BRANCH_NAME']

tagsID                           = env['TAGS_ID']

gitCommit                        = env['GIT_COMMIT']

gitRepoURL                       = env['GIT_REPO_URL']

gitChangeNote                    = env['GIT_SUBJECT']

gitEmail                         = env['GIT_EMAIL']

gitUser                          = env['GIT_NAME']

gitBranchName                    = env['GIT_BRANCH_NAME']

svnRevision                      = env['SVN_REVISION']

svnRepoURL                       = env['SVN_URL']

svnBranchName                    = env['BRANCH_NAME']

jenkinsJobStartTime              = env['JENKINS_JOB_START_TIME']


@Sortable(includes = ['commitRevision'])
@ToString
public class SourceRepoInfo {
   String commitRevision, repoURL, changeNote, committerEmail, comitter, branchName;
   
   public SourceRepoInfo(String commitRevision, String repoURL, String changeNote, String committerEmail, String comitter, String branchName){
      this.commitRevision = commitRevision;
      this.repoURL = repoURL;
      this.changeNote = changeNote;
      this.committerEmail = committerEmail;
      this.comitter = comitter;
      this.branchName = branchName;
   }
}

def sourceRepoInfo = null
if(gitCommit != null){
   sourceRepoInfo = new SourceRepoInfo(gitCommit, gitRepoURL, gitChangeNote, gitEmail, gitUser, gitBranchName)
}
else if(svnRevision != null){
   sourceRepoInfo = new SourceRepoInfo(svnRevision, svnRepoURL, null, null, null, svnBranchName)
}

def buildReport = null
if(buildReportFile != null){
   buildReport = new File(buildReportFile)
}
else{
   buildReport = new File("BuildReport.txt")
}

def timeStart
if(jenkinsJobStartTime != null){
   timeStart = Date.parseToStringDate(jenkinsJobStartTime) 
}
else{
   timeStart = new Date()
}
def timeStop

def notificationsProp = null
if(notificationEmailFile != null){
   notificationsProp = new File(notificationEmailFile)
}
else{
   notificationsProp = new File("NOTIFICATIONS.properties")
}
notificationsProp.append("#" + System.getProperty("line.separator"))

appendBuildReport(buildReport, "----------------------------------------------------")
appendBuildReport(buildReport, "Report for build tag: " + env["BUILD_TAG"])
appendBuildReport(buildReport, "Jenkins URL: " + env["BUILD_URL"])

def exec_server_host = [] //this execution server host will need to be derived from TAC metaservlet call 'listServer'

def ms_request = new groovy.json.JsonBuilder()
def ms_response = null
def repoSourcePath = null

//required environment variable, stop if not defined
if(deployEnv == null || "".equalsIgnoreCase(deployEnv.trim())){
   println "DEPLOY_ENVIRONMENT need to be defined"
   System.exit(1)
}

println "DEPLOY_ENVIRONMENT : $deployEnv"

if(branchName != null && !"".equalsIgnoreCase(branchName.trim())){
   repoSourcePath = branchName
}
else if(tagsID != null && !"".equalsIgnoreCase(tagsID.trim())){
   repoSourcePath = tagsID
}
else{
  println "either BRANCH_NAME or TAGS_ID is required environment parameter"
  System.exit(1)
}

//----------------------------
//---------- Step 0 ----------
//----------------------------
println "----------------------------------------------------"
println "-- Step 0: Retrieve the hostname from pre-defined TAC server properties"
println "----------------------------------------------------"

//safety check if env['JOB_EXEC_SERVER'] is a virtual server type
ms_request (
   actionName  : 'listVirtualServers',
   authUser    : tacUser,
   authPass    : tacPassword
)
ms_response = metaServletCall(tacUrl, ms_request)

def exec_server_list = []
def virtual_server = false
for (int i = 0; i < ms_response.result.size(); i++) {
   
   label = ms_response.result[i].label
   
   if(debug){
      println "ms_response.result[i].label : $label"
      println "jobExecServer : $jobExecServer"
   }
   
   def indivExecServer = jobExecServer.split(",")
   for(String each : indivExecServer){
      if(label.equalsIgnoreCase(each.trim())){
         virtual_server = true
         ms_response.result[i].servers.each {
            exec_server_list << it.serverLabel.toString()
         }
      }
   }
}

println "exec_server_list : $exec_server_list"


ms_request (
   actionName  : 'listServer',
   authUser    : tacUser,
   authPass    : tacPassword
)
ms_response = metaServletCall(tacUrl, ms_request)

/*
metaservlet command for action listServer will return json object in this format
{"executionTime":{"millis":0,"seconds":0},
 "result":[{"active":boolean value,
            "description":"description string",
            "fileTransferPort":numeric port value,
            "host":"hostname string (this is what i need to get from this command)",
            "id":id_value,
            "label":"label string (this is what was mapped in the environment input value JOB_EXEC_SERVER)",
            "monitoringPort":numeric port value,
            "port":numeric port value,
            "timeOutUnknownState":numeric seconds value,
            "timeZone":"CST6CDT",
            "useSSL": boolean value},
           {"active":boolean value,
            "description":"description string",
            "fileTransferPort":numeric port value,
            "host":"hostname string (this is what i need to get from this comman)",
            "id":id_value,
            "label":"label string (this is what was mapped in the environment input value JOB_EXEC_SERVER)",
            "monitoringPort":numeric port value,
            "port":numeric port value,
            "timeOutUnknownState":numeric seconds value,
            "timeZone":"CST6CDT",
            "useSSL": boolean value}],
 "returnCode":0}
 
which translate of object in this format

 ms_response.executionTime
 ms_response.result[]
 ms_response.result[].active
 ms_response.result[].description
 ms_response.result[].fileTransferPort
 .
 .
 .
 ms_response.returnCode

from the result, search the execution server lable ms_response.result[].label == JOB_EXEC_SERVER
and retrieve the ms_response.result[].host
*/

for (int i = 0; i < ms_response.result.size(); i++) {
   
   label = ms_response.result[i].label
   host = ms_response.result[i].host
   if(debug){
      println "ms_response.result[i].label : $label"
      println "ms_response.result[i].host : $host"
      println "jobExecServer : $jobExecServer"
   }
   
   def indivExecServer = []
   if(!virtual_server){
      indivExecServer = jobExecServer.split(",")
   }
   
   if(exec_server_list != null && exec_server_list.size() > 0){
      
      exec_server_list.each {
         indivExecServer << it
      }
   }
   for(String each : indivExecServer){
      if(label.equalsIgnoreCase(each.trim())){
         exec_server_host << host.toString()
      }
   }
}

if(exec_server_host != null && exec_server_host.size() > 0){
   println "exec_server_host : $exec_server_host"
   appendBuildReport(buildReport, "Non Talend component will be deployed to host : '$exec_server_host'")
}
else{
   println "talend execution server host cannot be derived from environment property value: 'JOB_EXEC_SERVER'"
   appendBuildReport(buildReport, "talend execution server host cannot be derived from environment property value: 'JOB_EXEC_SERVER'")
   System.exit(1)
}

println "envPropFileName : $envPropFileName"
def envPropFile = prepEnvPropFile(envPropFileName, buildReport, deployEnv)

//----------------------------
//---------- Step 1 ----------
//----------------------------


enum DirCheckListHeader {
   DIR_OBJECT("DIR_OBJECT"),
   TARGET("TARGET"),
   TARGET_TYPE("TARGET_TYPE"),
   DEPLOY_FLAG("DEPLOY_FLAG")
    
   private String headerLabel;
    
   private DirCheckListHeader(String headerLabel){
      this.headerLabel = headerLabel;
   }
   public String headerLabelValue() {return headerLabel}
}

@Sortable(includes = ['name'])
@ToString
public class DirObjects {
   String name, target, targetType;
   String sshUser, sshPassword
   File propertiesFile;
   Boolean deployFlag;
   Properties properties;
   Boolean debug;
   AntBuilder antDir;
   File deploymentReportFile;
   List deployHosts;
   
   public DirObjects(String name, String target, String targetType, File propertiesFile, Boolean deployFlag,
      String sshUser, String sshPassword,
      List deployHosts){
      this.name = name;
      this.target = target;
      this.targetType = targetType;
      this.propertiesFile = propertiesFile;
      this.deployFlag = deployFlag;
      this.deployHosts = deployHosts;
      this.sshUser = sshUser;
      this.sshPassword = sshPassword;
      this.antDir = new AntBuilder();
      this.deploymentReportFile = new File(this.name);
      this.properties = new Properties();
      
      propertiesFile.withInputStream {
         properties.load(it)
      }
   }
   
   public void checkDirectoriesForServers(){
      if(this.deployFlag){
         for(Object each : this.deployHosts){
            String host = (String) each;
            this.checkDirectories(host)
            //if targetType is defined as "property_name" that means it's using shared mount for all the execution servers
            //no need to redeploy the same file because shared mount is used for all execution server
            if("property_name".equalsIgnoreCase(this.targetType)){
               break;
            }
         }
      }
      else{
         appendDeployTaskReport("DEPLOY_FLAG for : ${this.name} is set to ${this.deployFlag}, skipping directory check")
         //println "    >> DEPLOY_FLAG for : $it.name is set to $it.deployFlag, skipping file deployment"
      }
   }

   private void appendDeployTaskReport(reportString){
      this.deploymentReportFile.append(reportString)
      this.deploymentReportFile.append(System.getProperty("line.separator"))
   }

   private void checkDirectories(String deployHost){
      def suppresssystemout = this.debug ? false : true
      def dirTarget = null
      def dirPermission = "--mode=750"
      
      if(this.properties.dir_permission != null && this.properties.dir_permission.toString().trim().length() > 0){
         dirPermission = "--mode=${this.properties.dir_permission}"
      }
      
      if("property_name".equalsIgnoreCase(this.targetType)){
         dirTarget = this.properties."${this.target}"
         appendDeployTaskReport("property_name for ${this.name} is mapped to directory path ${dirTarget}")
      }
      else if("path_name".equalsIgnoreCase(this.targetType)){
         dirTarget = this.target
      }
      else{
         println "    >> targetType undefined. please define TARGET_TYPE in the deploy list for DIR_OBJECT : ${this.name}" 
         return
      }
      
      if(this.debug){
         println "    >> dirTarget : $dirTarget" 
         println "    >> dirPermission : $dirPermission"
         println "    >> name : ${this.name}"
         println "    >> target : ${this.target}"
         println "    >> targetType : ${this.targetType}"
         println "    >> propertiesFile : ${this.propertiesFile.toString()}"
      }
      
      try{
         this.antDir.sshexec(
            host              : deployHost,
            username          : this.sshUser,
            password          : this.sshPassword,
            trust             : "true",
            suppresssystemout : "$suppresssystemout",
            output            : "${this.name}",
            append            : "true",
            command           : "[ -d $dirTarget ] && echo 'Directory @${deployHost}:$dirTarget verified exists' || mkdir -v -p ${dirPermission} ${dirTarget}",
            verbose           : false)
            
            String report = deploymentReportFile.text
            if(this.debug){
               println "Directory Verification Report : ${report.trim()}"
            }
      }catch(all){
         println "Error creating directory ${dirTarget}. $all"
         appendDeployTaskReport("Error creating directory ${dirTarget}")
         appendDeployTaskReport("$all")
         return
      }
      
      /*
      try{
         this.antDir.sshexec(
            host              : deployHost,
            username          : this.sshUser,
            password          : this.sshPassword,
            trust             :"true",
            suppresssystemout :"$suppresssystemout",
            output:"report.txt",
            command:"[ -d $dirTarget ] && chmod $dirPermission $dirTarget || echo 'Directory $dirTarget not exists'",
            verbose:false)
            
            String report = new File("report.txt").text
            println "Directory Verification Report : ${report.trim()}"
      }catch(all){
         println "Error changing permission on directory $dirTarget to $dirPermission"
         return
      }
      */
   }
}
def dir_checklist_map = [:]
def DIR_LIST_CSV_FILE = env["DIR_LIST_CSV_FILE"]
//add safety check and skip directory checklist verification if not defined
if(DIR_LIST_CSV_FILE != null && !"".equalsIgnoreCase(DIR_LIST_CSV_FILE.trim())){
   println "----------------------------------------------------"
   println "-- Step 1: Check directories in $exec_server_host"
   println "----------------------------------------------------"

   def dir_list = []  // User overwrite of jobs to process
   println "    - DIR_LIST_CSV_FILE=$DIR_LIST_CSV_FILE"
   try{
      DIR_OBJECT = ""
      TARGET = ""
      TARGET_TYPE = ""
      DEPLOY_FLAG = true
      Paths.get(DIR_LIST_CSV_FILE).withReader { reader ->
         CSVParser csv = new CSVParser(reader, DEFAULT.withHeader())
         Map csvHeader = csv.getHeaderMap()
         for(eachRecord in csv.getRecords()){
            
            for(Map.Entry<String, Integer> eachHeader in csvHeader.entrySet()){
               if(eachHeader.getKey().equalsIgnoreCase(DirCheckListHeader.DIR_OBJECT.headerLabelValue())){
                  DIR_OBJECT = eachRecord."${eachHeader.getKey()}".trim()
               }
               if(eachHeader.getKey().equalsIgnoreCase(DirCheckListHeader.TARGET.headerLabelValue())){
                  TARGET = eachRecord."${eachHeader.getKey()}".trim()
               }
               if(eachHeader.getKey().equalsIgnoreCase(DirCheckListHeader.TARGET_TYPE.headerLabelValue())){
                  TARGET_TYPE = eachRecord."${eachHeader.getKey()}".trim()
               }
               if(eachHeader.getKey().equalsIgnoreCase(DirCheckListHeader.DEPLOY_FLAG.headerLabelValue())){
                  DEPLOY_FLAG = "true".equalsIgnoreCase(eachRecord."${eachHeader.getKey()}".trim())
               }
            }
            
            DirObjects dirCheck = new DirObjects(DIR_OBJECT,
                                                 TARGET,
                                                 TARGET_TYPE,
                                                 Paths.get(envPropFile).toFile(),
                                                 DEPLOY_FLAG,
                                                 sshUser, 
                                                 sshPassword,
                                                 exec_server_host)
            
            dir_checklist_map.put(DIR_OBJECT, dirCheck)
         }
      }
   }catch(all){
      println "Error reading CSV Deploy List: $all"
      System.exit(1)
   }
   appendBuildReport(buildReport, "Checking directories defined in : ${env['DIR_LIST_CSV_FILE']}")

   //PoolUtils default poolsize = Runtime.getRuntime().availableProcessors() + 1;
   //tweak the poolsize of GParsPool
   //try 2 * processor, adjust as necessary
   //dev note: 2 * processor have been tried and seems to have little or no significant gains in overall
   //runtime. in addition to that, there's some intermittent issue with that many ssh connection being opened
   //reverting back to default
   //int poolSize = Runtime.getRuntime().availableProcessors() * 2
   
   GParsPool.withPool() {
      dir_checklist_map.eachWithIndexParallel{ each , poolIndex->
         //println "pool index : $poolIndex task name : ${eachTask.key} "
         each.value.checkDirectoriesForServers()
      }
   }
   
   dir_checklist_map = dir_checklist_map.sort{ it.key }
   appendBuildReport(buildReport, "----------------------------------------------------")
   appendBuildReport(buildReport, "DIRECTORY CHECKLIST VERIFICATION REPORT DETAIL")

   dir_checklist_map.each{ each ->
      each.value.deploymentReportFile.eachLine { line ->
         buildReport.append(Calendar.getInstance(TimeZone.getTimeZone("America/Chicago")).format("yyyy.MM.dd 'at' HH:mm:ss z") + " | " + line)
         buildReport.append(System.getProperty("line.separator"))
      }
   }
   appendBuildReport(buildReport, "----------------------------------------------------")
   appendBuildReport(buildReport, "")
}
else{
   println "DIR_LIST_CSV_FILE value not defined, skipping directory checklist verification"
   appendBuildReport(buildReport, "DIR_LIST_CSV_FILE value not defined, skipping directory checklist verification")
}

//----------------------------
//---------- Step 2 ----------
//----------------------------
println "----------------------------------------------------"
println "-- Step 2: Deploy files to $exec_server_host"
println "----------------------------------------------------"

enum DeployObjectsListHeader {
   DEPLOY_OBJECT("DEPLOY_OBJECT"),
   TARGET("TARGET"),
   TARGET_TYPE("TARGET_TYPE"),
   DEPLOY_FLAG("DEPLOY_FLAG"),
   ENV_AGNOSTIC("ENV_AGNOSTIC"),
   TAGS("TAGS"),
   USE_SYMLINK("USE_SYMLINK"),
   user_email("user_email")
   
   private String headerLabel;
    
   private DeployObjectsListHeader(String headerLabel){
      this.headerLabel = headerLabel;
   }
   public String headerLabelValue() {return headerLabel}
}

@Sortable(includes = ['name'])
@ToString
public class DeployObjects {
   String name, target, targetType, targetTag, deployEnv;
   String absoluteTarget;
   String sshUser, sshPassword;
   File propertiesFile;
   Boolean deployFlag, envAgnosticFlag, useSymlink;
   
   Properties properties;
   Boolean debug;
   AntBuilder antDeploy;
   File deploymentReportFile;
   String deploymentReportFileName;
   List deployHosts;
   String deploymentStatus;
   String repoSourcePath;
   File postDeploymentFile;
   SourceRepoInfo sourceRepoInfo;
   
   public DeployObjects(String name, String target, String targetType, String deployEnv, String targetTag, File propertiesFile,
      Boolean deployFlag, Boolean envAgnosticFlag, Boolean useSymlink,
      String sshUser, String sshPassword,
      List deployHosts, String repoSourcePath, SourceRepoInfo sourceRepoInfo){
      this.name = name;
      this.target = target;
      this.targetType = targetType;
      this.targetTag = targetType;
      this.deployEnv = deployEnv;
      this.propertiesFile = propertiesFile;
      this.deployFlag = deployFlag;
      this.envAgnosticFlag = envAgnosticFlag;
      this.useSymlink = useSymlink;
      this.sshUser = sshUser;
      this.sshPassword = sshPassword;
      this.deployHosts = deployHosts;
      this.repoSourcePath = repoSourcePath;
      this.antDeploy = new AntBuilder();
      this.deploymentReportFileName = name + "-" + UUID.randomUUID().toString();
      if(this.deploymentReportFileName.contains(FileSystems.getDefault().getSeparator())){
         this.deploymentReportFileName = this.deploymentReportFileName.replace(FileSystems.getDefault().getSeparator(), "")
      }
      this.deploymentReportFile = new File(this.deploymentReportFileName);
      this.properties = new Properties();
      //this.postDeploymentFile = new File(this.name);
      this.sourceRepoInfo = sourceRepoInfo;
      
      propertiesFile.withInputStream {
         properties.load(it)
      }
   }
   
   public void deployRuntimeFileForServers(){
      try{
         if(this.deployFlag){
            for(Object each : this.deployHosts){
               String host = (String) each;
               this.deployRuntimeFile(host)
               //if targetType is defined as "property_name" that means it's using shared mount for all the execution servers
               //no need to redeploy the same file because shared mount is used for all execution server
               if("property_name".equalsIgnoreCase(this.targetType)){
                  break;
               }
            }
         }
         else{
            appendDeployTaskReport("DEPLOY_FLAG for deployment ${this.name} to ${this.target} is set to ${this.deployFlag}, skipping deployment")
            //println "    >> DEPLOY_FLAG for : $it.name is set to $it.deployFlag, skipping file deployment"
            this.deploymentStatus = "SKIPPED"
         }
      }
      catch(all){
         //println "$all"
         this.deploymentStatus = "ERROR"
         appendDeployTaskReport("ERROR: $all")
      }
      
   }
   
   private void populatePostDeploymentFile(String fileName, String deployHost, String remoteBaseDir, String remoteSoftlinkSource, String remoteSoftlink, String md5){
      this.appendPostDeploymentFile("FILE_NAME=${fileName}")
      this.appendPostDeploymentFile("DEPLOY_HOST=${deployHost}")
      this.appendPostDeploymentFile("DEPLOY_DIR=${remoteBaseDir}")
      this.appendPostDeploymentFile("VERSIONED_DEPLOYED_FILE=${remoteSoftlinkSource}")
      this.appendPostDeploymentFile("ACTUAL_DEPLOYED_FILE=${remoteSoftlink}")
      this.appendPostDeploymentFile("USE_SYMLINK=${this.useSymlink.toString()}")
      def now = Calendar.getInstance(TimeZone.getTimeZone("America/Chicago")).format("yyyy.MM.dd 'at' HH:mm:ss z")
      this.appendPostDeploymentFile("DEPLOYMENT_TIMESTAMP=${now}")
      this.appendPostDeploymentFile("MD5_SIGNATURE=${md5.trim()}")
      if(sourceRepoInfo != null){
         this.appendPostDeploymentFile("COMMIT_REVISION=${this.sourceRepoInfo.commitRevision}")
         this.appendPostDeploymentFile("REPO_URL=${this.sourceRepoInfo.repoURL}")
         this.appendPostDeploymentFile("BRANCH_NAME=${sourceRepoInfo.branchName}")
         if(this.sourceRepoInfo.changeNote != null){
            this.appendPostDeploymentFile("CHANGE_NOTE=${this.sourceRepoInfo.changeNote}")
         }
         if(this.sourceRepoInfo.committerEmail != null){
            this.appendPostDeploymentFile("COMITTER_EMAIL=${this.sourceRepoInfo.committerEmail}")
         }
         if(this.sourceRepoInfo.comitter != null){
            this.appendPostDeploymentFile("COMITTER=${this.sourceRepoInfo.comitter}")
         }
      }
   }
   
   private void appendPostDeploymentFile(content){
      this.postDeploymentFile.append(content)
      this.postDeploymentFile.append(System.getProperty("line.separator"))
   }
   
   private void sendPostDeploymentDir(String deployHost){
      def dirPermission = "--mode=750"
      def filePermission = "755"
      def postDeploymentDir = ""
      def postDeploymentTriggerDir = ""
      //this.debug = true
      if(this.properties.dir_permission != null && this.properties.dir_permission.toString().trim().length() > 0){
         dirPermission = "--mode=${this.properties.dir_permission}"
      }
      if(this.properties.file_permission != null && this.properties.file_permission.toString().trim().length() > 0){
         filePermission = this.properties.file_permission
      }
      if(this.properties.jenkins_post_deployment_dir != null && this.properties.jenkins_post_deployment_dir.toString().trim().length() > 0){
         postDeploymentDir = this.properties.jenkins_post_deployment_dir.toString().trim()
         
         try{
            //safety command to make directory if not exists
            this.antDeploy.sshexec(
               host                 : deployHost,
               username             : this.sshUser,
               password             : this.sshPassword,
               trust                : "true",
               suppresssystemout    : "true",
               command              :"[ -d $postDeploymentDir ] || mkdir -v -p ${dirPermission} $postDeploymentDir",
               verbose              :false)
         }catch(all){
            println "Error creating directory $postDeploymentDir. $all"
            return
         }
         
         //Path infoFile = Files.copy(Paths.get(this.postDeploymentFile.getAbsolutePath()), Paths.get(this.postDeploymentFile.getAbsolutePath() + ".info"))
         Path infoFile = Paths.get(this.postDeploymentFile.getAbsolutePath())
         try{
            if(this.debug){
               println "deploying ${infoFile.toString()} to @$deployHost:$postDeploymentDir"
            }
            this.antDeploy.scp(
               trust       :"true",
               localFile   :"${infoFile.toString()}",
               todir       :"${this.sshUser}:${this.sshPassword}@${deployHost}:${postDeploymentDir}",
               verbose     :false
               )
         }catch(all){
            def report = "Error moving files ${infoFile.toString()} to @$deployHost:$postDeploymentDir, skipping file. $all"
            appendDeployTaskReport(report)
            appendDeployTaskReport("$all")
            return
         }
         
         try{
            println "updating permission to deployed object"
            this.antDeploy.sshexec(
               host              : deployHost,
               username          : this.sshUser,
               password          : this.sshPassword,
               trust             : "true",
               command           : "chmod -R $filePermission ${postDeploymentDir}/${this.postDeploymentFile.getName()}",
               verbose           :false)
         }
         catch(all){
            //println "Error updating permission"
            appendDeployTaskReport("Error updating permission")
            appendDeployTaskReport("$all")
            this.deploymentStatus = "PARTIAL SUCCESS"
            return
         }
      }
      if(this.properties.jenkins_test_automation_trigger_dir != null && this.properties.jenkins_test_automation_trigger_dir.toString().trim().length() > 0){
         postDeploymentTriggerDir = this.properties.jenkins_test_automation_trigger_dir.toString().trim()
         
         try{
            //safety command to make directory if not exists
            this.antDeploy.sshexec(
               host                 : deployHost,
               username             : this.sshUser,
               password             : this.sshPassword,
               trust                : "true",
               suppresssystemout    : "true",
               command              :"[ -d ${postDeploymentTriggerDir} ] || mkdir -v -p ${dirPermission} ${postDeploymentTriggerDir}",
               verbose              :false)
         }catch(all){
            println "Error creating directory $postDeploymentTriggerDir . $all"
            return
         }
         //Path triggerFile = Files.copy(Paths.get(this.postDeploymentFile.getAbsolutePath()), Paths.get(this.postDeploymentFile.getAbsolutePath() + ".trg"))
         def triggerFileName = this.postDeploymentFile.getName().substring(0, this.postDeploymentFile.getName().lastIndexOf(".")) + ".trg"
         def triggerFile = new File(triggerFileName)
         this.postDeploymentFile.renameTo(triggerFile)
         try{
            if(this.debug){
               println "deploying ${triggerFile.toString()} to @$deployHost:$postDeploymentTriggerDir"
            }
            this.antDeploy.scp(
               trust       :"true",
               localFile   :"${triggerFile.getAbsolutePath()}",
               todir       :"${this.sshUser}:${this.sshPassword}@${deployHost}:${postDeploymentTriggerDir}",
               verbose     :false
               )
            //this.postDeploymentFile.delete()
         }catch(all){
            def report = "Error moving files ${triggerFile.getAbsolutePath()} to @$deployHost:$postDeploymentTriggerDir, skipping file. $all"
            appendDeployTaskReport(report)
            appendDeployTaskReport("$all")
            return
         }
         
         try{
            println "updating permission to deployed object"
            this.antDeploy.sshexec(
               host              : deployHost,
               username          : this.sshUser,
               password          : this.sshPassword,
               trust             : "true",
               command           : "chmod -R $filePermission ${postDeploymentTriggerDir}/${triggerFile.getName()}",
               verbose           :false)
         }
         catch(all){
            //println "Error updating permission"
            appendDeployTaskReport("Error updating permission")
            appendDeployTaskReport("$all")
            this.deploymentStatus = "PARTIAL SUCCESS"
            return
         }
      }
      
      if(this.debug){
         println "    >> postDeploymentDir : $postDeploymentDir" 
         println "    >> postDeploymentTriggerDir : $postDeploymentTriggerDir" 
         println "    >> dirPermission : $dirPermission"
         //println "    >> name : ${postDeploymentFile}"
      }
      return 
   }

   private void appendDeployTaskReport(reportString){
      def now = Calendar.getInstance(TimeZone.getTimeZone("America/Chicago")).format("yyyy.MM.dd 'at' HH:mm:ss z")
      if(reportString != null && !"".equalsIgnoreCase(reportString.trim())){
         this.deploymentReportFile.append("$now | " + reportString)
      }
      this.deploymentReportFile.append(System.getProperty("line.separator"))
   }

   private void deployRuntimeFile(deployHost){
      //this.debug = true
      def suppresssystemout = this.debug ? false : true
      def scpTarget = null
      def dirPermission = "--mode=750"
      def filePermission = "755"
      
      if(this.properties.file_permission != null && this.properties.file_permission.toString().trim().length() > 0){
         filePermission = this.properties.file_permission
      }
      if(this.properties.dir_permission != null && this.properties.dir_permission.toString().trim().length() > 0){
         dirPermission = "--mode=${this.properties.dir_permission}"
      }
      
      if("property_name".equalsIgnoreCase(this.targetType)){
         scpTarget = this.properties."${this.target}"
         if(scpTarget == null || "".equalsIgnoreCase(scpTarget.trim())){
            appendDeployTaskReport("property ${this.target} is not found or have no value. please define the property ${this.target} in the environment properties file. SKIPPING DEPLOYMENT")
            this.deploymentStatus = "ERROR"
            return
         }
      }
      else if("path_name".equalsIgnoreCase(this.targetType)){
         scpTarget = this.target
      }
      else{
         //println "    >> targetType undefined. please define TARGET_TYPE in the deploy list for DEPLOY_OBJECT : ${this.name}" 
         appendDeployTaskReport("targetType undefined. please define TARGET_TYPE in the deploy list for DEPLOY_OBJECT : ${this.name}")
         this.deploymentStatus = "ERROR"
         return
      }
      
      if(this.debug){
         println "    >> fileName : ${this.name}"
         println "    >> envAgnosticFlag : ${this.envAgnosticFlag}"
         println "    >> target : ${this.target}"
         println "    >> targetType : ${this.targetType}"
         println "    >> envPropFile : ${this.propertiesFile.toString()}"
         println "    >> scpTarget : $scpTarget" 
      }
      
      def fileToDeploy = null
      def fileNameToDeploy = null
      if(this.envAgnosticFlag){
         fileNameToDeploy = "**/${this.name}"
      }
      else{
         fileNameToDeploy = "**/${this.deployEnv}/**/${this.name}"
      }
      fileToDeploy = new FileNameFinder().getFileNames(".", fileNameToDeploy)
      
      if(this.debug){
         println "    >> fileToDeploy : ${fileToDeploy.toString()}"
      }
   
      def report = null
      def checkRemoteFile = null
      def fileExtension = null
      def scpTargetFileName = null
      def scpTargetFilePath = null
      def remoteBaseDir = null
      def checkRemoteDir = null
      def remoteSoftlinkSource = null
      def remoteSoftlink = null
      def reportFileName = UUID.randomUUID().toString()
      if(fileToDeploy != null && fileToDeploy.size() > 0){
         fileToDeploy.each{
            Path fullFilePath = Paths.get(it)
            this.postDeploymentFile = null
            if(Files.exists(fullFilePath)){
               if(this.debug){
                  println "    >> fileToDeploy found : ${it}"
               }
               
               def fileName = fullFilePath.getFileName()
               
               //this logic is to do conditional check based on the file extension as to whether to create a softlink using
               //original filename or softlink using target filename
               fileExtension = ""
               //first check to see if the filename contains extension (.jar, .csv, .txt, etc.....)
               if(fileName.toString().lastIndexOf(".") != -1 && fileName.toString().lastIndexOf(".") != 0){
                  fileExtension = fileName.toString().substring(fileName.toString().lastIndexOf("."));
               }
        
               //if the file has an extension
               if(fileExtension != null && !"".equalsIgnoreCase(fileExtension)){
                  //check to see if the scp target contains the same extension
                  //if the scp target contains the same extension, then the scp target is a full file path
                  //which can be changed into a softlink as needed
                  if(scpTarget.endsWith(fileExtension.toString().trim())){
                     //find the scp target file name using path separator
                     int filePathIndex = scpTarget.lastIndexOf(FileSystems.getDefault().getSeparator())
                     scpTargetFileName = scpTarget.substring(filePathIndex+1)
                     scpTargetFilePath = scpTarget.substring(0, filePathIndex)
                     
                     remoteBaseDir = scpTargetFilePath.endsWith(FileSystems.getDefault().getSeparator()) ? scpTargetFilePath :
                                     (scpTargetFilePath + FileSystems.getDefault().getSeparator())
                     checkRemoteDir = scpTargetFilePath.endsWith(FileSystems.getDefault().getSeparator()) ?
                                      (scpTargetFilePath + this.repoSourcePath) :
                                      (scpTargetFilePath + FileSystems.getDefault().getSeparator() + this.repoSourcePath)
                     
                     checkRemoteFile = checkRemoteDir.endsWith(FileSystems.getDefault().getSeparator()) ?
                                       (checkRemoteDir + fileName.toString()) :
                                       (checkRemoteDir + FileSystems.getDefault().getSeparator() + fileName.toString())
                     
                     remoteSoftlinkSource = "." + FileSystems.getDefault().getSeparator() + this.repoSourcePath + FileSystems.getDefault().getSeparator() +
                                            fileName.toString()
                     remoteSoftlink = scpTarget
                  }
                  //if the scp target does not contain the same extension, then assume the scp target is a directory
                  //deploy the file using original filename
                  else{
                     remoteBaseDir = scpTarget.endsWith(FileSystems.getDefault().getSeparator()) ? scpTarget :
                                     (scpTarget + FileSystems.getDefault().getSeparator())
                     checkRemoteDir = scpTarget.endsWith(FileSystems.getDefault().getSeparator()) ?
                                      (scpTarget + this.repoSourcePath) :
                                      (scpTarget + FileSystems.getDefault().getSeparator() + this.repoSourcePath)
                     
                     checkRemoteFile = checkRemoteDir.endsWith(FileSystems.getDefault().getSeparator()) ?
                                       (checkRemoteDir + fileName.toString()) :
                                       (checkRemoteDir + FileSystems.getDefault().getSeparator() + fileName.toString())
                     
                     remoteSoftlinkSource = "." + FileSystems.getDefault().getSeparator() + this.repoSourcePath + FileSystems.getDefault().getSeparator() +
                                            fileName.toString()
                     remoteSoftlink = scpTarget.endsWith(FileSystems.getDefault().getSeparator()) ? 
                                      (scpTarget + fileName.toString()) :
                                      (scpTarget + FileSystems.getDefault().getSeparator() + fileName.toString())
                  }
               }
               //if the file has no extension, then things get a little complicated
               else{
                  //check to see the scp target contains the file name string
                  //if the scp target contains the file name string, then the scp target is a full file path
                  if(scpTarget.contains(fileName.toString().trim())){
                     scpTargetFileName = fileName
                     scpTargetFilePath = (scpTarget.toString()).replace(fileName.toString(), "")
                     
                     remoteBaseDir = scpTargetFilePath.endsWith(FileSystems.getDefault().getSeparator()) ? scpTargetFilePath :
                                     (scpTargetFilePath + FileSystems.getDefault().getSeparator())
                     checkRemoteDir = scpTargetFilePath.endsWith(FileSystems.getDefault().getSeparator()) ?
                                      (scpTargetFilePath + this.repoSourcePath) :
                                      (scpTargetFilePath + FileSystems.getDefault().getSeparator() + this.repoSourcePath)
                     
                     checkRemoteFile = checkRemoteDir.endsWith(FileSystems.getDefault().getSeparator()) ?
                                       (checkRemoteDir + fileName.toString()) :
                                       (checkRemoteDir + FileSystems.getDefault().getSeparator() + fileName.toString())
                     
                     remoteSoftlinkSource = "." + FileSystems.getDefault().getSeparator() + this.repoSourcePath + FileSystems.getDefault().getSeparator() +
                                            fileName.toString()
                     remoteSoftlink = scpTarget
                  }
                  //if the scp target does not contain the file name string, then assume the scp target is a directory
                  else{
                     remoteBaseDir = scpTarget.endsWith(FileSystems.getDefault().getSeparator()) ? scpTarget :
                                     (scpTarget + FileSystems.getDefault().getSeparator())
                     checkRemoteDir = scpTarget.endsWith(FileSystems.getDefault().getSeparator()) ?
                                      (scpTarget + this.repoSourcePath) :
                                      (scpTarget + FileSystems.getDefault().getSeparator() + this.repoSourcePath)
                     
                     checkRemoteFile = checkRemoteDir.endsWith(FileSystems.getDefault().getSeparator()) ?
                                       (checkRemoteDir + fileName.toString()) :
                                       (checkRemoteDir + FileSystems.getDefault().getSeparator() + fileName.toString())
                     
                     remoteSoftlinkSource = "." + FileSystems.getDefault().getSeparator() + this.repoSourcePath + FileSystems.getDefault().getSeparator() +
                                            fileName.toString()
                     remoteSoftlink = scpTarget.endsWith(FileSystems.getDefault().getSeparator()) ? 
                                      (scpTarget + fileName.toString()) :
                                      (scpTarget + FileSystems.getDefault().getSeparator() + fileName.toString())
                  }
               }
               this.absoluteTarget = remoteSoftlink
               def postDeploymentFileName = remoteSoftlink.substring(remoteSoftlink.lastIndexOf(FileSystems.getDefault().getSeparator())+1)
               this.postDeploymentFile = new File(postDeploymentFileName.toString() + ".info");
               try{
                  
                  this.antDeploy.sshexec(
                     host              : deployHost,
                     username          : this.sshUser,
                     password          : this.sshPassword,
                     trust             :"true",
                     suppresssystemout :"$suppresssystemout",
                     output            : reportFileName,
                     command           :"[ -d $checkRemoteDir ] && echo 'Directory @${deployHost}:$checkRemoteDir verified exists' || mkdir -v -p ${dirPermission} $checkRemoteDir",
                     verbose:false)
                  report = new File(reportFileName).text
                  appendDeployTaskReport(report)
                  if(debug){
                     println "Directory Verification Report : ${report.trim()}"
                  }
               }
               catch(all){
                  //println "Error creating directory $checkRemoteDir"
                  appendDeployTaskReport("Error creating directory $checkRemoteDir")
                  appendDeployTaskReport("$all")
                  this.deploymentStatus = "ERROR"
                  return
               }
               
               def remoteMD5Value
               def localMD5Value
               try{
                  if(this.debug){
                     println "checking md5sum of remote file $checkRemoteFile"
                  }
                  this.antDeploy.sshexec(
                     host              : deployHost,
                     username          : this.sshUser,
                     password          : this.sshPassword,
                     trust             : "true",
                     suppresssystemout : "$suppresssystemout",
                     output            : "${it}.remote.md5",
                     command           : "[ -f $checkRemoteFile ] && md5sum $checkRemoteFile || echo 'file $checkRemoteFile not exist'",
                     verbose           :false)
                     
                  String remoteMD5 = new File("${it}.remote.md5").text
                  int firstIndex = remoteMD5.indexOf("$checkRemoteFile")
                  remoteMD5Value = remoteMD5.substring(0, firstIndex)
                  if(this.debug){
                     println "remoteMD5Value : ${remoteMD5Value.trim()}"
                  }
               }catch(all){
                  //println "Error checking md5sum for remote file $all"
                  appendDeployTaskReport("Error checking md5sum for remote file $all")
                  remoteMD5Value = ""
                  this.deploymentStatus = "ERROR"
                  return
               }
               
               try{
                  if(this.debug){
                     println "checking md5sum of local file ${it}"
                  }
                  
                  this.antDeploy.checksum(
                     file:"${it}",
                     forceoverwrite:"yes")
                     
                  String localMD5 = new File("${it}.MD5").text
                  localMD5Value = localMD5
                  if(this.debug){
                     println "localMD5Value : ${localMD5Value.trim()}"
                  }
               }catch(all){
                  appendDeployTaskReport("Error checking md5sum for local file, skipping file ${it}")
                  appendDeployTaskReport("$all")
                  this.deploymentStatus = "ERROR"
                  return
               }
               
               if(!remoteMD5Value.trim().equals(localMD5Value.trim())){
                  
                  report = "MD5 mismatch for remote file and local file, overwriting remote file : @${deployHost}:$checkRemoteFile"
                  this.populatePostDeploymentFile(fileName.toString(), deployHost, remoteBaseDir, remoteSoftlinkSource, remoteSoftlink, localMD5Value)
                  
                  if(this.debug){
                     println "$report"
                  }
                  appendDeployTaskReport(report)
                  
                  try{
                     if(this.debug){
                        println "deploying ${it} to $checkRemoteFile"
                     }
                     
                     this.antDeploy.scp(
                        trust:"true",
                        localFile:"${it}",
                        todir:"${this.sshUser}:${this.sshPassword}@$deployHost:$checkRemoteFile",
                        verbose:false
                     )
                     
                     if(this.useSymlink){
                        this.antDeploy.sshexec(
                           host              : deployHost,
                           username          : this.sshUser,
                           password          : this.sshPassword,
                           trust             : "true",
                           suppresssystemout : "$suppresssystemout",
                           command           : "cd $remoteBaseDir && ln -nsf $remoteSoftlinkSource $remoteSoftlink",
                           verbose           : false)
                        report = "deployment of remote file : $checkRemoteFile completed, symlink $remoteSoftlink updated to point to $checkRemoteFile"
                        appendDeployTaskReport(report)
                        sendPostDeploymentDir(deployHost)
                     }
                     else{
                        try{
                           this.antDeploy.sshexec(
                              host              : deployHost,
                              username          : this.sshUser,
                              password          : this.sshPassword,
                              trust             : "true",
                              suppresssystemout : "$suppresssystemout",
                              output            : reportFileName,
                              command           : "if [[ -L $remoteSoftlink || ! -f $remoteSoftlink || \$(md5sum < $remoteSoftlink) != \$(md5sum < $checkRemoteFile) ]]; then rm -f $remoteSoftlink && cp $checkRemoteFile $remoteSoftlink && echo 'deployment of remote file : $remoteSoftlink completed'; else echo 'MD5 match, skipping deployment of file : @${deployHost}:$remoteSoftlink'; fi",
                              verbose           : false)
                           report = new File(reportFileName).text
                           appendDeployTaskReport(report)
                           if(debug){
                              println "Deployment Verification Report : ${report.trim()}"
                           }
                           //appendBuildReport(reportFile, report)
                           report = "deployment of remote file : $checkRemoteFile completed"
                           appendDeployTaskReport(report)
                           sendPostDeploymentDir(deployHost)
                        }
                        catch(all){
                           println "LINE 1017 : Error verifying symlink $remoteSoftlink. Attempt to fix by deleting and recreating"
                           println "$all"
                           this.antDeploy.sshexec(
                              host              : deployHost,
                              username          : this.sshUser,
                              password          : this.sshPassword,
                              trust             : "true",
                              suppresssystemout : "$suppresssystemout",
                              output            : reportFileName,
                              command           : "rm -f $remoteSoftlink && cp $checkRemoteFile $remoteSoftlink",
                              verbose           : false)
                           report = new File(reportFileName).text
                           appendDeployTaskReport(report)
                           sendPostDeploymentDir(deployHost)
                           if(debug){
                              println "Symlink Verification Report : ${report.trim()}"
                           }
                           //appendBuildReport(reportFile, report)
                        }
                     }
                     
                     if(this.debug){
                        println "$report"
                     }
                  }
                  catch(all){
                     report = "Error moving files ${it} to $scpTarget, skipping file."
                     //println "$report"
                     
                     appendDeployTaskReport(report)
                     appendDeployTaskReport("$all")
                     this.deploymentStatus = "ERROR"
                     return
                  }
                  
                  try{
                     println "updating permission to deployed object"
                     this.antDeploy.sshexec(
                        host        : deployHost,
                        username    : this.sshUser,
                        password    : this.sshPassword,
                        trust       : "true",
                        command     :"chmod -R $filePermission $checkRemoteFile",
                        verbose     :false)
                  }
                  catch(all){
                     //println "Error updating permission"
                     appendDeployTaskReport("Error updating permission")
                     appendDeployTaskReport("$all")
                     this.deploymentStatus = "PARTIAL SUCCESS"
                     return
                  }
                  
                  if(!this.useSymlink){
                     try{
                        println "updating permission to deployed object"
                        this.antDeploy.sshexec(
                           host        : deployHost,
                           username    : this.sshUser,
                           password    : this.sshPassword,
                           trust       :"true",
                           command     :"chmod -R $filePermission $remoteSoftlink",
                           verbose     :false)
                     }
                     catch(all){
                        //println "Error updating permission"
                        appendDeployTaskReport("Error updating permission")
                        appendDeployTaskReport("$all")
                        this.deploymentStatus = "PARTIAL SUCCESS"
                        return
                     }
                  }
               }
               else{
                  report =  "MD5 match, skipping deployment of file : @${deployHost}:$checkRemoteFile"
                  if(this.debug){
                     println "$report"
                  }
                  appendDeployTaskReport(report)
                  
                  if(this.useSymlink){
                     try{
                        this.antDeploy.sshexec(
                           host              : deployHost,
                           username          : this.sshUser,
                           password          : this.sshPassword,
                           trust             : "true",
                           suppresssystemout : "$suppresssystemout",
                           output            : reportFileName,
                           command           : "if [[ -L $remoteSoftlink && \$(readlink -- $remoteSoftlink) = $remoteSoftlinkSource ]]; then echo '${deployHost}:$remoteSoftlink softlink verified to point to $checkRemoteFile'; else cd $remoteBaseDir && ln -nsf $remoteSoftlinkSource $remoteSoftlink; fi",
                           verbose           :false)
                        report = new File(reportFileName).text
                        appendDeployTaskReport(report)
                        if(debug){
                           println "Symlink Verification Report : ${report.trim()}"
                        }
                     }
                     catch(all){
                        println "LINE 1115: Error verifying symlink $remoteSoftlink. Attempt to fix by deleting and recreating"
                        this.antDeploy.sshexec(
                           host              : deployHost,
                           username          : this.sshUser,
                           password          : this.sshPassword,
                           trust             : "true",
                           suppresssystemout : "$suppresssystemout",
                           output            : reportFileName,
                           command           :"rm -f $remoteSoftlink && cd $remoteBaseDir && ln -nsf $remoteSoftlinkSource $remoteSoftlink",
                           verbose           :false)
                        report = new File(reportFileName).text
                        appendDeployTaskReport(report)
                        if(debug){
                           println "Symlink Verification Report : ${report.trim()}"
                        }
                     }
                  }
                  else{
                     try{
                        this.antDeploy.sshexec(
                           host              : deployHost,
                           username          : this.sshUser,
                           password          : this.sshPassword,
                           trust             : "true",
                           suppresssystemout : "$suppresssystemout",
                           output            : reportFileName,
                           command           : "if [[ -L $remoteSoftlink || ! -f $remoteSoftlink || \$(md5sum < $remoteSoftlink) != \$(md5sum < $checkRemoteFile) ]]; then rm -f $remoteSoftlink && cp $checkRemoteFile $remoteSoftlink && echo 'deployment of remote file : $remoteSoftlink completed'; else echo 'MD5 match, skipping deployment of file : @${deployHost}:$remoteSoftlink'; fi",
                           verbose           : false)
                        report = new File(reportFileName).text
                        appendDeployTaskReport(report)
                        if(debug){
                           println "File Verification Report : ${report.trim()}"
                        }
                     }
                     catch(all){
                        println "Error verifying file $remoteSoftlink. Attempt to fix by deleting and recreating"
                        this.antDeploy.sshexec(
                           host              : deployHost,
                           username          : this.sshUser,
                           password          : this.sshPassword,
                           trust             : "true",
                           suppresssystemout : "$suppresssystemout",
                           output            : reportFileName,
                           command           : "rm -f $remoteSoftlink && cp $checkRemoteFile $remoteSoftlink",
                           verbose           :false)
                        report = new File(reportFileName).text
                        appendDeployTaskReport(report)
                        if(debug){
                           println "File Verification Report : ${report.trim()}"
                        }
                     }
                     try{
                        println "updating permission to deployed object"
                        this.antDeploy.sshexec(
                           host              : deployHost,
                           username          : this.sshUser,
                           password          : this.sshPassword,
                           trust             : "true",
                           command           : "chmod -R $filePermission $remoteSoftlink",
                           verbose           :false)
                     }
                     catch(all){
                        //println "Error updating permission"
                        appendDeployTaskReport("Error updating permission")
                        appendDeployTaskReport("$all")
                        this.deploymentStatus = "PARTIAL SUCCESS"
                        return
                     }
                  }
               }
            }
         }
      }
      else{
         report = "    >> file $fileNameToDeploy not found. please verify DEPLOY_OBJECT : ${fileNameToDeploy} is in SVN project UAH_UAH_CONFIG with all the right properties" 
         //println "$report"
         
         appendDeployTaskReport(report)
         this.deploymentStatus = "ERROR"
         return
      }
      
      if(this.deploymentStatus == null || "".equalsIgnoreCase(this.deploymentStatus.trim())){
         this.deploymentStatus = "SUCCESS"
      }
   }
}


Path nonTalendDeployList = Paths.get(env["NON_TALEND_DEPLOY_LIST_CSV_FILE"])

def deploy_list = []  //List of files to be deployed
println "    - NON_TALEND_DEPLOY_LIST_CSV_FILE='${env['NON_TALEND_DEPLOY_LIST_CSV_FILE']}"

//check build list override
if(nonTalendDeployListOverride != null && !"".equals(nonTalendDeployListOverride)){
   nonTalendDeployListOverrideFileName = "**/NON_TALEND_DEPLOY_LIST_OVERRIDE"
   nonTalendDeployListOverrideFile = new FileNameFinder().getFileNames(".", nonTalendDeployListOverrideFileName)
   if(nonTalendDeployListOverrideFile != null && nonTalendDeployListOverrideFile.size() > 0){
      println "NON_TALEND_DEPLOY_LIST_OVERRIDE file found"
      nonTalendDeployListOverrideFile.each{
         println "NON_TALEND_DEPLOY_LIST_OVERRIDE file found : ${it.toString()}"
         nonTalendDeployList = Paths.get(it)
      }
   }
}

def deployment_success = [:]
def deploy_map = [:]
def emailList = ""
def jobList = ""
try{
   DEPLOY_OBJECT = ""
   DEPLOY_FLAG = true
   ENV_AGNOSTIC = false
   TARGET = ""
   TARGET_TYPE = ""
   TAGS = ""
   USE_SYMLINK = false
   user_email = ""
   
   nonTalendDeployList.withReader { reader ->
      CSVParser csv = new CSVParser(reader, DEFAULT.withHeader())
      Map csvHeader = csv.getHeaderMap()
      for(eachRecord in csv.getRecords()){
         
         for(Map.Entry<String, Integer> eachHeader in csvHeader.entrySet()){
            if(eachHeader.getKey().equalsIgnoreCase(DeployObjectsListHeader.DEPLOY_OBJECT.headerLabelValue())){
               DEPLOY_OBJECT = eachRecord."${eachHeader.getKey()}".trim()
            }
            if(eachHeader.getKey().equalsIgnoreCase(DeployObjectsListHeader.DEPLOY_FLAG.headerLabelValue())){
               DEPLOY_FLAG = "true".equalsIgnoreCase(eachRecord."${eachHeader.getKey()}".trim())
            }
            if(eachHeader.getKey().equalsIgnoreCase(DeployObjectsListHeader.ENV_AGNOSTIC.headerLabelValue())){
               ENV_AGNOSTIC = "true".equalsIgnoreCase(eachRecord."${eachHeader.getKey()}".trim())
            }
            if(eachHeader.getKey().equalsIgnoreCase(DeployObjectsListHeader.TARGET.headerLabelValue())){
               TARGET = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
            }
            if(eachHeader.getKey().equalsIgnoreCase(DeployObjectsListHeader.TARGET_TYPE.headerLabelValue())){
               TARGET_TYPE = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
            }
            if(eachHeader.getKey().equalsIgnoreCase(DeployObjectsListHeader.TAGS.headerLabelValue())){
               TAGS = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
            }
            if(eachHeader.getKey().equalsIgnoreCase(DeployObjectsListHeader.USE_SYMLINK.headerLabelValue())){
               USE_SYMLINK = "true".equalsIgnoreCase(eachRecord."${eachHeader.getKey()}".trim())
            }
            if(eachHeader.getKey().equalsIgnoreCase(DeployObjectsListHeader.user_email.headerLabelValue())){
               user_email = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
               emailList += user_email + ","
            }
         }
         if(DEPLOY_OBJECT != null && !"".equals(DEPLOY_OBJECT.trim())){
            DeployObjects deployObject = new DeployObjects(DEPLOY_OBJECT,
                                                           TARGET,
                                                           TARGET_TYPE,
                                                           deployEnv,
                                                           TAGS,
                                                           Paths.get(envPropFile).toFile(),
                                                           DEPLOY_FLAG,
                                                           ENV_AGNOSTIC,
                                                           USE_SYMLINK,
                                                           sshUser,
                                                           sshPassword,
                                                           exec_server_host,
                                                           repoSourcePath,
                                                           sourceRepoInfo)
            deploy_map.put(DEPLOY_OBJECT + "-" + TARGET, deployObject)
         }
         else{
            println "ERROR! DEPLOY_OBJECT is not defined in the list."
            appendBuildReport(buildReport, "ERROR! DEPLOY_OBJECT is not defined in the list.")
         }
      }
      if(emailList != null && !"".equalsIgnoreCase(emailList)){
         if(emailList.endsWith(",")){
            emailList = emailList.substring(0, emailList.lastIndexOf(","))
         }
         notificationsProp.append("EMAIL_LIST=" + emailList)
         notificationsProp.append(System.getProperty("line.separator"))
      }
   }
   
   if(deploy_map.size() > 0){
      //PoolUtils default poolsize = Runtime.getRuntime().availableProcessors() + 1;
      //tweak the poolsize of GParsPool
      //try 2 * processor, adjust as necessary
      //dev note: 2 * processor have been tried and seems to have little or no significant gains in overall
      //runtime. in addition to that, there's some intermittent issue with that many ssh connection being opened
      //reverting back to default
      //int poolSize = Runtime.getRuntime().availableProcessors() * 2
      
      GParsPool.withPool() {
         deploy_map.eachWithIndexParallel{ each , poolIndex->
            //println "pool index : $poolIndex task name : ${eachTask.key} "
            each.value.deployRuntimeFileForServers()
         }
      }
      
      deploy_map = deploy_map.sort{ it.key }
      appendBuildReport(buildReport, "----------------------------------------------------")
      appendBuildReport(buildReport, "NON-TALEND SUPPORT FILES DEPLOYMENT REPORT SUMMARY")
      appendBuildReport(buildReport, "----------------------------------------------------")
   
      deploy_map.each{ each ->
         appendBuildReport(buildReport, "${each.key} deploymentStatus : ${each.value.deploymentStatus}")
         jobList += each.key + "-" + each.value.deploymentStatus + ","
         if(each.value.deploymentStatus.equalsIgnoreCase("SUCCESS") ||
            each.value.deploymentStatus.equalsIgnoreCase("SKIPPED")){
            deployment_success.put(each.key, each.value.deploymentStatus)
         }
      }
      
      appendBuildReport(buildReport, "----------------------------------------------------")
      appendBuildReport(buildReport, "NON-TALEND SUPPORT FILES DEPLOYMENT REPORT DETAIL:")
      appendBuildReport(buildReport, "----------------------------------------------------")
   
      deploy_map.each{ each ->
         appendBuildReport(buildReport, "++++++++++++++++++++++++++++++++++++++++++++++++++++")
         appendBuildReport(buildReport, "DEPLOYMENT REPORT DETAIL ${each.key}:")
         each.value.deploymentReportFile.eachLine { line ->
            buildReport.append(line)
            buildReport.append(System.getProperty("line.separator"))
         }
         appendBuildReport(buildReport, "++++++++++++++++++++++++++++++++++++++++++++++++++++")
      }
      appendBuildReport(buildReport, "----------------------------------------------------")
      appendBuildReport(buildReport, "")
   }
   else{
      println "Deployment map is empty. No DEPLOY_OBJECT found, all deployments skipped."
      appendBuildReport(buildReport, "Deployment map is empty. No DEPLOY_OBJECT found, all deployments skipped.")
   }
}catch(java.nio.charset.MalformedInputException mafe){
   appendBuildReport(buildReport, "MalformedInputException encountered on build list")
   appendBuildReport(buildReport, "Most likely there's a non-ascii/non UTF-8 character in the build list, please fix the build list")
   println "MalformedInputException encountered on build list"
   println "Most likely there's a non-ascii/non UTF-8 character in the build list, please fix the build list"
   System.exit(1)
}catch(all){
   println "Error reading CSV Job List: $all"
   System.exit(1)
}

timeStop = new Date()
TimeDuration duration = TimeCategory.minus(timeStop, timeStart)
appendBuildReport(buildReport, "Deployment process of non-talend component started at " + timeStart.format("EEE MMM dd HH:mm:ss zzz yyyy", TimeZone.getTimeZone("America/Chicago")))
appendBuildReport(buildReport, "Deployment process of non-talend component finished at " + timeStop.format("EEE MMM dd HH:mm:ss zzz yyyy", TimeZone.getTimeZone("America/Chicago")))
appendBuildReport(buildReport, "Deployment process of non-talend component duration: ${duration}")
appendBuildReport(buildReport, "----------------------------------------------------")
appendBuildReport(buildReport, "----------------------------------------------------")
appendBuildReport(buildReport, "")
notificationsProp.append("JENKINS_JOB_END_TIME=" + timeStop.format("EEE MMM dd HH:mm:ss zzz yyyy", TimeZone.getTimeZone("America/Chicago")))
notificationsProp.append(System.getProperty("line.separator"))
notificationsProp.append("JENKINS_JOB_DURATION=" + duration.toString())
notificationsProp.append(System.getProperty("line.separator"))

if(jobList != null && !"".equalsIgnoreCase(jobList)){
   if(jobList.endsWith(",")){
      jobList = jobList.substring(0, jobList.lastIndexOf(","))
   }
   notificationsProp.append("JOB_LIST=" + jobList)
   notificationsProp.append(System.getProperty("line.separator"))
}

if(deployment_success.size() == 0){
   appendBuildReport(buildReport, "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
   appendBuildReport(buildReport, "ERROR = ALL DEPLOYMENT FAILED" )
   appendBuildReport(buildReport, "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
   println "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
   println "ERROR = ALL DEPLOYMENT FAILED"
   println "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
}
else if(deploy_map.size() == deployment_success.size()){
   appendBuildReport(buildReport, "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
   appendBuildReport(buildReport, "SUCCESS = ALL DEPLOYMENT SUCCESSFUL" )
   appendBuildReport(buildReport, "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
   println "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
   println "SUCCESS = ALL DEPLOYMENT SUCCESSFUL"
   println "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
}
else{
   appendBuildReport(buildReport, "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
   appendBuildReport(buildReport, "PARTIAL SUCCESS = SOME DEPLOYMENT FAILED, PLEASE CHECK THE DEPLOYMENT SUMMARY AND DETAILS FOR INFORMATION" )
   appendBuildReport(buildReport, "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
   println "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
   println "PARTIAL SUCCESS = SOME DEPLOYMENT FAILED, PLEASE CHECK THE DEPLOYMENT SUMMARY AND DETAILS FOR INFORMATION"
   println "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
}

def prepEnvPropFile(envPropFileName, reportFile, deployEnv){
   def envPropFile = new FileNameFinder().getFileNames(".", "**/$deployEnv/**/$envPropFileName")
   def deployEnvPropFileName = null
   if(envPropFile.size() > 0 && Files.exists(Paths.get(envPropFile[0]))){
      println "    >> True: environment property file found : ${envPropFile[0]}"
      
      appendBuildReport(reportFile, "environment property file found : ${envPropFile[0]}")
      
      deployEnvPropFileName = "${envPropFile[0]}"
      println "    >> environment property file name to be deployed : ${deployEnvPropFileName}"
   }
   return deployEnvPropFileName
}

def metaServletCall(tacUrl, request){
   def urlSt = "$tacUrl/metaServlet?${request.toString().bytes.encodeBase64()}"
   
   if(debug){
      def scrubbedRequest = request.toString()
      if(scrubbedRequest.contains(tacPassword)){
         scrubbedRequest = scrubbedRequest.replace(tacPassword, "********")
      }
      println "    >> MetaServlet request : $scrubbedRequest"
      println "    >> MetaServlet url Call: $urlSt"
   }
   
   def tresp = urlSt.toURL().text
   
   if(debug) {
      print "    >> MetaServlet response : "
      println groovy.json.JsonOutput.prettyPrint(tresp)
   }
   
   def ms_response = new groovy.json.JsonSlurper().parseText(tresp)
   
   if(debug) {
      println "    >> MetaServlet ReturnCode= $ms_response.returnCode"
   }
   
   return ms_response
}

def appendBuildReport(reportFile, reportString){
   reportFile.append(reportString)
   reportFile.append(System.getProperty("line.separator"))
}