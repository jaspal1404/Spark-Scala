/**
 * Created by Jesen on 04/20/2016
 */
//@Grab('org.apache.ivy:ivy:2.4.0')
//@Grab('com.github.groovy-wslite:groovy-wslite:1.1.0')
//import wslite.rest.*
//import wslite.http.auth.*
//import wslite.util.*
@Grab('org.apache.commons:commons-csv:1.2')
import org.apache.commons.csv.*;
import static org.apache.commons.csv.CSVFormat.*

import java.nio.file.*;
import java.nio.charset.*;
import java.nio.*;

import groovy.transform.Sortable;
import groovy.transform.ToString;

import groovy.json.*
import groovy.xml.*
import groovy.util.*

import java.util.Map;
import java.util.Map.Entry;

import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

def env              = System.getenv()
buildListPath        = env['DEPLOY_LIST_PATH']
masterBuildList      = env['NON_TALEND_MASTER_BUILD_LIST_FILE']
buildUrl             = env['BUILD_URL']
supportFilePath      = env['CODEHUB_TALEND_SUPPORT_FILES_REPOSITORY']
branch               = env['GIT_BRANCH_NAME']

def xpathString = "api/xml?wrapper=changeSet&xpath=//changeSet//item&exclude=//changeSet//item//*[((self::commitId)or(self::timestamp)or(self::comment)or(self::date)or(self::path)or(self::revision)or(self::user))]&exclude=//changeSet//item[(contains(.,'useless'))or(contains(.,'auto%20comment'))]"

def changeSetText = (buildUrl + xpathString).toURL().text

def changeSetXML = new XmlSlurper().parseText(changeSetText)

//assert changeSetXML instanceof groovy.util.slurpersupport.GPathResult 

//println XmlUtil.serialize(changeSetXML)

enum BuildListHeader {
   DEPLOY_OBJECT("DEPLOY_OBJECT"),
   DEPLOY_FLAG("DEPLOY_FLAG"),
   ENV_AGNOSTIC("ENV_AGNOSTIC"),
   TARGET("TARGET"),
   TARGET_TYPE("TARGET_TYPE"),
   USE_SYMLINK("USE_SYMLINK"),
   TAGS("TAGS"),
   DESCRIPTION("DESCRIPTION"),
   user_email("user_email")
    
   private String headerLabel;
    
   private BuildListHeader(String headerLabel){
      this.headerLabel = headerLabel;
   }
   public String headerLabelValue() {return headerLabel}
}


@Sortable(excludes = ['DEPLOY_FLAG', 'ENV_AGNOSTIC', 'USE_SYMLINK'])
@ToString
class BuildJobs{
   String DEPLOY_OBJECT;
   boolean DEPLOY_FLAG;
   boolean ENV_AGNOSTIC;
   String TARGET;
   String TARGET_TYPE;
   boolean USE_SYMLINK;
   String TAGS;
   String DESCRIPTION;
   String userEmail;
}

List derivedJobsList = new ArrayList()
Map<String, Set> buildListPerBranch = new TreeMap<String, Set>()
def jobList = []
changeSetXML.item.each{ eachItem ->
   msg = eachItem.msg.text()
   //println "msg: ${msg}"
   userURL = eachItem.author.absoluteUrl.text()
   //println "userURL: ${userURL}"
   
   userURLapi = userURL + "/api/xml?wrapper=userEmail&xpath=//user//property//address"
   //println "userURLapi: ${userURLapi}"
   userEmail = userURLapi.toURL().text
   //println "userEmail: ${userEmail}"
   def userEmailXml = new XmlSlurper().parseText(userEmail)
   userEmailAddress = userEmailXml.address.text()
   //println "userEmailAddress: ${userEmailAddress}" 
   
   eachItem.affectedPath.each{eachPath ->
      if("${eachPath}".contains(supportFilePath)){
         //println "eachPath: ${eachPath}"
         jobList = checkMasterBuildList("${eachPath}", userEmailAddress)
      }
      
      if(jobList != null && jobList.size() > 0){
         Set<BuildJobs> jobsListUnique  = new TreeSet<BuildJobs>();
         jobsListUnique.addAll(jobList)
         if(buildListPerBranch != null && buildListPerBranch.containsKey(branch)){
            jobsListUnique.addAll(buildListPerBranch.get(branch))
         }
         buildListPerBranch.put(branch, jobsListUnique)
      }
   }
   
}

if(buildListPerBranch != null && buildListPerBranch.size() > 0){
   for(Map.Entry<String, Set> eachBranch in buildListPerBranch.entrySet()){
      List branchList = new ArrayList()
      branchList.addAll(eachBranch.getValue())
      String branchName = eachBranch.getKey()
      if(branchList != null && branchList.size() > 0){
         createDerivedJobList(branchName, branchList)
      }
   }
}


def createDerivedJobList(branch, derivedJobsList){
   if(derivedJobsList != null && derivedJobsList.size() > 0){
      if(!Files.exists(Paths.get(buildListPath))){
         Files.createDirectory(Paths.get(buildListPath))
      }
      
      List<BuildListHeader> csvHeader = Arrays.asList(BuildListHeader.values());
      def csvHeaderLabels = []
      csvHeader.each{ eachLabel ->
         csvHeaderLabels << eachLabel.headerLabelValue()
      }
      //println csvHeaderLabels
      FileWriter fileWriter = null;
      CSVPrinter csvFilePrinter = null;
      CSVFormat csvFileFormat = CSVFormat.DEFAULT.withRecordSeparator(System.lineSeparator());
      try{
         fileWriter = new FileWriter(buildListPath + FileSystems.getDefault().getSeparator().toString() + "NON_TALEND_DEPLOY_LIST_OVERRIDE");
         csvFilePrinter = new CSVPrinter(fileWriter, csvFileFormat);
         csvFilePrinter.printRecord(csvHeaderLabels);
         derivedJobsList.each{ eachJob ->
            List eachRecord = new ArrayList();
            eachRecord.add(eachJob.DEPLOY_OBJECT.toString());
            eachRecord.add(eachJob.DEPLOY_FLAG.toString());
            eachRecord.add(eachJob.ENV_AGNOSTIC.toString());
            eachRecord.add(eachJob.TARGET.toString());
            eachRecord.add(eachJob.TARGET_TYPE.toString());
            eachRecord.add(eachJob.USE_SYMLINK.toString());
            eachRecord.add(eachJob.TAGS.toString());
            eachRecord.add(eachJob.DESCRIPTION.toString());
            eachRecord.add(eachJob.userEmail.toString());
            csvFilePrinter.printRecord(eachRecord);
         }
         println "CSV file was created successfully !!!"
      }
      catch(all){
         println all
      }
      finally{
         try{
            fileWriter.flush();
            fileWriter.close();
            csvFilePrinter.close();
         }
         catch(IOException ioe){
            println ioe
         }
      }
   }
   else{
      println "change set does not match anything in master job list. no csv file created"
   }
}


def checkMasterBuildList(affectedPath, userEmailAddress){
   def masterBuildListFile = new FileNameFinder().getFileNames(".", "**/$masterBuildList")
   def buildJobList = null
   def jobs_list = []
   if(masterBuildListFile!= null && masterBuildListFile.size() > 0){
      masterBuildListFile.each{
         println "masterBuildListFile file found : ${it.toString()}"
         buildJobList = Paths.get(it)
      }
      try{
         DEPLOY_OBJECT = ""
         DEPLOY_FLAG = true
         ENV_AGNOSTIC = false
         TARGET = ""
         TARGET_TYPE = ""
         TAGS = ""
         USE_SYMLINK = false
         DESCRIPTION = ""
         
         buildJobList.withReader { reader ->
            CSVParser csv = new CSVParser(reader, DEFAULT.withHeader())
            Map csvHeader = csv.getHeaderMap()
            for(eachRecord in csv.getRecords()){
               for(Map.Entry<String, Integer> eachHeader in csvHeader.entrySet()){
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.DEPLOY_OBJECT.headerLabelValue())){
                     DEPLOY_OBJECT = eachRecord."${eachHeader.getKey()}".trim()
                     println DEPLOY_OBJECT
                     //String patternStart = "(.*)process(.*)";
                     //String patternEnd = "[_](\\d)[.](\\d)[.]item(.*)";
                     //String jobNameRegex = patternStart + Job_Name + patternEnd
                     println "checking DEPLOY_OBJECT :'$DEPLOY_OBJECT' and see if it's part of change set message :$affectedPath"
                     //println " also check using regex $jobNameRegex"
                     if(affectedPath.contains(DEPLOY_OBJECT)){
                        println "DEPLOY_OBJECT :$DEPLOY_OBJECT is in master build list"
                     }
                     /*
                     else if(affectedPath.matches(jobNameRegex)){
                        println "Job_Name :$Job_Name is in master build list"
                     }
                     */
                     else{
                        //println "Job_Name :$Job_Name not affected, checking next one"
                        DEPLOY_OBJECT = ""
                        break
                     }
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.DEPLOY_FLAG.headerLabelValue())){
                     DEPLOY_FLAG = "true".equalsIgnoreCase(eachRecord."${eachHeader.getKey()}".trim())
                     //println Task_Name
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.ENV_AGNOSTIC.headerLabelValue())){
                     ENV_AGNOSTIC = "true".equalsIgnoreCase(eachRecord."${eachHeader.getKey()}".trim())
                     //println Dev_Context
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.TARGET.headerLabelValue())){
                     TARGET = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                     //println Dev_JobServer
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.TARGET_TYPE.headerLabelValue())){
                     TARGET_TYPE = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                     //println Dev_RunTask
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.USE_SYMLINK.headerLabelValue())){
                     USE_SYMLINK = "true".equalsIgnoreCase(eachRecord."${eachHeader.getKey()}".trim())
                     //println Test_RunTask
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.TAGS.headerLabelValue())){
                     TAGS = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                     //println Stage_Context
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.DESCRIPTION.headerLabelValue())){
                     DESCRIPTION = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                     //println Stage_JobServer
                  }
               }
      
               if(DEPLOY_OBJECT != null && !"".equalsIgnoreCase(DEPLOY_OBJECT)){
                  jobs_list << ([
                     DEPLOY_OBJECT     : DEPLOY_OBJECT,
                     DEPLOY_FLAG       : DEPLOY_FLAG,
                     ENV_AGNOSTIC      : ENV_AGNOSTIC,
                     TARGET            : TARGET,
                     TARGET_TYPE       : TARGET_TYPE,
                     USE_SYMLINK       : USE_SYMLINK,
                     TAGS              : TAGS,
                     DESCRIPTION       : DESCRIPTION,
                     userEmail         : userEmailAddress
                     ] as BuildJobs)
               }
            }
         }
      }catch(java.nio.charset.MalformedInputException mafe){
         appendBuildReport(buildReport, "MalformedInputException encountered on build list")
         appendBuildReport(buildReport, "Most likely there's a non-ascii/non UTF-8 character in the build list, please fix the build list")
         println "MalformedInputException encountered on build list"
         println "Most likely there's a non-ascii/non UTF-8 character in the build list, please fix the build list"
         System.exit(1)
      }catch(all){
         println "Error reading CSV Job List: $all"
         System.exit(1)
      }
      //println "jobs_list content"
      /*
      if(jobs_list != null){
         jobs_list.each{
            println it.name +"," +it.task +"," +it.devContext +"," +it.devJobServer +"," +it.devRunTask +"," +it.tstContext +"," +it.tstJobServer +"," +it.tstRunTask +"," +it.stgContext +"," +it.stgJobServer +"," +it.stgRunTask +"," +it.prdContext +"," +it.prdJobServer +"," +it.contextValue +"," +it.taskPoolSize
         }
      }
      */
      return jobs_list
   }
}
