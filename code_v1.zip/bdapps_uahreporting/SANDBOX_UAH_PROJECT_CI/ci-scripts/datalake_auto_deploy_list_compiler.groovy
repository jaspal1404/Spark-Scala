/**
 * Created by Jesen on 04/20/2016
 */
//@Grab('org.apache.ivy:ivy:2.4.0')
//@Grab('com.github.groovy-wslite:groovy-wslite:1.1.0')
//import wslite.rest.*
//import wslite.http.auth.*
//import wslite.util.*
@Grab('org.apache.commons:commons-csv:1.2')
import org.apache.commons.csv.*;
import static org.apache.commons.csv.CSVFormat.*

import java.nio.file.*;
import java.nio.charset.*;
import java.nio.*;

import groovy.transform.Sortable;
import groovy.transform.ToString;

import groovy.json.*
import groovy.xml.*
import groovy.util.*

import java.util.Map;
import java.util.Map.Entry;

import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

def env              = System.getenv()
talendListPath       = env['TALEND_DEPLOY_LIST_PATH']
nonTalendListPath    = env['NON_TALEND_DEPLOY_LIST_PATH']
deployEnv            = env['DEPLOY_ENVIRONMENT']
notificationEmailFile   = env['NOTIFICATION_EMAIL_FILE']

def notificationsProp = null
if(notificationEmailFile != null){
   notificationsProp = new File(notificationEmailFile)
}
else{
   notificationsProp = new File("NOTIFICATIONS.properties")
}
notificationsProp.append("#" + System.getProperty("line.separator"))

enum BuildListHeader {
   Job_Name("Job_Name"),
   Task_Name("Task_Name"),
   Dev_Context("Dev_Context"),
   Dev_JobServer("Dev_JobServer"),
   Dev_RunTask("Dev_RunTask"),
   Test_Context("Test_Context"),
   Test_JobServer("Test_JobServer"),
   Test_RunTask("Test_RunTask"),
   Stage_Context("Stage_Context"),
   Stage_JobServer("Stage_JobServer"),
   Stage_RunTask("Stage_RunTask"),
   Prod_Context("Prod_Context"),
   Prod_JobServer("Prod_JobServer"),
   context_value("context_value"),
   task_pool_size("task_pool_size")
    
   private String headerLabel;
    
   private BuildListHeader(String headerLabel){
      this.headerLabel = headerLabel;
   }
   public String headerLabelValue() {return headerLabel}
}

@Sortable
@ToString
class BuildJobs {
   String name, task, taskPoolSize;
   String devContext, devJobServer, devRunTask;
   String testContext, testJobServer, testRunTask;
   String stageContext, stageJobServer, stageRunTask;
   String prodContext, prodJobServer, prodRunTask;
   String contextValue;
   String userEmail;
}

enum NonTalendListHeader {
   DEPLOY_OBJECT("DEPLOY_OBJECT"),
   DEPLOY_FLAG("DEPLOY_FLAG"),
   ENV_AGNOSTIC("ENV_AGNOSTIC"),
   TARGET("TARGET"),
   TARGET_TYPE("TARGET_TYPE"),
   USE_SYMLINK("USE_SYMLINK"),
   TAGS("TAGS"),
   DESCRIPTION("DESCRIPTION")
    
   private String headerLabel;
    
   private NonTalendListHeader(String headerLabel){
      this.headerLabel = headerLabel;
   }
   public String headerLabelValue() {return headerLabel}
}


@Sortable(excludes = ['DEPLOY_FLAG', 'ENV_AGNOSTIC', 'USE_SYMLINK'])
@ToString
class NonTalendDeployObjects{
   String DEPLOY_OBJECT;
   String DEPLOY_FLAG;
   String ENV_AGNOSTIC;
   String TARGET;
   String TARGET_TYPE;
   String USE_SYMLINK;
   String TAGS;
   String DESCRIPTION;
   String userEmail;
}

enum DeployEnvironment {
    DEV("DEV_631", "Default", "dev"),
    TST("TST_631", "Default", "tst"),
    PRD("PRD_631", "Default", "prd"),
    LAKEDEV("lakedev", "Default", "dev"),
    LAKETST("odfr2tst", "Default", "tst"),
    LAKEPRD("lakeprd", "Default", "prd")
    
    private String envLabel;
    private String defaultContext;
    private String environment;
    
    private DeployEnvironment(String env, String defaultContext, String environment){
      this.envLabel = env;
      this.defaultContext = defaultContext;
      this.environment = environment
    }
    
    public String envLabelValue() {return envLabel}
    public String defaultContextValue() {return defaultContext}
    public String environmentValue() {return environment}
    
}
DeployEnvironment deployEnvironment = DeployEnvironment."${deployEnv.toUpperCase()}"

def jobs_list = []
def notification_list = []  //List to send notification email to. email address should be derived from build list.

//check build list override

buildListOverrideFileName = "**/${talendListPath}/${deployEnv}/**/*.csv"
buildListOverrideFile = new FileNameFinder().getFileNames(".", buildListOverrideFileName)
if(buildListOverrideFile != null && buildListOverrideFile.size() > 0){
   println "Datalake Deployment config files found"
   buildListOverrideFile.each{
      println "Datalake Deployment config file found : ${it.toString()}"
      Path buildJobList = Paths.get(it)
      
      try{
         Job_Name = ""
         Task_Name = ""
         Dev_Context = ""
         Dev_JobServer = ""
         Dev_RunTask = ""
         Test_Context = ""
         Test_JobServer = ""
         Test_RunTask = ""
         Stage_Context = ""
         Stage_JobServer = ""
         Stage_RunTask = ""
         Prod_Context = ""
         Prod_JobServer = ""
         context_value = ""
         task_pool_size = ""
         Prod_RunTask = ""
         user_email = ""
               
               
         buildJobList.withReader { reader ->
            CSVParser csv = new CSVParser(reader, DEFAULT.withHeader())
            Map csvHeader = csv.getHeaderMap()
            for(eachRecord in csv.getRecords()){
               
               for(Map.Entry<String, Integer> eachHeader in csvHeader.entrySet()){
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Job_Name.headerLabelValue())){
                     Job_Name = eachRecord."${eachHeader.getKey()}".trim()
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Task_Name.headerLabelValue())){
                     Task_Name = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.context_value.headerLabelValue())){
                     context_value = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.task_pool_size.headerLabelValue())){
                     task_pool_size = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : "1"
                  }
                  
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Dev_Context.headerLabelValue())){
                     Dev_Context = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Dev_JobServer.headerLabelValue())){
                     Dev_JobServer = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Dev_RunTask.headerLabelValue())){
                     Dev_RunTask = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                  }
                  
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Test_Context.headerLabelValue())){
                     Test_Context = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Test_JobServer.headerLabelValue())){
                     Test_JobServer = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Test_RunTask.headerLabelValue())){
                     Test_RunTask = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                  }
                  
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Stage_Context.headerLabelValue())){
                     Stage_Context = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Stage_JobServer.headerLabelValue())){
                     Stage_JobServer = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Stage_RunTask.headerLabelValue())){
                     Stage_RunTask = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                  }
                  
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Prod_Context.headerLabelValue())){
                     Prod_Context = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Prod_JobServer.headerLabelValue())){
                     Prod_JobServer = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                  }
               }
              
               jobs_list << ([
                  name           : Job_Name,
                  task           : Task_Name,
                  devContext     : Dev_Context,
                  devJobServer   : Dev_JobServer,
                  devRunTask     : Dev_RunTask,
                  testContext    : Test_Context,
                  testJobServer  : Test_JobServer,
                  testRunTask    : Test_RunTask,
                  stageContext   : Stage_Context,
                  stageJobServer : Stage_JobServer,
                  stageRunTask   : Stage_RunTask,
                  prodContext    : Prod_Context,
                  prodJobServer  : Prod_JobServer,
                  contextValue   : context_value,
                  taskPoolSize   : task_pool_size,
                  userEmail      : user_email
                  ] as BuildJobs)
                  
            }
         }
      }
      catch(java.nio.charset.MalformedInputException mafe){
         println "MalformedInputException encountered on build list"
         println "Most likely there's a non-ascii/non UTF-8 character in the build list, please fix the build list"
      }
      catch(all){
         println "Error reading CSV Job List: $all"
      }
   }
}
else{
}
createDerivedTalendJobList(jobs_list, notificationsProp)

def nonTalendList = []
nonTalendDeployListOverrideFilename = "**/${nonTalendListPath}/${deployEnv}/**/*.csv"
nonTalendDeployListOverrideFiles = new FileNameFinder().getFileNames(".", nonTalendDeployListOverrideFilename)
if(nonTalendDeployListOverrideFiles != null && nonTalendDeployListOverrideFiles.size() > 0){
   println "Datalake Non-Talend Deployment config files found"
   nonTalendDeployListOverrideFiles.each{
      println "Datalake Non-Talend Deployment config file found : ${it.toString()}"
      Path buildJobList = Paths.get(it)
      
      try{
         deployObject = ""
         deployFlag = ""
         envAgnostic = ""
         target = ""
         targetType = ""
         useSymlink = ""
         tags = ""
         description = ""
         useremail = ""
         
         buildJobList.withReader { reader ->
            CSVParser csv = new CSVParser(reader, DEFAULT.withHeader())
            Map csvHeader = csv.getHeaderMap()
            for(eachRecord in csv.getRecords()){
               
               for(Map.Entry<String, Integer> eachHeader in csvHeader.entrySet()){
                  if(eachHeader.getKey().equalsIgnoreCase(NonTalendListHeader.DEPLOY_OBJECT.headerLabelValue())){
                     deployObject = eachRecord."${eachHeader.getKey()}".trim()
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(NonTalendListHeader.DEPLOY_FLAG.headerLabelValue())){
                     deployFlag = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(NonTalendListHeader.ENV_AGNOSTIC.headerLabelValue())){
                     envAgnostic = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(NonTalendListHeader.TARGET.headerLabelValue())){
                     target = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(NonTalendListHeader.TARGET_TYPE.headerLabelValue())){
                     targetType = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(NonTalendListHeader.USE_SYMLINK.headerLabelValue())){
                     useSymlink = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(NonTalendListHeader.TAGS.headerLabelValue())){
                     tags = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(NonTalendListHeader.DESCRIPTION.headerLabelValue())){
                     description = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                  }
               }
              
               nonTalendList << ([
                  DEPLOY_OBJECT     : deployObject,
                  DEPLOY_FLAG       : deployFlag,
                  ENV_AGNOSTIC      : envAgnostic,
                  TARGET            : target,
                  TARGET_TYPE       : targetType,
                  USE_SYMLINK       : useSymlink,
                  TAGS              : tags,
                  DESCRIPTION       : description,
                  userEmail         : useremail
                  ] as NonTalendDeployObjects)
                  
            }
         }
      }
      catch(java.nio.charset.MalformedInputException mafe){
         println "MalformedInputException encountered on build list"
         println "Most likely there's a non-ascii/non UTF-8 character in the build list, please fix the build list"
      }
      catch(all){
         println "Error reading CSV Job List: $all"
      }
   }
}
else{
}
createDerivedNonTalendDeployList(nonTalendList, notificationsProp)

def createDerivedTalendJobList(derivedJobsList, notificationsProp){
   if(derivedJobsList != null && derivedJobsList.size() > 0){
      
      List<BuildListHeader> csvHeader = Arrays.asList(BuildListHeader.values());
      def csvHeaderLabels = []
      csvHeader.each{ eachLabel ->
         csvHeaderLabels << eachLabel.headerLabelValue()
      }
      //println csvHeaderLabels
      FileWriter fileWriter = null;
      CSVPrinter csvFilePrinter = null;
      CSVFormat csvFileFormat = CSVFormat.DEFAULT.withRecordSeparator(System.lineSeparator());
      
      try{
         fileWriter = new FileWriter("." + FileSystems.getDefault().getSeparator().toString() + "BUILD_LIST_OVERRIDE");
         csvFilePrinter = new CSVPrinter(fileWriter, csvFileFormat);
         csvFilePrinter.printRecord(csvHeaderLabels);
         derivedJobsList.each{ eachJob ->
            List eachRecord = new ArrayList();
            eachRecord.add(eachJob.name.toString());
            eachRecord.add(eachJob.task.toString());
            eachRecord.add(eachJob.devContext.toString());
            eachRecord.add(eachJob.devJobServer.toString());
            eachRecord.add(eachJob.devRunTask.toString());
            eachRecord.add(eachJob.testContext.toString());
            eachRecord.add(eachJob.testJobServer.toString());
            eachRecord.add(eachJob.testRunTask.toString());
            eachRecord.add(eachJob.stageContext.toString());
            eachRecord.add(eachJob.stageJobServer.toString());
            eachRecord.add(eachJob.stageRunTask.toString());
            eachRecord.add(eachJob.prodContext.toString());
            eachRecord.add(eachJob.prodJobServer.toString());
            eachRecord.add(eachJob.contextValue.toString());
            eachRecord.add(eachJob.taskPoolSize.toString());
            csvFilePrinter.printRecord(eachRecord);
         }
         println "CSV file was created successfully !!!"
         notificationsProp.append("BUILD_LIST_OVERRIDE=BUILD_LIST_OVERRIDE")
         notificationsProp.append(System.getProperty("line.separator"))
      }
      catch(all){
         println all
      }
      finally{
         try{
            fileWriter.flush();
            fileWriter.close();
            csvFilePrinter.close();
         }
         catch(IOException ioe){
            println ioe
         }
      }
   }
   else{
      println "change set does not match anything in master job list. no csv file created"
   }
}


def createDerivedNonTalendDeployList(derivedJobsList, notificationsProp){
   if(derivedJobsList != null && derivedJobsList.size() > 0){
      
      List<BuildListHeader> csvHeader = Arrays.asList(NonTalendListHeader.values());
      def csvHeaderLabels = []
      csvHeader.each{ eachLabel ->
         csvHeaderLabels << eachLabel.headerLabelValue()
      }
      //println csvHeaderLabels
      FileWriter fileWriter = null;
      CSVPrinter csvFilePrinter = null;
      CSVFormat csvFileFormat = CSVFormat.DEFAULT.withRecordSeparator(System.lineSeparator());
      try{
         fileWriter = new FileWriter("." + FileSystems.getDefault().getSeparator().toString() + "NON_TALEND_DEPLOY_LIST_OVERRIDE");
         csvFilePrinter = new CSVPrinter(fileWriter, csvFileFormat);
         csvFilePrinter.printRecord(csvHeaderLabels);
         derivedJobsList.each{ eachJob ->
            List eachRecord = new ArrayList();
            eachRecord.add(eachJob.DEPLOY_OBJECT.toString());
            eachRecord.add(eachJob.DEPLOY_FLAG.toString());
            eachRecord.add(eachJob.ENV_AGNOSTIC.toString());
            eachRecord.add(eachJob.TARGET.toString());
            eachRecord.add(eachJob.TARGET_TYPE.toString());
            eachRecord.add(eachJob.USE_SYMLINK.toString());
            eachRecord.add(eachJob.TAGS.toString());
            eachRecord.add(eachJob.DESCRIPTION.toString());
            csvFilePrinter.printRecord(eachRecord);
         }
         println "CSV file was created successfully !!!"
         notificationsProp.append("NON_TALEND_DEPLOY_LIST_OVERRIDE=NON_TALEND_DEPLOY_LIST_OVERRIDE")
         notificationsProp.append(System.getProperty("line.separator"))
      }
      catch(all){
         println all
      }
      finally{
         try{
            fileWriter.flush();
            fileWriter.close();
            csvFilePrinter.close();
         }
         catch(IOException ioe){
            println ioe
         }
      }
   }
   else{
      println "change set does not match anything in master job list. no csv file created"
   }
}
