/**
 * Created by Jesen on 0/15/2017.
 */
@Grab('org.apache.commons:commons-csv:1.2')
import org.apache.commons.csv.CSVParser
import static org.apache.commons.csv.CSVFormat.*

import groovy.transform.Sortable;
import groovy.transform.ToString;
import groovy.time.*

import java.nio.file.*;
import java.nio.charset.*;
import java.nio.*;

import java.util.Set;
import java.util.TreeSet;

import org.talend.commandline.client.*;
import org.talend.commandline.client.command.*;
import org.talend.commandline.client.command.extension.PublishJobServerCommand;

def env = System.getenv()

////////////////////////////////////////////////////////
//these properties should be retrieved from jenkins build parameter
branchName              = env['BRANCH_NAME']
buildListOverride       = env['BUILD_LIST_OVERRIDE']
///////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////
//these properties should be contained in the common.server.properties file in svn
project                 = env['PROJECT_NAME']
deployEnv               = env['DEPLOY_ENVIRONMENT']

cmdLineHost             = env['CMDLINE_HOST']
cmdLinePort             = env['CMDLINE_PORT']

nexusUrl                = env['ARTIFACT_REPO_URL']
nexusSnapshotRepository = env['SNAPSHOT_ARTIFACT_REPO_NAME']
nexusReleaseRepository  = env['RELEASE_ARTIFACT_REPO_NAME']

landingDir              = env["ARTIFACT_LANDING_DIR"]
currentReleaseVersion   = env["CURRENT_RELEASE_VERSION"]
branchNameUnusedPattern = env["BRANCH_NAME_UNUSED_PATTERN"]
//////////////////////////////////////////////////////////////////////////////

///////////////////////////////////
//these properties should be contained in the server-properties file in svn

tacUrl                  = env['TAC_URL']
//////////////////////////////////////////////////////////////////////////////

debug                   = "true".equalsIgnoreCase(env['CI_DEBUG'])

ciWorkspace             = env['WORKSPACE']
ciJobName               = env['JOB_NAME']

svnRevision             = env['GIT_COMMIT'].toString().substring(0, 8)
svnURL                  = env['GIT_URL']


tacUser                 = env['TAC_USER']
tacPassword             = env['TAC_PASSWORD']

nexusUser               = env['NEXUS_USER']
nexusPassword           = env['NEXUS_PWD']

buildReportFile         = env['BUILD_REPORT_FILE']
notificationEmailFile   = env['NOTIFICATION_EMAIL_FILE']
jenkinsJobStartTime     = env['JENKINS_JOB_START_TIME']
//////////////////////////////////////////////////////////////////////////

def ms_request = new groovy.json.JsonBuilder()
def ms_response

def timeStart
if(jenkinsJobStartTime != null){
   timeStart = Date.parseToStringDate(jenkinsJobStartTime) 
}
else{
   timeStart = new Date()
}
def timeStop

//def build = Thread.currentThread().executable

def buildReport = null
if(buildReportFile != null){
   buildReport = new File(buildReportFile)
}
else{
   buildReport = new File("BuildReport.txt")
}

def notificationsProp = null
if(notificationEmailFile != null){
   notificationsProp = new File(notificationEmailFile)
}
else{
   notificationsProp = new File("NOTIFICATIONS.properties")
}
notificationsProp.append("#" + System.getProperty("line.separator"))

appendBuildReport(buildReport, "----------------------------------------------------")
appendBuildReport(buildReport, "Report for build tag: " + env["BUILD_TAG"])
appendBuildReport(buildReport, "Jenkins URL: " + env["BUILD_URL"])

//----------------------------
//---------- Step 0 ----------
//----------------------------
println "----------------------------------------------------"
println "-- Step 0: Set Build environment variables"
println "----------------------------------------------------"

releaseVersion = currentReleaseVersion


if(releaseVersion != null && !"".equalsIgnoreCase(releaseVersion.trim())){
   println "branch name: ${branchName} release version  : $releaseVersion"
}
else{
   println "CURRENT_RELEASE_VERSION is required environment parameter"
   System.exit(1)
}

appendBuildReport(buildReport, "Build is executed against branch: " + branchName + " branch URL: " + env["GIT_URL"])
tacHost = tacUrl.toURL().host

//custom nexus group name for ODF_ODF talend project
//this needs to be done for backward compatibility with legacy codes
//make sure the deployment script use this custom group as well
nexusGroup      = "v" + releaseVersion.replace(".", "_")

nexusRepositoryUrl = "$nexusUrl/content/repositories/$nexusSnapshotRepository/${project}"

def now = Calendar.getInstance(TimeZone.getTimeZone("America/Chicago")).format("yyyy.MM.dd 'at' HH:mm:ss z")

println "----------------------------------------------------"
println "-- Step 0-A: Get Jobs list to build"
println "----------------------------------------------------"

enum BuildListHeader {
   Job_Name("Job_Name"),
   Task_Name("Task_Name"),
   Dev_Context("Dev_Context"),
   Dev_JobServer("Dev_JobServer"),
   Dev_RunTask("Dev_RunTask"),
   Test_Context("Test_Context"),
   Test_JobServer("Test_JobServer"),
   Test_RunTask("Test_RunTask"),
   Stage_Context("Stage_Context"),
   Stage_JobServer("Stage_JobServer"),
   Stage_RunTask("Stage_RunTask"),
   Prod_Context("Prod_Context"),
   Prod_JobServer("Prod_JobServer"),
   context_value("context_value"),
   task_pool_size("task_pool_size"),
   user_email("user_email")
    
   private String headerLabel;
    
   private BuildListHeader(String headerLabel){
      this.headerLabel = headerLabel;
   }
   public String headerLabelValue() {return headerLabel}
}

@Sortable(excludes = ['devRunTask', 'tstRunTask', 'stgRunTask'])
@ToString
class BuildJobs{
   String name;
   String task;
   String devContext;
   String devJobServer;
   boolean devRunTask;
   String tstContext;
   String tstJobServer;
   boolean tstRunTask;
   String stgContext
   String stgJobServer;
   boolean stgRunTask;
   String prdContext;
   String prdJobServer;
   String contextValue;
   String taskPoolSize;
   String userEmail;
}

Path buildJobList = Paths.get(env["JOBS_LIST_CSV_FILE"])

def jobs_list = []  // User overwrite of jobs to process
def notification_list = []  //List to send notification email to. email address should be derived from build list.

//check build list override
if(buildListOverride != null && !"".equals(buildListOverride)){
   buildListOverrideFileName = "**/BUILD_LIST_OVERRIDE"
   buildListOverrideFile = new FileNameFinder().getFileNames(".", buildListOverrideFileName)
   if(buildListOverrideFile != null && buildListOverrideFile.size() > 0){
      println "BUILD_LIST_OVERRIDE file found"
      buildListOverrideFile.each{
         println "BUILD_LIST_OVERRIDE file found : ${it.toString()}"
         buildJobList = Paths.get(it)
      }
   }
}

def build_map = [:]
try{
   Job_Name = ""
   user_email = ""
   
   buildJobList.withReader { reader ->
      CSVParser csv = new CSVParser(reader, DEFAULT.withHeader())
      Map csvHeader = csv.getHeaderMap()
      for(eachRecord in csv.getRecords()){
         for(Map.Entry<String, Integer> eachHeader in csvHeader.entrySet()){
            if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Job_Name.headerLabelValue())){
               Job_Name = eachRecord."${eachHeader.getKey()}".trim()
            }
            if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.user_email.headerLabelValue())){
               user_email = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
            }
         }
         if(Job_Name != null && !"".equalsIgnoreCase(Job_Name)){
            jobs_list << ([
               name         : Job_Name
               ] as BuildJobs)
            
            if(user_email != null && !"".equalsIgnoreCase(user_email)){
               notification_list << ([
                  name        : Job_Name,
                  userEmail   : user_email
                  ] as BuildJobs)
            }
         }
      }
   }
}
catch(java.nio.charset.MalformedInputException mafe){
   appendBuildReport(buildReport, "MalformedInputException encountered on build list")
   appendBuildReport(buildReport, "Most likely there's a non-ascii/non UTF-8 character in the build list, please fix the build list")
   println "MalformedInputException encountered on build list"
   println "Most likely there's a non-ascii/non UTF-8 character in the build list, please fix the build list"
   System.exit(1)
}
catch(all){
    println "Error reading CSV Job List: $all"
    System.exit(1)
}

println "    svnRevision: '$svnRevision'"
println "    svnURL: '$svnURL'"
println "    branchName: '$branchName'"

Set<String> jobs_list_unique  = new TreeSet<String>();
jobs_list.each {
   if(it.name.trim().length() > 0){
      jobs_list_unique.add(it.name.trim())
   }
}

Set<String> email_list_unique  = new TreeSet<String>();
notification_list.each{ eachNotification ->
   if(eachNotification.userEmail != null && !"".equalsIgnoreCase(eachNotification.userEmail)){
      email_list_unique.add(eachNotification.userEmail.trim())
   }
}

def emailList = ""
email_list_unique.each{
   emailList += it + ","
}

if(emailList != null && !"".equalsIgnoreCase(emailList)){
   if(emailList.endsWith(",")){
      emailList = emailList.substring(0, emailList.lastIndexOf(","))
   }
   notificationsProp.append("EMAIL_LIST=" + emailList)
   notificationsProp.append(System.getProperty("line.separator"))
}

//----------------------------
//---------- Step 1 ----------
//----------------------------
println "----------------------------------------------------"
println "-- Step 1: Get TAC info"
println "----------------------------------------------------"

println "   - CmdLine Host:port  = $cmdLineHost:$cmdLinePort"
appendBuildReport(buildReport, "Build is executed in command line: $cmdLineHost:$cmdLinePort")
//----------------------------
//---------- Step 2 ----------
//----------------------------
svnSource       = "branches/" + branchName
tagName = "tags/SNAP-"
tagName += "${releaseVersion}.${svnRevision}"

println "----------------------------------------------------"
println "-- Step 2: Create Tag for svn source: '$svnSource' "
println "----------------------------------------------------"

println "   - Tag: '$tagName'"

ms_request (
   actionName  : 'createTag',
   authUser    : tacUser,
   authPass    : tacPassword,
   projectName : project,
   source      : svnSource,
   target      : tagName
)
ms_response = metaServletCall(tacUrl, ms_request)

if(ms_response.returnCode != 0){
   if("$ms_response.error" == "Project already contains a branch '$tagName'"){
      println "$ms_response.error forcing build process with the same tag"
      appendBuildReport(buildReport, "Project already contains a branch '$tagName'")
   }
   else{
      println "   - Error creating project tag. Error= $ms_response.error"
      System.exit(1)
   }
}
else{
   println "   - tags creation successful"
   appendBuildReport(buildReport, "'$tagName' tags creation successful")
}

//----------------------------
//---------- Step 3 ----------
//----------------------------
println "----------------------------------------------------"
println "-- Step 3: Build Jobs on the remote CommandLine."
println "----------------------------------------------------"

println "    - List of Jobs to build:"
for (String each : jobs_list_unique) {
   println "      - Job:'$each'"
   
   def buildJobsCommand = new BuildJobsCommand(each, tacUrl, tacUser, tacPassword,
      project, tagName, nexusRepositoryUrl, nexusUser, nexusPassword,
      releaseVersion, nexusGroup, "CI '$ciJobName' Build#$svnRevision", 
      cmdLineHost, cmdLinePort)
      
   build_map.put(each, buildJobsCommand)
}

build_map.each{ eachTask ->
   eachTask.value.buildJobs()
}


/******************************
//skip the retry for now, most build failures are caused by compile error and need to be fixed manually
//retry if there's any error
build_map.each{ eachTask ->
   if(eachTask.value.buildJobStatus.equalsIgnoreCase("ERROR")){
      eachTask.value.buildJobs()
   }
}
**************************************/

def jobList = ""
def build_success = [:]
appendBuildReport(buildReport, "----------------------------------------------------")
appendBuildReport(buildReport, "BUILD REPORT SUMMARY")
build_map.each{ eachTask ->
   appendBuildReport(buildReport, "JOB: ${eachTask.key} BUILD STATUS: ${eachTask.value.buildJobStatus}")
   if(!eachTask.value.buildJobStatus.equalsIgnoreCase("ERROR")){
      build_success.put(eachTask.key, eachTask.value)
   }
   jobList += eachTask.key.toString() + "-" + eachTask.value.buildJobStatus.toString() + ","
}
appendBuildReport(buildReport, "----------------------------------------------------")

appendBuildReport(buildReport, "----------------------------------------------------")
appendBuildReport(buildReport, "BUILD REPORT DETAIL")
build_map.each{ eachTask ->
   appendBuildReport(buildReport, "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
   appendBuildReport(buildReport, "JOB: " + eachTask.key)
   appendBuildReport(buildReport, "BUILD COMMAND ID: " + eachTask.value.commandID)
   appendBuildReport(buildReport, "BUILD STATUS: " + eachTask.value.buildJobStatus)
   appendBuildReport(buildReport, "BUILD START: " + eachTask.value.metric.timeStart.format("EEE MMM dd HH:mm:ss zzz yyyy", TimeZone.getTimeZone("America/Chicago")))
   appendBuildReport(buildReport, "BUILD FINISHED: " + eachTask.value.metric.timeStop.format("EEE MMM dd HH:mm:ss zzz yyyy", TimeZone.getTimeZone("America/Chicago")))
   appendBuildReport(buildReport, "BUILD DURATION: " + eachTask.value.metric.duration)
   appendBuildReport(buildReport, "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
}
appendBuildReport(buildReport, "----------------------------------------------------")
appendBuildReport(buildReport, "")

timeStop = new Date()
TimeDuration duration = TimeCategory.minus(timeStop, timeStart)
appendBuildReport(buildReport, "Build process started at " + timeStart.format("EEE MMM dd HH:mm:ss zzz yyyy", TimeZone.getTimeZone("America/Chicago")))
appendBuildReport(buildReport, "Build process finished at " + timeStop.format("EEE MMM dd HH:mm:ss zzz yyyy", TimeZone.getTimeZone("America/Chicago")))
appendBuildReport(buildReport, "Build process total duration: ${duration}")
appendBuildReport(buildReport, "----------------------------------------------------")
appendBuildReport(buildReport, "----------------------------------------------------")
appendBuildReport(buildReport, "")
notificationsProp.append("JENKINS_JOB_END_TIME=" + timeStop.format("EEE MMM dd HH:mm:ss zzz yyyy", TimeZone.getTimeZone("America/Chicago")))
notificationsProp.append(System.getProperty("line.separator"))
notificationsProp.append("JENKINS_JOB_DURATION=" + duration.toString())
notificationsProp.append(System.getProperty("line.separator"))

if(jobList != null && !"".equalsIgnoreCase(jobList)){
   if(jobList.endsWith(",")){
      jobList = jobList.substring(0, jobList.lastIndexOf(","))
   }
   notificationsProp.append("JOB_LIST=" + jobList)
   notificationsProp.append(System.getProperty("line.separator"))
}

if(build_success.size() == 0){
   appendBuildReport(buildReport, "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
   appendBuildReport(buildReport, "ERROR = ALL BUILD FAILED" )
   appendBuildReport(buildReport, "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
   println "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
   println "ERROR = ALL BUILD FAILED"
   println "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
}
else if(build_map.size() == build_success.size()){
   appendBuildReport(buildReport, "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
   appendBuildReport(buildReport, "SUCCESS = ALL BUILD SUCCESSFUL" )
   appendBuildReport(buildReport, "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
   println "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
   println "SUCCESS = ALL BUILD SUCCESSFUL"
   println "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
}
else{
   appendBuildReport(buildReport, "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
   appendBuildReport(buildReport, "PARTIAL SUCCESS = SOME BUILD FAILED, PLEASE CHECK THE BUILD SUMMARY AND DETAILS FOR INFORMATION" )
   appendBuildReport(buildReport, "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
   println "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
   println "PARTIAL SUCCESS = SOME BUILD FAILED, PLEASE CHECK THE BUILD SUMMARY AND DETAILS FOR INFORMATION"
   println "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
}

/****************
def branch  = tagName
def buildOrigin  = "CI '$ciJobName' Build#$svnRevision"

def client = new CommandLineJavaClient(cmdLineHost, Integer.valueOf(cmdLinePort))

try {
   println "   - Connection to CommandLine at: '$cmdLineHost:$cmdLinePort'"
   client.connect()
   println "     - Connected. Version= '${client.getServerVersion()}'"
   
   List<JavaServerCommand> cmdList = []
   
   println "   - InitRemote: $tacUrl, user:$tacUser, pwd:*****"
   cmdList << new InitRemoteCommand(
                     tacUrl,
                     tacUser,
                     tacPassword
                     )
   
   println "   - LogonProject: $project, user:$tacUser, pwd:*****, branch:'$branch'"
   cmdList << new LogonProjectCommand(
                     project,
                     tacUser,
                     tacPassword,
                     false,
                     branch
                     )
                     
   appendBuildReport(buildReport, "Publishing to Nexus repository '$nexusRepositoryUrl' with group id: '$nexusGroup' and publish version: '$releaseVersion'")
   for (String each : jobs_list_unique){
      println "   - Publishing Job: '$each' to '$nexusSnapshotRepository' Nexus repository"
      appendBuildReport(buildReport, "Publishing Job: '$each'")
      
      def pjsc = new PublishJobServerCommand()
      pjsc.setValue "JOB_NAME"                     , each
      pjsc.setValue "ARTIFACT_REPOSITORY"          , nexusRepositoryUrl.toString()
      pjsc.setValue "USERNAME"                     , nexusUser.toString()
      pjsc.setValue "PASSWORD"                     , nexusPassword.toString()
      pjsc.setValue "SNAPSHOT"                     , true
      pjsc.setValue "PUBLISH_VERSION"              , releaseVersion.toString()
      pjsc.setValue "ARTIFACT"                     , each
      pjsc.setValue "GROUP"                        , nexusGroup.toString()
      pjsc.setValue "TYPE"                         , "std"
      pjsc.setValue "JOB_CONTEXT"                  , "Default"
      pjsc.setValue "JOB_APPLY_CONTEXT_TO_CHILDREN", true
      
      def cmdStr = pjsc.writeToString()
      cmdStr += " -p '$nexusPassword'"
      cmdList << new CmdLineJSCommand(cmdStr)
   }
   
   println "   - LogoffProject: $project"
   cmdList << new LogoffProjectCommand()
   try{
      st = client.addCommandAndWait(new CommandGroupCommand(cmdList, buildOrigin))
      println "     - $st"
      if(st.level != CommandStatus.CommandStatusLevel.COMPLETED){
         if("$st".contains("InitRemoteCommand") || "$st".contains("LogonProjectCommand")){
            println "EXCEPTION OCCURED WHEN EXECUTING COMMAND LINE. Caused by build server. Restarting build server"
            def antSSH = new AntBuilder()
            antSSH.sshexec(
               host:"$cmdLineHost",
               username:"$sshUser",
               password:"$sshPassword",
               trust:"true",
               command:"sh  ${cmdStopScript}",
               verbose:false)
            sleep(10000)
            antSSH.sshexec(
               host:"$cmdLineHost",
               username:"$sshUser",
               password:"$sshPassword",
               trust:"true",
               command:"rm -rf ${cmdWorkspace}",
               verbose:false)
            antSSH.sshexec(
               host:"$cmdLineHost",
               username:"$sshUser",
               password:"$sshPassword",
               trust:"true",
               command:"sh  ${cmdStartScript}",
               verbose:false)
            sleep(10000)
            def newClient = new CommandLineJavaClient(cmdLineHost, Integer.valueOf(cmdLinePort))
            println "   - Connection to CommandLine at: '$cmdLineHost:$cmdLinePort'"
            try{
               newClient.connect()
               println "     - Connected. Version= '${newClient.getServerVersion()}'"
            }catch(java.net.ConnectException ce){
               println "   - Connection to CommandLine at: '$cmdLineHost:$cmdLinePort' failed. Sleeping thread for 30 seconds and retrying"
               sleep(30000)
               try{
                  newClient.connect()
                  println "     - Connected. Version= '${newClient.getServerVersion()}'"
               }catch(java.net.ConnectException ce1){
                  ce1.printStackTrace()
                  throw ce1
               }
            }
            st = newClient.addCommandAndWait(new CommandGroupCommand(cmdList, buildOrigin))
            if(st.level != CommandStatus.CommandStatusLevel.COMPLETED){
               throw new Exception("Command failed: $st") //to exit the 'each' closure
            }
         }
         else if("$st".contains("PublishJobServerCommand")){
            //build.setResult(Result.UNSTABLE)
            //println "Command failed: $st"
            println "Command failed: $st"
            Set<String> new_jobs_list  = new TreeSet<String>();
            for (String each : jobs_list_unique){
               if("$st".contains(each)){
                  appendBuildReport(buildReport, "Command failed: $st")
                  appendBuildReport(buildReport, "Skipping job: $each")
               }
               else{
                  new_jobs_list.add(each)
               }
            }
            retryBuild(buildReport, new_jobs_list, branch, buildOrigin)
         }
         else{
            throw new Exception("Command failed: $st") //to exit the 'each' closure
         }
      }
   }
   catch(java.lang.Exception e1){
      e1.printStackTrace()
      throw e1
   }
}
catch(all){
   println "Error: $all"
   System.exit(1)
}
finally {
   client.disconnect()
   timeStop = new Date()
   TimeDuration duration = TimeCategory.minus(timeStop, timeStart)
   appendBuildReport(buildReport, "Build process started at " + timeStart.format("EEE MMM dd HH:mm:ss zzz yyyy", TimeZone.getTimeZone("America/Chicago")))
   appendBuildReport(buildReport, "Build process finished at " + timeStop.format("EEE MMM dd HH:mm:ss zzz yyyy", TimeZone.getTimeZone("America/Chicago")))
   appendBuildReport(buildReport, "Build process duration: ${duration}")
   appendBuildReport(buildReport, "----------------------------------------------------")
   appendBuildReport(buildReport, "----------------------------------------------------")
   appendBuildReport(buildReport, "")
   notificationsProp.append("JENKINS_JOB_END_TIME=" + timeStop.format("EEE MMM dd HH:mm:ss zzz yyyy", TimeZone.getTimeZone("America/Chicago")))
   notificationsProp.append(System.getProperty("line.separator"))
   notificationsProp.append("JENKINS_JOB_DURATION=" + duration.toString())
   notificationsProp.append(System.getProperty("line.separator"))
}
**************/

public class CmdLineJSCommand extends JavaServerCommand {
   private String cmdStr
   public CmdLineJSCommand(String cmdStr){
      this.cmdStr = cmdStr
   }
   public String writeToString(){
      return cmdStr
   }
}

def metaServletCall(tacUrl, request){
    def urlSt = "$tacUrl/metaServlet?${request.toString().bytes.encodeBase64()}"

   if(debug){
      def scrubbedRequest = request.toString()
      if(scrubbedRequest.contains(tacPassword)){
         scrubbedRequest = scrubbedRequest.replace(tacPassword, "********")
      }
      println "    >> MetaServlet request : $scrubbedRequest"
      println "    >> MetaServlet url Call: $urlSt"
   }

   def tresp = urlSt.toURL().text
   
   if(debug) {
      print "    >> MetaServlet response : "
      println groovy.json.JsonOutput.prettyPrint(tresp)
   }
   
   def ms_response = new groovy.json.JsonSlurper().parseText(tresp)
   
   if(debug) {
      println "    >> MetaServlet ReturnCode= $ms_response.returnCode"
   }
   
   return ms_response
}

def appendBuildReport(reportFile, reportString){
   reportFile.append(reportString)
   reportFile.append(System.getProperty("line.separator"))
}
/***********************
def retryBuild(buildReport, new_jobs_list_unique, branch, buildOrigin){
   appendBuildReport(buildReport, "Retrying build after a failure in PublishJobServerCommand")
   List<JavaServerCommand> newCmdList = []
   println "   - InitRemote: $tacUrl, user:$tacUser, pwd:*****"
   
   newCmdList << new InitRemoteCommand(tacUrl, tacUser, tacPassword)
   println "   - LogonProject: $project, user:$tacUser, pwd:*****, branch:'$branch'"
   newCmdList << new LogonProjectCommand(project, tacUser, tacPassword, false, branch)
   
   appendBuildReport(buildReport, "Publishing to Nexus repository '$nexusRepositoryUrl' with group id: '$nexusGroup' and publish version: '$releaseVersion'")
   
   for (String each : new_jobs_list_unique) {
      println "   - Publishing Job: '$each' to '$nexusSnapshotRepository' Nexus repository"
      appendBuildReport(buildReport, "Publishing Job: '$each'")
      
      def pjsc = new PublishJobServerCommand()
      pjsc.setValue "JOB_NAME"                     , each
      pjsc.setValue "ARTIFACT_REPOSITORY"          , nexusRepositoryUrl.toString()
      pjsc.setValue "USERNAME"                     , nexusUser.toString()
      pjsc.setValue "PASSWORD"                     , nexusPassword.toString()
      pjsc.setValue "SNAPSHOT"                     , true
      pjsc.setValue "PUBLISH_VERSION"              , releaseVersion.toString()
      pjsc.setValue "ARTIFACT"                     , each
      pjsc.setValue "GROUP"                        , nexusGroup.toString()
      pjsc.setValue "TYPE"                         , "std"
      pjsc.setValue "JOB_CONTEXT"                  , "Default"
      pjsc.setValue "JOB_APPLY_CONTEXT_TO_CHILDREN", true
      
      def cmdStr = pjsc.writeToString()
      cmdStr += " -p '$nexusPassword'"
      newCmdList << new CmdLineJSCommand(cmdStr)
   }
   println "   - LogoffProject: $project"
   newCmdList << new LogoffProjectCommand()
   
   def newClient = new CommandLineJavaClient(cmdLineHost, Integer.valueOf(cmdLinePort))
   println "   - Connection to CommandLine at: '$cmdLineHost:$cmdLinePort'"
   try{
      newClient.connect()
      println "     - Connected. Version= '${newClient.getServerVersion()}'"
   }catch(java.net.ConnectException ce){
      println "   - Connection to CommandLine at: '$cmdLineHost:$cmdLinePort' failed. Sleeping thread for 30 seconds and retrying"
      sleep(30000)
      try{
         newClient.connect()
         println "     - Connected. Version= '${newClient.getServerVersion()}'"
      }catch(java.net.ConnectException ce1){
         ce1.printStackTrace()
         throw ce1
      }
   }
   st = newClient.addCommandAndWait(new CommandGroupCommand(newCmdList, buildOrigin))
   if(st.level != CommandStatus.CommandStatusLevel.COMPLETED){
      throw new Exception("Command failed: $st") //to exit the 'each' closure
   }
}
******************************************/

class BuildJobsCommandMetric{
   Date timeStart;
   Date timeStop;
   TimeDuration duration;
   
   public BuildJobsCommandMetric(){
      this.timeStart = new Date()
   }
}

@Sortable(excludes = ['client', 'cmdList', 'commandGroup', 'metric'])
@ToString
class BuildJobsCommand{
   String jobName;
   String tacUrl;
   String tacUser;
   String tacPassword;
   String project;
   String branch;
   String nexusRepositoryUrl;
   String nexusUser;
   String nexusPassword;
   String releaseVersion;
   String nexusGroup;
   String buildOrigin;
   String buildJobStatus;
   Integer commandID;
   
   CommandLineJavaClient client;
   List<JavaServerCommand> cmdList = [];
   CommandGroupCommand commandGroup;
   BuildJobsCommandMetric metric;
   
   public BuildJobsCommand(String jobName, String tacUrl, String tacUser, String tacPassword,
      String project, String branch, String nexusRepositoryUrl, String nexusUser, String nexusPassword,
      String releaseVersion, String nexusGroup, String buildOrigin, 
      String cmdLineHost, String cmdLinePort){
         
      this.client = new CommandLineJavaClient(cmdLineHost, Integer.valueOf(cmdLinePort));
      this.jobName = jobName;
      this.tacUrl = tacUrl;
      this.tacUser = tacUser;
      this.tacPassword = tacPassword;
      this.project = project;
      this.branch = branch;
      this.nexusRepositoryUrl = nexusRepositoryUrl;
      this.nexusUser = nexusUser;
      this.nexusPassword = nexusPassword;
      this.releaseVersion = releaseVersion;
      this.nexusGroup = nexusGroup;
      this.buildOrigin = buildOrigin;
   }
   
   private void assembleBuildCommands(){
      //println "   - InitRemote: $tacUrl, user:$tacUser, pwd:*****"
      this.cmdList << new InitRemoteCommand(this.tacUrl, this.tacUser, this.tacPassword)
      
      //println "   - LogonProject: $project, user:$tacUser, pwd:*****, branch:'$branch'"
      this.cmdList << new LogonProjectCommand(this.project, this.tacUser, this.tacPassword, false, this.branch)
      
      def pjsc = new PublishJobServerCommand()
      pjsc.setValue "JOB_NAME"                     , this.jobName
      pjsc.setValue "ARTIFACT_REPOSITORY"          , this.nexusRepositoryUrl
      pjsc.setValue "USERNAME"                     , this.nexusUser
      pjsc.setValue "PASSWORD"                     , this.nexusPassword
      pjsc.setValue "SNAPSHOT"                     , true
      pjsc.setValue "PUBLISH_VERSION"              , this.releaseVersion
      pjsc.setValue "ARTIFACT"                     , this.jobName
      pjsc.setValue "GROUP"                        , this.nexusGroup
      pjsc.setValue "TYPE"                         , "std"
      pjsc.setValue "JOB_CONTEXT"                  , "Default"
      pjsc.setValue "JOB_APPLY_CONTEXT_TO_CHILDREN", true
      
      def cmdStr = pjsc.writeToString()
      cmdStr += " -p '${this.nexusPassword}'"
      this.cmdList << new CmdLineJSCommand(cmdStr)
      this.cmdList << new LogoffProjectCommand()
      this.commandGroup = new CommandGroupCommand(this.cmdList, this.buildOrigin)
   }
   
   private void executeBuildCommands(){
      
      this.metric = new BuildJobsCommandMetric();
      try{
         this.client.connect()
         
         try{
            this.commandID = client.addCommand(this.commandGroup)
            def st = this.client.getCommandStatusAndWait(this.commandID)
            //println "this.commandGroup.writeToString(): ${this.commandGroup.writeToString()}"
            
            if(st.level != CommandStatus.CommandStatusLevel.COMPLETED){
               this.buildJobStatus = "ERROR"
            }
            else{
               this.buildJobStatus = "SUCCESS"
            }
            this.metric.timeStop = new Date()
            this.metric.duration = TimeCategory.minus(this.metric.timeStop, this.metric.timeStart)
         }
         catch(java.lang.Exception e1){
            e1.printStackTrace()
            throw e1
         }
      }
      catch(all){
         println "Error: $all"
      }
      finally{
         this.client.disconnect()
      }
   }
   
   public void buildJobs(){
      this.assembleBuildCommands();
      this.executeBuildCommands();
   }
}