/**
 * Created by Jesen on 04/20/2016
 */
@Grab('org.apache.commons:commons-csv:1.2')
import org.apache.commons.csv.*;
import static org.apache.commons.csv.CSVFormat.*

import java.nio.file.*;
import java.nio.charset.*;
import java.nio.*;

import groovy.transform.Sortable;
import groovy.transform.ToString;

import groovy.json.*
import groovy.xml.*
import groovy.util.*

import java.util.Map;
import java.util.Map.Entry;

import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

def env              = System.getenv()
buildListPath        = env['BUILD_LIST_PATH']
changeSetFile        = env['CHANGESET_FILE']
masterBuildList      = env['MASTER_BUILD_LIST_FILE']
buildUrl             = env['BUILD_URL']
branch               = env['GIT_BRANCH_NAME']

def xpathString = "api/xml?wrapper=changeSet&xpath=//changeSet//item&exclude=//changeSet//item//*[((self::commitId)or(self::timestamp)or(self::comment)or(self::date)or(self::path)or(self::revision)or(self::user))]&exclude=//changeSet//item[(contains(.,'useless'))or(contains(.,'auto%20comment'))]"

def changeSetText = (buildUrl + xpathString).toURL().text

def changeSetXML = new XmlSlurper().parseText(changeSetText)

//assert changeSetXML instanceof groovy.util.slurpersupport.GPathResult 

//println XmlUtil.serialize(changeSetXML)

enum BuildListHeader {
   Job_Name("Job_Name"),
   Task_Name("Task_Name"),
   Dev_Context("Dev_Context"),
   Dev_JobServer("Dev_JobServer"),
   Dev_RunTask("Dev_RunTask"),
   Test_Context("Test_Context"),
   Test_JobServer("Test_JobServer"),
   Test_RunTask("Test_RunTask"),
   Stage_Context("Stage_Context"),
   Stage_JobServer("Stage_JobServer"),
   Stage_RunTask("Stage_RunTask"),
   Prod_Context("Prod_Context"),
   Prod_JobServer("Prod_JobServer"),
   context_value("context_value"),
   task_pool_size("task_pool_size"),
   user_email("user_email")
    
   private String headerLabel;
    
   private BuildListHeader(String headerLabel){
      this.headerLabel = headerLabel;
   }
   public String headerLabelValue() {return headerLabel}
}


@Sortable(excludes = ['devRunTask', 'tstRunTask', 'stgRunTask'])
@ToString
class BuildJobs{
   String name;
   String task;
   String devContext;
   String devJobServer;
   boolean devRunTask;
   String tstContext;
   String tstJobServer;
   boolean tstRunTask;
   String stgContext
   String stgJobServer;
   boolean stgRunTask;
   String prdContext;
   String prdJobServer;
   String contextValue;
   String taskPoolSize;
   String userEmail;
}

List derivedJobsList = new ArrayList()
Map<String, Set> buildListPerBranch = new TreeMap<String, Set>()
def jobList = []
changeSetXML.item.each{ eachItem ->
   msg = eachItem.msg.text()
   //println "msg: ${msg}"
   userURL = eachItem.author.absoluteUrl.text()
   //println "userURL: ${userURL}"
   
   userURLapi = userURL + "/api/xml?wrapper=userEmail&xpath=//user//property//address"
   //println "userURLapi: ${userURLapi}"
   userEmail = userURLapi.toURL().text
   //println "userEmail: ${userEmail}"
   def userEmailXml = new XmlSlurper().parseText(userEmail)
   userEmailAddress = userEmailXml.address.text()
   //println "userEmailAddress: ${userEmailAddress}"   
   
   eachItem.affectedPath.each{eachPath ->
      if("${eachPath}".contains("/process/")){
         //println "eachPath: ${eachPath}"
         jobList = checkMasterBuildList("${eachPath}", userEmailAddress)
      }
      
      if(jobList != null && jobList.size() > 0){
         Set<BuildJobs> jobsListUnique  = new TreeSet<BuildJobs>();
         jobsListUnique.addAll(jobList)
         if(buildListPerBranch != null && buildListPerBranch.containsKey(branch)){
            jobsListUnique.addAll(buildListPerBranch.get(branch))
         }
         buildListPerBranch.put(branch, jobsListUnique)
      }
   }
   
}

if(buildListPerBranch != null && buildListPerBranch.size() > 0){
   for(Map.Entry<String, Set> eachBranch in buildListPerBranch.entrySet()){
      List branchList = new ArrayList()
      branchList.addAll(eachBranch.getValue())
      String branchName = eachBranch.getKey()
      if(branchList != null && branchList.size() > 0){
         createDerivedJobList(branchName, branchList)
      }
   }
}


def createDerivedJobList(branch, derivedJobsList){
   if(derivedJobsList != null && derivedJobsList.size() > 0){
      if(!Files.exists(Paths.get(buildListPath))){
         Files.createDirectory(Paths.get(buildListPath))
      }
      
      List<BuildListHeader> csvHeader = Arrays.asList(BuildListHeader.values());
      def csvHeaderLabels = []
      csvHeader.each{ eachLabel ->
         csvHeaderLabels << eachLabel.headerLabelValue()
      }
      //println csvHeaderLabels
      FileWriter fileWriter = null;
      CSVPrinter csvFilePrinter = null;
      CSVFormat csvFileFormat = CSVFormat.DEFAULT.withRecordSeparator(System.lineSeparator());
      
      try{
         fileWriter = new FileWriter(buildListPath + FileSystems.getDefault().getSeparator().toString() + "BUILD_LIST_OVERRIDE");
         csvFilePrinter = new CSVPrinter(fileWriter, csvFileFormat);
         csvFilePrinter.printRecord(csvHeaderLabels);
         derivedJobsList.each{ eachJob ->
            List eachRecord = new ArrayList();
            eachRecord.add(eachJob.name.toString());
            eachRecord.add(eachJob.task.toString());
            eachRecord.add(eachJob.devContext.toString());
            eachRecord.add(eachJob.devJobServer.toString());
            eachRecord.add(eachJob.devRunTask.toString());
            eachRecord.add(eachJob.tstContext.toString());
            eachRecord.add(eachJob.tstJobServer.toString());
            eachRecord.add(eachJob.tstRunTask.toString());
            eachRecord.add(eachJob.stgContext.toString());
            eachRecord.add(eachJob.stgJobServer.toString());
            eachRecord.add(eachJob.stgRunTask.toString());
            eachRecord.add(eachJob.prdContext.toString());
            eachRecord.add(eachJob.prdJobServer.toString());
            eachRecord.add(eachJob.contextValue.toString());
            eachRecord.add(eachJob.taskPoolSize.toString());
            eachRecord.add(eachJob.userEmail.toString());
            csvFilePrinter.printRecord(eachRecord);
         }
         println "CSV file was created successfully !!!"
      }
      catch(all){
         println all
      }
      finally{
         try{
            fileWriter.flush();
            fileWriter.close();
            csvFilePrinter.close();
         }
         catch(IOException ioe){
            println ioe
         }
      }
   }
   else{
      println "change set does not match anything in master job list. no csv file created"
   }
}

def checkMasterBuildList(affectedPath, userEmailAddress){
  def masterBuildListFile = new FileNameFinder().getFileNames(".", "**/$masterBuildList")
  def buildJobList = null
  def jobs_list = []
  if(masterBuildListFile!= null && masterBuildListFile.size() > 0){
   masterBuildListFile.each{
      println "masterBuildListFile file found : ${it.toString()}"
      buildJobList = Paths.get(it)
   }
   try{
      Job_Name = ""
      Task_Name = ""
      Dev_Context = ""
      Dev_JobServer = ""
      Dev_RunTask = false
      Test_Context = ""
      Test_JobServer = ""
      Test_RunTask = false
      Stage_Context = ""
      Stage_JobServer = ""
      Stage_RunTask = false
      Prod_Context = ""
      Prod_JobServer = ""
      context_value = ""
      task_pool_size = "1"
      Prod_RunTask = false
      
      buildJobList.withReader { reader ->
         CSVParser csv = new CSVParser(reader, DEFAULT.withHeader())
         Map csvHeader = csv.getHeaderMap()
         for(eachRecord in csv.getRecords()){
            for(Map.Entry<String, Integer> eachHeader in csvHeader.entrySet()){
               if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Job_Name.headerLabelValue())){
                  Job_Name = eachRecord."${eachHeader.getKey()}".trim()
                  //println Job_Name
                  String patternStart = "(.*)process(.*)";
                  String patternEnd = "[_](\\d)[.](\\d)[.]item(.*)";
                  String jobNameRegex = patternStart + Job_Name + patternEnd
                  //println "checking Job_Name :'$Job_Name' and see if it's part of change set message :$msg"
                  //println " also check using regex $jobNameRegex"
                  if(affectedPath.contains("'" + Job_Name + "'")){
                     println "Job_Name :$Job_Name is in master build list"
                  }
                  else if(affectedPath.matches(jobNameRegex)){
                     println "Job_Name :$Job_Name is in master build list"
                  }
                  else{
                     //println "Job_Name :$Job_Name not affected, checking next one"
                     Job_Name = ""
                     break
                  }
               }
               if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Task_Name.headerLabelValue())){
                  Task_Name = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                  //println Task_Name
               }
               if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Dev_Context.headerLabelValue())){
                  Dev_Context = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                  //println Dev_Context
               }
               if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Dev_JobServer.headerLabelValue())){
                  Dev_JobServer = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                  //println Dev_JobServer
               }
               if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Dev_RunTask.headerLabelValue())){
                  Dev_RunTask = "true".equalsIgnoreCase(eachRecord."${eachHeader.getKey()}".trim())
                  //println Dev_RunTask
               }
               if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Test_Context.headerLabelValue())){
                  Test_Context = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                  //println Test_Context
               }
               if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Test_JobServer.headerLabelValue())){
                  Test_JobServer = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                  //println Test_JobServer
               }
               if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Test_RunTask.headerLabelValue())){
                  Test_RunTask = "true".equalsIgnoreCase(eachRecord."${eachHeader.getKey()}".trim())
                  //println Test_RunTask
               }
               if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Stage_Context.headerLabelValue())){
                  Stage_Context = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                  //println Stage_Context
               }
               if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Stage_JobServer.headerLabelValue())){
                  Stage_JobServer = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                  //println Stage_JobServer
               }
               if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Stage_RunTask.headerLabelValue())){
                  Stage_RunTask = "true".equalsIgnoreCase(eachRecord."${eachHeader.getKey()}".trim())
                  //println Stage_RunTask
               }
               if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Prod_Context.headerLabelValue())){
                  Prod_Context = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                  //println Prod_Context
               }
               if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Prod_JobServer.headerLabelValue())){
                  Prod_JobServer = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                  //println Prod_JobServer
               }
               if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.context_value.headerLabelValue())){
                  context_value = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
                  //println context_value
               }
               if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.task_pool_size.headerLabelValue())){
                  task_pool_size = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : "1"
                  //println task_pool_size
               }
            }
            if(Job_Name != null && !"".equalsIgnoreCase(Job_Name)){
               jobs_list << ([
                  name         : Job_Name,
                  task         : Task_Name,
                  devContext   : Dev_Context,
                  devJobServer : Dev_JobServer,
                  devRunTask   : Dev_RunTask,
                  tstContext   : Test_Context,
                  tstJobServer : Test_JobServer,
                  tstRunTask   : Test_RunTask,
                  stgContext   : Stage_Context,
                  stgJobServer : Stage_JobServer,
                  stgRunTask   : Stage_RunTask,
                  prdContext   : Prod_Context,
                  prdJobServer : Prod_JobServer,
                  contextValue : context_value,
                  taskPoolSize : task_pool_size,
                  userEmail    : userEmailAddress
                  ] as BuildJobs)
            }
         }
      }
   }catch(java.nio.charset.MalformedInputException mafe){
      appendBuildReport(buildReport, "MalformedInputException encountered on build list")
      appendBuildReport(buildReport, "Most likely there's a non-ascii/non UTF-8 character in the build list, please fix the build list")
      println "MalformedInputException encountered on build list"
      println "Most likely there's a non-ascii/non UTF-8 character in the build list, please fix the build list"
      System.exit(1)
   }catch(all){
      println "Error reading CSV Job List: $all"
      System.exit(1)
   }
   //println "jobs_list content"
   /*
   if(jobs_list != null){
      jobs_list.each{
         println it.name +"," +it.task +"," +it.devContext +"," +it.devJobServer +"," +it.devRunTask +"," +it.tstContext +"," +it.tstJobServer +"," +it.tstRunTask +"," +it.stgContext +"," +it.stgJobServer +"," +it.stgRunTask +"," +it.prdContext +"," +it.prdJobServer +"," +it.contextValue +"," +it.taskPoolSize
      }
   }
   */
   return jobs_list
  }
}
