/**
 * Created by Jesen on 05/04/2016
 */

@Grab('org.apache.commons:commons-csv:1.2')
@Grab('commons-io:commons-io:2.5')

import org.apache.commons.io.*;
import org.apache.commons.csv.CSVParser
import static org.apache.commons.csv.CSVFormat.*

import java.nio.file.*;
import java.nio.charset.*;
import java.nio.*;

import groovy.transform.Sortable;
import groovy.transform.ToString;
import groovy.json.*;
import groovy.text.*;
import groovy.time.*

import org.talend.commandline.client.*;
import org.talend.commandline.client.command.*;

import java.util.zip.*;
import java.util.Map;
import java.util.Map.Entry;

import groovyx.gpars.*;

def env = System.getenv()

//////////////////////////////////////////////////////////////////////////////
//these properties should be retrieved from jenkins build parameter
branchName              = env['BRANCH_NAME']
buildListOverride       = env['BUILD_LIST_OVERRIDE']
//////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////
//these properties should be contained in the common.server.properties file in svn
project                 = env['PROJECT_NAME']

cmdLineHost             = env['CMDLINE_HOST']
cmdLinePort             = env['CMDLINE_PORT']

nexusUrl                = env['ARTIFACT_REPO_URL']
nexusSnapshotRepository = env['SNAPSHOT_ARTIFACT_REPO_NAME']
nexusReleaseRepository  = env['RELEASE_ARTIFACT_REPO_NAME']

landingDir              = env["ARTIFACT_LANDING_DIR"]
currentReleaseVersion   = env["CURRENT_RELEASE_VERSION"]
branchNameUnusedPattern = env["BRANCH_NAME_UNUSED_PATTERN"]
//////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////
//these properties should be contained in the env.server.properties file in svn
tacUrl                  = env['TAC_URL']
jobExecServer           = env['JOB_EXEC_SERVER']
defaultTaskNamePrefix   = env['TASK_NAME_PREFIX']
defaultTaskNamePostfix  = env['TASK_NAME_POSTFIX']
defaultEnvContext       = env['DEFAULT_ENVIRONMENT_CONTEXT']
//////////////////////////////////////////////////////////////////////////////

debug                   = "true".equalsIgnoreCase(env['CI_DEBUG'])

ciWorkspace             = env['WORKSPACE']
ciJobName               = env['JOB_NAME']

tagsID                  = env['TAGS_ID']

talendSvnRevision       = env['GIT_COMMIT'].toString().substring(0, 8)

buildReportFile         = env['BUILD_REPORT_FILE']
notificationEmailFile   = env['NOTIFICATION_EMAIL_FILE']

deployEnv               = env['DEPLOY_ENVIRONMENT']
//////////////////////////////////////////////////////////////////////////////
//these properties should be part of jenkins credential injector
tacUser                 = env['TAC_USER']
tacPassword             = env['TAC_PASSWORD']

sshUser                 = env['SSH_USER']
sshPassword             = env['SSH_PWD']

//safety check to retrieve environment specific password
if(sshPassword == null || "".equalsIgnoreCase(sshPassword.trim())){
   sshPassword          = env[sshUser]
}
//2nd safety check to retrieve environment specific password to prevent account being locked
if(sshPassword == null || "".equalsIgnoreCase(sshPassword.trim())){
   println "SSH_PWD need to be defined"
   System.exit(1)
}

nexusUser               = env['NEXUS_USER']
nexusPassword           = env['NEXUS_PWD']
envPropFileName         = env['ENV_PROP_FILE']
jenkinsJobStartTime     = env['JENKINS_JOB_START_TIME']
//////////////////////////////////////////////////////////////////////////////

nexusRepositoryProject  = project
nexusRepository         = nexusSnapshotRepository

def ms_request = new groovy.json.JsonBuilder()
def ms_response
def simpleTemplateEngine = new SimpleTemplateEngine()

def timeStart
if(jenkinsJobStartTime != null){
   timeStart = Date.parseToStringDate(jenkinsJobStartTime) 
}
else{
   timeStart = new Date()
}
def timeStop


def now = Calendar.getInstance(TimeZone.getTimeZone("America/Chicago")).format("yyyy.MM.dd 'at' HH:mm:ss z")
def buildReport = null
def defaultVersionPostFix = null
if(buildReportFile != null){
   buildReport = new File(buildReportFile)
}
else{
   buildReport = new File("BuildReport.txt")
}

def notificationsProp = null
if(notificationEmailFile != null){
   notificationsProp = new File(notificationEmailFile)
}
else{
   notificationsProp = new File("NOTIFICATIONS.properties")
}
notificationsProp.append("#" + System.getProperty("line.separator"))

appendBuildReport(buildReport, "----------------------------------------------------")
appendBuildReport(buildReport, "Report for build tag: " + env["BUILD_TAG"])
appendBuildReport(buildReport, "Jenkins URL: " + env["BUILD_URL"])

//----------------------------
//---------- Step 0 ----------
//----------------------------
println "----------------------------------------------------"
println "-- Step 0: Set Build environment variables"
println "----------------------------------------------------"

exec_server_host = retrieveTalendExecHostname(tacUrl, tacUser, tacPassword, jobExecServer, ms_request)

Properties prop = loadEnvPropertiesFile(envPropFileName)
appendBuildReport(buildReport, "----------------------------------------------------")
appendBuildReport(buildReport, "-- Step 0: Set Build environment variables")
appendBuildReport(buildReport, "----------------------------------------------------")

if(deployEnv != null && !"".equalsIgnoreCase(deployEnv.trim())){
   println "DEPLOY_ENVIRONMENT : ${deployEnv.trim()}"
}
else{
   println "DEPLOY_ENVIRONMENT need to be defined"
   System.exit(1)
}

////////////////////////////////////////////////////////////////////////////
//this is custom code from ODF_ODF project
enum DeployEnvironment {
    DEV("DEV_631", "Default", "dev"),
    TST("TST_631", "Default", "tst"),
    PRD("PRD_631", "Default", "prd"),
    LAKEDEV("lakedev", "Default", "dev"),
    LAKETST("odfr2tst", "Default", "tst"),
    LAKEPRD("lakeprd", "Default", "prd")
    
    private String envLabel;
    private String defaultContext;
    private String environment;
    
    private DeployEnvironment(String env, String defaultContext, String environment){
      this.envLabel = env;
      this.defaultContext = defaultContext;
      this.environment = environment
    }
    
    public String envLabelValue() {return envLabel}
    public String defaultContextValue() {return defaultContext}
    public String environmentValue() {return environment}
    
}
DeployEnvironment deployEnvironment = DeployEnvironment."${deployEnv.toUpperCase()}"
//end custom code
///////////////////////////////////////////////////////////////////

releaseVersion = currentReleaseVersion

if(releaseVersion != null && !"".equalsIgnoreCase(releaseVersion.trim())){
   println "branch name: ${branchName} release version  : $releaseVersion"
}
else{
   println "CURRENT_RELEASE_VERSION is required environment parameter"
   System.exit(1)
}

//custom postfix specific for ODF_ODF
defaultVersionPostFix = "v" + releaseVersion.replace(".", "")
pubVersion = "${releaseVersion}"
if(nexusRepository.toUpperCase().contains("SNAPSHOT")){
   pubVersion = pubVersion + "-SNAPSHOT"
}

println "   - pubVersion: $pubVersion"
appendBuildReport(buildReport, "pubVersion: $pubVersion")

tacHost = tacUrl.toURL().host

//custom nexus group specific for ODF_ODF
nexusGroup      = "v" + releaseVersion.replace(".", "_")

nexusRepositoryUrl = "$nexusUrl/content/repositories/$nexusRepository/${nexusRepositoryProject}"

println ">> DEPLOY_ENVIRONMENT : ${deployEnv}"
println ">> ${deployEnv} Environement URL: ${tacUrl} "
println ">> user: ${tacUser} "
println ">> host: ${tacHost} "
appendBuildReport(buildReport, "DEPLOY_ENVIRONMENT : ${deployEnv}")
appendBuildReport(buildReport, "${deployEnv} Environement URL: ${tacUrl} ")
appendBuildReport(buildReport, "user: ${tacUser} ")
appendBuildReport(buildReport, "host: ${tacHost} ")


println "----------------------------------------------------"
println "-- Step 0-A: Get Jobs list to deploy"
println "----------------------------------------------------"

enum BuildListHeader {
   Job_Name("Job_Name"),
   Task_Name("Task_Name"),
   Dev_Context("Dev_Context"),
   Dev_JobServer("Dev_JobServer"),
   Dev_RunTask("Dev_RunTask"),
   Test_Context("Test_Context"),
   Test_JobServer("Test_JobServer"),
   Test_RunTask("Test_RunTask"),
   Stage_Context("Stage_Context"),
   Stage_JobServer("Stage_JobServer"),
   Stage_RunTask("Stage_RunTask"),
   Prod_Context("Prod_Context"),
   Prod_JobServer("Prod_JobServer"),
   Prod_RunTask("Prod_RunTask"),
   context_value("context_value"),
   task_pool_size("task_pool_size"),
   user_email("user_email")
    
   private String headerLabel;
    
   private BuildListHeader(String headerLabel){
      this.headerLabel = headerLabel;
   }
   public String headerLabelValue() {return headerLabel}
}

class BuildJobs {
   String name, task, taskPoolSize;
   String envContext, jobServer;
   String contextValue;
   boolean runTask;
   String userEmail;
}

@Sortable(includes = ['taskName', 'jobName'])
@ToString
public class DeployTasks {
   String projectName;
   String jobName;
   String taskName;
   String taskID;
   String taskContext;
   String taskJobServer;
   String taskContextValue;
   String taskArtifact;
   String deployArtifact;
   String taskPoolSize;
   String taskDescription;
   File deployTaskReportFile;
   String deploymentStatus;
   String executionStatus;
   String deploymentTimestamp;
   String taskBranchName;
   String taskTagName;
   String svnRevision;
   boolean runTask;
}

@Sortable(excludes = ['antGet', 'downloadReportFile'])
@ToString
public class DownloadArtifacts{
   String jobName;
   String taskNexusArtifact;
   String taskLocalArtifact;
   String taskDeployArtifact;
   File downloadReportFile;
   AntBuilder antGet;
}

Path buildJobList = Paths.get(env["JOBS_LIST_CSV_FILE"])

def jobs_list = []
def notification_list = []  //List to send notification email to. email address should be derived from build list.

//check build list override
if(buildListOverride != null && !"".equals(buildListOverride)){
   buildListOverrideFileName = "**/BUILD_LIST_OVERRIDE"
   buildListOverrideFile = new FileNameFinder().getFileNames(".", buildListOverrideFileName)
   if(buildListOverrideFile != null && buildListOverrideFile.size() > 0){
      println "BUILD_LIST_OVERRIDE file found"
      buildListOverrideFile.each{
         println "BUILD_LIST_OVERRIDE file found : ${it.toString()}"
         buildJobList = Paths.get(it)
      }
   }
}

try{
   Job_Name = ""
   Task_Name = ""
   Dev_Context = "Default"
   Dev_JobServer = ""
   Dev_RunTask = false
   Test_Context = "Default"
   Test_JobServer = ""
   Test_RunTask = false
   Prod_Context = "Default"
   Prod_JobServer = ""
   context_value = ""
   task_pool_size = "1"
   Prod_RunTask = false
   envContext = "Default"
   jobServer = ""
   runTask = false
   user_email = ""
         
         
   buildJobList.withReader { reader ->
      CSVParser csv = new CSVParser(reader, DEFAULT.withHeader())
      Map csvHeader = csv.getHeaderMap()
      for(eachRecord in csv.getRecords()){
         
         for(Map.Entry<String, Integer> eachHeader in csvHeader.entrySet()){
            if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Job_Name.headerLabelValue())){
               Job_Name = eachRecord."${eachHeader.getKey()}".trim()
            }
            if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Task_Name.headerLabelValue())){
               Task_Name = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
            }
            if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.context_value.headerLabelValue())){
               context_value = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
            }
            if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.task_pool_size.headerLabelValue())){
               task_pool_size = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : "1"
            }
            if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.user_email.headerLabelValue())){
               user_email = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : ""
            }
            
            switch (deployEnv.toString().toUpperCase()) {
               case "TST":
               case "LAKETST":
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Test_Context.headerLabelValue())){
                     envContext = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : "Default"
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Test_JobServer.headerLabelValue())){
                     jobServer = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : jobExecServer.trim()
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Test_RunTask.headerLabelValue())){
                     runTask = "true".equalsIgnoreCase(eachRecord."${eachHeader.getKey()}".trim()) 
                  }
                  break;
               case "STG":
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Stage_Context.headerLabelValue())){
                     envContext = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : "Default"
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Stage_JobServer.headerLabelValue())){
                     jobServer = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : jobExecServer.trim()
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Stage_RunTask.headerLabelValue())){
                     runTask = "true".equalsIgnoreCase(eachRecord."${eachHeader.getKey()}".trim()) 
                  }
                  break;
               case "PRD":
               case "LAKEPRD":
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Prod_Context.headerLabelValue())){
                     envContext = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : "Default"
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Prod_JobServer.headerLabelValue())){
                     jobServer = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : jobExecServer.trim()
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Prod_RunTask.headerLabelValue())){
                     runTask = "true".equalsIgnoreCase(eachRecord."${eachHeader.getKey()}".trim()) 
                  }
                  break;
               case "DEV":
               default:
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Dev_Context.headerLabelValue())){
                     envContext = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : "Default"
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Dev_JobServer.headerLabelValue())){
                     jobServer = eachRecord."${eachHeader.getKey()}" != null && eachRecord."${eachHeader.getKey()}".trim().length() > 0 ? eachRecord."${eachHeader.getKey()}".trim() : jobExecServer.trim()
                  }
                  if(eachHeader.getKey().equalsIgnoreCase(BuildListHeader.Dev_RunTask.headerLabelValue())){
                     runTask = "true".equalsIgnoreCase(eachRecord."${eachHeader.getKey()}".trim()) 
                  }
                  break;
            }
         }
        
         jobs_list << ([
            name           : Job_Name,
            task           : Task_Name,
            envContext     : envContext,
            jobServer      : jobServer,
            runTask        : runTask,
            contextValue   : context_value,
            taskPoolSize   : task_pool_size
            ] as BuildJobs)
            
         if(user_email != null && !"".equalsIgnoreCase(user_email)){
            notification_list << ([
               name        : Job_Name,
               userEmail   : user_email
               ] as BuildJobs)
         }
      }
   }
}
catch(java.nio.charset.MalformedInputException mafe){
   appendBuildReport(buildReport, "MalformedInputException encountered on build list")
   appendBuildReport(buildReport, "Most likely there's a non-ascii/non UTF-8 character in the build list, please fix the build list")
   println "MalformedInputException encountered on build list"
   println "Most likely there's a non-ascii/non UTF-8 character in the build list, please fix the build list"
   System.exit(1)
}
catch(all){
   println "Error reading CSV Job List: $all"
   System.exit(1)
}

println "----------------------------------------------------"
println "-- Step 1: Build a Task deployment list"
println "----------------------------------------------------"

appendBuildReport(buildReport, "----------------------------------------------------")
appendBuildReport(buildReport, "-- Step 1: Build a Task deployment list")
appendBuildReport(buildReport, "----------------------------------------------------")

def tasks_list = []
def task_map = [:]

for(jobt in jobs_list){
   job  = jobt.name
   
   if(job.trim().length() < 1){
      continue
   }
   
   int taskPoolSize = 1
   
   try{
      if(jobt.taskPoolSize != null && jobt.taskPoolSize.trim().length() > 0){
         taskPoolSize = jobt.taskPoolSize.toInteger()
      }
   }catch(all){
      taskPoolSize = 1
   }
   
   jobTaskName = ""
   if(jobt.task != null && jobt.task.trim().length() > 0){
      jobTaskName = jobt.task
      
      ////////////////////////////////////////////////////////////////////////////
      //this is custom code from ODF_ODF project
      //initially the Task_Name column is meant for an override value so user can simply inject whatever label they want
      //and then someone had a bright idea to use specific values of task name to run in df2_ing_prc_mgr job
      //i.e <exec_region>_df2_preingest_workflow_FLI_<source code>_<partner code>_<numeric value>
      //and those specific values is environment specific and incompatible with simple override
      //the exec_region values are needed because CORE TST and LAKE TST share the same TAC
      //the numeric value are needed because it's suppose to be used as part of a pool
      //in addition to that, someone may use different exec_region in the deploy list to deploy to the wrong environment

      //so for sanity check
      switch (deployEnvironment) {
         case DeployEnvironment.DEV:
         //if the deployment environment is dev and the task name begins with string meant for different environment
         //replace the value with the right environment
            if(jobTaskName.startsWith( DeployEnvironment.TST.envLabelValue() ) || 
               jobTaskName.startsWith( DeployEnvironment.PRD.envLabelValue() ) || 
               jobTaskName.startsWith( DeployEnvironment.LAKEDEV.envLabelValue() ) || 
               jobTaskName.startsWith( DeployEnvironment.LAKETST.envLabelValue() ) ||
               jobTaskName.startsWith( DeployEnvironment.LAKEPRD.envLabelValue() ) ){
               
               regexPattern = "(" 
               regexPattern += DeployEnvironment.TST.envLabelValue() + "|"
               regexPattern += DeployEnvironment.PRD.envLabelValue() + "|"
               regexPattern += DeployEnvironment.LAKEDEV.envLabelValue() + "|"
               regexPattern += DeployEnvironment.LAKETST.envLabelValue() + "|"
               regexPattern += DeployEnvironment.LAKEPRD.envLabelValue()
               regexPattern += ")"
               jobTaskName = jobTaskName.replaceFirst(regexPattern, deployEnvironment.envLabelValue())
            }
            //otherwise just use the label value which is
            else if( !jobTaskName.startsWith( deployEnvironment.envLabelValue() ) ){
               jobTaskName = deployEnvironment.envLabelValue() + "_" + jobTaskName
            }
            break;
         
         case DeployEnvironment.TST:
            if(jobTaskName.startsWith( DeployEnvironment.DEV.envLabelValue() ) || 
               jobTaskName.startsWith( DeployEnvironment.PRD.envLabelValue() ) || 
               jobTaskName.startsWith( DeployEnvironment.LAKEDEV.envLabelValue() ) || 
               jobTaskName.startsWith( DeployEnvironment.LAKETST.envLabelValue() ) ||
               jobTaskName.startsWith( DeployEnvironment.LAKEPRD.envLabelValue() ) ){
               
               regexPattern = "(" 
               regexPattern += DeployEnvironment.DEV.envLabelValue() + "|"
               regexPattern += DeployEnvironment.PRD.envLabelValue() + "|"
               regexPattern += DeployEnvironment.LAKEDEV.envLabelValue() + "|"
               regexPattern += DeployEnvironment.LAKETST.envLabelValue() + "|"
               regexPattern += DeployEnvironment.LAKEPRD.envLabelValue()
               regexPattern += ")"
               jobTaskName = jobTaskName.replaceFirst(regexPattern, deployEnvironment.envLabelValue())
            }
            else if( !jobTaskName.startsWith( deployEnvironment.envLabelValue() ) ){
               jobTaskName = deployEnvironment.envLabelValue() + "_" + jobTaskName
            }
            break;
         
         case DeployEnvironment.PRD:
            if(jobTaskName.startsWith( DeployEnvironment.DEV.envLabelValue() ) || 
               jobTaskName.startsWith( DeployEnvironment.TST.envLabelValue() ) || 
               jobTaskName.startsWith( DeployEnvironment.LAKEDEV.envLabelValue() ) || 
               jobTaskName.startsWith( DeployEnvironment.LAKETST.envLabelValue() ) ||
               jobTaskName.startsWith( DeployEnvironment.LAKEPRD.envLabelValue() ) ){
               
               regexPattern = "(" 
               regexPattern += DeployEnvironment.DEV.envLabelValue() + "|"
               regexPattern += DeployEnvironment.TST.envLabelValue() + "|"
               regexPattern += DeployEnvironment.LAKEDEV.envLabelValue() + "|"
               regexPattern += DeployEnvironment.LAKETST.envLabelValue() + "|"
               regexPattern += DeployEnvironment.LAKEPRD.envLabelValue()
               regexPattern += ")"
               jobTaskName = jobTaskName.replaceFirst(regexPattern, deployEnvironment.envLabelValue())
            }
            else if( !jobTaskName.startsWith( deployEnvironment.envLabelValue() ) ){
               jobTaskName = deployEnvironment.envLabelValue() + "_" + jobTaskName
            }
            break;
         
         case DeployEnvironment.LAKEDEV:
            if(jobTaskName.startsWith( DeployEnvironment.DEV.envLabelValue() ) || 
               jobTaskName.startsWith( DeployEnvironment.TST.envLabelValue() ) || 
               jobTaskName.startsWith( DeployEnvironment.PRD.envLabelValue() ) || 
               jobTaskName.startsWith( DeployEnvironment.LAKETST.envLabelValue() ) ||
               jobTaskName.startsWith( DeployEnvironment.LAKEPRD.envLabelValue() ) ){
               
               regexPattern = "(" 
               regexPattern += DeployEnvironment.DEV.envLabelValue() + "|"
               regexPattern += DeployEnvironment.TST.envLabelValue() + "|"
               regexPattern += DeployEnvironment.PRD.envLabelValue() + "|"
               regexPattern += DeployEnvironment.LAKETST.envLabelValue() + "|"
               regexPattern += DeployEnvironment.LAKEPRD.envLabelValue()
               regexPattern += ")"
               jobTaskName = jobTaskName.replaceFirst(regexPattern, deployEnvironment.envLabelValue())
            }
            else if( !jobTaskName.startsWith( deployEnvironment.envLabelValue() ) ){
               jobTaskName = deployEnvironment.envLabelValue() + "_" + jobTaskName
            }
            break;
         
         case DeployEnvironment.LAKETST:
            if(jobTaskName.startsWith( DeployEnvironment.DEV.envLabelValue() ) || 
               jobTaskName.startsWith( DeployEnvironment.TST.envLabelValue() ) || 
               jobTaskName.startsWith( DeployEnvironment.PRD.envLabelValue() ) || 
               jobTaskName.startsWith( DeployEnvironment.LAKEDEV.envLabelValue() ) ||
               jobTaskName.startsWith( DeployEnvironment.LAKEPRD.envLabelValue() ) ){
               
               regexPattern = "(" 
               regexPattern += DeployEnvironment.DEV.envLabelValue() + "|"
               regexPattern += DeployEnvironment.TST.envLabelValue() + "|"
               regexPattern += DeployEnvironment.PRD.envLabelValue() + "|"
               regexPattern += DeployEnvironment.LAKEDEV.envLabelValue() + "|"
               regexPattern += DeployEnvironment.LAKEPRD.envLabelValue()
               regexPattern += ")"
               jobTaskName = jobTaskName.replaceFirst(regexPattern, deployEnvironment.envLabelValue())
            }
            else if( !jobTaskName.startsWith( deployEnvironment.envLabelValue() ) ){
               jobTaskName = deployEnvironment.envLabelValue() + "_" + jobTaskName
            }
            break;
         
         case DeployEnvironment.LAKEPRD:
            if(jobTaskName.startsWith( DeployEnvironment.DEV.envLabelValue() ) || 
               jobTaskName.startsWith( DeployEnvironment.TST.envLabelValue() ) || 
               jobTaskName.startsWith( DeployEnvironment.PRD.envLabelValue() ) || 
               jobTaskName.startsWith( DeployEnvironment.LAKEDEV.envLabelValue() ) ||
               jobTaskName.startsWith( DeployEnvironment.LAKETST.envLabelValue() ) ){
               
               regexPattern = "(" 
               regexPattern += DeployEnvironment.DEV.envLabelValue() + "|"
               regexPattern += DeployEnvironment.TST.envLabelValue() + "|"
               regexPattern += DeployEnvironment.PRD.envLabelValue() + "|"
               regexPattern += DeployEnvironment.LAKEDEV.envLabelValue() + "|"
               regexPattern += DeployEnvironment.LAKETST.envLabelValue()
               regexPattern += ")"
               jobTaskName = jobTaskName.replaceFirst(regexPattern, deployEnvironment.envLabelValue())
            }
            else if( !jobTaskName.startsWith( deployEnvironment.envLabelValue() ) ){
               jobTaskName = deployEnvironment.envLabelValue() + "_" + jobTaskName
            }
            break;
      }
      ////////////////////////////////////////////////////////////////////////////
   }
   else{
      jobTaskName = jobt.name + "_" +  defaultVersionPostFix
      
      if( !jobTaskName.startsWith( deployEnvironment.envLabelValue() ) ){
         jobTaskName = deployEnvironment.envLabelValue() + "_" + jobTaskName
      }
      
      if(defaultTaskNamePostfix != null && ( defaultTaskNamePostfix.trim().length() > 0 )){
         jobTaskName += "_" + defaultTaskNamePostfix
      }
   }
   
   //talend don't like periods "." in the job task name. safety check and replace all periods with underscore
   jobTaskName = jobTaskName.replace(".", "_")
   
   jobContext = jobt.envContext
   jobserver = jobt.jobServer
   executeTest = jobt.runTask
   contextValue = jobt.contextValue != null ? jobt.contextValue.trim() : ""
   println "   - job: '$job' - jobTaskName: '$jobTaskName' - jobContext: '$jobContext' - jobserver: '$jobserver' - executeTest: '$executeTest' - taskPoolSize: '$taskPoolSize'"
   
   artifact = "$nexusRepositoryUrl/$nexusGroup/$job/$pubVersion/${job}-${pubVersion}.zip"
   
   println "   - job          = $job"
   println "   - artifact     = $artifact"
   println "   - jobTaskName  = $jobTaskName"
   println "   - context      = $jobContext"
   
   for (int i = 1; i <= taskPoolSize; i++) {
      StringBuilder task = new StringBuilder(jobTaskName)
      //StringBuilder taskFormatted = new StringBuilder(jobTaskName)
      //def task = jobTaskName
      if(taskPoolSize > 1){
         //task += "_" + i.toString()
         
         numericFormat = "%0"+taskPoolSize.toString().length()+"d"
         println "----------------------------------------------------"
         println "-- Step 1-B: Build list for multiple tasks '$task' using taskPoolSize : '$taskPoolSize'"
         println "----------------------------------------------------"
         
         task.append("_" + String.format( numericFormat, i ) )
      }
      def binding = ["Job_Name":"$job", 
                     "Task_Name":"$task",
                     "task_pool_size":"$taskPoolSize"]
      def contextValueTemplate = simpleTemplateEngine.createTemplate(contextValue).make(binding)
      
      tasks_list << ([
         jobName              : job,
         taskName             : task.toString(),
         taskContext          : jobContext,
         taskJobServer        : jobserver,
         taskContextValue     : contextValueTemplate.toString(),
         taskArtifact         : artifact,
         runTask              : executeTest,
         taskDescription      : "CI '$ciJobName' Published Version: '$pubVersion' talendSvnRevision: '$talendSvnRevision'",
         deployTaskReportFile : new File(task.toString()),
         svnRevision          : talendSvnRevision,
         taskBranchName       : branchName,
         taskTagName          : tagsID,
         projectName          : project
         ] as DeployTasks)
   }
}

def jobList = ""
tasks_list.unique().each { eachTask ->
   println "----------------------------------------------------"
   println "tasks_list.each"
   println "- taskName: '$eachTask.taskName' - taskContext: '$eachTask.taskContext' - taskJobServer: '$eachTask.taskJobServer' - taskContextValue: '$eachTask.taskContextValue' - taskArtifact: '$eachTask.taskArtifact'"
   MetaServletTalendDeployment deployment = new MetaServletTalendDeployment("$tacHost", "$tacUrl", "$tacUser", "$tacPassword", "$sshUser", "$sshPassword", "$landingDir", eachTask, exec_server_host[0], prop, jobExecServer.trim())
   task_map.put(eachTask.taskName, deployment)
}

Set<String> email_list_unique  = new TreeSet<String>();
notification_list.each{ eachNotification ->
   if(eachNotification.userEmail != null && !"".equalsIgnoreCase(eachNotification.userEmail)){
      email_list_unique.add(eachNotification.userEmail.trim())
   }
}

def emailList = ""
email_list_unique.each{
   emailList += it + ", "
}

if(emailList != null && !"".equalsIgnoreCase(emailList)){
   if(emailList.endsWith(",")){
      emailList = emailList.substring(0, emailList.lastIndexOf(","))
   }
   notificationsProp.append("EMAIL_LIST=" + emailList)
   notificationsProp.append(System.getProperty("line.separator"))
}

println "    talendSvnRevision: '$talendSvnRevision'"

ciDeployFolder   = "deploy#$talendSvnRevision"

def artifact, task, taskId

println "----------------------------------------------------"
println "-- EXECUTING PARALLEL TASK DEPLOYMENT PROCESS"
println "----------------------------------------------------"

appendBuildReport(buildReport, "----------------------------------------------------")
appendBuildReport(buildReport, "-- EXECUTING PARALLEL TASK DEPLOYMENT PROCESS")
appendBuildReport(buildReport, "----------------------------------------------------")

//PoolUtils default poolsize = Runtime.getRuntime().availableProcessors() + 1;
//tweak the poolsize of GParsPool
//try 2 * processor, adjust as necessary
//dev note: 2 * processor have been tried and seems to have little or no significant gains in overall
//runtime. in addition to that, there's some intermittent issue with that many ssh connection being opened
//reverting back to default
//int poolSize = Runtime.getRuntime().availableProcessors() * 2

GParsPool.withPool() {
   task_map.eachWithIndexParallel{ eachTask , poolIndex->
      //println "pool index : $poolIndex task name : ${eachTask.key} "
      eachTask.value.executeTalendTaskDeployment()
   }
}

println "----------------------------------------------------"
println "-- FINISHED PARALLEL TASK DEPLOYMENT PROCESS"
println "----------------------------------------------------"

appendBuildReport(buildReport, "----------------------------------------------------")
appendBuildReport(buildReport, "-- FINISHED PARALLEL TASK DEPLOYMENT PROCESS")
appendBuildReport(buildReport, "----------------------------------------------------")

timeStop = new Date()
TimeDuration duration = TimeCategory.minus(timeStop, timeStart)
appendBuildReport(buildReport, "Deployment process started at " + timeStart.format("EEE MMM dd HH:mm:ss zzz yyyy", TimeZone.getTimeZone("America/Chicago")))
appendBuildReport(buildReport, "Deployment process finished at " + timeStop.format("EEE MMM dd HH:mm:ss zzz yyyy", TimeZone.getTimeZone("America/Chicago")))
appendBuildReport(buildReport, "Deployment process duration: ${duration}")
notificationsProp.append("JENKINS_JOB_END_TIME=" + timeStop.format("EEE MMM dd HH:mm:ss zzz yyyy", TimeZone.getTimeZone("America/Chicago")))
notificationsProp.append(System.getProperty("line.separator"))
notificationsProp.append("JENKINS_JOB_DURATION=" + duration.toString())
notificationsProp.append(System.getProperty("line.separator"))

task_map = task_map.sort{ it.key }
task_map.each{ eachTask ->
   eachTask.value.runTalendTask()
}

appendBuildReport(buildReport, "Finished deployment of all talend components")
appendBuildReport(buildReport, "----------------------------------------------------")

appendBuildReport(buildReport, "----------------------------------------------------")
appendBuildReport(buildReport, "DEPLOYMENT REPORT SUMMARY")

def deployment_success = [:]
def deployment_partial_success = [:]
def deployment_error = [:]
task_map.each{ eachTask ->
   appendBuildReport(buildReport, "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
   appendBuildReport(buildReport, "TASK NAME: " + eachTask.value.deployTask.taskName )
   appendBuildReport(buildReport, "TASK ID: " + eachTask.value.deployTask.taskID)
   appendBuildReport(buildReport, "DEPLOYMENT STATUS: " + eachTask.value.deployTask.deploymentStatus)
   if(eachTask.value.deployTask.deploymentStatus.equalsIgnoreCase("SUCCESS")){
      deployment_success.put(eachTask.value.deployTask.taskName, eachTask.value.deployTask.deploymentStatus)
   }
   else if(eachTask.value.deployTask.deploymentStatus.equalsIgnoreCase("ERROR")){
      deployment_error.put(eachTask.value.deployTask.taskName, eachTask.value.deployTask.deploymentStatus)
   }
   else{
      deployment_partial_success.put(eachTask.value.deployTask.taskName, eachTask.value.deployTask.deploymentStatus)
   }
   if(eachTask.value.deployTask.runTask){
      appendBuildReport(buildReport, "EXECUTION STATUS: " + eachTask.value.deployTask.executionStatus)
   }
   appendBuildReport(buildReport, "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
   jobList += eachTask.value.deployTask.taskName + " STATUS: " + eachTask.value.deployTask.deploymentStatus + ","
}
appendBuildReport(buildReport, "----------------------------------------------------")

appendBuildReport(buildReport, "TOTAL TALEND JOBS DEPLOYED SUCCESSFULLY: " + deployment_success.size())
appendBuildReport(buildReport, "TOTAL TALEND JOBS DEPLOYED PARTIAL SUCCESS: " + deployment_partial_success.size())
appendBuildReport(buildReport, "TOTAL TALEND JOBS NOT DEPLOYED: " + deployment_error.size())
appendBuildReport(buildReport, "TOTAL TALEND JOBS PROCESSED: " + task_map.size())

appendBuildReport(buildReport, "----------------------------------------------------")
appendBuildReport(buildReport, "DEPLOYMENT REPORT DETAIL")

task_map.each{ eachTask ->
   eachTask.value.deploymentReportFile.eachLine { line ->
      buildReport.append(line)
      buildReport.append(System.getProperty("line.separator"))
   }
}
appendBuildReport(buildReport, "----------------------------------------------------")
appendBuildReport(buildReport, "")

if(jobList != null && !"".equalsIgnoreCase(jobList)){
   if(jobList.endsWith(",")){
      jobList = jobList.substring(0, jobList.lastIndexOf(","))
   }
   notificationsProp.append("JOB_LIST=" + jobList)
   notificationsProp.append(System.getProperty("line.separator"))
}

if(deployment_error.size() == task_map.size()){
   appendBuildReport(buildReport, "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
   appendBuildReport(buildReport, "ERROR = ALL DEPLOYMENT FAILED" )
   appendBuildReport(buildReport, "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
   println "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
   println "ERROR = ALL DEPLOYMENT FAILED"
   println "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
}
else if(task_map.size() == deployment_success.size()){
   appendBuildReport(buildReport, "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
   appendBuildReport(buildReport, "SUCCESS = ALL DEPLOYMENT SUCCESSFUL" )
   appendBuildReport(buildReport, "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
   println "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
   println "SUCCESS = ALL DEPLOYMENT SUCCESSFUL"
   println "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
}
else{
   appendBuildReport(buildReport, "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
   appendBuildReport(buildReport, "PARTIAL SUCCESS = SOME DEPLOYMENT FAILED, PLEASE CHECK THE DEPLOYMENT SUMMARY AND DETAILS FOR INFORMATION" )
   appendBuildReport(buildReport, "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
   println "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
   println "PARTIAL SUCCESS = SOME DEPLOYMENT FAILED, PLEASE CHECK THE DEPLOYMENT SUMMARY AND DETAILS FOR INFORMATION"
   println "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
}


def appendBuildReport(reportFile, reportString){
   def now = Calendar.getInstance(TimeZone.getTimeZone("America/Chicago")).format("yyyy.MM.dd 'at' HH:mm:ss z")
   if(reportString != null && !"".equalsIgnoreCase(reportString.trim())){
      reportFile.append("$now |")
      reportFile.append(reportString)
   }
   reportFile.append(System.getProperty("line.separator"))
}

def metaServletCall(tacUrl, request){
   def urlSt = "$tacUrl/metaServlet?${request.toString().bytes.encodeBase64()}"
   //debug=true
   if(debug){
      def scrubbedRequest = request.toString()
      if(scrubbedRequest.contains(tacPassword)){
         scrubbedRequest = scrubbedRequest.replace(tacPassword, "********")
      }
      println "    >> MetaServlet request : $scrubbedRequest"
      println "    >> MetaServlet url Call: $urlSt"
   }
   
   def tresp = urlSt.toURL().text
   
   if(debug) {
      print "    >> MetaServlet response : "
      println groovy.json.JsonOutput.prettyPrint(tresp)
   }
   
   def ms_response = new groovy.json.JsonSlurper().parseText(tresp)
   
   if(debug) {
      println "    >> MetaServlet ReturnCode= $ms_response.returnCode"
   }
   return ms_response
}

def retrieveTalendExecHostname(tacUrl, tacUser, tacPassword, jobExecServer, ms_request){
   //safety check if env['JOB_EXEC_SERVER'] is a virtual server type
   ms_request (
      actionName  : 'listVirtualServers',
      authUser    : tacUser,
      authPass    : tacPassword
   )
   ms_response = metaServletCall(tacUrl, ms_request)

   def exec_server_list = []
   def exec_server_host = [] //this execution server host will need to be derived from TAC metaservlet call 'listServer'
   def virtual_server = false
   for (int i = 0; i < ms_response.result.size(); i++) {
   
      label = ms_response.result[i].label
      
      if(debug){
         println "ms_response.result[i].label : $label"
         println "jobExecServer : $jobExecServer"
      }
      
      def indivExecServer = jobExecServer.split(",")
      for(String each : indivExecServer){
         if(label.equalsIgnoreCase(each.trim())){
            virtual_server = true
            ms_response.result[i].servers.each {
               exec_server_list << it.serverLabel.toString()
            }
         }
      }
   }

   println "exec_server_list : $exec_server_list"
   ms_request (
      actionName  : 'listServer',
      authUser    : tacUser,
      authPass    : tacPassword
   )
   ms_response = metaServletCall(tacUrl, ms_request)

/*
metaservlet command for action listServer will return json object in this format
{"executionTime":{"millis":0,"seconds":0},
"result":[{"active":boolean value,
           "description":"description string",
           "fileTransferPort":numeric port value,
           "host":"hostname string (this is what i need to get from this command)",
           "id":id_value,
           "label":"label string (this is what was mapped in the environment input value JOB_EXEC_SERVER)",
           "monitoringPort":numeric port value,
           "port":numeric port value,
           "timeOutUnknownState":numeric seconds value,
           "timeZone":"CST6CDT",
           "useSSL": boolean value},
          {"active":boolean value,
           "description":"description string",
           "fileTransferPort":numeric port value,
           "host":"hostname string (this is what i need to get from this comman)",
           "id":id_value,
           "label":"label string (this is what was mapped in the environment input value JOB_EXEC_SERVER)",
           "monitoringPort":numeric port value,
           "port":numeric port value,
           "timeOutUnknownState":numeric seconds value,
           "timeZone":"CST6CDT",
           "useSSL": boolean value}],
"returnCode":0}

which translate of object in this format

ms_response.executionTime
ms_response.result[]
ms_response.result[].active
ms_response.result[].description
ms_response.result[].fileTransferPort
.
.
.
ms_response.returnCode

from the result, search the execution server lable ms_response.result[].label == JOB_EXEC_SERVER
and retrieve the ms_response.result[].host
*/
   
   for (int i = 0; i < ms_response.result.size(); i++) {
      label = ms_response.result[i].label
      host = ms_response.result[i].host
      if(debug){
         println "ms_response.result[i].label : $label"
         println "ms_response.result[i].host : $host"
         println "jobExecServer : $jobExecServer"
      }
      
      def indivExecServer = []
      if(!virtual_server){
         indivExecServer = jobExecServer.split(",")
      }
      
      if(exec_server_list != null && exec_server_list.size() > 0){
      
         exec_server_list.each {
            indivExecServer << it
         }
      }
      for(String each : indivExecServer){
         if(label.equalsIgnoreCase(each.trim())){
            exec_server_host << host.toString()
         }
      }
   }
   
   if(exec_server_host != null && exec_server_host.size() > 0){
      println "exec_server_host : $exec_server_host"
      return exec_server_host
   }
   else{
      println "talend execution server host cannot be derived from environment property value: 'JOB_EXEC_SERVER'"
      appendBuildReport(buildReport, "talend execution server host cannot be derived from environment property value: 'JOB_EXEC_SERVER'")
      System.exit(1)
   }
}

def loadEnvPropertiesFile(envPropFileName){
   Properties properties = null
   
   if(envPropFileName != null && !"".equalsIgnoreCase(envPropFileName.trim())){
      def envPropFile = new FileNameFinder().getFileNames(".", "**/$envPropFileName")
      def deployEnvPropFileName = null
      
      if(envPropFile.size() > 0 && Files.exists(Paths.get(envPropFile[0]))){
         println "    >> True: environment property file found : ${envPropFile[0]}"
         deployEnvPropFileName = "${envPropFile[0]}"
         properties = new Properties()
         File propertiesFile = Paths.get(deployEnvPropFileName).toFile()
         propertiesFile.withInputStream {
            properties.load(it)
         }
      }
   }
   return properties
}

public class MetaServletTalendDeployment{
   String tacHost;
   String tacUrl;
   String tacUser;
   String tacPwd;
   String sshUser;
   String sshPwd;
   String landingDir;
   String defaultJobServer;
   File deploymentReportFile;
   DeployTasks deployTask;
   Boolean debug;
   AntBuilder antDeploy;
   File postDeploymentFile;
   String execServerHost;
   Properties execProp;
   
   public MetaServletTalendDeployment(String tacHost, String tacUrl, String tacUser, String tacPwd,
      String sshUser, String sshPwd, String landingDir, DeployTasks deployTask,
      String execServerHost, Properties execProp, String defaultJobServer){
      this.tacHost = tacHost;
      this.tacUrl = tacUrl;
      this.tacUser = tacUser;
      this.tacPwd = tacPwd;
      this.sshUser = sshUser;
      this.sshPwd = sshPwd;
      this.landingDir = landingDir;
      this.deployTask = deployTask;
      this.deploymentReportFile = new File(this.deployTask.taskName);
      this.antDeploy = new AntBuilder();
      this.execServerHost = execServerHost;
      this.execProp = execProp;
      this.postDeploymentFile = new File(this.deployTask.jobName + "." + this.deployTask.taskName);
      this.defaultJobServer = defaultJobServer;
   }

   private void appendDeployTaskReport(reportString){
      def now = Calendar.getInstance(TimeZone.getTimeZone("America/Chicago")).format("yyyy.MM.dd 'at' HH:mm:ss z")
      if(reportString != null && !"".equalsIgnoreCase(reportString.trim())){
         this.deploymentReportFile.append("$now | " + reportString)
      }
      this.deploymentReportFile.append(System.getProperty("line.separator"))
   }

   private Object metaServletCall(request){
      String urlSt = this.tacUrl + (this.tacUrl.endsWith("/") ? "": "/" ) +"metaServlet?${request.toString().bytes.encodeBase64()}"
      //this.debug = true
      if(this.debug){
         String scrubbedRequest = request.toString()
         if(scrubbedRequest.contains(this.tacPwd)){
            scrubbedRequest = scrubbedRequest.replace(this.tacPwd, "********")
         }
         println "    >> MetaServlet request : $scrubbedRequest"
         println "    >> MetaServlet url Call: $urlSt"
      }
      
      String response = urlSt.toURL().text
      
      if(this.debug) {
         print "    >> MetaServlet response : "
         println groovy.json.JsonOutput.prettyPrint(response)
      }
      
      return (new groovy.json.JsonSlurper().parseText(response))
   }
   
   private Object getTaskIdByName(){
      JsonBuilder ms_request = new groovy.json.JsonBuilder()
      ms_request (
          actionName : 'getTaskIdByName',
          authUser   : this.tacUser,
          authPass   : this.tacPwd,
          taskName   : this.deployTask.taskName
      )
      return this.metaServletCall(ms_request)
   }
   
   private Object updateTask(String taskId, String deployArtifact){
      JsonBuilder ms_request = new groovy.json.JsonBuilder()
      def now = Calendar.getInstance(TimeZone.getTimeZone("America/Chicago")).format("yyyy.MM.dd 'at' HH:mm:ss z")
      ms_request (
         actionName              : 'updateTask',
         authUser                : this.tacUser,
         authPass                : this.tacPwd,
         taskId                  : taskId,
         projectName             : this.deployTask.projectName,
         jobName                 : this.deployTask.jobName,
         description             : this.deployTask.taskDescription + " $now",
         filePath                : deployArtifact,
         active                  : true,
         onUnknownStateJob       : "WAIT",
         execStatisticsEnabled   : true,
         executionServerName     : this.deployTask.taskJobServer,
         contextName             : this.deployTask.taskContext
      )
      return this.metaServletCall(ms_request)
   }
   
   private Object updateTaskContext(String taskId, Object contextJsonObject, String deployArtifact){
      JsonBuilder ms_request = new groovy.json.JsonBuilder()
      
      if(contextJsonObject != null){
         ms_request (
            actionName           : 'updateTask',
            authUser             : this.tacUser,
            authPass             : this.tacPwd,
            taskId               : taskId,
            projectName          : this.deployTask.projectName,
            jobName              : this.deployTask.jobName,
            filePath             : deployArtifact,
            contextName          : this.deployTask.taskContext,
            context              : contextJsonObject
         )
         return this.metaServletCall(ms_request)
      }
      //ELSE CONDITION IS IRRELEVANT BECAUSE OF TALEND BUG!
      else{
         ms_request (
            actionName           : 'updateTask',
            authUser             : this.tacUser,
            authPass             : this.tacPwd,
            taskId               : taskId,
            projectName          : this.deployTask.projectName,
            jobName              : this.deployTask.jobName,
            filePath             : deployArtifact,
            contextName          : this.deployTask.taskContext
         )
         return this.metaServletCall(ms_request)
      }
   }
   
   private Object runTask(String taskId){
      JsonBuilder ms_request = new groovy.json.JsonBuilder()
      ms_request (
         actionName     : 'runTask',
         authUser       : this.tacUser,
         authPass       : this.tacPwd,
         mode           : 'synchronous',
         taskId         : taskId
      )
      return this.metaServletCall(ms_request)
   }
   
   private Object taskLog(String taskId){
      JsonBuilder ms_request = new groovy.json.JsonBuilder()
      ms_request (
         actionName     : 'taskLog',
         authUser       : this.tacUser,
         authPass       : this.tacPwd,
         taskId         : taskId
      )
      return this.metaServletCall(ms_request)
   }
   
   private Object getTaskStatus(String taskId){
      JsonBuilder ms_request = new groovy.json.JsonBuilder()
      ms_request (
         actionName     : 'getTaskStatus',
         authUser       : this.tacUser,
         authPass       : this.tacPwd,
         taskId         : taskId
      )
      return this.metaServletCall(ms_request)
   }
   
   private Object stopTask(String taskId){
      JsonBuilder ms_request = new groovy.json.JsonBuilder()
      ms_request (
         actionName     : 'stopTask',
         authUser       : this.tacUser,
         authPass       : this.tacPwd,
         taskId         : taskId
      )
      return this.metaServletCall(ms_request)
   }
   
   private Object requestDeploy(String taskId){
      JsonBuilder ms_request = new groovy.json.JsonBuilder()
      ms_request (
         actionName  : 'requestDeploy',
         authUser    : this.tacUser,
         authPass    : this.tacPwd,
         taskId      : taskId
      )
      return this.metaServletCall(ms_request)
   }
   
   private String downloadDeployArtifact(){
      String deployArtifact = this.generateDeployArtifactName()
      
      this.antDeploy.sshexec(
         host        : this.tacHost,
         username    : this.sshUser,
         password    : this.sshPwd,
         output      : "${this.deployTask.taskName}_wget_status",
         trust       : "true",
         command     : "wget --quiet ${this.deployTask.taskArtifact} --output-document=${deployArtifact} || echo \$?",
         verbose     : false)
         
      def wgetStatus = new File("${this.deployTask.taskName}_wget_status").text
      
      if(wgetStatus != null && !"".equals(wgetStatus) && !wgetStatus.equals("0")){
         this.appendDeployTaskReport("******************************************************************************************")
         this.appendDeployTaskReport("******************************************************************************************")
         this.appendDeployTaskReport("******************************************************************************************")
         this.appendDeployTaskReport("ERROR: EXCEPTION WHEN CALLING downloadDeployArtifact()")
         this.appendDeployTaskReport("ERROR: ${this.deployTask.taskArtifact} cannot be downloaded into  ${deployArtifact}")
         this.appendDeployTaskReport("ERROR: please verify there's permission to write ${deployArtifact} and verify ${this.deployTask.taskArtifact} exist")
         this.appendDeployTaskReport("******************************************************************************************")
         this.appendDeployTaskReport("******************************************************************************************")
         this.appendDeployTaskReport("******************************************************************************************")
         return null
      }
      else{
         return deployArtifact
      }
   }
   
   private void cleanupDeployArtifact(){
      String deployArtifact = this.generateDeployArtifactName()
      
      try{
         this.antDeploy.sshexec(
            host        : this.tacHost,
            username    : this.sshUser,
            password    : this.sshPwd,
            trust       :"true",
            command     :"rm -f ${deployArtifact}",
            timeout     : 60000,
            verbose:false)
      }
      catch(all){
         this.appendDeployTaskReport("******************************************************************************************")
         this.appendDeployTaskReport("******************************************************************************************")
         this.appendDeployTaskReport("******************************************************************************************")
         this.appendDeployTaskReport("WARNING: EXCEPTION WHEN CALLING cleanupDeployArtifact()")
         this.appendDeployTaskReport("WARNING: $deployArtifact may still be in the TAC server ${this.tacHost}")
         this.appendDeployTaskReport("WARNING: please do a manual cleanup if necessary")
         this.appendDeployTaskReport("WARNING: $all")
         this.appendDeployTaskReport("******************************************************************************************")
         this.appendDeployTaskReport("******************************************************************************************")
         this.appendDeployTaskReport("******************************************************************************************")
      }
   }
   
   
   private String generateDeployArtifactName(){
      String nexusArtifact = new String(this.deployTask.taskArtifact)
      Integer i=new Integer(nexusArtifact.lastIndexOf("/"))
      String localArtifact = new String(nexusArtifact.substring(i+1))
      String artifactExtension = FilenameUtils.getExtension(localArtifact)
      String deployArtifact = this.landingDir + FileSystems.getDefault().getSeparator() + this.deployTask.taskName + "." + artifactExtension
      
      return deployArtifact
   }
   
   private void appendPostDeploymentFile(content){
      this.postDeploymentFile.append(content)
      this.postDeploymentFile.append(System.getProperty("line.separator"))
   }
   
   private void sendPostDeploymentDir(){
      def dirPermission = "--mode=770"
      def postDeploymentDir = ""
      def postDeploymentTriggerDir = ""
      
      if(this.execProp.dir_permission != null && this.execProp.dir_permission.toString().trim().length() > 0){
         dirPermission = "--mode=${properties.dir_permission}"
      }
      if(this.execProp.jenkins_post_deployment_dir != null && this.execProp.jenkins_post_deployment_dir.toString().trim().length() > 0){
         postDeploymentDir = this.execProp.jenkins_post_deployment_dir.toString().trim()
         
         try{
            //safety command to make directory if not exists
            antDeploy.sshexec(
               host                 : this.execServerHost,
               username             : this.sshUser,
               password             : this.sshPwd,
               trust                : "true",
               suppresssystemout    : "true",
               command              :"[ -d $postDeploymentDir ] || mkdir -v -p ${dirPermission} $postDeploymentDir",
               verbose              :false)
         }catch(all){
            println "Error creating directory $postDeploymentDir. $all"
            return
         }
         
         Path infoFile = Files.copy(Paths.get(this.postDeploymentFile.getAbsolutePath()), Paths.get(this.postDeploymentFile.getAbsolutePath() + ".info"))
         try{
            if(debug){
               println "deploying ${infoFile.toString()} to @$deployHost:$postDeploymentDir"
            }
            antDeploy.scp(
               trust       :"true",
               localFile   :"${infoFile.toString()}",
               todir       :"${this.sshUser}:${this.sshPwd}@${this.execServerHost}:${postDeploymentDir}",
               verbose     :false
               )
            Files.deleteIfExists(infoFile)
         }catch(all){
            report = "Error moving files ${infoFile.toString()} to @$deployHost:$postDeploymentDir, skipping file. $all"		
            return
         }
      }
      if(this.execProp.jenkins_test_automation_trigger_dir != null && this.execProp.jenkins_test_automation_trigger_dir.toString().trim().length() > 0){
         postDeploymentTriggerDir = this.execProp.jenkins_test_automation_trigger_dir.toString().trim()
         
         try{
            //safety command to make directory if not exists
            antDeploy.sshexec(
               host                 : this.execServerHost,
               username             : this.sshUser,
               password             : this.sshPwd,
               trust                : "true",
               suppresssystemout    : "true",
               command              :"[ -d ${postDeploymentTriggerDir} ] || mkdir -v -p ${dirPermission} ${postDeploymentTriggerDir}",
               verbose              :false)
         }catch(all){
            println "Error creating directory $postDeploymentTriggerDir . $all"
            return
         }
         Path triggerFile = Files.copy(Paths.get(this.postDeploymentFile.getAbsolutePath()), Paths.get(this.postDeploymentFile.getAbsolutePath() + ".trg"))
         try{
            if(debug){
               println "deploying ${triggerFile.toString()} to @$deployHost:$postDeploymentTriggerDir"
            }
            antDeploy.scp(
               trust       :"true",
               localFile   :"${triggerFile.toString()}",
               todir       :"${this.sshUser}:${this.sshPwd}@${this.execServerHost}:${postDeploymentTriggerDir}",
               verbose     :false
               )
            Files.deleteIfExists(triggerFile)
         }catch(all){
            report = "Error moving files ${triggerFile.toString()} to @$deployHost:$postDeploymentTriggerDir, skipping file. $all"		
            return
         }
      }
      
      if(debug){
         println "    >> postDeploymentDir : $postDeploymentDir" 
         println "    >> postDeploymentTriggerDir : $postDeploymentTriggerDir" 
         println "    >> dirPermission : $dirPermission"
         println "    >> name : ${postDeploymentFile}"
      }
      return 
   }

   public String executeTalendTaskDeployment(){
      String taskID = null
      try{
         taskID = this.deployTalendTask()
         this.deployTask.taskID = taskID
         this.cleanupDeployArtifact()
         if(this.deployTask.deploymentStatus == null || "".equalsIgnoreCase(this.deployTask.deploymentStatus.trim())){
            this.deployTask.deploymentStatus = "SUCCESS"
         }
         
         if(this.deployTask.taskID != null && !"".equalsIgnoreCase(this.deployTask.taskID.trim())){
            Files.deleteIfExists(Paths.get(this.deployTask.jobName + "." + this.deployTask.taskName))
            this.appendPostDeploymentFile("TASK_ID=${this.deployTask.taskID}")
            this.appendPostDeploymentFile("JOB_NAME=${this.deployTask.jobName}")
            this.appendPostDeploymentFile("TASK_NAME=${this.deployTask.taskName}")
            this.appendPostDeploymentFile("DEPLOYMENT_TIMESTAMP=${this.deployTask.deploymentTimestamp}")
            this.appendPostDeploymentFile("ARTIFACT_ORIGIN=${this.deployTask.taskArtifact}")
            this.appendPostDeploymentFile("CONTEXT=${this.deployTask.taskContext}")
            this.appendPostDeploymentFile("CONTEXT_VALUE=${this.deployTask.taskContextValue}")
            this.appendPostDeploymentFile("JOB_SERVER=${this.deployTask.taskJobServer}")
            this.appendPostDeploymentFile("TAC_URL=${this.tacUrl}")
            
            if(this.deployTask.taskTagName != null && !"".equalsIgnoreCase(this.deployTask.taskTagName.trim())){
               appendPostDeploymentFile("TAGS=${this.deployTask.taskTagName}")
            }
            
            if(this.deployTask.taskBranchName != null && !"".equalsIgnoreCase(this.deployTask.taskBranchName.trim())){
               appendPostDeploymentFile("BRANCH=${this.deployTask.taskBranchName}")
            }
            appendPostDeploymentFile("SVN_REVISION=${this.deployTask.svnRevision}")
            
         }
         
         if(this.deployTask.deploymentStatus.contains("SUCCESS") && 
            this.execProp != null && (this.execServerHost != null && !"".equalsIgnoreCase(this.execServerHost.trim()))){
            this.sendPostDeploymentDir()
         }
      }
      catch(all){
         taskID = null
         this.cleanupDeployArtifact()
         this.appendDeployTaskReport("******************************************************************************************")
         this.appendDeployTaskReport("******************************************************************************************")
         this.appendDeployTaskReport("******************************************************************************************")
         this.appendDeployTaskReport("ERROR: EXCEPTION WHEN CALLING deployTalendTask()")
         this.appendDeployTaskReport("ERROR: $all")
         this.appendDeployTaskReport("******************************************************************************************")
         this.appendDeployTaskReport("******************************************************************************************")
         this.appendDeployTaskReport("******************************************************************************************")
         this.deployTask.deploymentStatus = "ERROR"
      }
      return taskID
   }
   
   private String deployTalendTask(){
      //this.deployTask
      
      def now = Calendar.getInstance(TimeZone.getTimeZone("America/Chicago")).format("yyyy.MM.dd 'at' HH:mm:ss z")
      JsonBuilder ms_request = new groovy.json.JsonBuilder()
      this.deployTask.deploymentStatus = ""
      this.deployTask.deploymentTimestamp = "$now"
      //println "   - deployTalendTask: Check if task '${this.deployTask.taskName}' already exist"
      this.appendDeployTaskReport("******************************************************************************************")
      this.appendDeployTaskReport("Starting deployment process for '${this.deployTask.taskName}'")
      this.appendDeployTaskReport("******************************************************************************************")
      this.appendDeployTaskReport("------------------------------------------------------------------------------------------")
      this.appendDeployTaskReport("PRE-CHECK: Check if task '${this.deployTask.taskName}' already exist")
      this.appendDeployTaskReport("------------------------------------------------------------------------------------------")
      def getTaskIdByNameResponse = getTaskIdByName()
      int retryAttempt = 0
      int retryLimit = 10
      String taskId = null
      String deployArtifact = this.downloadDeployArtifact()
      
      if(deployArtifact == null){
         this.deployTask.deploymentStatus = "ERROR"
         return null
      }
      
      if(getTaskIdByNameResponse.returnCode == 5){   ////!!!! Task does not exist. Create it
         //println "No existing task with label= '${this.deployTask.taskName}'"
         this.appendDeployTaskReport("No existing task with label= '${this.deployTask.taskName}' found on TAC: ${this.tacHost}")
         //println "deployTalendTask: Create task '${this.deployTask.taskName}'  filePath: '@$tacHost:${this.deployTask.deployArtifact.taskDeployArtifact}'"
         
         this.appendDeployTaskReport("------------------------------------------------------------------------------------------")
         this.appendDeployTaskReport("START Step 1: CREATING new task '${this.deployTask.taskName}'")
         this.appendDeployTaskReport("using artifact from : '${this.deployTask.taskArtifact}'")
         this.appendDeployTaskReport("------------------------------------------------------------------------------------------")
         def associatePreGeneratedJobResponse = null
         while(retryAttempt < retryLimit){
            retryAttempt++
            ms_request (
               actionName          : 'associatePreGeneratedJob',
               authUser            : this.tacUser,
               authPass            : this.tacPwd,
               taskName            : this.deployTask.taskName,
               contextName         : this.deployTask.taskContext,
               filePath            : deployArtifact,
               active              : true,
               onUnknownStateJob   : "WAIT",
               description         : this.deployTask.taskDescription + "$now",
               executionServerName : this.deployTask.taskJobServer
            )
            
            associatePreGeneratedJobResponse = this.metaServletCall(ms_request)
      
            if(associatePreGeneratedJobResponse.returnCode != 0 && 
               ("${associatePreGeneratedJobResponse.error}".contains("(No such file or directory)") ||
                "${associatePreGeneratedJobResponse.error}".contains("Error when decompressing the uploaded file") ||
                "${associatePreGeneratedJobResponse.error}".contains("This job doesn't have context:") ||
                "${associatePreGeneratedJobResponse.error}".contains("Can't find the execution server"))){
               //println "     - Error creating task. Error= ${associatePreGeneratedJobResponse.error}"
               this.appendDeployTaskReport("WARNING = Error creating task: '${this.deployTask.taskName}'")
               this.appendDeployTaskReport("WARNING = ${associatePreGeneratedJobResponse.error}")
               //println "     - Retrying... attempt $retryAttempt of $retryLimit"
               this.appendDeployTaskReport("WARNING = Retrying... attempt $retryAttempt of $retryLimit")
               if("${associatePreGeneratedJobResponse.error}".contains("This job doesn't have context:")){
                  this.deployTask.taskContext = "Default"
                  this.appendDeployTaskReport("WARNING = ${associatePreGeneratedJobResponse.error} Forcing to use 'Default' context")
                  this.deployTask.deploymentStatus = "PARTIAL"
               }
               if("${associatePreGeneratedJobResponse.error}".contains("Can't find the execution server")){
                  this.deployTask.taskJobServer = this.defaultJobServer
                  this.appendDeployTaskReport("WARNING = ${associatePreGeneratedJobResponse.error} Forcing to use Default execution server ${this.defaultJobServer}")
                  this.deployTask.deploymentStatus = "PARTIAL"
               }
               if("${associatePreGeneratedJobResponse.error}".contains("Error when decompressing the uploaded file")){
                  deployArtifact = this.downloadDeployArtifact()
      
                  if(deployArtifact == null){
                     this.deployTask.deploymentStatus = "ERROR"
                     return null
                  }
               }
            }
            else{
               break;
            }
         }
         if(associatePreGeneratedJobResponse.returnCode != 0){
            //println "     - Error creating task. Error= ${associatePreGeneratedJobResponse.error}"
            this.appendDeployTaskReport("ERROR = Error creating task: '${this.deployTask.taskName}'")
            this.appendDeployTaskReport("ERROR = ${associatePreGeneratedJobResponse.error}")
            this.appendDeployTaskReport("ERROR = Retry attempt has been exceeded.")
            this.appendDeployTaskReport("ERROR = Task '${this.deployTask.taskName}' is not created")
            this.deployTask.deploymentStatus = "ERROR"
            return null
         }
         else{
            //println "   - deployTalendTask: Get task ID for task ${this.deployTask.taskName}"
            this.appendDeployTaskReport("Get task ID for task ${this.deployTask.taskName}")
            try{
               taskId = getTaskIdByName().taskId.toString()
               this.appendDeployTaskReport("Task: ${this.deployTask.taskName} Task ID: $taskId")
            }
            catch(all){
               this.appendDeployTaskReport("ERROR = Error retrieving task id for : ${this.deployTask.taskName}, is the task exists?")
               this.deployTask.deploymentStatus = "ERROR"
               return null
            }
         }
         
         this.appendDeployTaskReport("------------------------------------------------------------------------------------------")
         this.appendDeployTaskReport("END Step 1: Task: ${this.deployTask.taskName} Task ID: $taskId CREATED")
         this.appendDeployTaskReport("------------------------------------------------------------------------------------------")
      }
      else{  ////!!!! Task already exist Update it
         taskId = getTaskIdByNameResponse.taskId.toString()
         //println "     - Task already exist: check the status"
         this.appendDeployTaskReport("Task already exist")
         
         this.appendDeployTaskReport("------------------------------------------------------------------------------------------")
         this.appendDeployTaskReport("START Step 1: UPDATING Task: ${this.deployTask.taskName} Task ID: $taskId")
         this.appendDeployTaskReport("using artifact from : '${this.deployTask.taskArtifact}'")
         this.appendDeployTaskReport("------------------------------------------------------------------------------------------")
         
         this.appendDeployTaskReport("Checking task status")
         def getTaskStatusResponse = getTaskStatus(taskId)
      
         if(getTaskStatusResponse.returnCode != 0){
            //println "     - Error checking task status. Error= ${getTaskStatusResponse.error}"
            this.appendDeployTaskReport("Error checking task status. Error= ${getTaskStatusResponse.error}")
         }
         else{
            if(getTaskStatusResponse.status == 'RUNNING'){
               //println "      -  Status     : '${getTaskStatusResponse.status}'"
               this.appendDeployTaskReport("Task status : '${getTaskStatusResponse.status}'")
               //println "     - Task is currently RUNNING: stopping task"
               this.appendDeployTaskReport("Task is currently RUNNING")
               this.appendDeployTaskReport("Stopping Task: ${this.deployTask.taskName} Task ID: $taskId for update")
               
               retryAttempt = 0
               def stopTaskResponse = null
               while(retryAttempt < retryLimit){
                  retryAttempt++
                  stopTaskResponse = stopTask(taskId)
                  if(stopTaskResponse.returnCode != 0){
                     //println "     - Error updating task. Error= ${updateTaskResponse.error}"
                     //println "     - Retrying... attempt $retryAttempt of $retryLimit"
                     this.appendDeployTaskReport("WARNING = Error Stopping Task: ${this.deployTask.taskName} Task ID: $taskId")
                     this.appendDeployTaskReport("WARNING = ${stopTaskResponse.error}")
                     this.appendDeployTaskReport("WARNING = Retrying... attempt $retryAttempt of $retryLimit")
                  }
                  else{
                     break;
                  }
               }
               
               if(stopTaskResponse.returnCode != 0){
                  //println "     - Error stopping task. Error= ${stopTaskResponse.error}"
                  this.appendDeployTaskReport("ERROR = Error Stopping Task: ${this.deployTask.taskName} Task ID: $taskId")
                  this.appendDeployTaskReport("ERROR = ${stopTaskResponse.error}")
                  this.appendDeployTaskReport("ERROR = Retry attempt exceeded. Stopping attempt")
                  this.appendDeployTaskReport("ERROR = ${this.deployTask.taskName} cannot be stopped and not updated")
                  this.deployTask.deploymentStatus = "ERROR"
                  return null
               }
            }
            else{
               this.appendDeployTaskReport("Task status : '${getTaskStatusResponse.status}'")
            }
         }
       
         //println "     - Task already exist: update it"
         this.appendDeployTaskReport("Updating Task: ${this.deployTask.taskName} Task ID: $taskId")
         //println "     - taskId= '$taskId'"
         //println "     - contextName= '$job_context'"
         //println "     - artifact= '@$tacHost:$landingDir/${artifact_pck.substring(i+1)}'"
         //println "   - deployTalendTask: Update task ${this.deployTask.taskName}"
         retryAttempt = 0
         def updateTaskResponse = null
         while(retryAttempt < retryLimit){
            retryAttempt++
            updateTaskResponse = updateTask(taskId, deployArtifact)
            if(updateTaskResponse.returnCode != 0 && 
               ("${updateTaskResponse.error}".contains("(No such file or directory)") ||
                "${updateTaskResponse.error}".contains("Error when decompressing the uploaded file") ||
                "${updateTaskResponse.error}".contains("This job doesn't have context:") ||
                "${updateTaskResponse.error}".contains("Can't find the execution server"))){
               //println "     - Error updating task. Error= ${updateTaskResponse.error}"
               //println "     - Retrying... attempt $retryAttempt of $retryLimit"
               this.appendDeployTaskReport("WARNING = Error updating Task: ${this.deployTask.taskName} Task ID: $taskId")
               this.appendDeployTaskReport("WARNING = ${updateTaskResponse.error}")
               this.appendDeployTaskReport("WARNING = Retrying... attempt $retryAttempt of $retryLimit")
               if("${updateTaskResponse.error}".contains("This job doesn't have context:")){
                  this.deployTask.taskContext = "Default"
                  this.appendDeployTaskReport("WARNING = ${updateTaskResponse.error} Forcing to use 'Default' context")
                  this.deployTask.deploymentStatus = "PARTIAL"
               }
               if("${updateTaskResponse.error}".contains("Can't find the execution server")){
                  this.deployTask.taskJobServer = this.defaultJobServer
                  this.appendDeployTaskReport("WARNING = ${updateTaskResponse.error} Forcing to use Default execution server ${this.defaultJobServer}")
                  this.deployTask.deploymentStatus = "PARTIAL"
               }
               if("${updateTaskResponse.error}".contains("Error when decompressing the uploaded file")){
                  deployArtifact = this.downloadDeployArtifact()
      
                  if(deployArtifact == null){
                     this.deployTask.deploymentStatus = "ERROR"
                     return null
                  }
               }
            }
            else{
               break;
            }
         }
      
         if(updateTaskResponse.returnCode != 0){
            //println "     - Error updating task. Error= $updateTaskResponse.error"
            this.appendDeployTaskReport("ERROR = Error updating Task: ${this.deployTask.taskName} Task ID: $taskId")
            this.appendDeployTaskReport("ERROR = ${updateTaskResponse.error}")
            this.appendDeployTaskReport("ERROR = Retry attempt exceeded. Stopping")
            this.appendDeployTaskReport("ERROR = ${this.deployTask.taskName} cannot be updated")
            this.deployTask.deploymentStatus = "ERROR"
            return null
         }
         
         this.appendDeployTaskReport("------------------------------------------------------------------------------------------")
         this.appendDeployTaskReport("END Step 1: Task: ${this.deployTask.taskName} Task ID: $taskId UPDATED")
         this.appendDeployTaskReport("------------------------------------------------------------------------------------------")
      } // End of else{  ////!!!! Task already exist Update it

      def jsonParser = new groovy.json.JsonSlurper()
      def contextJsonObj = null
      try{
         if(this.deployTask.taskContextValue != null && this.deployTask.taskContextValue.trim().length() > 0){
            contextJsonObj = jsonParser.parseText("{" + this.deployTask.taskContextValue + "}")
         }
      }
      catch(all){
         //println "ERROR PARSING CONTEXT VALUE INTO JSON OBJECT: ${this.deployTask.taskContextValue}"
         this.appendDeployTaskReport("ERROR PARSING CONTEXT VALUE INTO JSON OBJECT: ${this.deployTask.taskContextValue}")
         //println "$all"
         this.appendDeployTaskReport("$all")
         //appendBuildReport(buildReport, "ERROR PARSING CONTEXT VALUE INTO JSON OBJECT: $context_value.")
         //appendBuildReport(buildReport, "$all")
         this.appendDeployTaskReport("TALEND TASK ${this.deployTask.taskName} WILL BE DEPLOYED WITHOUT CONTEXT VALUE PARAMETERS")
         contextJsonObj = null
         this.deployTask.deploymentStatus = "PARTIAL"
      }
      
      if(contextJsonObj != null){
         this.appendDeployTaskReport("------------------------------------------------------------------------------------------")
         this.appendDeployTaskReport("START Step 2: UPDATING Task: ${this.deployTask.taskName} Task ID: $taskId")
         this.appendDeployTaskReport("Using context ENVIRONMENT : ${this.deployTask.taskContext}")
         this.appendDeployTaskReport("Using context PARAMETERS : ${this.deployTask.taskContextValue}")
         
         retryAttempt = 0
         def updateTaskContextResponse = null
         while(retryAttempt < retryLimit){
            retryAttempt++
            updateTaskContextResponse = this.updateTaskContext(taskId, contextJsonObj, deployArtifact)
            if(updateTaskContextResponse.returnCode != 0){
               //println "     - Error updating task. Error= ${updateTaskContextResponse.error}"
               //println "     - Retrying... attempt $retryAttempt of $retryLimit"
               this.appendDeployTaskReport("WARNING = Error updating Task: ${this.deployTask.taskName} Task ID: $taskId")
               this.appendDeployTaskReport("WARNING = ${updateTaskContextResponse.error}")
               this.appendDeployTaskReport("WARNING = Retrying... attempt $retryAttempt of $retryLimit")
            }
            else{
               break;
            }
         }
         
         if(updateTaskContextResponse.returnCode != 0){
            //println "     - Error updating task. Error= $updateTaskContextResponse.error"
            this.appendDeployTaskReport("ERROR = Error updating Task: ${this.deployTask.taskName} Task ID: $taskId")
            this.appendDeployTaskReport("ERROR = ${updateTaskContextResponse.error}")
            this.appendDeployTaskReport("ERROR = Retry attempt exceeded. Stopping")
            this.appendDeployTaskReport("ERROR = ${this.deployTask.taskName} cannot be updated")
            this.deployTask.deploymentStatus = "ERROR"
            return null
         }
         this.appendDeployTaskReport("------------------------------------------------------------------------------------------")
         this.appendDeployTaskReport("------------------------------------------------------------------------------------------")
         this.appendDeployTaskReport("END Step 2: Task: ${this.deployTask.taskName} Task ID: $taskId UPDATED")
         this.appendDeployTaskReport("Using context ENVIRONMENT : ${this.deployTask.taskContext}")
         this.appendDeployTaskReport("Using context PARAMETERS : ${this.deployTask.taskContextValue}")
      }
      this.appendDeployTaskReport("------------------------------------------------------------------------------------------")
      
      this.appendDeployTaskReport("------------------------------------------------------------------------------------------")
      this.appendDeployTaskReport("START Final Step: DEPLOYING Task: ${this.deployTask.taskName} Task ID: $taskId")
      this.appendDeployTaskReport("------------------------------------------------------------------------------------------")
      retryAttempt = 0
      def requestDeployResponse = null
      while(retryAttempt < retryLimit){
         retryAttempt++
         requestDeployResponse = this.requestDeploy(taskId)
         if(requestDeployResponse.returnCode != 0){
            //println "     - Error updating task. Error= ${updateTaskResponse.error}"
            //println "     - Retrying... attempt $retryAttempt of $retryLimit"
            this.appendDeployTaskReport("WARNING = Error deploying Task: ${this.deployTask.taskName} Task ID: $taskId")
            this.appendDeployTaskReport("WARNING = ${requestDeployResponse.error}")
            this.appendDeployTaskReport("WARNING = Retrying... attempt $retryAttempt of $retryLimit")
         }
         else{
            break;
         }
      }
      
      if(requestDeployResponse.returnCode != 0){
         //println "     - Error updating task. Error= $updateTaskResponse.error"
         this.appendDeployTaskReport("ERROR = Error deploying Task: ${this.deployTask.taskName} Task ID: $taskId")
         this.appendDeployTaskReport("ERROR = ${requestDeployResponse.error}")
         this.appendDeployTaskReport("ERROR = Retry attempt exceeded. Stopping")
         this.appendDeployTaskReport("ERROR = ${this.deployTask.taskName} cannot be deployed")
         this.deployTask.deploymentStatus = "ERROR"
         return null
      }
      
      this.appendDeployTaskReport("------------------------------------------------------------------------------------------")
      this.appendDeployTaskReport("END Final Step: Task: ${this.deployTask.taskName} Task ID: $taskId DEPLOYED")
      this.appendDeployTaskReport("------------------------------------------------------------------------------------------")
      this.appendDeployTaskReport("******************************************************************************************")
      this.appendDeployTaskReport("Finished deployment process for '${this.deployTask.taskName}'")
      this.appendDeployTaskReport("******************************************************************************************")
      this.deployTask.deploymentStatus = this.deployTask.deploymentStatus  + "SUCCESS"
      return taskId
   }
   
   public void runTalendTask(){
      if(this.deployTask.runTask){
         JsonBuilder ms_request = new groovy.json.JsonBuilder()
         //println "   - deployTalendTask: Check if task '${this.deployTask.taskName}' already exist"
         String taskId = null
         this.appendDeployTaskReport("******************************************************************************************")
         this.appendDeployTaskReport("Attempting to auto-execute '${this.deployTask.taskName}'")
         this.appendDeployTaskReport("******************************************************************************************")
         this.appendDeployTaskReport("Check if task '${this.deployTask.taskName}' already exist")
         def getTaskIdByNameResponse = getTaskIdByName()
         
         if(getTaskIdByNameResponse.returnCode == 5){   ////!!!! Task does not exist. Create it
            //println "No existing task with label= '${this.deployTask.taskName}'"
            this.appendDeployTaskReport("No existing task with label= '${this.deployTask.taskName}'")
         }
         else{
            taskId = getTaskIdByNameResponse.taskId.toString()
            //println "     - Task already exist: check the status"
            this.appendDeployTaskReport("Task: ${this.deployTask.taskName} Task ID: $taskId exists, check the status")
            this.appendDeployTaskReport("Check the status")
         
            def getTaskStatusResponse = getTaskStatus(taskId)
         
            if(getTaskStatusResponse.returnCode != 0){
               //println "     - Error checking task status. Error= ${getTaskStatusResponse.error}"
               this.appendDeployTaskReport("Error checking task status. Error= ${getTaskStatusResponse.error}")
            }
            else{
               if(getTaskStatusResponse.status == 'RUNNING'){
                  //println "      -  Status     : '${getTaskStatusResponse.status}'"
                  this.appendDeployTaskReport("Status : '${getTaskStatusResponse.status}'")
                  //println "     - Task is currently RUNNING: stopping task"
                  this.appendDeployTaskReport("Task is currently RUNNING")
               }
               else{
                  this.appendDeployTaskReport("------------------------------------------------------------------------------------------")
                  this.appendDeployTaskReport("START Step 4: EXECUTING Task: ${this.deployTask.taskName} taskid: $taskId")
                  this.appendDeployTaskReport("------------------------------------------------------------------------------------------")
                  def executionError = 0
                  def runTaskResponse = runTask(taskId)
                  
                  if(runTaskResponse.returnCode != 0){
                     //println "   - Error Excuting task. Error= $runTaskResponse.error"
                     this.appendDeployTaskReport("ERROR = Error Excuting Task: ${this.deployTask.taskName} Task ID: $taskId")
                     this.appendDeployTaskReport("ERROR = ${runTaskResponse.error}")
                     this.appendDeployTaskReport("ERROR = ${this.deployTask.taskName} cannot be executed")
                     this.deployTask.executionStatus = "ERROR"
                     return
                  }
                  else{
                     def jobExecRequestId = runTaskResponse.execRequestId
                     //println "   - Execution report of task '$task' id '$taskId':"
                     //println "      -  execBasicStatus     : '$ms_response.execBasicStatus'"
                     //println "      -  execDetailedStatus  : '$ms_response.execDetailedStatus'"
                     //println "      -  jobExitCode         : '$ms_response.jobExitCode'"
                     this.appendDeployTaskReport("Execution report of Task: '${this.deployTask.taskName}' taskid: '$taskId':")
                     this.appendDeployTaskReport("execBasicStatus     : '$runTaskResponse.execBasicStatus'")
                     this.appendDeployTaskReport("execDetailedStatus  : '$runTaskResponse.execDetailedStatus'")
                     this.appendDeployTaskReport("jobExitCode         : '$runTaskResponse.jobExitCode'")
                     
                     if(runTaskResponse.jobExitCode == 0){
                        //println "----------------------------------------------------"
                        //println "-- Step 2-D: Get Execution log for task ${this.deployTask.taskName}"
                        //println "----------------------------------------------------"
                        this.appendDeployTaskReport("----------------------------------------------------")
                        this.appendDeployTaskReport("Get Execution log for  Task: ${this.deployTask.taskName} taskid: $taskId")
                        this.appendDeployTaskReport("----------------------------------------------------")
                        def taskLogResponse = taskLog(taskId)
                        def resultLog = taskLogResponse.result
                        def lastResultLog = null
                        try{
                           int firstIndex = resultLog.indexOf("### Job STARTED")
                           int nextIndex = resultLog.indexOf("### Job ENDED") + "### Job ENDED".length()
                           lastResultLog = resultLog.substring(0, nextIndex)
                           //println "   - Log:"
                           //println "$lastResultLog"
                           this.appendDeployTaskReport("Log:")
                           this.appendDeployTaskReport("$lastResultLog")
                        }
                        catch(all){
                           lastResultLog = resultLog
                           //println "   - Log:"
                           //println "$lastResultLog"
                           this.appendDeployTaskReport("Log:")
                           this.appendDeployTaskReport("$lastResultLog")
                           this.appendDeployTaskReport("$all")
                           //println "   - Error Excuting task. Error= $runTaskResponse.error"
                           this.appendDeployTaskReport("ERROR = Error Excuting Task: ${this.deployTask.taskName} Task ID: $taskId")
                           this.appendDeployTaskReport("ERROR = ${runTaskResponse.error}")
                           this.appendDeployTaskReport("ERROR = ${this.deployTask.taskName} cannot be executed")
                           this.deployTask.executionStatus = "ERROR"
                           return
                        }
                     }
                  }
                  
                  this.appendDeployTaskReport("------------------------------------------------------------------------------------------")
                  this.appendDeployTaskReport("END Step 4: Task: ${this.deployTask.taskName} taskid: $taskId FINISHED EXECUTION")
                  this.appendDeployTaskReport("------------------------------------------------------------------------------------------")
                  this.appendDeployTaskReport("******************************************************************************************")
                  this.appendDeployTaskReport("Finished auto-execute '${this.deployTask.taskName}'")
                  this.appendDeployTaskReport("******************************************************************************************")
                  this.deployTask.executionStatus = "SUCCESS"
               }
            }
         }
      }
   }
}