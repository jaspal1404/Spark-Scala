/**
 * Created by Jesen on 04/20/2016
 */
//@Grab('org.apache.ivy:ivy:2.4.0')
@Grab('com.github.groovy-wslite:groovy-wslite:1.1.0')
import wslite.rest.*
import wslite.http.auth.*
import wslite.util.*
import groovy.json.*

def env           = System.getenv()
branchName        = env['GIT_BRANCH_NAME']
relBranchName     = env['RELEASE_BRANCH']

codeHubURL        = env['CODEHUB_URL']
codeHubAPI        = env['CODEHUB_API_PATH']
codeHubORG        = env['CODEHUB_ORG']
codeHubREPO       = env['CODEHUB_REPO']

mavenUser         = env['MAVEN_USER']
mavenPassword     = env['MAVEN_PASS']

debug             = "true".equalsIgnoreCase(env['CI_DEBUG'])

HTTP_ACCEPTED_RESPONSE  = "201"


def jsonCreateHookBranchPermission = new JsonBuilder()
def jsonUpdateHookBranchPermission = new JsonBuilder()
def slurper = new JsonSlurper()
def sout = new StringBuilder()
def serr = new StringBuilder()
def exout = new StringBuilder()
def exerr = new StringBuilder()

//see https://codehub.optum.com/help/articles/repository-hooks-apis for usage on codehub api
def response = null
def client = new RESTClient("${codeHubURL}")
client.authorization = new HTTPBasicAuthorization("${mavenUser}", "${mavenPassword}")
client.httpClient.sslTrustAllCerts = true

response = client.get(path:"/${codeHubAPI}/${codeHubORG}/${codeHubREPO}/hooks",
                      accept:'application/json',
                      headers:['Content-Type':'application/json'])

def result = response.json
if(debug){
  println JsonOutput.prettyPrint(result.toString())
}

/*REST api execution will return json object in this format
[
  {
    "id":"hookID",
    "type":"BranchPermissionsHook",
    "url":"https://codehub.optum.com/api/repos/optum_datafabric/odf_odf_custom_library/hooks/hookID",
    "repo_url":"https://codehub.optum.com/api/repos/optum_datafabric/odf_odf_custom_library",
    "active":true,
    "settings":
      {
        "message":"branch is frozen",
        "branches":
          [
          "development"
          ]
      },
    "events":
      [
      "pre-receive"
      ],
    "created_at":"2017-01-27T21:44:55.000Z",
    "updated_at":"2017-01-27T21:44:55.000Z"
  }
  .
  .
  .
  .
]
 
which translate of object in this format

result.id
result.type
result.settings.branches[]
.
.

from the result, search the hook type "BranchPermissionsHook"
and retrieve the id
if not found,just create new hook of that type
*/
hookBranches = []
exceptedUsers = []
exceptedUsers << "${mavenUser}"
boolean branchPermissionHookExists = false
for (int i = 0; i < result.size(); i++) {
  id = result[i].id
  type = result[i].type
  
  //println type
  //println id
  if(type.equalsIgnoreCase("BranchPermissionsHook")){
    println "hook exists, delete it. will recreate later"
    branchPermissionHookExists = true
    hookBranches = result[i].settings.branches
    //println hookBranches
    
    response = client.delete(path:"/${codeHubAPI}/${codeHubORG}/${codeHubREPO}/hooks/${id}",
                             accept:'application/json',
                             headers:['Content-Type':'application/json'])
    break
  }
}

hookBranches << branchName
hookBranches << relBranchName
//println hookBranches
def uniqueBranches = hookBranches.unique()

if(debug){
  println uniqueBranches
}

jsonCreateHookBranchPermission{
  key       "branch_permissions"
  settings{
    branches uniqueBranches
    users exceptedUsers
    message "Branch is automatically frozen for release ${relBranchName}. Please request admin to unfreeze the branch and update the release version in branch: ${branchName}"
  }
}

response = client.post(path:"/${codeHubAPI}/${codeHubORG}/${codeHubREPO}/hooks",
                       accept:'application/json',
                       headers:['Content-Type':'application/json']) {
                        text jsonCreateHookBranchPermission.toString()
                       }
if(debug){
  println response.statusCode
  println response.statusMessage
  println JsonOutput.prettyPrint(response.json.toString())
}

if(!response.statusCode.toString().equalsIgnoreCase(HTTP_ACCEPTED_RESPONSE) ){
  System.exit(1)
}
else{
  println response.json.toString()
}
