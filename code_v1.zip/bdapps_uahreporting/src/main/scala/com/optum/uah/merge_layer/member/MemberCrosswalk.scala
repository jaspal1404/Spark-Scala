package com.optum.uah.merge_layer.member

import java.io.File

import com.optum.uah.function_library.{CommonFunctions, GlobalContext, ReadJson}
import org.apache.commons.io.FileUtils
import org.apache.spark.sql
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{row_number, _}


/**
  * Created by psahota on 11/27/2017.
  *
  **/
object MemberCrosswalk {


  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .enableHiveSupport()
      .getOrCreate()
    import spark.implicits._
    val GlobalContext = new GlobalContext()
    val CommonFunctions = new CommonFunctions()
    val tgtLoc =  args(0)
    // val tgtLoc = "/datalake/optum/optuminsight/d_uah/dev/d_hdfs/mergelayer/member_crosswalk"
    val propFilePath = args(1)
    // val propFilePath = "/mapr/datalake/optum/optuminsight/d_uah/dev/d_scripts/properties/memberProperties_hce.json"
    val tblName = tgtLoc.split("mergelayer/")(1)
    //val tblName_legacy = tgtLoc.split("mergelayer/")(1)+"_cdw"
    //val dbName = args(2)
    val workingDir =  tgtLoc.split("/"+tblName).head+ "/working/" +  tblName
    FileUtils.deleteDirectory(new File("/mapr"+tgtLoc))
    var sparkSession = GlobalContext.getRnASession("MemberUAH")
    ReadJson.createJsonObject(propFilePath)
    val cirrus_df = CommonFunctions.runSql(sparkSession,ReadJson.getProperty(tblName))
    //val cirrus_df = "SELECT DISTINCT subsaffextid.subsaffiliationmemberid,subsaffextid.externalidtype,subsaffextid.affiliationexternalid, FROM_UNIXTIME(UNIX_TIMESTAMP(), 'yyyy-MM-dd HH:mm:ss:SSS') as row_timestamp, 'active' as record_status, \"PUL\" as source_cd from uhc_pfv_tst.subsaffiliationexternalid_std subsaffextid"
    sparkSession = GlobalContext.getUAHSession("MemberUAH")
    val result_df = cirrus_df.withColumn("member_lookup_identifier", row_number.over(Window.orderBy(col("subsaffiliationmemberid"))))
    val final_df=result_df.withColumn("member_lookup_identifier", $"member_lookup_identifier".cast(sql.types.StringType))
    CommonFunctions.saveDataframeAsFile(final_df,tgtLoc+"/source_cd=PUL","overwrite") //this is for writing the Parquet File
  }
}