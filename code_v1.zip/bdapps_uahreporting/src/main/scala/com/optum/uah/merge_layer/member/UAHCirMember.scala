package com.optum.uah.merge_layer.member

import org.apache.spark.sql.{DataFrame, SparkSession}
import com.optum.uah.function_library.{CommonFunctions, GlobalContext, ReadJson}
import org.apache.spark.sql.functions._

/**
  * Created by sbandar8 on 8/8/2017.
  */
object UAHCirMember {

  val CommonFunctions = new CommonFunctions()
  val GlobalContext = new GlobalContext()

  def main(args: Array[String]): Unit = {
    val tgtLoc = args(0)
    val propFilePath = args(1)
    val tblName = tgtLoc.split("mergelayer/")(1)

    print("This is the target table name:" + tblName)
    val workingDir = tgtLoc.split("/" + tblName).head + "/working/" + tblName

    //    ReadJson.setProperties(propFilePath)
    ReadJson.createJsonObject(propFilePath)
    print("This is a table name from Json read: " + ReadJson.getProperty(tblName))

    // Read job last run timestamp from staging file/table
    var maxLoadTimestamp = CommonFunctions.getHbaseMrglayerTs(tblName)

    println(" Hbase table TS from hbase table before: " + maxLoadTimestamp)

    val sparkSession = GlobalContext.getRnASession("MemberRnA")

    // Call function to load Cirrus data
    val cirDeltaDf = getCirrusData(maxLoadTimestamp, tblName, sparkSession)
    println("Delta file records count from a dataframe*************" + cirDeltaDf.count())
    println("========")

    // Run the dedup process only if we have incremental records
    if (cirDeltaDf.count() != 0) {

      println(" I am in cirDeltaDf not eq to 0 block")

      // Load spark session for uah metastore
      val sparkSession = GlobalContext.getUAHSession("MemberUAH")

      if (CommonFunctions.getListOfFiles("/mapr" + tgtLoc).isEmpty) {
        println("Cirrus initial Delta DF Count*************: " + cirDeltaDf.count())

        // Calling the Dedup function to identify records with latest timestamp
        val dedupDf = CommonFunctions.dedupLogic(cirDeltaDf)

        println("dedupDf1 DF Count*************: " + dedupDf.count())

        // Update Hbase table with max load timestamp of the record
        maxLoadTimestamp = dedupDf.agg(max("uah_timestamp")).first()(0).toString
        CommonFunctions.updateHbaseMrglayerTs(tblName, maxLoadTimestamp)

        // Save dedup records into the merge layer *****
        CommonFunctions.saveDataframeAsFile(dedupDf, tgtLoc + "/source_cd=CRS", "overwrite")
      }
      else {

        // Load the history records in merge layer from previous run
        val mergeFullDf = getMergeTblData(tgtLoc, sparkSession)
        println("Record count for the records already presnet in merge layer DF Count*************: " + mergeFullDf.count())

        // Union Cirrus and merge layer dataframes
        val unionedDf = CommonFunctions.unionDataframes(mergeFullDf, cirDeltaDf)

        // Calling the Dedup function to get record with latest timestamp
        val dedupDf = CommonFunctions.dedupLogic(unionedDf)
        println("Record count for the records after dedup process executes *************: " + dedupDf.count())

        maxLoadTimestamp = dedupDf.agg(max("uah_timestamp")).first()(0).toString
        CommonFunctions.updateHbaseMrglayerTs(tblName, maxLoadTimestamp)

        // Save dedup records into the merge layer *****
        CommonFunctions.saveDataframeOverwriteAsFile(sparkSession, dedupDf, tgtLoc + "/source_cd=CRS", workingDir)
      }
    }

    sparkSession.close()
  }

  def getCirrusData(maxLoadTimestamp: String, tblName: String, sparkSession: SparkSession): DataFrame = {

    var resultDf: DataFrame = sparkSession.emptyDataFrame
    // Load data from cirrus table into a dataframe with incremental data
    print("This is the target table name from jason before if" + ReadJson.getProperty(tblName))
    println("This is a string for result DF: " + ReadJson.getProperty(tblName))

    if (maxLoadTimestamp == "Null") {
      resultDf = CommonFunctions.runSql(sparkSession, ReadJson.getProperty(tblName)).filter(col("record_status") === "active").dropDuplicates("key", "uah_timestamp")

      print("This is the target table name from jason" + ReadJson.getProperty(tblName))
    }
    else {
      resultDf = CommonFunctions.runSql(sparkSession, ReadJson.getProperty(tblName)).filter("uah_timestamp > \"" + maxLoadTimestamp + "\"").filter(col("record_status") === "active").dropDuplicates("key", "uah_timestamp")
    }
    print("This is the target table name from json outside of if" + ReadJson.getProperty(tblName))
    resultDf
  }
  def getMergeTblData(tgtLoc: String, sparkSession: SparkSession): DataFrame = {

    // Load the history records in merge layer from previous run
    val resultDf = sparkSession.read.parquet(tgtLoc)
    println(" merge layer dataframe count" + resultDf)

    resultDf
  }
}
