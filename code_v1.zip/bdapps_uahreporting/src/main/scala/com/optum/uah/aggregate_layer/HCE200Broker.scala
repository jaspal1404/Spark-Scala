package com.optum.uah.aggregate_layer

import com.optum.uah.function_library.{ CommonFunctions, GlobalContext, ReadJson }
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

object Hce200Broker {
  val GContext = new GlobalContext()
  val func = new CommonFunctions()

  def main(args: Array[String]): Unit = {

    val propFilePath = args(1)
    ReadJson.createJsonObject(propFilePath)
    println("Properties file location" + propFilePath)
    val brokerDataSet = createHce200BrokerExtract(args)

  }

  def createHce200BrokerExtract(args: Array[String]): Unit = {

    val sparkSession = GContext.getUAHSession("BrokerUAH")
    sparkSession.sql("set spark.sql.parquet.useDataSourceApi=false")
    sparkSession.sql("set spark.sql.hive.convertMetastoreParquet=false")

    val brokerAgg = func.runSql(sparkSession, ReadJson.getProperty("brokerhce200aggregate_layer")).dropDuplicates()

    var path = args(0) + "/broker"

    func.saveDataframeAsFile(brokerAgg, path, "overwrite")
    func.createExternalTableFromParquet(sparkSession, path, "broker", args(1)) //test it with a small file
  }

}