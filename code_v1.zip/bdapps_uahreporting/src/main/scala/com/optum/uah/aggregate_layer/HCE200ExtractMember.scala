
package com.optum.uah.aggregate_layer
import com.optum.uah.function_library.Logger.log
import com.optum.uah.function_library.{ GlobalContext, CommonFunctions, ReadJson }


object HCE200ExtractMember {
  def main(args: Array[String]): Unit = {


    val srcLoc = args(0)
    val subjArea = args(1)
    val tgtLoc = args(2)
    val propFilePath = args(3)
    val GContext = new GlobalContext()
    val func = new CommonFunctions()
    val sparkSession = GContext.getUAHSession("MemberUAHAggregate")
//    val rJson = new ReadJson(propFilePath)
    ReadJson.createJsonObject(propFilePath)
    ReadJson.getProperty(subjArea)
    val temp = ReadJson.getProperty(subjArea)

    val fields = temp.split(',')

    //    # Array(memberid, address1, address2, city, state, postalcode, countyfipsdesc, birthDate, namefirst, phone, namelast, gender, memberExternalID)

    val merge_df = sparkSession.read.parquet(srcLoc).select(fields.head, fields.tail: _*)

    merge_df.rdd.repartition(1).map(x => x.mkString("|")).saveAsTextFile(tgtLoc) //       /u0001 - suggested

  }
}
