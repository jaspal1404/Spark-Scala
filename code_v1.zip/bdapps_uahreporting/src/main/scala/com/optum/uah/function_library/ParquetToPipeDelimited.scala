package com.optum.uah.function_library

import org.apache.spark.sql.SparkSession
import java.text.SimpleDateFormat
import org.apache.hadoop.fs._
import java.io.IOException
import java.util.Date

/** <h1>FileConversionParquetToPipeDelimitedFormat</h1>
 *  Here we are converting the Parquet File into Pipe Delimited Format and Transferring it across to the Intermediate Location 
 *  with the corresponding Crosswalk File Name to be picked up by ECG to Send it Across to PO's
 *  @author tshasank
 *  @version 1.0
 */
 
object ParquetToPipeDelimited {
  
  //Arguments needed --> Input Path, Target Path, Target Filename
  
    def main(args: Array[String]): Unit = {

    val length = 3;
    if (args.length != length) {
      throw new IOException("Arguments mismatch! Expected arguments are : " + length + " , But actual arguments passed are : " + args.length);
    }
    val session = SparkSession.builder().appName("FileConversionParquetToPipe").getOrCreate()
    val readParquetDF = session.read.parquet(args(0).trim())
    readParquetDF.repartition(1).write.mode("Overwrite").format("csv").option("delimiter", "|").option("header", "true").save(args(1).trim()+"/xwalktemp")
    
    val fs = FileSystem.get(session.sparkContext.hadoopConfiguration)
    
    val formt = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss")
    val currentDt = formt.format(new Date())
    
    val file = fs.globStatus(new Path(args(1).trim()+"/xwalktemp/"+"part*"))(0).getPath().getName()
    fs.rename(new Path(args(1).trim()+"/xwalktemp/" + file), new Path(args(1).trim()+"/" + args(2).trim()+"_"+currentDt))
    fs.delete(new Path(args(1).trim()+"/xwalktemp"), true)

  }
}