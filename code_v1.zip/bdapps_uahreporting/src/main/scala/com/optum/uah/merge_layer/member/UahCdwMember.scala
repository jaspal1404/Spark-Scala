package com.optum.uah.merge_layer.member

import com.optum.uah.function_library.{CommonFunctions, GlobalContext, MasterIdentifier, ReadJson}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * Created by kgoje on 8/9/2017.
  */
object UahCdwMember {

  //  var hist_leg_df: DataFrame = sc.emptyDataFrame

  def main(args: Array[String]): Unit = {

    val spark = SparkSession.builder().enableHiveSupport().getOrCreate()
    import spark.implicits._

    val tgtLoc = args(0)
    val propFilePath = args(1)
    val tblName = tgtLoc.split("mergelayer/")(1)
    val tblName_legacy = tgtLoc.split("mergelayer/")(1)+"_cdw"

    val workingDir =  tgtLoc.split("/"+tblName).head+ "/working/" +  tblName

    val GlobalContext = new GlobalContext()

    ReadJson.createJsonObject(propFilePath)
    val CommonFunctions = new CommonFunctions()
    var MasterIdentifier = new MasterIdentifier()

    var sparkSession = GlobalContext.getUAHSession("MemberUAH")
    val dbName = sparkSession.conf.get("spark.database.cirrus.rnatenant")
    var deDupID = ""
    //    var maxLoadTimestamp = CommonFunctions.getHbaseMrglayerTs(tblName)

    if(tblName.equals("memberdemographic_std")){
      deDupID = "memberid"
    }else {
      deDupID = "memgroupgid"
    }

    if(deDupID.equals("")){
      println("table not recognized")
    }else{

      val cdwDeltaDf = CommonFunctions.runSql(sparkSession, ReadJson.getProperty(tblName_legacy))
      // println("Delta file records count from a dataframe*************" + cdwDeltaDf.count())

      var sparkSession2 = GlobalContext.getRnASession("MemberRnA")
      val cdwDeltaDf2 = sparkSession2.createDataFrame(cdwDeltaDf.rdd,cdwDeltaDf.schema)

      var crossWalkDF: DataFrame = null
      if(deDupID.equals("memberid")){
        val crossWalk = MasterIdentifier.legacyMemberdentitfier(sparkSession2,cdwDeltaDf2,deDupID,dbName)
        crossWalkDF = sparkSession.createDataFrame(crossWalk.rdd, crossWalk.schema)
      } else {
        val crossWalk = MasterIdentifier.legacyMemGroupdentitfier(sparkSession2, cdwDeltaDf2, deDupID, dbName)
        crossWalkDF = sparkSession.createDataFrame(crossWalk.rdd, crossWalk.schema)
      }

      if (crossWalkDF.count() != 0) {

        if (CommonFunctions.getListOfFiles("/mapr" + tgtLoc).isEmpty) {

          // println("Cirrus initial Delta DF Count*************: " + crossWalkDF.count())

          // Calling the Dedup function to identify records with latest timestamp
          //          val dedupDf = CommonFunctions.dedupLogicLegacy(crossWalkDF, "source_"+deDupID)
          //            println("dedupDf1 DF Count*************: " + dedupDf.count())

          //          maxLoadTimestamp = dedupDf.agg(max("uah_timestamp")).first()(0).toString
          //          CommonFunctions.updateHbaseMrglayerTs(tblName, maxLoadTimestamp)

          // Save dedup records into the merge layer *****
          CommonFunctions.saveDataframeAsFile(crossWalkDF, tgtLoc+"/source_cd=PUL","overwrite")
          //          CommonFunctions.createExternalTableFromParquet(sparkSession,tgtLoc,tblName,"uah_mergelayer")
        }
        else {
          println("******************************************************************************")
          println("**Target location (Merge Layer) already has some records**")
          val merge_df = sparkSession.read.parquet(tgtLoc+"/source_cd=PUL")
          println("Merge Layer record count from before starting the job *************" + merge_df.count())

          val union_df = merge_df.union(crossWalkDF)
          // Save dedup records into the merge layer *****
          //val rank_df = union_df.withColumn("rank", rank.over(Window.partitionBy("source_"+deDupID).orderBy($"uah_timestamp".desc)))
          val rank_df = union_df.withColumn("rank", row_number.over(Window.partitionBy("source_"+deDupID).orderBy($"uah_timestamp".desc)))
          val temp_df = rank_df.filter("rank = '1'")
          val write_df = temp_df.drop("rank")
          sparkSession = GlobalContext.getUAHSession("MemberUAH")
          //          maxLoadTimestamp = write_df.agg(max("uah_timestamp")).first()(0).toString
          //          CommonFunctions.updateHbaseMrglayerTs(tblName, maxLoadTimestamp)
          println("Merge Layer record count after the job *************" + write_df.count())
          CommonFunctions.saveDataframeOverwriteAsFile(sparkSession, write_df, tgtLoc+"/source_cd=PUL", workingDir)
          //
          //          CommonFunctions.createExternalTableFromParquet(sparkSession,tgtLoc,tblName,"uah_mergelayer")
        }
      }
    }

  }
}