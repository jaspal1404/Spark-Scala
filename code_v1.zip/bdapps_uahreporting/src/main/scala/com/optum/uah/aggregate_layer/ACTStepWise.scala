package com.optum.uah.aggregate_layer
import java.io.File
import com.optum.uah.function_library.Logger.log
import com.optum.uah.function_library.{CommonFunctions, GlobalContext, ReadJson}
import org.apache.commons.io.FileUtils
import org.apache.jute.compiler.JMap
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.json4s.JsonAST.JValue
import org.apache.log4j.Logger
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._


/**
  * Created by mkadiyal on 1/12/2018.
  * Edited by psahota on 1/16/2018
  * Edited by ssawan12 on 1/19/2018
  */
object ACTStepWise {
  val log: Logger = Logger.getLogger(getClass.getName)
  var commonFunctions:CommonFunctions = _  
  
   var memgroupcontractplanoptionview_std:DataFrame = _  
    var memgroupid_std:DataFrame = _ 
    var memgroupcontractview_std:DataFrame =_
    var memgroupaddress_std:DataFrame=_
  
  def main(args: Array[String]): Unit = {//Spark submit shell path: /mapr/datalake/optum/optuminsight/d_uah/dev/d_scripts/UAH_ACT_StepWise.sh
    //    val srcLoc = args(0)
    val propFilePath = args(0)
    val aggrLoc = args(1)
    //val tgtLoc = args(2)
    val subjArea = args(2) //"member,customer,broker,rateplans"
    val grpByCols = args(3)
    val orderByCols = args(4)
    //Extract SQL and execute Spark SQL; Store the data in a data frame
    ///mapr/datalake/optum/optuminsight/d_uah/dev/d_scripts/properties/ACTStepWise.json
    val jsonMap:JValue = ReadJson.createJsonObject(propFilePath)
//    val extractSql = ReadJson.getProperty(subjArea)

    val GContext = new GlobalContext()
    val sparkSession = GContext.getUAHSession("StepWiseUAHAggregate")
    commonFunctions = new CommonFunctions()
  //  masterIdentifierdF(sparkSession)
println("subjArea: " + subjArea)
    val i:Int = 0
    val strDf = subjArea.split(',')
    var aggrFolder: String = null
   // var extractFolder:String = null
    for(i <- 0 to (strDf.length-1))
      {
      log.info("i: " + i)
      println("strDf(i): " + strDf(i))
        if (strDf(i) == "member"){
          log.info("in member ")
          val writeDf = actMemberExtract(jsonMap,sparkSession,grpByCols,orderByCols)
          aggrFolder = aggrLoc+"/member"
          //extractFolder = tgtLoc+"/member"
//          writeDf.count()
          FileUtils.deleteDirectory(new File("/mapr/"+aggrFolder))
          dfWrite(writeDf,aggrFolder)
          //createExtract(writeDf,extractFolder)     // Format for this is TBD
        }
        else if (strDf(i) == "customer"){
          log.info("in customer ")
        val writeDf = actCustomerExtract(jsonMap,sparkSession)
          aggrFolder = aggrLoc+"/customer"
          FileUtils.deleteDirectory(new File("/mapr/"+aggrFolder))
          //extractFolder = tgtLoc+"/customer"
//          writeDf.count()
          dfWrite(writeDf,aggrFolder)
          //createExtract(writeDf,extractFolder)    // Format for this is TBD
        }
        else if (strDf(i) == "planRate"){
          log.info("in plan rate")
        val writeDf = actCurrPlanRatesExtract(jsonMap,sparkSession)
          aggrFolder = aggrLoc+"/currplanrate"
          FileUtils.deleteDirectory(new File("/mapr/"+aggrFolder))
          //extractFolder = tgtLoc+"/customer"
//          writeDf.count()
          dfWrite(writeDf,aggrFolder)
          //createExtract(writeDf,extractFolder)    // Format for this is TBD
        }
        else if ( strDf(i) == "customerRate")
        {
          log.info("in customerRate")          
          val writeDf = actCustomerRateExtract(jsonMap,sparkSession)
          aggrFolder = aggrLoc+"/customerrate"
          FileUtils.deleteDirectory(new File("/mapr/"+aggrFolder))
          dfWrite(writeDf,aggrFolder)
        }
         else {
           println("no matching argument")
         }
      }
  }
  
   def masterIdentifierdF(sparkSession: SparkSession) = {
      memgroupcontractplanoptionview_std =commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupcontractplanoptionview_std"))
      memgroupid_std = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupid_std"))
      memgroupcontractview_std = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupcontractview_std"))
      memgroupaddress_std = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupaddress_std"))  
    }

  def actMemberExtract(jsonMap: JValue,sparkSession: SparkSession,grpByCols:String,orderByCols:String): DataFrame ={
    //load each table in a DF and do joins on DF's and then return the resultant DF
    val memberdemographic_std_dly = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memberdemographic_std_dly"))
    val memberdemographic_std_mth = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memberdemographic_std_mth"))


    val memberbenefit_std_dly = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memberbenefit_std_dly"))
    val memberbenefit_std_mth = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memberbenefit_std_mth"))



    val memberCobVerification_std = commonFunctions.runSql(sparkSession, ReadJson.getProperty("membercobverification_std_dly"))
    val relationshiptype_ref_df = commonFunctions.runSql(sparkSession,ReadJson.getProperty("relationshipcode_reference_view_dly"))

    val memdemopk:DataFrame = memberdemographic_std_dly.select("uah_memberid").distinct().union(memberbenefit_std_dly.select("uah_memberid").distinct()).union(memberCobVerification_std.select("uah_memberid").distinct())


    val memberdemographic_std = memberdemographic_std_dly.union(memberdemographic_std_mth).join(memdemopk,Seq("uah_memberid"))
    val memberbenefit_std = memberbenefit_std_dly.union(memberbenefit_std_mth).join(memdemopk,Seq("uah_memberid"))

    //Joins
    val Employee_id_df = memberdemographic_std.join(memberbenefit_std,Seq("uah_memberid"),"inner").drop(memberdemographic_std.col("uah_memgroupid"))
    val  MedCovInd_df = Employee_id_df.join(memberCobVerification_std,Seq("uah_memberid"),"left_outer")
    val relationtype_desc_df = MedCovInd_df .join(relationshiptype_ref_df , Seq("relationshipcode"),"left_outer")


    val grpByColSeq = grpByCols.split(",").toSeq.map(x => col(x))
    val orderByColSeq = orderByCols.split(",").toSeq.map(x => col(x).desc)
    val w = Window.partitionBy(grpByColSeq: _*).orderBy(orderByColSeq: _*)
    val resultDf = relationtype_desc_df.withColumn("rn", row_number.over(w)).where(col("rn") === 1).drop("rn")
    val finalDf = resultDf.withColumn("employStatusCode",lit("")).drop("uah_timestamp","run_id","memgroupcontractplanoptionid")

    finalDf

  }


  def actCustomerExtract(jsonMap:JValue,sparkSession: SparkSession): DataFrame ={
      //      load each table in a DF and do joins on DF's and then return the resultant DF
      
    val memgroupid_std_dly =  commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupid_std_dly"))
    val memgroupid_std_mth =  commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupid_std_mth"))
    
    val memgroupcontractview_std_dly = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupcontractview_std_dly"))
    val memgroupcontractview_std_mth = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupcontractview_std_mth"))
    
    
    //val memgroupcontractgovtreportview_std_mth = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupcontractgovtreportview_std_mth"))
    val memgroupcontractgovtreportview_std = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupcontractgovtreportview_std_dly"))
        
    val memgroupinsuringrule_view = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupinsuringrule_view_dly"))
    //val memgroupinsuringrule_view_mth = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupinsuringrule_view_mth"))  
    
    val memgroupsettings_std = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupsettings_std_dly"))
    //val memgroupsettings_std_mth = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupsettings_std_mth"))
    
    val memgroupaddress_std = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupaddress_std_dly"))
    //val memgroupaddress_std_mth = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupaddress_std_mth"))
    
    //val memgroupreportingcode_view_mth = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupreportingcode_view_mth"))
    val memgroupreportingcode_view = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupreportingcode_view_dly"))
    
    val zipcode_view = commonFunctions.runSql(sparkSession,ReadJson.getProperty("zipcode_view_dly"))
    
    val pk : DataFrame = memgroupid_std_dly.select("uah_memgroupid").union(memgroupcontractview_std_dly.select("uah_memgroupgid")).union(memgroupcontractgovtreportview_std.select("source_memgroupid")).
    union(memgroupinsuringrule_view.select("source_memgroupid")).union(memgroupsettings_std.select("uah_memgroupid")).union(memgroupaddress_std.select("uah_memgroupid")).union(memgroupreportingcode_view.select("source_memgroupid").distinct())
    
    val memgroupid_std = memgroupid_std_dly.union(memgroupid_std_mth).join(pk,Seq("uah_memgroupid"),"inner")
    val memgroupcontractview_std_union = memgroupcontractview_std_dly.union(memgroupcontractview_std_mth)
    val memgroupcontractview_std = memgroupcontractview_std_union.join(pk,pk.col("uah_memgroupid") === memgroupcontractview_std_union.col("uah_memgroupgid"),"inner")
    //val countyname = zipcode_view.join(memgroupaddress_std,memgroupaddress_std.col("postalCode") === zipcode_view.col("zip"),"inner")
      

      val memberGroupContract_id = memgroupid_std.join(memgroupcontractview_std,Seq("uah_memgroupid"),"inner")
      val uah_acr_indicator_df = memberGroupContract_id.join(memgroupcontractgovtreportview_std,memgroupcontractgovtreportview_std.col("source_memgroupid")===memberGroupContract_id.col("uah_memgroupid"),"left_outer").drop("source_memgroupid","referencecode")
      val uah_cobra_indicator_df = uah_acr_indicator_df.join(memgroupinsuringrule_view,memgroupinsuringrule_view.col("source_memgroupid")===uah_acr_indicator_df.col("uah_memgroupid"),"left_outer")
      val addressdetails_df = uah_cobra_indicator_df.join(memgroupaddress_std,Seq("uah_memgroupid"),"left_outer")
      val ServiceTeamdf = addressdetails_df.join(memgroupreportingcode_view,Seq("source_memgroupid"),"left_outer")
      val grpsizeindicator =ServiceTeamdf.join(memgroupsettings_std,Seq("uah_memgroupid"),"left_outer").drop("source_memgroupid","uah_memgroupgid","organizationtype","organizationtypedesc")
      val finaldf = grpsizeindicator.join(zipcode_view,grpsizeindicator.col("postalCode") === zipcode_view.col("zip"),"left_outer").drop("zip")

      
      finaldf
      
      /*val memgroupinsuringrule_view = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupinsuringrule_view"))
     
      val memgroupreportingcode_view = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupreportingcode_view"))
      val reference_view = commonFunctions.runSql(sparkSession, ReadJson.getProperty("reference_view"))
      val memgroupcontractgovtreportview_std = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupcontractgovtreportview_std"))

      val memgroupsettings_std = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupsettings_std"))
      val zipcode_view = commonFunctions.runSql(sparkSession, ReadJson.getProperty("zipcode_view"))
      
      val memberbenefit_std = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memberbenefit_std"))
      
      val memgrouplevelcount_df = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgrouplevelcount"))
      val contractlevelcount_df = commonFunctions.runSql(sparkSession, ReadJson.getProperty("contractlevelcount"))
      val uah_cobra_indicator_df = memgroupinsuringrule_view.join(memgroupcontractplanoptionview_std,memgroupinsuringrule_view.col("source_memgroupid")===memgroupcontractplanoptionview_std.col("uah_memgroupid"),"inner")
      val memgroupid_df = uah_cobra_indicator_df.join(memgroupid_std,Seq("uah_memgroupid"),"inner")
      val memgroupcontractgcid_df = memgroupid_df.join(memgroupcontractview_std,memgroupid_df.col("uah_memgroupid") === memgroupcontractview_std.col("uah_memgroupgid"),"inner").drop("uah_memgroupgid")
      val memgroupname_df = memgroupcontractgcid_df.join(memgroupaddress_std,Seq("uah_memgroupid"),"inner")
      val reportingcodetype_df = memgroupreportingcode_view.join(reference_view,memgroupreportingcode_view.col("reportingcodetype")===reference_view.col("referencecode"))
      val referencedesc_df = memgroupname_df.join(reportingcodetype_df,Seq("source_memgroupid"),"inner")
      val uah_acr_indicator_df = referencedesc_df.join(memgroupcontractgovtreportview_std,Seq("source_memgroupid"),"LEFTOUTER").drop("source_memgroupid","referencecode")

      val sizedefinitiontype_df = uah_acr_indicator_df.join(memgroupsettings_std, Seq("uah_memgroupid"),"inner")
      val countyname_df = sizedefinitiontype_df.join(zipcode_view, sizedefinitiontype_df.col("uah_memgroupid")===zipcode_view.col("source_memgroupid"), "inner").drop(zipcode_view.col("source_memgroupid"))
      val countyname_memgrouplevelcount_df = countyname_df.join(memgrouplevelcount_df, Seq("uah_memgroupid"),"LEFTOUTER")
      val memgrouplevelcount_contractlevelcount_df = countyname_memgrouplevelcount_df.join(contractlevelcount_df, Seq("uah_memgroupid"),"LEFTOUTER")
      memgrouplevelcount_contractlevelcount_df*/

    }
    
     def actCurrPlanRatesExtract(jsonMap:JValue,sparkSession: SparkSession): DataFrame ={
      //      load each table in a DF and do joins on DF's and then return the resultant DF
      val carrierlobplanview_std = commonFunctions.runSql(sparkSession, ReadJson.getProperty("carrierlobplanview_std"))
      //val memgroupcontractplanoptionview_std = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupcontractplanoptionview_std"))
      //val memgroupid_std = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupid_std"))
      //val memgroupcontractview_std = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupcontractview_std"))
      //val memgroupaddress_std = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupaddress_std"))
      val memgroupcontractplanoptionvw_std = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupcontractplanoptionvw_std"))
      val beneplansettings_std = commonFunctions.runSql(sparkSession, ReadJson.getProperty("beneplansettings_std"))
      val memgroupctrctplnoptnetwklistvw_std = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupctrctplnoptnetwklistvw_std"))
      val benefitbundleriderplan_std = commonFunctions.runSql(sparkSession, ReadJson.getProperty("benefitbundleriderplan_std"))
      val benefitbundleplan_std = commonFunctions.runSql(sparkSession, ReadJson.getProperty("benefitbundleplan_std"))

      val memgroupcontractplanoption_benefitbundleplan = memgroupcontractplanoptionvw_std.join(benefitbundleplan_std,Seq("benefitbundleoptionid"),"inner").withColumnRenamed("planid", "medical_planid")
      val memgroupcontractplanoption_beneplansettings = memgroupcontractplanoption_benefitbundleplan.join(beneplansettings_std, memgroupcontractplanoption_benefitbundleplan("medical_planid") === beneplansettings_std("planid"),"left").withColumnRenamed("planname","medical_planname").drop("planid","benefitType")
    //  val memgroupcontractplanoption_benefitbundleriderplan = memgroupcontractplanoption_beneplansettings.join(benefitbundleriderplan_std, Seq("benefitBundleOptionID"),"left").drop("participationType")
    //  val beneplansettings_RX = beneplansettings_std.filter("benefitType = 'RX'")
   //   val memgroupcontractplanoption_beneplansettingsRX = memgroupcontractplanoption_benefitbundleriderplan.join(beneplansettings_std.filter("benefitType = 'RX'"), Seq("planid"),"left").withColumnRenamed("planid","rx_planid").withColumnRenamed("planname","rx_planname").drop("benefitType")
    //  val memgroupcontractplanoption_benefitbundleriderplanRR = memgroupcontractplanoption_beneplansettingsRX.join(benefitbundleriderplan_std, Seq("benefitBundleOptionID"),"left").drop("participationType")
     // val  beneplansettings_NONRX = beneplansettings_std.filter("benefitType != 'RX'")
      //val memgroupcontractplanoption_beneplansettingsRR = memgroupcontractplanoption_benefitbundleriderplanRR.join(beneplansettings_std.filter("benefitType != 'RX'"), Seq("planid"),"left").withColumnRenamed("planid","optional_rider_planid").withColumnRenamed("planname","optional_rider_planname").drop("benefitType")
     
      
      val benefitbundleriderplan__beneplansettingsRX = beneplansettings_std.filter("benefitType = 'RX'").join(benefitbundleriderplan_std,Seq("planid"),"inner").drop("benefitType","participationType").withColumnRenamed("planid","rx_planid")withColumnRenamed("planname","rx_planname")
      val memgroupcontractplanoption_beneplansettingsRX = memgroupcontractplanoption_beneplansettings.join(benefitbundleriderplan__beneplansettingsRX, Seq("benefitbundleoptionid"),"left")
      val benefitbundleriderplan__beneplansettingsNONRX = beneplansettings_std.filter("benefitType != 'RX'").join(benefitbundleriderplan_std,Seq("planid"),"inner").drop("benefitType","participationType").withColumnRenamed("planid","optional_rider_planid")withColumnRenamed("planname","optional_rider_planname")
      val memgroupcontractplanoption_beneplansettingsNONRX = memgroupcontractplanoption_beneplansettingsRX.join(benefitbundleriderplan__beneplansettingsNONRX, Seq("benefitbundleoptionid"),"left")
      
      val memgroupcontractplanoption_carrierlobplanview = memgroupcontractplanoption_beneplansettingsNONRX.join(carrierlobplanview_std, Seq("carrierlobplanid"),"inner").drop("carrierlobplanid")
      val memgroupcontractplanoption_memgroupctrctplnoptnetwklistvw = memgroupcontractplanoption_carrierlobplanview.join(memgroupctrctplnoptnetwklistvw_std, Seq("memgroupcontractplanoptionid"),"inner").drop("memgroupcontractplanoptionid")
      val memgroupcontractplanoption_memgroupcontractplanoptionView = memgroupcontractplanoption_memgroupctrctplnoptnetwklistvw.join(memgroupcontractplanoptionview_std,Seq("uah_memgroupid"),"inner")
      val memgroupcontractplanoption_memgroupid = memgroupcontractplanoption_memgroupcontractplanoptionView.join(memgroupid_std,Seq("uah_memgroupid"),"inner")
      val memgroupcontractplanoption_memgroupcontractview = memgroupcontractplanoption_memgroupid.join(memgroupcontractview_std,memgroupcontractplanoption_memgroupid.col("uah_memgroupid") === memgroupcontractview_std.col("uah_memgroupgid"),"inner").drop("uah_memgroupgid")
      val memgroupaddress = memgroupaddress_std.drop("industryclasscode", "address1", "address2", "city", "state", "postalcode", "phonenum", "phoneext", "organizationtype", "organizationtypedesc")
      val memgroupcontractplanoption_memgroupaddress = memgroupcontractplanoption_memgroupcontractview.join(memgroupaddress,Seq("uah_memgroupid"),"inner").drop("group_sic_code","originalcontractdate")
      val final_df = memgroupcontractplanoption_memgroupaddress.dropDuplicates()
       final_df
    }
      def actCurrPlanExtract(jsonMap:JValue,sparkSession: SparkSession): DataFrame ={
      //      load each table in a DF and do joins on DF's and then return the resultant DF
      val carrierlobplanview_std = commonFunctions.runSql(sparkSession, ReadJson.getProperty("carrierlobplanview_std"))
      val memgroupcontractview_std = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupcontractview_std"))
      val memgroupcontractplanoptionvw_std = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupcontractplanoptionvw_std"))
      val beneplansettings_std = commonFunctions.runSql(sparkSession, ReadJson.getProperty("beneplansettings_std"))
      val memgroupctrctplnoptnetwklistvw_std = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupctrctplnoptnetwklistvw_std"))
      val benefitbundleriderplan_std = commonFunctions.runSql(sparkSession, ReadJson.getProperty("benefitbundleriderplan_std"))
      val benefitbundleplan_std = commonFunctions.runSql(sparkSession, ReadJson.getProperty("benefitbundleplan_std"))

      val memgroupcontractplanoptionvw_memgroupcontractview = memgroupcontractview_std.join(memgroupcontractplanoptionvw_std, memgroupcontractview_std("uah_memgroupgid") === memgroupcontractplanoptionvw_std("uah_memgroupid"),"inner").drop("uah_memgroupgid","originalcontractdate")
      
      val memgroupcontractplanoption_benefitbundleplan = memgroupcontractplanoptionvw_memgroupcontractview.join(benefitbundleplan_std,Seq("benefitbundleoptionid"),"inner").withColumnRenamed("planid", "medical_planid")
      
      val memgroupcontractplanoption_carrierlobplanview = memgroupcontractplanoption_benefitbundleplan.join(carrierlobplanview_std, Seq("carrierlobplanid"),"inner").drop("carrierlobplanid")
      val memgroupcontractplanoption_memgroupctrctplnoptnetwklistvw = memgroupcontractplanoption_carrierlobplanview.join(memgroupctrctplnoptnetwklistvw_std, Seq("memgroupcontractplanoptionid"),"inner").drop("memgroupcontractplanoptionid")
      
      val memgroupcontractplanoption_beneplansettings = memgroupcontractplanoption_memgroupctrctplnoptnetwklistvw.join(beneplansettings_std, memgroupcontractplanoption_benefitbundleplan("medical_planid") === beneplansettings_std("planid"),"left").withColumnRenamed("planname","medical_planname").drop("planid","benefitType")
      
      val benefitbundleriderplan__beneplansettingsRX = beneplansettings_std.drop("plantype").filter("benefitType = 'RX'").join(benefitbundleriderplan_std,Seq("planid"),"inner").drop("benefitType","participationType").withColumnRenamed("planid","rx_planid")withColumnRenamed("planname","rx_planname")
      val memgroupcontractplanoption_beneplansettingsRX = memgroupcontractplanoption_beneplansettings.join(benefitbundleriderplan__beneplansettingsRX, Seq("benefitbundleoptionid"),"left")
      val benefitbundleriderplan__beneplansettingsNONRX = beneplansettings_std.drop("plantype").filter("benefitType != 'RX'").join(benefitbundleriderplan_std,Seq("planid"),"inner").drop("benefitType","participationType").withColumnRenamed("planid","optional_rider_planid")withColumnRenamed("planname","optional_rider_planname")
      val memgroupcontractplanoption_beneplansettingsNONRX = memgroupcontractplanoption_beneplansettingsRX.join(benefitbundleriderplan__beneplansettingsNONRX, Seq("benefitbundleoptionid"),"left")
      val final_df = memgroupcontractplanoption_beneplansettingsNONRX.dropDuplicates()
       final_df
    }
      def actCustomerRateExtract(jsonMap:JValue,sparkSession: SparkSession): DataFrame ={
      //      load each table in a DF and do joins on DF's and then return the resultant DF
      
      /*val memgroupcontractview_std = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupcontractview_std"))
      val memgroupcontractplanoptionvw_std = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupcontractplanoptionvw_std"))
      val benefitbundleplan_std = commonFunctions.runSql(sparkSession, ReadJson.getProperty("benefitbundleplan_std"))
      */
      val memgroupcontractview_std_dly = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupcontractview_std_dly"))
      val memgroupcontractview_std_mth = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupcontractview_std_mth"))
      
      val benefitbundleplan_std_dly = commonFunctions.runSql(sparkSession, ReadJson.getProperty("benefitbundleplan_std_dly"))
      val benefitbundleplan_std_mth = commonFunctions.runSql(sparkSession, ReadJson.getProperty("benefitbundleplan_std_mth"))

      val memgroupcontractplanoptionvw_std_dly = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupcontractplanoptionvw_std_dly"))
      val memgroupcontractplanoptionvw_std_mth = commonFunctions.runSql(sparkSession, ReadJson.getProperty("memgroupcontractplanoptionvw_std_mth"))
      
       var uah_memberid:DataFrame = memgroupcontractview_std_dly.select("uah_memberid").union(memgroupcontractplanoptionvw_std_dly.select("uah_memberid")).distinct
       
       val memgroupcontractplanoptionvw_std_memberid = memgroupcontractplanoptionvw_std_mth.join(uah_memberid.except(memgroupcontractplanoptionvw_std_dly.select("uah_memberid")),Seq("uah_memberid"),"inner").union(memgroupcontractplanoptionvw_std_dly)
       
       var benefitbundleoptionid:DataFrame = benefitbundleplan_std_dly.select("benefitbundleoptionid").union(memgroupcontractplanoptionvw_std_memberid.select("benefitbundleoptionid")).distinct
       
       val memgroupcontractplanoptionvw_std = memgroupcontractplanoptionvw_std_mth.join(benefitbundleoptionid.except(memgroupcontractplanoptionvw_std_dly.select("benefitbundleoptionid")),Seq("benefitbundleoptionid"),"inner").union(memgroupcontractplanoptionvw_std_dly)
       
       uah_memberid = memgroupcontractview_std_dly.select("uah_memberid").union(memgroupcontractplanoptionvw_std_dly.select("uah_memberid")).distinct
       benefitbundleoptionid = benefitbundleplan_std_dly.select("benefitbundleoptionid").union(memgroupcontractplanoptionvw_std_memberid.select("benefitbundleoptionid")).distinct
       
       
       val memgroupcontractview_std = memgroupcontractview_std_mth.join(uah_memberid.except(memgroupcontractview_std_dly.select("uah_memberid")),Seq("uah_memberid"),"inner").union(memgroupcontractview_std_dly)
       
       
       val benefitbundleplan_std = benefitbundleplan_std_mth.join(benefitbundleoptionid.except(benefitbundleplan_std_dly.select("benefitbundleoptionid")),Seq("benefitbundleoptionid"),"inner").union(benefitbundleplan_std_dly)
    
      //val memgroupcontractplanoptionvw_std = memgroupcontractplanoptionvw_std_dly.union(memgroupcontractplanoptionvw_std_mth)
       
       val memgroupcontractplanoptionvw_memgroupcontractview = memgroupcontractview_std.join(memgroupcontractplanoptionvw_std, memgroupcontractview_std("uah_memgroupgid") === memgroupcontractplanoptionvw_std("uah_memgroupid"),"inner").drop("uah_memgroupgid","originalcontractdate")
      
      val memgroupcontractplanoption_benefitbundleplan = memgroupcontractplanoptionvw_memgroupcontractview.join(benefitbundleplan_std,Seq("benefitbundleoptionid"),"inner")      
      
      val customerRate = memgroupcontractplanoption_benefitbundleplan.select("uah_memgroupid","uah_memgroupcontractgcid","memgroupcontractoptid","memgroupcontractplanoptionid","planid")
      
       customerRate.dropDuplicates
    }
     def dfWrite(writeDf:DataFrame,aggrLoc:String): Unit ={
      commonFunctions.saveDataframeAsFile(writeDf,aggrLoc,"overwrite") //this is for writing the Parquet File. VALIDATE THIS.
    }
//commented below function as we are not creating the extract
    /*def createExtract(writeDf:DataFrame,tgtLoc:String): Unit ={
      // added this for creating a tab delimited extract
      writeDf.rdd.repartition(1).map(x => x.mkString("\t")).saveAsTextFile(tgtLoc)
    }*/
  
}
