package com.optum.uah.merge_layer.customer

import com.optum.uah.function_library.{CommonFunctions, GlobalContext, ReadJson}
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.SparkSession
import com.optum.uah.function_library.Logger.log
import org.apache.spark.sql.functions._
import org.apache.hadoop.fs.{FileStatus, FileSystem, Path}
import java.util.Properties
import java.util.Scanner
import java.io.File
import java.io.FileInputStream

import com.optum.uah.merge_layer.claims.UAHCirClaims.CommonFunctions
import org.apache.hadoop.fs.{FileStatus, FileSystem, Path}

object UAHCirCustomer {

  val GContext = new GlobalContext()
  val func = new CommonFunctions()

  val sparkUAH = GContext.getUAHSession("UAHCirrusCustomer")
  val sparkRNA = GContext.getRnASession("UAHCirCustomer")

  def main(args: Array[String]): Unit = {
    //val tgtLoc = args(0)
    //    val propFilePath = args(1)
    //    val tblName = tgtLoc.split("mergelayer/")(1)
    //    val workingDir = tgtLoc.split("/" + tblName).head + "/working/" + tblName

    val extTableLocation = args(0)
    val jsonLocation = args(1)

//    val tableName = extTableLocation.split("mergelayer/")(1)
    val tableName = extTableLocation.split("/")(extTableLocation.split("/").size-1)
    this.getMergeData(jsonLocation, extTableLocation, tableName,args )
    GContext.stop()
  }

  /**
    * Defining  the main entry for a Spark submit . We normally use it for testing
    */

  //Incremental Load
  def appendIncrementData(sparkRNA: SparkSession, targetLoc: String, tblName: String, jsonLoc: String, tgtDF: DataFrame,args: Array[String] ) {
    var maxLoadTimestamp =""
    if (args.length==3) maxLoadTimestamp = func.getHbaseMrglayerTs(sparkRNA, tblName, args(2))
    else maxLoadTimestamp = func.getHbaseMrglayerTs(tblName)
    //var maxLoadTimestamp = "2017-10-18 00:00:00"
    ReadJson.createJsonObject(jsonLoc)
    log.info("Incremental Load")
    log.info("maxLoadTimestamp :" + maxLoadTimestamp)
    val fs = FileSystem.get(sparkRNA.sparkContext.hadoopConfiguration)
    val cirDeltaDf = tgtDF.filter("uah_timestamp > \"" + maxLoadTimestamp + "\"").filter(col("record_status") === "active").dropDuplicates("key", "uah_timestamp")
    //log.info("cirDeltaDf Count::" + cirDeltaDf.count)
    if(cirDeltaDf.count()!=0){
      val parquetDf = sparkRNA.read.option("inferSchema", "true").parquet(targetLoc)
      //val parquetDf = sparkRNA.read.parquet(targetLoc)
      //log.info("parquetDf Count::" + parquetDf.count)

      val cirrusDf = parquetDf.filter(col("source_cd") === "CRS").filter(col("record_status") === "active").dropDuplicates
      val unionedCirrusDf = cirrusDf.union(cirDeltaDf);
      //log.info("unionedCirrusDf Count::" + unionedCirrusDf.count)
      //unionedCirrusDf.show()

      val dedupDf = func.dedupLogic(unionedCirrusDf).dropDuplicates
      //log.info("dedupDf Count :" + dedupDf.count)

      maxLoadTimestamp = dedupDf.agg(max("uah_timestamp")).first()(0).toString
      if (args.length==3) func.updateHbaseMrglayerTs(sparkRNA, tblName, maxLoadTimestamp, args(2))
      else func.updateHbaseMrglayerTs(tblName, maxLoadTimestamp)

      dedupDf.write.mode("overwrite").partitionBy("source_cd").parquet(targetLoc+"_temp")
      fs.delete(new Path(targetLoc), true)
      fs.rename(new Path(targetLoc+"_temp"), new Path(targetLoc))
    }
    //else log.info("No New Records Exist as the Record Count is " + dedupDf.count)
    GContext.stop()
  }

  //Load table data into Merge Layer
  def getMergeData(jsonLoc: String, extTableLocation: String, tableName: String, args: Array[String]) {

    ReadJson.createJsonObject(jsonLoc)
    println("Getting attributes for " + tableName + " cirrus table from RnA tenant")
    val mergeDF = func.runSql(sparkRNA, ReadJson.getProperty(tableName)).filter(col("record_status") === "active").dropDuplicates

    if (CommonFunctions.getListOfFiles("/mapr" + extTableLocation + "/source_cd=CRS").isEmpty)  {
      println("Target Location Doesn't Exists :" + CommonFunctions.getListOfFiles("/mapr" + extTableLocation + "/source_cd=CRS").isEmpty)
      mergeDF.write.mode("overwrite").save(extTableLocation + "/source_cd=CRS")
      val maxLoadTimestamp = mergeDF.agg(max("uah_timestamp")).first()(0).toString
      if (args.length==3) func.updateHbaseMrglayerTs(sparkRNA, tableName, maxLoadTimestamp, args(2))
      else func.updateHbaseMrglayerTs(tableName, maxLoadTimestamp)
      println("Update maxLoadTimestamp in Hbase Table::" + maxLoadTimestamp)
    } else {
      //println("In Else Loop")
      println("Starting Incremental Load ")
      this.appendIncrementData(sparkRNA, extTableLocation, tableName, jsonLoc, mergeDF, args)
      println("Done with appendCirrusData")
    }
  }
}
