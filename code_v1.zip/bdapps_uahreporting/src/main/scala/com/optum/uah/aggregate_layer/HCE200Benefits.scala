package com.optum.uah.aggregate_layer

import com.optum.uah.function_library.GlobalContext
import com.optum.uah.function_library.CommonFunctions
import com.optum.uah.function_library.ReadJson
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.SparkSession
import java.io.IOException
import org.apache.spark.SparkContext

/**
 * @author TeamTitan, Nagababu
 */
object HCE200Benefits {

  val gContext = new GlobalContext()
  val func = new CommonFunctions()
  val sparkSession = gContext.getUAHSession("HCE200Benefits")
  println("### app_id ### :" + sparkSession.sparkContext.applicationId)

  def main(args: Array[String]): Unit = {

    val length = 3;
    if (args.length != length) {
      throw new IOException("Arguments mismatch! Expected arguments are : " + length + " , But actual arguments are : " + args.length);
    }
    //Loading json
    ReadJson.createJsonObject(args(0).trim());

    val opPath = args(1).trim();
    val tableName = args(2).trim();
    //val aggDB = sparkSession.conf.get("spark.database.uah.aggregate")
    val mergeDB = sparkSession.conf.get("spark.database.uah.merge")

    //Created dataframes based on the sqls mentioned in json.
    val beneplansettings_std_and_parent_child_group_levelDF = this.getDataFrame(sparkSession, "beneplansettings_std_and_parent_child_group_level", mergeDB)
    val eligibles_familyunitscheduleid_omdepage_mamplan_parstatustype_parstatustypedescDF = this.getDataFrame(sparkSession, "eligibles_familyunitscheduleid_omdepage_mamplan_parstatustype_parstatustypedesc", mergeDB)

    //Plan ID is coming from memberbenefit_std, and this table is also part of eligibles_familyunitscheduleid_omdepage_mamplan_parstatustype_parstatustypedesc
    //Because of mb.planid!=mb.controlplanid condition, planid query created separately. Major Medical plan also coming from memberbenefit_std but 
    //since doesn't contains any different conditions like plan id (mb.planid!=mb.controlplanid), we have added Mejormedicalplan in eligibles_familyunitscheduleid_omdepage_mamplan_parstatustype_parstatustypedesc

    val planidDF = this.getDataFrame(sparkSession, "planid", mergeDB)
    val dedgoalamtDF = this.getDataFrame(sparkSession, "dedgoalamt", mergeDB)

    val coinsurance_in_single_familyDF = this.getDataFrame(sparkSession, "coinsurance_in_single_family", mergeDB)

    val copayment_officeDF = this.getDataFrame(sparkSession, "copayment_office", mergeDB)
    val copayment_specialistDF = this.getDataFrame(sparkSession, "copayment_specialist", mergeDB)

    val deductible_in_network_single_familyDF = this.getDataFrame(sparkSession, "deductible_in_network_single_family", mergeDB)

    val lifetime_mac_inplanDF = this.getDataFrame(sparkSession, "lifetime_mac_inplan", mergeDB)

    val out_of_pocket_max_in_network_single_familyDF = this.getDataFrame(sparkSession, "out_of_pocket_max_in_network_single_family", mergeDB)

    val deductible_accumulatorDF = this.getDataFrame(sparkSession, "deductible_accumulator", mergeDB)

    val aggjDF = this.aggCustomer(beneplansettings_std_and_parent_child_group_levelDF,
      eligibles_familyunitscheduleid_omdepage_mamplan_parstatustype_parstatustypedescDF,
      planidDF, dedgoalamtDF, copayment_officeDF, copayment_specialistDF, coinsurance_in_single_familyDF, deductible_in_network_single_familyDF,
      lifetime_mac_inplanDF, out_of_pocket_max_in_network_single_familyDF, deductible_accumulatorDF)

    func.writeToParquet(aggjDF.dropDuplicates(), opPath)
    //need to comment below logic
    //func.createExternalTableFromParquet(sparkSession, opPath, tableName, aggDB)

  }

  /**
   * aggCustomer function reads the source dataframes as inputs arguments and do the necessary joins/aggregations and returns final aggregated dataframe.
   */
  def aggCustomer(beneplansettings_std_and_parent_child_group_levelDF: DataFrame,
                  eligibles_familyunitscheduleid_omdepage_mamplan_parstatustype_parstatustypedescDF: DataFrame,
                  planidDF: DataFrame, dedgoalamtDF: DataFrame,
                  copayment_officeDF: DataFrame, copayment_specialistDF: DataFrame,
                  coinsurance_in_single_familyDF: DataFrame,
                  deductible_in_network_single_familyDF: DataFrame,
                  lifetime_mac_inplanDF: DataFrame,
                  out_of_pocket_max_in_network_single_familyDF: DataFrame,
                  deductible_accumulatorDF: DataFrame): DataFrame = {

    var joinDF = beneplansettings_std_and_parent_child_group_levelDF.join(eligibles_familyunitscheduleid_omdepage_mamplan_parstatustype_parstatustypedescDF,
      beneplansettings_std_and_parent_child_group_levelDF.col("benefitplanversionid").equalTo(eligibles_familyunitscheduleid_omdepage_mamplan_parstatustype_parstatustypedescDF.col("benefitplanversionid")).
        and(beneplansettings_std_and_parent_child_group_levelDF.col("source_memgroupcontractgcid").equalTo(eligibles_familyunitscheduleid_omdepage_mamplan_parstatustype_parstatustypedescDF.col("source_memgroupcontractgcid")))
        .and(beneplansettings_std_and_parent_child_group_levelDF.col("source_memgroupid").equalTo(eligibles_familyunitscheduleid_omdepage_mamplan_parstatustype_parstatustypedescDF.col("source_memgroupid"))), "inner")
      .drop(eligibles_familyunitscheduleid_omdepage_mamplan_parstatustype_parstatustypedescDF.col("benefitplanversionid"))
      .drop(eligibles_familyunitscheduleid_omdepage_mamplan_parstatustype_parstatustypedescDF.col("source_memgroupcontractgcid"))
      .drop(eligibles_familyunitscheduleid_omdepage_mamplan_parstatustype_parstatustypedescDF.col("source_memgroupid")).distinct()

    //TO improve performance
    joinDF = joinDF.repartition(600, joinDF.col("benefitplanversionid"))

    joinDF = joinDF.join(planidDF, joinDF.col("benefitplanversionid").equalTo(planidDF.col("benefitplanversionid")).
      and(joinDF.col("source_memgroupcontractgcid").equalTo(planidDF.col("memgroupcontractid"))).
      and(joinDF.col("source_memgroupid").equalTo(planidDF.col("source_memgroupid"))), "inner").
      drop(planidDF.col("benefitplanversionid")).drop(planidDF.col("memgroupcontractid")).drop(planidDF.col("source_memgroupid")).distinct()

    joinDF = joinDF.join(dedgoalamtDF, joinDF.col("benefitplanversionid").equalTo(dedgoalamtDF.col("benefitplanversionid"))
      .and(joinDF.col("source_memgroupcontractgcid").equalTo(dedgoalamtDF.col("memgroupcontractid")))
      .and(joinDF.col("source_memgroupid").equalTo(dedgoalamtDF.col("source_memgroupid"))), "inner")
      .drop(dedgoalamtDF.col("benefitplanversionid")).drop(dedgoalamtDF.col("memgroupcontractid")).drop(dedgoalamtDF.col("source_memgroupid")).distinct()

    joinDF = joinDF.join(copayment_officeDF, joinDF.col("benefitplanversionid").equalTo(copayment_officeDF.col("benefitplanversionid"))
      .and(joinDF.col("source_memgroupcontractgcid").equalTo(copayment_officeDF.col("memgroupcontractid")))
      .and(joinDF.col("source_memgroupid").equalTo(copayment_officeDF.col("source_memgroupid"))), "inner")
      .drop(copayment_officeDF.col("benefitplanversionid")).drop(copayment_officeDF.col("memgroupcontractid")).drop(copayment_officeDF.col("source_memgroupid")).distinct()

    joinDF = joinDF.join(copayment_specialistDF, joinDF.col("benefitplanversionid").equalTo(copayment_specialistDF.col("benefitplanversionid"))
      .and(joinDF.col("source_memgroupcontractgcid").equalTo(copayment_specialistDF.col("memgroupcontractid")))
      .and(joinDF.col("source_memgroupid").equalTo(copayment_specialistDF.col("source_memgroupid"))), "inner")
      .drop(copayment_specialistDF.col("benefitplanversionid")).drop(copayment_specialistDF.col("memgroupcontractid")).drop(copayment_specialistDF.col("source_memgroupid")).distinct()

    joinDF = joinDF.join(coinsurance_in_single_familyDF, joinDF.col("benefitplanversionid").equalTo(coinsurance_in_single_familyDF.col("benefitplanversionid"))
      .and(joinDF.col("source_memgroupcontractgcid").equalTo(coinsurance_in_single_familyDF.col("memgroupcontractid")))
      .and(joinDF.col("source_memgroupid").equalTo(coinsurance_in_single_familyDF.col("source_memgroupid"))), "inner")
      .drop(coinsurance_in_single_familyDF.col("benefitplanversionid")).drop(coinsurance_in_single_familyDF.col("memgroupcontractid")).drop(coinsurance_in_single_familyDF.col("source_memgroupid")).distinct()

    joinDF = joinDF.join(deductible_in_network_single_familyDF, joinDF.col("benefitplanversionid").equalTo(deductible_in_network_single_familyDF.col("benefitplanversionid"))
      .and(joinDF.col("source_memgroupcontractgcid").equalTo(deductible_in_network_single_familyDF.col("memgroupcontractid")))
      .and(joinDF.col("source_memgroupid").equalTo(deductible_in_network_single_familyDF.col("source_memgroupid"))), "inner")
      .drop(deductible_in_network_single_familyDF.col("benefitplanversionid")).drop(deductible_in_network_single_familyDF.col("memgroupcontractid")).drop(deductible_in_network_single_familyDF.col("source_memgroupid")).distinct()

    joinDF = joinDF.join(lifetime_mac_inplanDF, joinDF.col("benefitplanversionid").equalTo(lifetime_mac_inplanDF.col("benefitplanversionid"))
      .and(joinDF.col("source_memgroupcontractgcid").equalTo(lifetime_mac_inplanDF.col("memgroupcontractid")))
      .and(joinDF.col("source_memgroupid").equalTo(lifetime_mac_inplanDF.col("source_memgroupid"))), "inner")
      .drop(lifetime_mac_inplanDF.col("benefitplanversionid")).drop(lifetime_mac_inplanDF.col("memgroupcontractid")).drop(lifetime_mac_inplanDF.col("source_memgroupid")).distinct()

    joinDF = joinDF.join(out_of_pocket_max_in_network_single_familyDF, joinDF.col("benefitplanversionid").equalTo(out_of_pocket_max_in_network_single_familyDF.col("benefitplanversionid"))
      .and(joinDF.col("source_memgroupcontractgcid").equalTo(out_of_pocket_max_in_network_single_familyDF.col("memgroupcontractid")))
      .and(joinDF.col("source_memgroupid").equalTo(out_of_pocket_max_in_network_single_familyDF.col("source_memgroupid"))), "inner")
      .drop(out_of_pocket_max_in_network_single_familyDF.col("benefitplanversionid")).drop(out_of_pocket_max_in_network_single_familyDF.col("memgroupcontractid")).drop(out_of_pocket_max_in_network_single_familyDF.col("source_memgroupid")).distinct()

    joinDF = joinDF.join(deductible_accumulatorDF, joinDF.col("benefitplanversionid").equalTo(deductible_accumulatorDF.col("benefitplanversionid"))
      .and(joinDF.col("source_memgroupcontractgcid").equalTo(deductible_accumulatorDF.col("memgroupcontractid")))
      .and(joinDF.col("source_memgroupid").equalTo(deductible_accumulatorDF.col("source_memgroupid"))), "inner")
      .drop(deductible_accumulatorDF.col("benefitplanversionid")).drop(deductible_accumulatorDF.col("memgroupcontractid")).drop(deductible_accumulatorDF.col("source_memgroupid"))
      .drop(joinDF.col("source_memgroupcontractgcid")).distinct()

    return joinDF;
  }

  /**
   * getDataFrame returns a DataFrame by using SparkSession and json propertyKey as inputs
   */
  def getDataFrame(sparkSession: SparkSession, propertyKey: String, mergeDB: String): DataFrame = {
    if (null != mergeDB)
      sparkSession.sqlContext.setConf("spark.sql.parquet.writeLegacyFormat", "true")
      sparkSession.sql("use " + mergeDB);
    func.runSql(sparkSession, ReadJson.getProperty(propertyKey))
  }

}