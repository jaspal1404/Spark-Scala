package com.optum.uah.merge_layer.member

import org.apache.spark.sql.functions._
import com.optum.uah.function_library.{CommonFunctions, GlobalContext, ReadJson}

import org.apache.spark.sql.SparkSession

import scala.io.Source
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions.Window

/**
  * Created by kgoje on 8/15/2017.
  * Modified by mkadiyal on 8/30/2017
  * Modified by psahota on 10/27/2017
  */
object UAHCirrusMember {

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .enableHiveSupport()
      .getOrCreate()

    import spark.implicits._
    val tgtLoc=args(0)
        //    val tblName=args(1)
//    val tblName = tgtLoc.split("mergelayer/")(1)
    val tblName = tgtLoc.split("/")(tgtLoc.split("/").size-1)
    val propFilePath=args(1)
    //    val test = tgtLoc.split("mergelayer/")(1)
    val workingDir =  tgtLoc.split("/"+tblName).head+ "/working/" +  tblName
    val GlobalContext = new GlobalContext()
    ReadJson.createJsonObject(propFilePath)
    var sparkSession = GlobalContext.getRnASession("MemberUAH")
    val CommonFunctions = new CommonFunctions()
    var jobLastRunTimestamp = "\""
    var maxLoadTimestamp = "\""
    if (args.length==3) {
      jobLastRunTimestamp = jobLastRunTimestamp + CommonFunctions.getHbaseMrglayerTs(sparkSession, tblName, args(2)) + "\""
    }
    else {
      jobLastRunTimestamp = jobLastRunTimestamp + CommonFunctions.getHbaseMrglayerTs(tblName) + "\""
    }
    println("Time stamp from Hbase before Loading:" + jobLastRunTimestamp)
    println(ReadJson.getProperty(tblName))
    val cirDelta_df = CommonFunctions.runSql(sparkSession, ReadJson.getProperty(tblName)).filter("uah_timestamp >= " + jobLastRunTimestamp)
    println("Delta file records count from a dataframe*************" + cirDelta_df.count())

    if (cirDelta_df.count() != 0) {
      println("******************************************************************************")

      if (CommonFunctions.getListOfFiles("/mapr" + tgtLoc+"/source_cd=CRS").isEmpty) {
        println("Cirrus initial Delta DF Count*************: " + cirDelta_df.count())
        val tempDf = cirDelta_df.groupBy("key").agg(max("uah_timestamp") as "r_uah_timestamp").withColumnRenamed("key", "r_key")
        val dedupDf1 = cirDelta_df.join(tempDf, cirDelta_df("key") === tempDf("r_key") && cirDelta_df("uah_timestamp") === tempDf("r_uah_timestamp")).drop("r_key").drop("r_uah_timestamp")
        maxLoadTimestamp = dedupDf1.agg(max("uah_timestamp")).first()(0).toString
//        if (args.length ==3) {
//          CommonFunctions.updateHbaseMrglayerTs(sparkSession, tblName, maxLoadTimestamp, args(2))
//        }
//        else {
//          CommonFunctions.updateHbaseMrglayerTs(tblName, maxLoadTimestamp)
//        }
        CommonFunctions.saveDataframeAsFile(dedupDf1, tgtLoc+"/source_cd=CRS","overwrite")
        //        CommonFunctions.createExternalTableFromParquet(sparkSession,tgtLoc,tblName,"uah_mergelayer")
      }
      else {
        println(" In else block which means there is a data present in the target location and initiating the dedup process ")
        // Load the history records in merge layer from previous run
        val mergeLayer_df=sparkSession.read.parquet(tgtLoc+"/source_cd=CRS")
        println("Record count for the records already presnet in merge layer DF Count*************: " + mergeLayer_df.count())
        // val unionedDf = mergeLayer_df.union(cirDelta_df).dropDuplicates("key","uah_timestamp")
        val unionedDf = mergeLayer_df.union(cirDelta_df)
        // val rank_df = unionedDf.withColumn("rank", rank.over(Window.partitionBy("memberid").orderBy($"uah_timestamp".desc)))
        val rank_df = unionedDf.withColumn("rank", row_number.over(Window.partitionBy("key").orderBy($"uah_timestamp".desc)))
        val temp_df = rank_df.filter("rank = '1'")
        val write_df = temp_df.drop("rank")
        maxLoadTimestamp = write_df.agg(max("uah_timestamp")).first()(0).toString
//        CommonFunctions.updateHbaseMrglayerTs(tblName, maxLoadTimestamp)
        CommonFunctions.saveDataframeOverwriteAsFile(sparkSession, write_df, tgtLoc+"/source_cd=CRS", workingDir)
        //        CommonFunctions.createExternalTableFromParquet(sparkSession,tgtLoc,tblName,"uah_mergelayer")
      }
      if (args.length ==3) {
        CommonFunctions.updateHbaseMrglayerTs(sparkSession, tblName, maxLoadTimestamp, args(2))
      }
      else {
        CommonFunctions.updateHbaseMrglayerTs(tblName, maxLoadTimestamp)
      }
      //      val latestTs = CommonFunctions.updateHbaseMrglayerTs(tblName )
      //      println("Time stamp After Hbase Update and before Dataframe Load :" + latestTs)
    }
    else {
      println("****Delta Records Count is Zero****")
    }
  }
}