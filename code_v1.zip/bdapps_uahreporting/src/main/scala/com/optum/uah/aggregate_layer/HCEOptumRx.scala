package com.optum.uah.aggregate_layer
import com.optum.uah.function_library.{CommonFunctions, ReadJson, GlobalContext}
import org.apache.commons.io.FileUtils
import java.io.File

/**
  * Created by mkadiyal on 10/23/2017.
  */
object HCEOptumRx {
  def main(args: Array[String]): Unit = {
    //Spark submit shell path: /mapr/datalake/optum/optuminsight/d_uah/dev/d_scripts/UAH_HCE_Extract_OptumRx.sh
    //val srcLoc = args(0)
    val subjArea = args(0)
    //    val tgtLoc = args(0)
    val propFilePath = args(1)
    val aggrLoc = args(2)

    //Extract SQL and execute Spark SQL; Store the data in a data frame
    ///mapr/datalake/optum/optuminsight/d_uah/dev/d_scripts/properties/optumRxProperties.json
    ReadJson.createJsonObject(propFilePath)
    val extractSql = ReadJson.getProperty(subjArea)

    val GContext = new GlobalContext()
    val sparkSession = GContext.getUAHSession("ORxUAHAggregate")
    val CommonFunctions = new CommonFunctions()
    val extractDf = CommonFunctions.runSql(sparkSession, extractSql)

    //Write the output of the data frame as a Parquet file in aggregate layer and as a text file in outbound location
    //Load strategy: Truncate/Load
    //Aggregate layer path: /mapr/datalake/optum/optuminsight/d_uah/dev/d_hdfsaggregate_layer/hce/optumrx
    //outbound folder path: /mapr/datalake/optum/optuminsight/d_uah/dev/d_outbound/hceExtracts/optumrx
    FileUtils.deleteDirectory(new File("/mapr/"+aggrLoc))
    //    FileUtils.deleteDirectory(new File("/mapr/"+tgtLoc))

    CommonFunctions.saveDataframeAsFile(extractDf,aggrLoc,"overwrite") //this is for writing the Parquet File. VALIDATE THIS.
    //    extractDf.rdd.repartition(1).map(x => x.mkString("|")).saveAsTextFile(tgtLoc) //       /u0001 - suggested
  }

}
