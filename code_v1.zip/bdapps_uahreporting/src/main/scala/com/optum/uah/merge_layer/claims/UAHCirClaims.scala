package com.optum.uah.merge_layer.claims

import com.optum.uah.function_library.{CommonFunctions, GlobalContext, ReadJson}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window


/**
  * Created by sbandar8 on 8/8/2017.
  */
object UAHCirClaims {

  val CommonFunctions = new CommonFunctions()
  val GlobalContext = new GlobalContext()

  def main(args: Array[String]): Unit = {

    val tgtLoc = args(0)
    val propFilePath = args(1)
    val tblName = tgtLoc.split("mergelayer/")(1)
    val workingDir = tgtLoc.split("/" + tblName).head + "/working/" + tblName
    var grpByCols, orderByCols = ""
    if (args.length > 2) {
      grpByCols = args(2)
      orderByCols = args(3)
    }

    //Load json property file to get sql based on the subject area and table
    ReadJson.createJsonObject(propFilePath)

    // Read job last run timestamp from staging file/table
    var maxLoadTimestamp = CommonFunctions.getHbaseMrglayerTs(tblName)
    val sparkSession = GlobalContext.getRnASession("ClaimsRnA")

    // Call function to load Cirrus data
    val cirDeltaDf = getCirrusData(maxLoadTimestamp, tblName, sparkSession)
    println("Delta file records count from a dataframe*************" + cirDeltaDf.count())

    // Run the dedup process only if we have incremental records
    if (cirDeltaDf.count() != 0) {

      // Load spark session for uah metastore
      val sparkSession = GlobalContext.getUAHSession("ClaimsUAH")

      if (CommonFunctions.getListOfFiles("/mapr" + tgtLoc + "/source_cd=CRS").isEmpty) {

        // Calling the Dedup function to identify records with latest timestamp
        val dedupDf = {
          if (tblName == "claimlineinst_std" ||
            tblName == "claimlineprof_std" ||
            tblName == "claimheader_std" ||
            tblName == "claimnote_std" ||
            tblName == "claimprovideraddress_std" ||
            tblName == "claimcobadjustment_std" ||
            tblName == "claimlineadjudication_std" ||
            tblName == "umauthview_std" ||
            tblName == "claimpricinginputdetailview_std" ||
            tblName == "clabenefit_std" ||
            tblName == "cladofr_view" ||
            tblName == "oonpricingschednoteview_std" ||
            tblName == "oonpricingschedorderdetailview_std" ||
            tblName == "aptransactiondetailview_std" ||
            tblName == "apgenerationresponseview_std" ||
            tblName == "aptransactionattribsetglstring_view" ||
            tblName == "claimevent_std")
          {
            val tempDf = CommonFunctions.dedupLogic(cirDeltaDf, grpByCols, orderByCols)
            tempDf
          }
          else {
            val tempDf = CommonFunctions.dedupLogic(cirDeltaDf)
            tempDf
          }
        }
        println("Record count for the records after dedup process executes *************: " + dedupDf.count())

        // Update Hbase table with max load timestamp of the record
        maxLoadTimestamp = dedupDf.agg(max("uah_timestamp")).first()(0).toString
        CommonFunctions.updateHbaseMrglayerTs(tblName, maxLoadTimestamp)

        // Save dedup records into the merge layer *****
        CommonFunctions.saveDataframeAsFile(dedupDf, tgtLoc+"/source_cd=CRS", "overwrite")
      }

      else {

        // Load the history records in merge layer from previous run
        val mergeFullDf = getMergeTblData(tgtLoc, sparkSession)
        println("Record count for the records already presnet in merge layer DF Count*************: " + mergeFullDf.count())

        // Union Cirrus and merge layer dataframes
        val unionedDf = CommonFunctions.unionDataframes(mergeFullDf, cirDeltaDf)

        // Calling the Dedup function to identify records with latest timestamp
        val dedupDf = {
          if (tblName == "claimlineinst_std" ||
            tblName == "claimlineprof_std" ||
            tblName == "claimheader_std" ||
            tblName == "claimnote_std" ||
            tblName == "claimprovideraddress_std" ||
            tblName == "claimcobadjustment_std" ||
            tblName == "claimlineadjudication_std" ||
            tblName == "umauthview_std" ||
            tblName == "claimpricinginputdetailview_std" ||
            tblName == "clabenefit_std" ||
            tblName == "cladofr_view" ||
            tblName == "oonpricingschednoteview_std" ||
            tblName == "oonpricingschedorderdetailview_std"||
            tblName == "aptransactiondetailview_std" ||
            tblName == "apgenerationresponseview_std" ||
            tblName == "aptransactionattribsetglstring_view" ||
            tblName == "claimevent_std")
          {
            val tempDf = CommonFunctions.dedupLogic(unionedDf, grpByCols, orderByCols)
            tempDf
          }
          else {
            val tempDf = CommonFunctions.dedupLogic(unionedDf)
            tempDf
          }
        }
        println("Record count for the records after dedup process executes *************: " + dedupDf.count())

        maxLoadTimestamp = dedupDf.agg(max("uah_timestamp")).first()(0).toString
        CommonFunctions.updateHbaseMrglayerTs(tblName, maxLoadTimestamp)

        // Save dedup records into the merge layer *****
        CommonFunctions.saveDataframeOverwriteAsFile(sparkSession, dedupDf, tgtLoc+"/source_cd=CRS", workingDir)
      }

    }

    sparkSession.close()
  }


  def getCirrusData(maxLoadTimestamp: String, tblName: String, sparkSession: SparkSession): DataFrame = {

    var resultDf: DataFrame = sparkSession.emptyDataFrame

    // Load data from cirrus table into a dataframe with incremental data
    if ( maxLoadTimestamp == "Null") {
      resultDf = CommonFunctions.runSql(sparkSession, ReadJson.getProperty(tblName)).filter(col("record_status") === "active")
    }
    else {
      resultDf = CommonFunctions.runSql(sparkSession, ReadJson.getProperty(tblName)).filter("uah_timestamp > \"" + maxLoadTimestamp + "\"").filter(col("record_status") === "active")
    }

    resultDf
  }


  def getMergeTblData(tgtLoc: String, sparkSession: SparkSession): DataFrame = {

    // Load the history records in merge layer from previous run
    val resultDf = sparkSession.read.parquet(tgtLoc)

    resultDf
  }
}
