package com.optum.uah.merge_layer.provider
import com.optum.uah.function_library.{ CommonFunctions, GlobalContext, ReadJson, CrossRefUtility }
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{ array, col, explode, lit, struct, unix_timestamp, concat_ws }
import com.optum.uah.function_library.Logger.log
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel

//ACTION ITEM: This class need to be merged. Next time when we are working on Customer please merge the 'UAHCirProvider_merge'
//** into this class UAHCirProvider
//


object UAHProvider_merge {
  val GContext = new GlobalContext()
  val func = new CommonFunctions()
//  val rJson = new ReadJson(GContext.runHome + "/hce200Provider.json")
  ReadJson.createJsonObject(GContext.runHome + "/hce200Provider.json")
  val CrossWalkDF = ProviderCrosswalk.getProviderCrosswalk().toDF()
  val crossRef = new CrossRefUtility("/datalake/optum/optuminsight/d_uah/dev/d_mtables/datacrosswalk", "uah_code")
  def main(args: Array[String]): Unit = {

    var sparkSession = GContext.getUAHSession("ProviderUAH")
    log.info("Getting results afterCrossWalk")

    var path = args(0) //{CirrusProvtinaddressesview_merge,CirrusProviderorglocationphnview_merge}
    val Provtinaddressesview = getCirrusProvtinaddressesview_merge(path)
    func.createExternalTableFromParquet(sparkSession, Provtinaddressesview, "uah_m_cirrus_Provtinaddressesview", args(1))

    val Providerorglocationphnview = getCirrusProviderorglocationphnview_merge(path)
    func.createExternalTableFromParquet(sparkSession, Providerorglocationphnview, "uah_m_cirrus_Providerorglocationphnview", args(1))

    val Provideridentifiersearchview = getCirrusProvideridentifiersearchview_merge(path)
    func.createExternalTableFromParquet(sparkSession, Provideridentifiersearchview, "uah_m_cirrus_Provideridentifiersearchview", args(1))

    val Providerorgfacility_snapshot = getCirrusProviderorgfacility_snapshotmerge(path)
    func.createExternalTableFromParquet(sparkSession, Providerorgfacility_snapshot, "uah_m_cirrus_Providerorgfacility_snapshot", args(1))

    val Providerorgaffiliationtinview = getCirrusProviderorgaffiliationtinview_merge(path)
    func.createExternalTableFromParquet(sparkSession, Providerorgaffiliationtinview, "uah_m_cirrus_Providerorgaffiliationtinview", args(1))

    val Providerorgidview = getCirrusProviderorgidview_merge(path)
    func.createExternalTableFromParquet(sparkSession, Providerorgidview, "uah_m_cirrus_Providerorgidview", args(1))

    val providerid_snapshotOrc = getCirrusproviderid_snapshotOrc_merge(path)
    func.createExternalTableFromParquet(sparkSession, providerid_snapshotOrc, "uah_m_cirrus_providerid_snapshotOrc", args(1))

    val Claimpricinginputdetailview = getCirrusClaimpricinginputdetailview_merge(path)
    func.createExternalTableFromParquet(sparkSession, Claimpricinginputdetailview, "uah_m_cirrus_Claimpricinginputdetailview", args(1))

    val Taxonomycode_snapshot = getCirrusTaxonomycode_snapshotmerge(path)
    func.createExternalTableFromParquet(sparkSession, Taxonomycode_snapshot, "uah_m_cirrus_Taxonomycode_snapshot", args(1))

    val Networkidquerysrchview = getCirrusNetworkidquerysrchview_merge(path)
    func.createExternalTableFromParquet(sparkSession, Networkidquerysrchview, "uah_m_cirrus_Networkidquerysrchview", args(1))
    
    
    
        //Jeff code
    //1. Grab hbase value
    //val tgtLoc = args(0)
    //val tblName = tgtLoc.split("mergelayer/")(1)
    //val workingDir =  tgtLoc.split("/"+tblName).head+ "/working/" +  tblName
    val jsonLoc = args(0)
    val tblName = args(1)
    val tgtLoc = args(2)
    val workingDir = args(3)
    val hiveTableName = args(4)
    
    //appendCirrusData(sparkSession, tgtLoc, workingDir, tblName, jsonLoc, hiveTableName)

  }
  
    def appendCirrusData(sparkSession: SparkSession, tgtLoc: String, workingDir: String, tblName: String, jsonLoc: String, hiveTableName:String){
        var maxLoadTimestamp = func.getHbaseMrglayerTs(tblName)
    
        ReadJson.createJsonObject(jsonLoc)
        //val cirDeltaDf = func.runSql(sparkSession, jsonData.getProperty(tblName)).filter("uah_timestamp >= \"" + maxLoadTimestamp + "\"").dropDuplicates("key","uah_timestamp")
        val cirDeltaDf = func.runSql(sparkSession, ReadJson.getProperty(tblName).stripPrefix("List(")).filter("uah_timestamp >= \"" + maxLoadTimestamp + "\"").dropDuplicates("key","uah_timestamp")
        val parquetDf = sparkSession.read.parquet(tgtLoc)
        parquetDf.show()
        cirDeltaDf.show()
    //    //cirrus dataframe
        val cirrusDf = parquetDf.filter(col("source_cd") === "CRS")
    //    //pulse dataframe
        val legacyDf = parquetDf.filter(col("source_cd") === "PUL")
    //    //union cirrus
        val unionedCirrusDf = cirrusDf.union(cirDeltaDf)
    //    //callupdate the hbase tracking table
        val dedupDf = func.dedupLogic(unionedCirrusDf)
        maxLoadTimestamp = dedupDf.agg(max("uah_timestamp")).first()(0).toString
        func.updateHbaseMrglayerTs(tblName, maxLoadTimestamp)
    //    //union old + new cirrus with legacy
        val unionedDF = unionedCirrusDf.union(legacyDf)
    //    //overwrite parquet
        func.saveDataframeOverwriteAsFile(sparkSession, unionedDF, tgtLoc, workingDir)
        //func.createExternalTableFromParquet(sparkSession, "/mapr/datalake/optum/optuminsight/d_uah/dev/d_hdfs/mergelayer/Providerorgaffiliationtinview/1505734204695", "uah_m_test_providerorgaffiliationtinview", "uah_mergelayer_dev")
        var sparkSessionUAH = GContext.getUAHSession("MemberUAH")
        func.createExternalTableFromParquet(sparkSessionUAH, tgtLoc, hiveTableName, "uah_mergelayer_dev")

  }
  
  
  
  /** Runcrossref on legacy data and union with cirrus data save dataframe as parquet file and create external table on top up
    * @param sparkSession
    * @param df
    *
    */
  def getCirrusProvtinaddressesview_merge(path: String): String = {
    val sparkSession = GContext.getUAHSession("UAHCirrus")
    val legacyPostCross = UAHProviderTransformLegacy.getLegacyCrosswalked(CrossWalkDF)
    import sparkSession.implicits._

    val seq = Seq("provider_type~pulse") //need to add , "provider_speciality~pulse"
    crossRef.refDataLoader(seq)
    val legacypostref = legacyPostCross.withColumn("provider_type2", crossRef.crsRefLkp(lit("provider_type"), lit("pulse"), col("provider_type"))) //.withColumn("network_name2", crossRef.crsRefLkp(lit("network_name"), lit("Pulse"), col("network_name")))
    val legacyPostTransformation = legacypostref.drop("provider_type").withColumnRenamed("provider_type2", "provider_type") //.drop("network_name").withColumnRenamed("network_name2", "network_name")

    val legacyPostCrosstempfilter = legacyPostTransformation.alias("a").select(col("a.*")).filter(col("address_type").isin("BILL")).withColumn("billingAddressAddress4", lit(null)).withColumn("billingAddressAddress5", lit(null)).withColumn("key", lit(null)).withColumn("record_status", lit("Active")).withColumn("uah_timestamp", unix_timestamp().cast("timestamp")).withColumn("source_cd", lit("PUL"))

    //        val legacyPostCrosstemp = legacyPostCrosstempfilter.alias("a").select(col("uah_providerid"), col("line1").alias("billingAddressAddress1"), col("line2").alias("billingAddressAddress2"), col("line3").alias("billingAddressAddress3"), col("billingAddressAddress4"), col("billingAddressAddress5"), col("a.city").alias("billingAddressCity"), col("a.state").alias("billingAddressState"), concat_ws("-", col("a.zip"), col("a.zip_extension")).alias("billingAddressPostalCode"), concat_ws("-", col("a.area_code"), col("a.phone_number")).alias("providerFullPhoneNumber"), col("key"), col("cdc_flag"), col("uah_timestamp"), col("source_cd"), col("providerid_ext_src"), col("ext_src_cd"))
    val legacyPostCrosstemp = legacyPostCrosstempfilter.alias("a").select(col("uah_providerid"), col("line1").alias("billingAddressAddress1"), col("line2").alias("billingAddressAddress2"), col("line3").alias("billingAddressAddress3"), col("billingAddressAddress4"), col("billingAddressAddress5"), col("a.city").alias("billingAddressCity"), col("a.state").alias("billingAddressState"), concat_ws("-", col("a.zip"), col("a.zip_extension")).alias("billingAddressPostalCode"), col("a.FEDERAL_TAX_ID").alias("providerTaxID"), col("key"), col("record_status"), col("uah_timestamp"), col("source_cd"), col("providerid_ext_src"), col("ext_src_cd"))

    //legacyPostCrosstemp.printSchema()
    //Getting cirrus data
   // val cirrusProvtinaddressesview = UAHCirProvider.getCirrusProvtinaddressesview_std()
    //val cirrusProvtinaddressesviewtemp = cirrusProvtinaddressesview.alias("a").select(col("a.*")).withColumnRenamed("ptProvTINID", "uah_providerid")
   // val cirrusProvtinaddressesviewfinal = cirrusProvtinaddressesviewtemp.withColumn("providerid_ext_src", lit(null)).withColumn("ext_src_cd", lit(null))

   // val cirrusProvtinaddressesviewfinalDF = sparkSession.createDataFrame(cirrusProvtinaddressesviewfinal.rdd, cirrusProvtinaddressesviewfinal.schema)

    //cirrusProvtinaddressesviewfinal.printSchema()
    val unionedDataframe = legacyPostCrosstemp.distinct()
    func.saveAsFileforDataset(unionedDataframe, "parquet", path + "/CirrusProvtinaddressesview_merge")
    path + "/CirrusProvtinaddressesview_merge"
    /*mark as success for this table*/
  }

  //service
  /** save dataframe as parquet file and create external table on top up
    * @param sparkSession
    * @param df
    *
    */
  def getCirrusProviderorglocationphnview_merge(path: String): String = {
    val sparkSession = GContext.getUAHSession("UAHCirrus")
    val legacyPostCross = UAHProviderTransformLegacy.getLegacyCrosswalked(CrossWalkDF)
    import sparkSession.implicits._
    val seq = Seq("provider_type~pulse") //need to add , "provider_speciality~pulse"
    crossRef.refDataLoader(seq)
    val legacypostref = legacyPostCross.withColumn("provider_type2", crossRef.crsRefLkp(lit("provider_type"), lit("pulse"), col("provider_type"))) //.withColumn("network_name2", crossRef.crsRefLkp(lit("network_name"), lit("Pulse"), col("network_name")))
    val legacyPostTransformation = legacypostref.drop("provider_type").withColumnRenamed("provider_type2", "provider_type") //.drop("network_name").withColumnRenamed("network_name2", "network_name")
    val legacyPostCrosstempfilter = legacyPostTransformation.alias("a").select(col("a.*")).filter(col("address_type").isin("PR")).withColumn("servicingAddressAddress4", lit(null)).withColumn("servicingAddressAddress5", lit(null)).withColumn("key", lit(null)).withColumn("record_status", lit("Active")).withColumn("uah_timestamp", unix_timestamp().cast("timestamp")).withColumn("source_cd", lit("PUL"))
   // legacyPostCrosstempfilter.printSchema()
    val legacyPostCrosstemp = legacyPostCrosstempfilter.alias("a").select(col("uah_providerid"), col("line1").alias("servicingAddressAddress1"), col("line2").alias("servicingAddressAddress2"), col("line3").alias("servicingAddressAddress3"), col("servicingAddressAddress4"), col("servicingAddressAddress5"), col("a.city").alias("servicingAddressCity"), col("a.state").alias("servicingAddressState"), concat_ws("-", col("a.zip"), col("a.zip_extension")).alias("servicingAddressPostalCode"), concat_ws("-", col("a.area_code"), col("a.phone_number")).alias("providerFullPhoneNumber"), col("key"), col("record_status"), col("uah_timestamp"), col("source_cd"), col("providerid_ext_src"), col("ext_src_cd"))
    //legacyPostCrosstemp.printSchema()
   // val cirProviderOrgLocationView = UAHCirProvider.getCirrusProviderorglocationphnview_std().toDF()
    //val cirProviderOrgLocationViewtemp = cirProviderOrgLocationView.alias("a").select(col("a.*")).withColumnRenamed("providerorglocationProviderOrgID", "uah_providerid")
    //val cirProviderOrgLocationViewfinal = cirProviderOrgLocationViewtemp.withColumn("providerid_ext_src", lit(null)).withColumn("ext_src_cd", lit(null))
    //val cirProviderOrgLocationViewfinalDF = sparkSession.createDataFrame(cirProviderOrgLocationViewfinal.rdd, cirProviderOrgLocationViewfinal.schema)
   // cirProviderOrgLocationViewfinalDF.printSchema()
    val unionedDataframe = legacyPostCrosstemp.distinct()
    func.saveAsFileforDataset(unionedDataframe, "parquet", path + "/CirrusProviderorglocationphnview_merge")
    path + "/CirrusProviderorglocationphnview_merge"
  }

  //

  def getCirrusProvideridentifiersearchview_merge(path: String): String = {
    val sparkSession = GContext.getUAHSession("UAHCirrus")
    import sparkSession.implicits._
   // val provideridentifiersearchview = UAHCirProvider.getCirrusProvideridentifiersearchview_std()
    val providerCrosswalkedLegacy = UAHProviderTransformLegacy.getLegacyCrosswalked(CrossWalkDF)
    val requiredColumnsLegacy = providerCrosswalkedLegacy.alias("a").select(col("a.*")).withColumn("licenseTypeDesc", lit(null)).withColumn("key", lit(null)).withColumn("record_status", lit("Active")).withColumn("uah_timestamp", unix_timestamp().cast("timestamp")).withColumn("source_cd", lit("PUL"))
    val legacyProvideridentifiersearchDF = requiredColumnsLegacy.select(col("uah_providerid"), col("LICENSING_CODE").as("providerDEA"), col("licenseTypeDesc"), col("key"), col("record_status"), col("uah_timestamp"), col("source_cd"), col("providerid_ext_src"), col("ext_src_cd"))
  //  legacyProvideridentifiersearchDF.printSchema()
   // val cirrusProvideridentifiersearchView = provideridentifiersearchview.withColumn("providerid_ext_src", lit(null)).withColumn("ext_src_cd", lit(null)).withColumnRenamed("providerProviderID", "uah_providerid")
    //val cirrusProvideridentifiersearchViewDF = cirrusProvideridentifiersearchView.select(col("uah_providerid"), col("providerDEA"), col("licenseTypeDesc"), col("key"), col("record_status"), col("uah_timestamp"), col("source_cd"), col("providerid_ext_src"), col("ext_src_cd"))
   // cirrusProvideridentifiersearchViewDF.printSchema()
    val unionedDataframe = legacyProvideridentifiersearchDF.distinct()
    func.saveAsFileforDataset(unionedDataframe, "parquet", path + "/CirrusProvideridentifiersearchview_merge")
    path + "/CirrusProvideridentifiersearchview_merge"
  }

  /*
   * substring(c.countyfips,3,5) as countycd, c.countyfips, b.countycode, c.countyname,c.key as key,c.cdc_flag AS record_status,c.cdc_ts AS uah_timestamp,'CRS'
     PROVIDERID,b.LINE1,b.LINE2,b.LINE3,b.CITY,b.STATE,b.ZIP,b.COUNTY,b.ADDRESS_TYPE,b.AREA_CODE,c.LICENSING_CODE,a.FIRST_NAME,b.PHONE_NUMBER,a.LAST_NAME,a.UHC_MPIN,
    a.SOCIAL_SECURITY_NUMBER,a.FEDERAL_TAX_ID,a.PROVIDER_TYPE,a.PAR_EFFECTIVE_FROM_DATE,a.PAR_DISENROLLED_DATE,a.PAR_STATUS_TYPE,g.ADDRESS_SOURCE_TYPE,g.ADDRESS_ID ,
    d.specialty_type,d.sub_specialty1,d.sub_specialty2,d.sub_specialty3,e.national_provider_id,f.network,f.network_name,g.zip_extension
   */
  def getCirrusProviderorgfacility_snapshotmerge(path: String): String = {
    val sparkSession = GContext.getUAHSession("UAHCirrus")
    import sparkSession.implicits._
   // val originalCirrusProviderOrgAffiliationView = UAHCirProvider.getCirrusProviderorgfacility_snapshotorc()
    val providerCrosswalkedLegacy = UAHProviderTransformLegacy.getLegacyCrosswalked(CrossWalkDF)
    val requiredColumnsLegacy = providerCrosswalkedLegacy.select(col("uah_providerid"), col("providerid_ext_src"), col("ext_src_cd"), col("PROVIDERID").alias("providerID"), col("COUNTY").alias("countyInd")).withColumn("key", lit(null)).withColumn("record_status", lit("active")).
      withColumn("uah_timestamp", unix_timestamp().cast("timestamp")).withColumn("source_cd", lit("PUL"))
    //requiredColumnsLegacy.printSchema()
 //   val cirrusProviderOrgAffiliationView = originalCirrusProviderOrgAffiliationView.withColumn("providerid_ext_src", lit(null)).withColumn("ext_src_cd", lit(null))
 //   val cirrusProviderOrgAffiliationDF = sparkSession.createDataFrame(cirrusProviderOrgAffiliationView.rdd, cirrusProviderOrgAffiliationView.schema)
  //  cirrusProviderOrgAffiliationDF.createOrReplaceTempView("cirrusProviderOrgAffiliationView")
   // val cirrusFinalDF = func.runSql(sparkSession, "select providerid as uah_providerid,providerid_ext_src,ext_src_cd,providerid as providerID,countyname AS countyInd,key,record_status,uah_timestamp,source_cd from cirrusProviderOrgAffiliationView")
    //cirrusFinalDF.printSchema()
    val unionedDataframe = requiredColumnsLegacy.distinct()
    func.saveAsFileforDataset(unionedDataframe, "parquet", path + "/CirrusProviderorgfacility_snapshotmerge")
    path + "/CirrusProviderorgfacility_snapshotmerge"
  }
  /*DONE
   * providernameFirst,
  
    providernameLast,
    providerType,
    poaProviderOrgID,//dont need
    provTINID,
    pProviderID,
    GROUPNAM,
    key,
    record_status
    ,uah_timestamp
    ,src_cd
    col("a.provider_id").alias("providerid"),col("b.provider_code").alias("PROVCODE"),col("b.LAST_NAME").alias("PRVLNAME"),col("b.first_name").alias("PRVFNAME"),
    col("a.provider_code").alias("GROUPCOD"), col("a.facility_name").alias("GROUPNAM"),col("a.federal_tax_id").alias("PRVTAXID")) DONE*/

  def getCirrusProviderorgaffiliationtinview_merge(path: String): String = {
    val sparkSession = GContext.getUAHSession("UAHCirrus")
    import sparkSession.implicits._
   // val originalCirrusProviderOrgAffiliationView = UAHCirProvider.getCirrusProviderorgaffiliationtinview_std();
    val providerCrosswalkedLegacy = UAHProviderTransformLegacy.getProviderGroupAffiliationCrosswalked(CrossWalkDF)
    val seq = Seq("provider_type~pulse") //need to add , "provider_speciality~pulse"
    crossRef.refDataLoader(seq)
    val legacypostref = providerCrosswalkedLegacy.withColumn("provider_type2", crossRef.crsRefLkp(lit("provider_type"), lit("pulse"), col("provider_type"))) //.withColumn("network_name2", crossRef.crsRefLkp(lit("network_name"), lit("Pulse"), col("network_name")))
    val legacyPostTransformation = legacypostref.drop("provider_type").withColumnRenamed("provider_type2", "provider_type")
    val requiredColumnsLegacy = legacyPostTransformation.select(col("uah_providerid"), col("providerid_ext_src"), col("ext_src_cd"), col("PROVIDERID").alias("providerID"), col("PRVFNAME").alias("providernameFirst"), col("PRVLNAME")
      .alias("providernameLast"), col("provider_type").alias("providerType"), col("GROUPNAM"), col("PRVTAXID").alias("provTINID"), col("PROVCODE")).withColumn("key", lit(null)).withColumn("record_status", lit("active")).
      withColumn("uah_timestamp", unix_timestamp().cast("timestamp")).withColumn("source_cd", lit("PUL"))
    //requiredColumnsLegacy.printSchema()
   // val cirrusProviderOrgAffiliationView = originalCirrusProviderOrgAffiliationView.withColumn("providerid_ext_src", lit(null)).withColumn("ext_src_cd", lit(null)).withColumn("PROVCODE", lit(null))
   // val cirrusProviderOrgAffiliationDF = sparkSession.createDataFrame(cirrusProviderOrgAffiliationView.rdd, cirrusProviderOrgAffiliationView.schema)
   // cirrusProviderOrgAffiliationDF.createOrReplaceTempView("cirrusProviderOrgAffiliationView")
   // val cirrusFinalDF = func.runSql(sparkSession, "select pProviderID as uah_providerid,providerid_ext_src,ext_src_cd,pProviderID as providerID,providernameFirst,providernameLast,providerType,GROUPNAM,provTINID,PROVCODE,key,record_status,uah_timestamp,source_cd from cirrusProviderOrgAffiliationView")
   // cirrusFinalDF.printSchema()
    val unionedDataframe = requiredColumnsLegacy.distinct()
    func.saveAsFileforDataset(unionedDataframe, "parquet", path + "/CirrusProviderorgaffiliationtinview_merge")
     path + "/CirrusProviderorgaffiliationtinview_merge"
  }
  /*DONE
   * 
   *  providerorgidProviderOrgID: String,
    GROUPCOD: String,key: String,record_status: String,uah_timestamp: String,src_cd: String
     PROVIDERID,b.LINE1,b.LINE2,b.LINE3,b.CITY,b.STATE,b.ZIP,b.COUNTY,b.ADDRESS_TYPE,b.AREA_CODE,c.LICENSING_CODE,a.FIRST_NAME,b.PHONE_NUMBER,a.LAST_NAME,a.UHC_MPIN,
    a.SOCIAL_SECURITY_NUMBER,a.FEDERAL_TAX_ID,a.PROVIDER_TYPE,a.PAR_EFFECTIVE_FROM_DATE,a.PAR_DISENROLLED_DATE,a.PAR_STATUS_TYPE,g.ADDRESS_SOURCE_TYPE,g.ADDRESS_ID ,
    d.specialty_type,d.sub_specialty1,d.sub_specialty2,d.sub_specialty3,e.national_provider_id,f.network,f.network_name,g.zip_extension
   */
  def getCirrusProviderorgidview_merge(path: String): String = {
    val sparkSession = GContext.getUAHSession("UAHCirrus")
    import sparkSession.implicits._
    //val originalCirrusProviderorgidview_std = UAHCirProvider.getCirrusProviderorgidview_std()
    val providerCrosswalkedLegacy = UAHProviderTransformLegacy.getProviderGroupAffiliationCrosswalked(CrossWalkDF)
    val requiredColumnsLegacy = providerCrosswalkedLegacy.select(col("uah_providerid"), col("providerid_ext_src"), col("ext_src_cd"), col("PROVIDERID").alias("providerID"), col("GROUPCOD")).withColumn("key", lit(null)).withColumn("record_status", lit("active")).
      withColumn("uah_timestamp", unix_timestamp().cast("timestamp")).withColumn("source_cd", lit("PUL"))
   // requiredColumnsLegacy.printSchema()
   // val cirrusProviderorgidview = originalCirrusProviderorgidview_std.alias("a").select(col("a.*")).withColumn("providerid_ext_src", lit(null)).withColumn("ext_src_cd", lit(null))
   // val cirrusProviderorgidviewDF = sparkSession.createDataFrame(cirrusProviderorgidview.rdd, cirrusProviderorgidview.schema)
   // cirrusProviderorgidviewDF.createOrReplaceTempView("cirrusProviderorgidview")
   // val cirrusFinalDF = func.runSql(sparkSession, "select providerorgidProviderOrgID as uah_providerid,providerid_ext_src,ext_src_cd,providerorgidProviderOrgID as providerID,GROUPCOD,key,record_status,uah_timestamp,source_cd from cirrusProviderorgidview")
   // cirrusFinalDF.printSchema()
    val unionedDataframe = requiredColumnsLegacy.distinct()
    func.saveAsFileforDataset(unionedDataframe, "parquet", path + "/CirrusProviderorgidview_merge")
    path + "/CirrusProviderorgidview_merge"
  }
  /*
   * transpose
   *  providerID: String,
    providerIDText: String,key: String,record_status: String,uah_timestamp: String,source_cd: String
     PROVIDERID,b.LINE1,b.LINE2,b.LINE3,b.CITY,b.STATE,b.ZIP,b.COUNTY,b.ADDRESS_TYPE,b.AREA_CODE,c.LICENSING_CODE,a.FIRST_NAME,b.PHONE_NUMBER,a.LAST_NAME,a.UHC_MPIN,
    a.SOCIAL_SECURITY_NUMBER,a.FEDERAL_TAX_ID,a.PROVIDER_TYPE,a.PAR_EFFECTIVE_FROM_DATE,a.PAR_DISENROLLED_DATE,a.PAR_STATUS_TYPE,g.ADDRESS_SOURCE_TYPE,g.ADDRESS_ID ,
    d.specialty_type,d.sub_specialty1,d.sub_specialty2,d.sub_specialty3,e.national_provider_id,f.network,f.network_name,g.zip_extension
   */
  def getCirrusproviderid_snapshotOrc_merge(path: String): String = {
    val sparkSession = GContext.getUAHSession("UAHCirrus")
    import sparkSession.implicits._
  //  val originalCirrusProviderorgidview_std = UAHCirProvider.providerid_snapshotOrc
    val providerCrosswalkedLegacy = UAHProviderTransformLegacy.getLegacyCrosswalked(CrossWalkDF)
    val requiredColumnsLegacy = providerCrosswalkedLegacy.select(col("uah_providerid"), col("providerid_ext_src"), col("ext_src_cd"), col("PROVIDERID").alias("providerID"), col("UHC_MPIN"), col("SOCIAL_SECURITY_NUMBER"), col("national_provider_id").cast("String"))
    val legacyPostTransformationFinal = toRows(requiredColumnsLegacy, Seq("uah_providerid", "providerid_ext_src", "ext_src_cd", "providerID"), "providerIDText").drop("key").withColumn("key", lit(null)).withColumn("record_status", lit("active")).
      withColumn("uah_timestamp", unix_timestamp().cast("timestamp")).withColumn("source_cd", lit("PUL"))
   // val cirrusProviderorgidview = originalCirrusProviderorgidview_std.alias("a").select(col("a.*")).withColumn("providerid_ext_src", lit(null)).withColumn("ext_src_cd", lit(null))
   // val cirrusProviderorgidviewDF = sparkSession.createDataFrame(cirrusProviderorgidview.rdd, cirrusProviderorgidview.schema)
   // cirrusProviderorgidviewDF.createOrReplaceTempView("cirrusProviderorgidview")
   // val cirrusFinalDF = func.runSql(sparkSession, "select providerID as uah_providerid,providerid_ext_src,ext_src_cd,providerID,providerIDText,key,record_status,uah_timestamp,source_cd from cirrusProviderorgidview")
     val unionedDataframe = legacyPostTransformationFinal.distinct()
    func.saveAsFileforDataset(unionedDataframe, "parquet", path + "/Cirrusproviderid_snapshotOrc_merge")
    path + "/Cirrusproviderid_snapshotOrc_merge"
  }
  /*Done
   * providerID: String,
    providerParStatusType: String,key: String,record_status: String,uah_timestamp: String,source_cd: String
     PROVIDERID,b.LINE1,b.LINE2,b.LINE3,b.CITY,b.STATE,b.ZIP,b.COUNTY,b.ADDRESS_TYPE,b.AREA_CODE,c.LICENSING_CODE,a.FIRST_NAME,b.PHONE_NUMBER,a.LAST_NAME,a.UHC_MPIN,
    a.SOCIAL_SECURITY_NUMBER,a.FEDERAL_TAX_ID,a.PROVIDER_TYPE,a.PAR_EFFECTIVE_FROM_DATE,a.PAR_DISENROLLED_DATE,a.PAR_STATUS_TYPE,g.ADDRESS_SOURCE_TYPE,g.ADDRESS_ID ,
    d.specialty_type,d.sub_specialty1,d.sub_specialty2,d.sub_specialty3,e.national_provider_id,f.network,f.network_name,g.zip_extension
   */
  def getCirrusClaimpricinginputdetailview_merge(path: String): String = {
    val sparkSession = GContext.getUAHSession("UAHCirrus")
    import sparkSession.implicits._
   // val originalCirrusProviderorgidview_std = UAHCirProvider.getCirrusClaimpricinginputdetailview_std()
    val providerCrosswalkedLegacy = UAHProviderTransformLegacy.getLegacyCrosswalked(CrossWalkDF)
    val requiredColumnsLegacy = providerCrosswalkedLegacy.select(col("uah_providerid"), col("providerid_ext_src"), col("ext_src_cd"), col("PROVIDERID").alias("providerID"), col("PAR_STATUS_TYPE").alias("providerParStatusType"), col("PAR_EFFECTIVE_FROM_DATE"), col("PAR_DISENROLLED_DATE")).withColumn("key", lit(null)).withColumn("record_status", lit("active")).
      withColumn("uah_timestamp", unix_timestamp().cast("timestamp")).withColumn("source_cd", lit("PUL"))
   // requiredColumnsLegacy.printSchema()
  //  val cirrusProviderorgidview = originalCirrusProviderorgidview_std.alias("a").select(col("a.*")).withColumn("providerid_ext_src", lit(null)).withColumn("ext_src_cd", lit(null))
  //  val cirrusProviderorgidviewDF = sparkSession.createDataFrame(cirrusProviderorgidview.rdd, cirrusProviderorgidview.schema)
   // cirrusProviderorgidviewDF.createOrReplaceTempView("cirrusProviderorgidview")
   // val cirrusFinalDF = func.runSql(sparkSession, "select providerID as uah_providerid,providerid_ext_src,ext_src_cd,providerID,providerParStatusType,'' AS PAR_EFFECTIVE_FROM_DATE,'' AS  PAR_DISENROLLED_DATE,key,record_status,uah_timestamp,source_cd from cirrusProviderorgidview")
   // cirrusFinalDF.printSchema()
    val unionedDataframe = requiredColumnsLegacy.distinct()
    func.saveAsFileforDataset(unionedDataframe, "parquet", path + "/CirrusClaimpricinginputdetailview_merge")
    path + "/CirrusClaimpricinginputdetailview_merge"
  }
  /*Done
   * taxonomyclass: String,
    providerID: String,key: String,record_status: String,uah_timestamp: String,source_cd: String
     PROVIDERID,b.LINE1,b.LINE2,b.LINE3,b.CITY,b.STATE,b.ZIP,b.COUNTY,b.ADDRESS_TYPE,b.AREA_CODE,c.LICENSING_CODE,a.FIRST_NAME,b.PHONE_NUMBER,a.LAST_NAME,a.UHC_MPIN,
    a.SOCIAL_SECURITY_NUMBER,a.FEDERAL_TAX_ID,a.PROVIDER_TYPE,a.PAR_EFFECTIVE_FROM_DATE,a.PAR_DISENROLLED_DATE,a.PAR_STATUS_TYPE,g.ADDRESS_SOURCE_TYPE,g.ADDRESS_ID ,
    d.specialty_type,d.sub_specialty1,d.sub_specialty2,d.sub_specialty3,e.national_provider_id,f.network,f.network_name,g.zip_extension
   */
  def getCirrusTaxonomycode_snapshotmerge(path: String): String = {
    val sparkSession = GContext.getUAHSession("UAHCirrus")
    import sparkSession.implicits._
   // val originalCirrusProviderorgidview_std = UAHCirProvider.getCirrusTaxonomycode_snapshotorc()
    val providerCrosswalkedLegacy = UAHProviderTransformLegacy.getLegacyCrosswalked(CrossWalkDF)
    val seq = Seq("speciality_type~pulse") //need to add , "provider_speciality~pulse"
    crossRef.refDataLoader(seq)
    var legacypostref = providerCrosswalkedLegacy.withColumn("specialty_type22", crossRef.crsRefLkp(lit("specialty_type"), lit("pulse"), col("specialty_type")))
      .withColumn("specialty_type33", crossRef.crsRefLkp(lit("specialty_type"), lit("pulse"), col("sub_specialty1")))
      .withColumn("specialty_type44", crossRef.crsRefLkp(lit("specialty_type"), lit("pulse"), col("sub_specialty2")))
      .withColumn("specialty_type55", crossRef.crsRefLkp(lit("specialty_type"), lit("pulse"), col("sub_specialty3")))
    val legacyPostTransformation1 = legacypostref.drop("specialty_type", "sub_specialty1", "sub_specialty2", "sub_specialty3").withColumnRenamed("specialty_type22", "specialty_type")
      .withColumnRenamed("specialty_type33", "sub_specialty1")
      .withColumnRenamed("specialty_type44", "sub_specialty2")
      .withColumnRenamed("specialty_type55", "sub_specialty3")
    val legacyPostTransformation2 = legacyPostTransformation1.select(col("uah_providerid"), col("providerid_ext_src"), col("ext_src_cd"), col("specialty_type"), col("PROVIDERID").alias("providerID"), col("specialty_type"),col("sub_specialty1"), col("sub_specialty2"), col("sub_specialty3"))
    val legacyPostTransformationFinal = toRows(legacyPostTransformation2, Seq("uah_providerid", "providerid_ext_src", "ext_src_cd", "providerID"), "taxonomyclass").drop("key").withColumn("key", lit(null)).withColumn("record_status", lit("active")).
      withColumn("uah_timestamp", unix_timestamp().cast("timestamp")).withColumn("source_cd", lit("PUL"))
 //   val cirrusProviderorgidview = originalCirrusProviderorgidview_std.alias("a").select(col("a.*")).withColumn("providerid_ext_src", lit(null)).withColumn("ext_src_cd", lit(null))
  //  val cirrusProviderorgidviewDF = sparkSession.createDataFrame(cirrusProviderorgidview.rdd, cirrusProviderorgidview.schema)
   // cirrusProviderorgidviewDF.createOrReplaceTempView("cirrusProviderorgidview")
  //  val cirrusFinalDF = func.runSql(sparkSession, "select providerID as uah_providerid,providerid_ext_src,ext_src_cd, providerID,taxonomyclass,key,record_status,uah_timestamp,source_cd from cirrusProviderorgidview")
    val unionedDataframe = legacyPostTransformationFinal.distinct()
    func.saveAsFileforDataset(unionedDataframe, "parquet", path + "/CirrusTaxonomycode_snapshot_merge")
    path + "/CirrusTaxonomycode_snapshot_merge"
  }
  /*
   * D
   * networkname: String,
    providerID: String,key: String,record_status: String,uah_timestamp: String,src_cd: String
    PROVIDERID,b.LINE1,b.LINE2,b.LINE3,b.CITY,b.STATE,b.ZIP,b.COUNTY,b.ADDRESS_TYPE,b.AREA_CODE,c.LICENSING_CODE,a.FIRST_NAME,b.PHONE_NUMBER,a.LAST_NAME,a.UHC_MPIN,
    a.SOCIAL_SECURITY_NUMBER,a.FEDERAL_TAX_ID,a.PROVIDER_TYPE,a.PAR_EFFECTIVE_FROM_DATE,a.PAR_DISENROLLED_DATE,a.PAR_STATUS_TYPE,g.ADDRESS_SOURCE_TYPE,g.ADDRESS_ID ,
    d.specialty_type,d.sub_specialty1,d.sub_specialty2,d.sub_specialty3,e.national_provider_id,f.network,f.network_name,g.zip_extension,provider_network~pulse 
 se
   */
  def getCirrusNetworkidquerysrchview_merge(path: String): String = {
    val sparkSession = GContext.getUAHSession("UAHCirrus")
    import sparkSession.implicits._
    //val originalCirrusNetcontractnetworkview_std = UAHCirProvider.getCirrusNetworkidquerysrchview_std()
    val providerCrosswalkedLegacy = UAHProviderTransformLegacy.getLegacyCrosswalked(CrossWalkDF)
    //UAHProviderTransformLegacy.getNetworkCrosswalked(providerCrosswalkedLegacy, NetworkCrosswalk.getNetworkCrosswalk())
    val seq = Seq("provider_network~pulse") //need to add , "provider_speciality~pulse"
    crossRef.refDataLoader(seq)
    val legacypostref = providerCrosswalkedLegacy.withColumn("network_name2", crossRef.crsRefLkp(lit("network_name"), lit("pulse"), col("network_name"))) //.withColumn("network_name2", crossRef.crsRefLkp(lit("network_name"), lit("Pulse"), col("network_name")))
    val legacyPostTransformation = legacypostref.drop("network_name").withColumnRenamed("network_name2", "network_name")
    val requiredColumnsLegacy = legacyPostTransformation.select(col("uah_providerid"), col("providerid_ext_src"), col("ext_src_cd"), col("PROVIDERID").alias("providerID"), col("network").alias("networkId"), col("network_name").alias("provider_network")).withColumn("key", lit(null)).withColumn("record_status", lit("active")).
      withColumn("uah_timestamp", unix_timestamp().cast("timestamp")).withColumn("source_cd", lit("PUL"))
   // requiredColumnsLegacy.printSchema()
  //  val cirrusNetcontractnetworkview = originalCirrusNetcontractnetworkview_std.alias("a").select(col("a.*")).withColumn("providerid_ext_src", lit(null)).withColumn("ext_src_cd", lit(null))
   // val cirrusNetcontractnetworkviewDF = sparkSession.createDataFrame(cirrusNetcontractnetworkview.rdd, cirrusNetcontractnetworkview.schema)
   // cirrusNetcontractnetworkviewDF.createOrReplaceTempView("cirrusNetcontractnetworkview")
   // val cirrusFinalDF = func.runSql(sparkSession, "select providerID as uah_providerid,providerid_ext_src,ext_src_cd,providerID,networkId,provider_network,key,record_status,uah_timestamp,source_cd from cirrusNetcontractnetworkview")
    //cirrusFinalDF.printSchema()
    val unionedDataframe = requiredColumnsLegacy.distinct()
    func.saveAsFileforDataset(unionedDataframe, "parquet", path + "/CirrusNetworkidquerysrchview_merge")
    path + "/CirrusNetworkidquerysrchview_merge"
  }

  def toRows(df: DataFrame, by: Seq[String], columnName: String): DataFrame = {
    val sparkSession = GContext.getUAHSession("UAHCirrus")
    import sparkSession.implicits._
    val (cols, types) = df.dtypes.filter { case (c, _) => !by.contains(c) }.unzip
    val kvs = explode(array(cols.map(c => struct(lit(c).alias("key"), col(c).alias(columnName))): _*))
    val byExprs = by.map(col(_))
    df.select(byExprs :+ kvs.alias("_kvs"): _*).select(byExprs ++ Seq(col("_kvs.key"), col("_kvs." + columnName)): _*) //$"_kvs.key",
  }

}