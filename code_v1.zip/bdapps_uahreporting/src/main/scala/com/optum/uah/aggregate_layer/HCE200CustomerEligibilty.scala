package com.optum.uah.aggregate_layer
import com.optum.uah.function_library.GlobalContext
import com.optum.uah.function_library.CommonFunctions
import com.optum.uah.function_library.ReadJson
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.SparkSession
import java.io.IOException
import org.apache.spark.SparkContext
import org.apache.spark.sql.functions.{ array, col, explode, lit, struct, unix_timestamp, concat_ws }

/**
* @author TeamTitan
*/
object HCE200CustomerEligibilty {
  val gContext = new GlobalContext()
  val func = new CommonFunctions()

  val sparkSession = gContext.getUAHSession("CustomerEligibilty")

  def main(args: Array[String]): Unit = {

    val length = 3;
    if (args.length != length) {
      throw new IOException("Arguments mismatch! Expected arguments are : " + length + " , But actual arguments are : " + args.length);
    }

    //Loading json
    ReadJson.createJsonObject(args(0).trim());
    val opPath = args(1).trim();
    val tableName = args(2).trim();
    //val aggrDB = sparkSession.conf.get("spark.database.uah.aggregate")
    val mergeDB = sparkSession.conf.get("spark.database.uah.merge")

    //Created dataframes based on the sqls mentioned in json.
    val memgroupcontractview_stdDF = this.getDataFrame(sparkSession, "memgroupcontractview_std", mergeDB)
    val memgroupid_stdDF = this.getDataFrame(sparkSession, "memgroupid_std", mergeDB)
    //val memGroupContractPlanOptExtview_stdDF = this.getDataFrame(sparkSession, "memGroupContractPlanOptExtview_std", mergeDB)
	  val memGroupContractPlanOptionView_stdDF = this.getDataFrame(sparkSession, "memgroupcontractplanoptionview_std", mergeDB)
    val memgroupcontractrenewal_viewDF = this.getDataFrame(sparkSession, "memgroupcontractrenewal_view", mergeDB)
    val product_codeDF = this.getDataFrame(sparkSession, "product_code", mergeDB)
    val aggrCustomerEligDF = this.aggCustomerElig(memgroupid_stdDF, memgroupcontractview_stdDF, memGroupContractPlanOptionView_stdDF, memgroupcontractrenewal_viewDF, product_codeDF)
    aggrCustomerEligDF.printSchema()
    func.writeToParquet(aggrCustomerEligDF.distinct(), opPath)
    //func.createExternalTableFromParquet(sparkSession, opPath, tableName, aggrDB)
    
  }

  /**
   * aggCustomer function reads the source dataframes as inputs arguments and do the necessary joins/aggregations and returns final aggregated dataframe.
   */
  def aggCustomerElig(memgroupid_stdDF: DataFrame, memgroupcontractview_stdDF: DataFrame, memGroupContractPlanOptionView_stdDF: DataFrame, memgroupcontractrenewal_viewDF: DataFrame, product_codeDF: DataFrame): DataFrame = {
         
    
    //Left Join memgroupid_stdDF with memgroupcontractview_stdDF
    val contractview_joinDF = memgroupid_stdDF.join(memgroupcontractview_stdDF, memgroupid_stdDF.col("source_memgroupid").equalTo(memgroupcontractview_stdDF.col("source_memgroupgid")), "inner").drop(memgroupcontractview_stdDF.col("source_memgroupgid"))
    
    //adding memGroupContractPlanOptionView_stdDF
    val contractPlanOptExtview_joinDF = contractview_joinDF.join(memGroupContractPlanOptionView_stdDF, contractview_joinDF.col("source_memgroupid").equalTo(memGroupContractPlanOptionView_stdDF.col("source_memgroupid")), "inner").drop(memGroupContractPlanOptionView_stdDF.col("source_memgroupid")).drop(memGroupContractPlanOptionView_stdDF.col("uah_memgroupid"))
    contractPlanOptExtview_joinDF.show()

    //adding memgroupcontractrenewal_viewDF
    val contractrenewal_joinDF = contractPlanOptExtview_joinDF.join(memgroupcontractrenewal_viewDF, contractPlanOptExtview_joinDF.col("source_memgroupid").equalTo(memgroupcontractrenewal_viewDF.col("source_memgroupid")), "inner").drop(memgroupcontractrenewal_viewDF.col("source_memgroupid")).dropDuplicates()

    //adding product_codeDF
     product_codeDF.createOrReplaceTempView("productcode_view")
     val RankDF=sparkSession.sql("select *, ROW_NUMBER() OVER (PARTITION BY memgroupid, memgroupcontractid, memgroupcontractoptid, memgroupcontractplanoptionid ORDER BY memgroupcontractopteffectivedate, planversion DESC) as RNK from productcode_view")
     RankDF.createOrReplaceTempView("RankDF")
   //  val productcode_ViewDF = sparkSession.sql("select memgroupid, memgroupcontractoptid, memgroupcontractplanoptionid, memgroupcontractid, benefitbundleid, benefitbundleoptionid, benefitbundleplanplanid, productid, gatedind, ehbind, fundingsource, carriername, lobname, networkscheduleid, cmspct, situsstate, ucrpercentile from RankDF where RNK = '1'")
//removing memgroupcontractid
     //adding uah_memgroupcontractplanoptionid, uah_memgroupcontractoptid,source_memgroupcontractoptid,source_memgroupcontractplanoptionid

     val productcode_ViewDF = sparkSession.sql("select memgroupid, memgroupcontractoptid, memgroupcontractplanoptionid, benefitbundleid, benefitbundleoptionid, benefitbundleplanplanid, productid, gatedind, ehbind, fundingsource, carriername, lobname, networkscheduleid, cmspct, situsstate, ucrpercentile from RankDF where RNK = '1'")
    // val Final_joinDf = contractrenewal_joinDF.join(productcode_ViewDF, contractrenewal_joinDF.col("source_memgroupid") === productcode_ViewDF.col("memgroupid") && contractrenewal_joinDF.col("source_memgroupcontractoptid") === productcode_ViewDF.col("memgroupcontractoptid") && contractrenewal_joinDF.col("source_memgroupcontractplanoptionid") === productcode_ViewDF.col("memgroupcontractplanoptionid"), "inner").drop(productcode_ViewDF.col("memgroupid")).drop(productcode_ViewDF.col("memgroupcontractplanoptionid")).drop(productcode_ViewDF.col("memgroupcontractoptid")).dropDuplicates()
       val Final_joinDf = contractrenewal_joinDF.join(productcode_ViewDF, contractrenewal_joinDF.col("source_memgroupid") === productcode_ViewDF.col("memgroupid") && contractrenewal_joinDF.col("source_memgroupcontractoptid") === productcode_ViewDF.col("memgroupcontractoptid") && contractrenewal_joinDF.col("source_memgroupcontractplanoptionid") === productcode_ViewDF.col("memgroupcontractplanoptionid"), "inner").drop(productcode_ViewDF.col("memgroupid")).drop(productcode_ViewDF.col("memgroupcontractplanoptionid")).drop(productcode_ViewDF.col("memgroupcontractoptid")).drop(contractrenewal_joinDF.col("source_memgroupcontractplanoptionid")).drop(contractrenewal_joinDF.col("source_memgroupcontractoptid")).drop(contractrenewal_joinDF.col("source_memgroupcontractid")).dropDuplicates()
	Final_joinDf
  }

  /**
   * getDataFram returns a DataFrame by using SparkSession and json propertyKey as inputs
   */
  def getDataFrame(sparkSession: SparkSession, propertyKey: String, mergeDB: String): DataFrame = {
    sparkSession.sql("use " + mergeDB);
    func.runSql(sparkSession, ReadJson.getProperty(propertyKey))
  }

}
