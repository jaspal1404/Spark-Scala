package com.optum.uah.merge_layer.broker

import com.optum.uah.function_library.{ CommonFunctions, GlobalContext, ReadJson }
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.DataFrame

object BrokerCroswalk {
  val GContext = new GlobalContext()
  val func = new CommonFunctions()

  def loadBrokerLookup(): DataFrame = {
    val sparkSession = GContext.getRnASession("BrokerRnA")
    import sparkSession.implicits._

    //val networkidquerysrchview_std = func.runSql(sparkSession, "select trim(networkdesc) as networkdesc,networknetworkID,networkidoriginalsourcesystemid,cast(trim(run_id) as decimal) as run_id,cast(trim(load_timestamp) as date) as load_timestamp,trim(record_status) as record_status,trim(key) as key from RNACIRRUSDB.networkidquerysrchview_std where trim(networkidoriginalsourcesystemtype) = 'PUL'")
    val cirrusBroker = func.runSql(sparkSession, ReadJson.getProperty("cirrusBroker"))
    //val brokerMig = cirrusBroker.filter(trim(col("Producer_Type")) === 1)
    //val cirrusBroker = func.runSql(sparkSession,"select producerID as Cirrus_Producer_Identifier,cast(trim(run_id) as decimal) as run_id,from_unixtime( unix_timestamp(load_timestamp )) as load_timestamp,trim(record_status) as record_status,trim(key) as key,originalSourceSystemID as Source_Producer_Identifier,'1' as Producer_Type from RNACIRRUSDB.producerexternalid_view where trim(originalSourceSystemtype) = 'PUL'")

    val brokerDedup = Window.partitionBy('key).orderBy('load_timestamp.desc, 'run_id.desc)
    val seqNumber = Window.orderBy('key)

    val uniqBroker = cirrusBroker.withColumn("row", rank().over(brokerDedup)).filter('row === 1).drop("row")
    uniqBroker.withColumn("Producer_lookup_Identifier", row_number().over(seqNumber)).withColumn("row_timestamp", from_unixtime(unix_timestamp())).withColumn("Source_code", lit("PUL")).withColumn("active_flag", lit("Active"))

  }
  def main(args: Array[String]): Unit = {
    val path = args(0) + "/broker_lookup_std"
    val propFilePath = args(1)
    ReadJson.createJsonObject(propFilePath)

    val columns = Seq("Producer_lookup_Identifier", "Producer_Type", "Cirrus_Producer_Identifier", "Source_Producer_Identifier", "Row_Timestamp", "Source_code", "active_flag")

    val finalcrossWalk = loadBrokerLookup().select(columns.map(c => col(c)): _*)

    val sparkSession = GContext.getUAHSession("tempTable")
     func.saveDataframeAsFile(finalcrossWalk, path, "overwrite")
   // func.createExternalTableFromParquet(sparkSession, path, "broker_lookup_std", sparkSession.conf.get("spark.database.uah.merge"))

    GContext.stop()
  }

} 