package com.optum.uah.merge_layer.provider
import com.optum.uah.function_library.{CommonFunctions, GlobalContext, ReadJson }
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

/** <h1>ProviderCrosswalk</h1>
  * ProviderCrosswalk has the logic  to union two tables providermdm_orgorc and providermdm_proforc  which has ProviderMDM LTK and pulse providerID
  * <p>
  * Now this ProviderMDM LTK is present in cirrus table so we look up the cirrus tables and finally build a crosswalk that has ProviderMDM LTK, cirrusProviderId and pulse providerId
  * @author  dbhatta3
  * @version 1.0
  */
object ProviderCrosswalk {
  val GContext = new GlobalContext()
  val func = new CommonFunctions()

  def main(args: Array[String]): Unit = {
	  
	val propFilePath = args(1)    
    //Load json property file to get sql based on the subject area and table
    ReadJson.createJsonObject(propFilePath)
    println("Properties file location"+propFilePath)
    val sparkSession = GContext.getUAHSession("ProviderUAH")
	
	  val path = args(0) +"/provider_lookup_std"
    val provider_snapshot_view = getProviderCrosswalk()
    func.saveDataframeAsFile(provider_snapshot_view, path, "overwrite")
	
   // func.createExternalTableFromParquet(sparkSession, path, "provider_lookup_std", sparkSession.conf.get("spark.database.uah.merge"))
	
  }

  def getProviderCrosswalk(): DataFrame= {
    
    val sparkSession = GContext.getRnASession("ProviderRnA")
     import sparkSession.implicits._
    val unionMDMData = getProviderMDMUnion()
    val provider_snapshot_view = func.runSql(sparkSession, ReadJson.getProperty("provider_snapshot_view_crosswalk"))
     unionMDMData.join(provider_snapshot_view, Seq("MDMLTKProviderIdentifier"),"inner").withColumn("rowTimestamp",unix_timestamp().cast("timestamp")).
     withColumn("sourceCode", lit("PUL")).withColumn("activeFlag", lit("Y"))
  }

  def getProviderMDMUnion(): DataFrame = {
    val sparkSession = GContext.getRnASession("ProviderRnA")
    import sparkSession.implicits._
    val providermdm_orgorc = func.runSql(sparkSession, ReadJson.getProperty("providermdm_orgorc_xw"))
    val providermdm_proforc = func.runSql(sparkSession, ReadJson.getProperty("providermdm_proforc_xw"))
    val providerMDMUnion_std = providermdm_orgorc.union(providermdm_proforc).distinct()
    providerMDMUnion_std
  }

}
