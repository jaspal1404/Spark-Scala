
package com.optum.uah.aggregate_layer
import java.io.File

import com.optum.uah.function_library.Logger.log
import com.optum.uah.function_library.{CommonFunctions, GlobalContext, ReadJson}
import org.apache.commons.io.FileUtils


object HceMember {
  def main(args: Array[String]): Unit = {
    //Spark submit shell path: /mapr/datalake/optum/optuminsight/d_uah/dev/d_scripts/UAH_HCE_Extract_OptumRx.sh
    //    val srcLoc = args(0)
    val subjArea = args(0)
    //    val tgtLoc = args(2)
    val propFilePath = args(1)
    val aggrLoc = args(2)

    //Extract SQL and execute Spark SQL; Store the data in a data frame
    ///mapr/datalake/optum/optuminsight/d_uah/dev/d_scripts/properties/memberProperties.json
    ReadJson.createJsonObject(propFilePath)
    val extractSql = ReadJson.getProperty(subjArea)

    val GContext = new GlobalContext()
    val sparkSession = GContext.getUAHSession("MemberUAHAggregate")
    val CommonFunctions = new CommonFunctions()
    val extractDf = CommonFunctions.runSql(sparkSession, extractSql)

    //Write the output of the data frame as a Parquet file in aggregate layer and as a text file in outbound location
    //Load strategy: Truncate/Load
    //Aggregate layer path: /mapr/datalake/optum/optuminsight/d_uah/dev/d_hdfs/aggregate_layer/hce/member
    //outbound folder path: /mapr/datalake/optum/optuminsight/d_uah/dev/d_outbound/hceExtracts/member
    FileUtils.deleteDirectory(new File("/mapr/"+aggrLoc))
    //    FileUtils.deleteDirectory(new File("/mapr/"+tgtLoc))

    CommonFunctions.saveDataframeAsFile(extractDf,aggrLoc,"overwrite") //this is for writing the Parquet File. VALIDATE THIS.
    //    extractDf.rdd.repartition(1).map(x => x.mkString("|")).saveAsTextFile(tgtLoc) //       /u0001 - suggested
  }

}
