package com.optum.uah.merge_layer.membereligibility

import com.optum.uah.function_library.{CommonFunctions, GlobalContext, ReadJson}
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql.functions.row_number
import org.apache.spark.sql.expressions.Window
import org.apache.commons.io.FileUtils
import java.io.File
import org.apache.spark.sql


/**
  * Created by kgoje on 11/2/2017.
  * Modified by psahota on 11/4/2017.
  */
object UahGroupContractLookUp {


  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .enableHiveSupport()
      .getOrCreate()
    import spark.implicits._
    val GlobalContext = new GlobalContext()
    val CommonFunctions = new CommonFunctions()
    val tgtLoc =  args(0)
    val propFilePath = args(1)
    val tblName = tgtLoc.split("mergelayer/")(1)
    val tblName_legacy = tgtLoc.split("mergelayer/")(1)+"_cdw"
    //val dbName = args(2)
    val workingDir =  tgtLoc.split("/"+tblName).head+ "/working/" +  tblName
    FileUtils.deleteDirectory(new File("/mapr"+tgtLoc))
    var sparkSession = GlobalContext.getRnASession("MemberUAH")
    ReadJson.createJsonObject(propFilePath)
    val cirrus_df = CommonFunctions.runSql(sparkSession,ReadJson.getProperty(tblName))
    //val cirrus_query="select memgroupexternalid.memgroupid as memGroupID, memgroupexternalid.originalsourcesystemid as Source_GroupID, memgroupcontract.memgroupcontractid as memGroupContractID,FROM_UNIXTIME(UNIX_TIMESTAMP(), 'yyyy-MM-dd HH:mm:ss:SSS') as Row_Timestamp, 'PUL' as Source_Code,'A' as Active_Flag from uhc_pfv_tst.memgroupexternalid_view memgroupexternalid join uhc_pfv_tst.memgroupcontract_view memgroupcontract on memgroupexternalid.memgroupid = memgroupcontract.memgroupid"
    //val cirrus_df = CommonFunctions.runSql(sparkSession,cirrus_query)
    sparkSession = GlobalContext.getUAHSession("MemberUAH")
    //val cdw_query="select contract_id as Source_ContractID , group_code from uah_cdw_prod.uah_cdw_dss_i_contract"
    //val legacy_df = CommonFunctions.runSql(sparkSession,cdw_query)
    val legacy_df = CommonFunctions.runSql(sparkSession,ReadJson.getProperty(tblName_legacy))
    val result_df = cirrus_df.join(legacy_df, cirrus_df("source_groupid") === legacy_df("group_code") ).withColumn("groupcontract_lookup_identifier", row_number.over(Window.orderBy(col("memgroupid"))))
    //val final_df=result_df.drop("group_code")
    val final_df=result_df.withColumn("groupcontract_lookup_identifier", $"groupcontract_lookup_identifier".cast(sql.types.StringType)).drop("group_code")
    CommonFunctions.saveDataframeAsFile(final_df,tgtLoc+"/source_cd=PUL","overwrite") //this is for writing the Parquet File
  }

}
