package com.optum.uah.aggregate_layer

import com.optum.uah.function_library.{ CommonFunctions, GlobalContext, ReadJson }
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import com.optum.uah.function_library.Logger.log

/**
 * Created by rgupta59 on 09/14/2017.
  * Updated by dp1009 on 10/24/2017*
 */
object MemberAddressReport {
  val GContext = new GlobalContext()
  val func = new CommonFunctions()

  //Member Address Report
  def getmemeberAddressReport(sparkSession: SparkSession, path: String, tableName: String) {
    val memberBenefitDf = func.runSql(sparkSession, ReadJson.getProperty("memberbenefit"))
    println("memberBenefitDf ==> "+memberBenefitDf.count())
    val memberDemographicDf = func.runSql(sparkSession, ReadJson.getProperty("memberdemographic"))
    println("memberDemographicDf ==> "+memberDemographicDf.count())
    val subsaffiliationDf = func.runSql(sparkSession, ReadJson.getProperty("subsaffiliation"))
    println("subsaffiliationDf ==> "+subsaffiliationDf.count())
    val memberBenefitCovLevelCodeDf = func.runSql(sparkSession, ReadJson.getProperty("memberbenefitcovlevelcode"))
    println("memberBenefitCovLevelCodeDf ==> "+memberBenefitCovLevelCodeDf.count())
    memberBenefitCovLevelCodeDf.createOrReplaceTempView("benefitcoverage")
    val memBenefitCovEffDateDf = func.runSql(sparkSession, ReadJson.getProperty("membenefitcoveffdate"))
    println("memBenefitCovEffDateDf ==> "+memBenefitCovEffDateDf.count())
    val billingschedviewDf = func.runSql(sparkSession, ReadJson.getProperty("billingsched"))
    println("billingschedviewDf ==> "+billingschedviewDf.count())
    val memGroupContractPlanOptExtviewDf = func.runSql(sparkSession, ReadJson.getProperty("memgroupcontractplanoptextview"))
    println("memGroupContractPlanOptExtviewDf ==> "+memGroupContractPlanOptExtviewDf.count())
    val memgroupcontractviewDf = func.runSql(sparkSession, ReadJson.getProperty("memgroupcontractview"))
    println("memgroupcontractviewDf ==> "+memgroupcontractviewDf.count())
    val memgroupcontractplanoptionviewDf = func.runSql(sparkSession, ReadJson.getProperty("memgroupcontractplanoptionview"))
    println("memgroupcontractplanoptionviewDf ==> "+memgroupcontractplanoptionviewDf.count())
    val memgroupcontractplanattrsetvwDf = func.runSql(sparkSession, ReadJson.getProperty("memgroupcontractplanattrsetvw"))
    println("memgroupcontractplanattrsetvwDf ==> "+memgroupcontractplanattrsetvwDf.count())
    import sparkSession.implicits._
    
    
    
    val memeberAddressReportJoin = memberBenefitDf.join(memberDemographicDf, Seq("uah_memberid","uah_memgroupid"), "inner")
    .join(memgroupcontractplanoptionviewDf, Seq("uah_memgroupid","memgroupcontractplanoptionid","memgroupcontractoptid"), "inner")
    .join(subsaffiliationDf, Seq("uah_memberid","uah_memgroupid"), "inner")
    .join(memBenefitCovEffDateDf, Seq("uah_memberid"), "inner")
    .join(billingschedviewDf, Seq("uah_memgroupid"), "inner")
    .join(memGroupContractPlanOptExtviewDf, Seq("uah_memgroupid","memgroupcontractplanoptionid","memgroupcontractoptid"), "left_outer")
    .join(memgroupcontractviewDf, Seq("uah_memgroupid"), "inner")
    .join(memgroupcontractplanattrsetvwDf, Seq("uah_memgroupid"), "inner").filter("uah_memgroupid is not null").dropDuplicates()

    
    log.info("Final dataframe Schema + " + memeberAddressReportJoin.printSchema())

    //Casting to Date

    val memeberAddressReport = memeberAddressReportJoin.withColumn("birthdate", col("birthdate").cast("date"))
      .withColumn("effectivedate", col("effectivedate").cast("date"))
      .withColumn("expirationdate", col("expirationdate").cast("date"))
      .withColumn("memgroupcontractoptexpirationdate", col("memgroupcontractoptexpirationdate").cast("date"))
      .withColumn("benplanexpdate", col("benplanexpdate").cast("date"))
      .withColumn("benplaneffdate", col("benplaneffdate").cast("date")).dropDuplicates()

    log.info("Final dataframe Schema + " + memeberAddressReport.printSchema())

    func.saveAsFileWithPartition(memeberAddressReport, "parquet", path, "uah_memgroupid")
    //func.createExternalTableFromParquetWithPartition(sparkSession, path, tableName, database, "uah_memgroupid", "String")

    //func.saveDataframeAsFile(memeberAddressReport, path, "overwrite")
    //func.createExternalTableFromParquet(sparkSession, path, tableName, database)
    sparkSession.close()  
  }

  def main(args: Array[String]): Unit = {

    if (args.length < 3) {

      println("Usage :::" + "Jar_name  Target_Location  Json_Path Target_DatabaseName")
      println("Usage :::" + "Jar_name  Target_Location  Json_Path Target_DatabaseName")

    } else {
      val sparkSession = GContext.getUAHSession("MARAggregate")
      
      val tgtLoc = args(0)
      println("Target loaction ::: " + tgtLoc)
      val tblName = args(1)
      println("Table Name :::" + tblName)
      val propFilePath = args(2)
   //   val database = sparkSession.conf.get("spark.database.uah.aggregate")
     // log.info("Database name is :::" + database)
 
      ReadJson.createJsonObject(propFilePath)
      val benefitsDeductibleDS = getmemeberAddressReport(sparkSession, tgtLoc, tblName)
    }
    GContext.stop()

  }

}
