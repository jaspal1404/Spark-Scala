package com.optum.uah.aggregate_layer
import java.time.LocalDate

import org.apache.spark.sql.functions._
import com.optum.uah.function_library.Logger.log
import com.optum.uah.function_library.{CommonFunctions, GlobalContext, ReadJson}
import org.apache.spark.sql.SparkSession
import org.apache.commons.io.FileUtils
import java.io.File


object HceMemberEligibility {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .enableHiveSupport()
      .getOrCreate()
    import spark.implicits._

    val subjArea = args(0)
    val propFilePath = args(1)
    val aggrLoc = args(2)
    val grpByCols = args(3)
    val orderByCols = args(4)
    val GlobalContext = new GlobalContext()
    val CommonFunctions = new CommonFunctions()
    val sparkSession = GlobalContext.getUAHSession("MemberUAHAggregate")
    //    val rJson = new ReadJson(propFilePath)
    ReadJson.createJsonObject(propFilePath)
    ReadJson.getProperty(subjArea)
    val extractSql = ReadJson.getProperty(subjArea)

    //    val fields = temp.split(',')

    //    # Array(memberid, address1, address2, city, state, postalcode, countyfipsdesc, birthDate, namefirst, phone, namelast, gender, memberExternalID)

    val mergeDf = CommonFunctions.runSql(sparkSession,extractSql)
    val reqDate = LocalDate.now().plusYears(-3).toString()
    val extractDf = mergeDf.filter($"benplaneffdate" > reqDate)

    val finalDf = CommonFunctions.dedupLogic(extractDf, grpByCols, orderByCols)

    FileUtils.deleteDirectory(new File("/mapr/"+aggrLoc))
    //FileUtils.deleteDirectory(new File("/mapr/"+tgtLoc))

    //extractDf.rdd.repartition(1).map(x => x.mkString("|")).saveAsTextFile(tgtLoc) //       /u0001 - suggested
    CommonFunctions.saveDataframeAsFile(finalDf,aggrLoc,"overwrite") //this is for writing the Parquet File
  }
}

