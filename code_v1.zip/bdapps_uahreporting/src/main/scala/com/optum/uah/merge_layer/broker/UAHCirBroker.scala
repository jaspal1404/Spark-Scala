package com.optum.uah.merge_layer.broker

import com.optum.uah.function_library.{ CommonFunctions, GlobalContext, ReadJson }
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.DataFrame
import com.optum.uah.function_library.Logger.log
import org.apache.spark.sql.functions._
import com.optum.uah.function_library.GlobalContext
import com.optum.uah.function_library.ReadJson
import com.optum.uah.function_library.CommonFunctions
import org.apache.spark.sql.types.StringType

/**
 * <h1>Broker</h1>
 * Broker has the logic to create data sets for HCE200 Broker attributes. This has implementation for
 * both cirrus and legacy.The legacy tables are from medmart. The required api's are exposed through @class shared_views
 * <p>
 * Also have the class definations for Broker, ProviderAddress etc
 * @author  dbhatta3
 * @version 1.0
 */

object UAHCirBroker {

  /* Initializing Context and config reading*/
  /* the variable GContext.runHome build from environment variable UAH_RUNTIME
  * that you should populate from you Spark submit script
  * like: //
  *
  * export UAH_RUNTIME=/datalake/optum/optuminsight/d_uah/dev/developer/debraj
  * */

  val GContext = new GlobalContext()
  val func = new CommonFunctions()

  //ReadJson.createJsonObject(GContext.runHome + "/hce200Broker.json")

  /* Defining  the main entry for a Spark submit . We normally use it for testing  */

  def main(args: Array[String]): Unit = {

    val propFilePath = args(1)
    //Load json property file to get sql based on the subject area and table
    ReadJson.createJsonObject(propFilePath)
    println("Properties file location" + propFilePath)
    val sparkSession = GContext.getUAHSession("BrokerUAH")
  /*  sparkSession.sql("set spark.sql.parquet.useDataSourceApi=false")
    sparkSession.sql("set spark.sql.hive.convertMetastoreParquet=false")*/

    val path1 = getCirrusBrokerAddressView_std(args)
    func.createExternalTableFromParquet(sparkSession, path1, "produceraddressview_std", sparkSession.conf.get("spark.database.uah.merge"))

    val path2 = getCirrusBrokermemGroupContract_std(args)
    func.createExternalTableFromParquet(sparkSession, path2, "memgroupcontractproducerview_std", sparkSession.conf.get("spark.database.uah.merge"))

    val path3 = getproducerexternalid_view(args)
    func.createExternalTableFromParquet(sparkSession, path3, "producerexternalid_view", sparkSession.conf.get("spark.database.uah.merge"))

  }

  def getCirrusBrokerAddressView_std(args: Array[String]): String = {
    val sparkSession = GContext.getRnASession("BrokerRnA")
    var brokerAddressDataFrame: DataFrame = sparkSession.emptyDataFrame
    var tableName = "produceraddressview_std"
    brokerAddressDataFrame = func.runSql(sparkSession, ReadJson.getProperty("produceraddressview_std"))
    val brokerAddressDataFrame_union = brokerAddressDataFrame.withColumn("uah_brokerid", brokerAddressDataFrame.col("prodProducerID"))
    //.withColumn("brokerid_ext_src", lit(null).cast(StringType)).withColumn("ext_src_cd", lit(null).cast(StringType))
    var path = args(0) + "/produceraddressview_std" + "/source_cd=CRS"
    var returnMaxTS: String = ""
    brokerAddressDataFrame = func.incrDataLoad(tableName, brokerAddressDataFrame_union, path, sparkSession)

    if (brokerAddressDataFrame.count.!=(0)) {
      var newmaxLoadTimestamp = brokerAddressDataFrame.agg(max("uah_timestamp")).first()(0).toString
      println("new max load timestamp" + newmaxLoadTimestamp)
      func.updateHbaseMrglayerTs(tableName, newmaxLoadTimestamp)
    }
    path
  }

  def getCirrusBrokermemGroupContract_std(args: Array[String]): String = {
    val sparkSession = GContext.getRnASession("BrokerRnA")
    var brokerMemGrpDataFrame: DataFrame = sparkSession.emptyDataFrame
    var tableName = "memgroupcontractproducerview_std"
    brokerMemGrpDataFrame = func.runSql(sparkSession, ReadJson.getProperty("memgroupcontractproducerview_std"))
    val brokerMemGrpDataFrame_union = brokerMemGrpDataFrame.withColumn("uah_brokerid", brokerMemGrpDataFrame.col("producerpid"))
    var path = args(0) + "/memgroupcontractproducerview_std" + "/source_cd=CRS"
    var returnMaxTS: String = ""
    brokerMemGrpDataFrame = func.incrDataLoad(tableName, brokerMemGrpDataFrame_union, path, sparkSession)

    if (brokerMemGrpDataFrame.count.!=(0)) {
      var newmaxLoadTimestamp = brokerMemGrpDataFrame.agg(max("uah_timestamp")).first()(0).toString
      println("new max load timestamp" + newmaxLoadTimestamp)
      func.updateHbaseMrglayerTs(tableName, newmaxLoadTimestamp)
    }
    path
  }

  def getproducerexternalid_view(args: Array[String]): String = {
    val sparkSession = GContext.getRnASession("BrokerRnA")
    var brokerProdExtDataFrame: DataFrame = sparkSession.emptyDataFrame
    var tableName = "producerexternalid_view"
    brokerProdExtDataFrame = func.runSql(sparkSession, ReadJson.getProperty("producerexternalid_view"))
    val brokerProdExtDataFrame_union = brokerProdExtDataFrame.withColumn("uah_brokerid", brokerProdExtDataFrame.col("producerid"))
    var path = args(0) + "/producerexternalid_view" + "/source_cd=CRS"
    var returnMaxTS: String = ""
    brokerProdExtDataFrame = func.incrDataLoad(tableName, brokerProdExtDataFrame_union, path, sparkSession)

    if (brokerProdExtDataFrame.count.!=(0)) {
      var newmaxLoadTimestamp = brokerProdExtDataFrame.agg(max("uah_timestamp")).first()(0).toString
      println("new max load timestamp" + newmaxLoadTimestamp)
      func.updateHbaseMrglayerTs(tableName, newmaxLoadTimestamp)
    }
    path
  }

}
