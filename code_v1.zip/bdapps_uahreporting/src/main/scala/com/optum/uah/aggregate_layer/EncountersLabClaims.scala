package com.optum.uah.aggregate_layer

import com.optum.uah.function_library.{CommonFunctions, GlobalContext, ReadJson}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.hadoop.fs._
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._


/**
  * Created by Kang Jeffery on 1/3/2018.
  * modified by vatmakur on 1/4/2018
  */
object EncountersLabClaims {

  val CommonFunctions = new CommonFunctions()
  val GlobalContext = new GlobalContext()
  val log: Logger = Logger.getLogger(getClass.getName)

  // Get the 39 months older timestamp
  val oldTimestamp = CommonFunctions.getPreviousDateByMonths(39)

  def main(args: Array[String]): Unit = {

    val tgtLoc = args(0)
    val tblList = List("claimcobadjustment_std","umauthview_std", "claimlineprof_std", "clabenefit_std", "claimdiagnosisview_std", "claimheader_std", "claimprovideraddress_std", "claimlineadjudication_std", "cladeny_std", "claimpricingoutputdetailview_std", "vendor_view","apgenerationresponseview_std","aptransactiondetailview_std")
    //val tblName = tgtLoc.split("aggregate_layer/")(1)
    val propFilePath = args(1)
    val outboundLoc = args(2)

    // Log info
    log.info("Job Name: aggregate layer extract")
    log.info("Job Group: Underwriting")
    log.info("Event1: Job execution started")

    //Load json property file to get sql based on the subject area and table
    ReadJson.createJsonObject(propFilePath)

    // Load spark session for uah metastore
    val sparkSession = GlobalContext.getUAHSession("encountersLabClaims")

    val clmCobAdjustDf = getMergeData(tblList(0)+"_cir", sparkSession) //"claimid,claimlinenum", "run_id,uah_timestamp,changedatetime,claimcobadjustmentid")
    clmCobAdjustDf.createOrReplaceTempView("clmcobadjust")

    val umAuthViewDf = getMergeData(tblList(1)+"_cir", sparkSession) //"memberid", "run_id,uah_timestamp,uachangedatetime")
    umAuthViewDf.createOrReplaceTempView("umauthview")

    val prevDate = CommonFunctions.getPreviousDateByMonths(39)
    //println("39 months older date: " + prevDate)
    val clmLineProfDf = getMergeData(tblList(2)+"_cir", sparkSession).where(col("dateofservicefrom") >= prevDate)
    clmLineProfDf.createOrReplaceTempView("clmlineprof")

    val claBenefitDf = getMergeData(tblList(3)+"_cir", sparkSession) //"claclaimid,claclaimlinenum", "run_id,uah_timestamp,clachangedatetime")
    claBenefitDf.createOrReplaceTempView("clabenefit")

    val clmDiagDf = generateDiagCodes(getMergeData(tblList(4)+"_cir", sparkSession), "diagnosiscode")
    clmDiagDf.createOrReplaceTempView("clmdiag")

    val clmHeaderDf = getMergeData(tblList(5)+"_cir", sparkSession) //"chclaimid", "run_id,uah_timestamp,chchangedatetime")
    clmHeaderDf.createOrReplaceTempView("clmheader")

    val clmProvAddrDf = getMergeData(tblList(6)+"_cir", sparkSession) //"cpclaimid,cpclaimlinenum", "run_id,uah_timestamp,cpachangedatetime")
    clmProvAddrDf.createOrReplaceTempView("clmprovaddr")

    val clmLineAdjudDf = getMergeData(tblList(7)+"_cir", sparkSession) //"claimid,claimlinenum", "run_id,uah_timestamp,clachangedatetime")
    clmLineAdjudDf.createOrReplaceTempView("clmlineadjud")

    val claDenyDf = generateReasonAndRemarkCodes(getMergeData(tblList(8)+"_cir", sparkSession), "adjustmentreasoncode")
    claDenyDf.createOrReplaceTempView("cladeny")

    val clmPrcngOutputDtlViewDf = getMergeData(tblList(9)+"_cir", sparkSession)
    clmPrcngOutputDtlViewDf.createOrReplaceTempView("clmprcngoutputdtlview")

    val vendorViewDf = getMergeDataWithDedup(tblList(10)+"_cir", sparkSession, "vendorid", "run_id,uah_timestamp,changedatetime")
    vendorViewDf.createOrReplaceTempView("vendorview")

    val apGenResponseViewDf = getMergeDataWithDedup(tblList(11)+"_cir", sparkSession, "aptransactionid", "run_id,uah_timestamp,apgrchangedatetime")
    apGenResponseViewDf.createOrReplaceTempView("apgenresponseview")

    val apTxnDtlViewDf = getMergeDataWithDedup(tblList(12)+"_cir", sparkSession, "claimid,ataptransactionid", "run_id,uah_timestamp,atdchangedatetime")
    apTxnDtlViewDf.createOrReplaceTempView("aptxndtlview")

    // Join the tables to get the final hce claims extract
    val finalDf = sparkSession.sql(ReadJson.getProperty("encounters_lab_claims"))

    // Save unioned data into aggregate layer
    //CommonFunctions.saveDataframeAsFile(finalDf, tgtLoc, "overwrite")

    // Write a text file extract from the parquet data
    finalDf.repartition(1).write.option("delimiter", "|").mode("overwrite").option("header", "true").csv(outboundLoc)

    // Rename the text delimited file
    val sc = sparkSession.sparkContext
    val fs = FileSystem.get(sc.hadoopConfiguration)
    val fileName = fs.globStatus(new Path(outboundLoc + "/*.csv"))(0).getPath().getName()
    fs.rename(new Path(outboundLoc + "/" + fileName), new Path(outboundLoc + "/encounters_lab_claims.dat"))

    log.info("Record count: " + finalDf.count())
    log.info("Event2: Job completed")

    sparkSession.close()

  }


  def getMergeData(tblName: String, sparkSession:SparkSession): DataFrame = {

    // Load merge layer data into a dataframe
    val resultDf = CommonFunctions.runSql(sparkSession, ReadJson.getProperty(tblName)).dropDuplicates()

    resultDf
  }


  def getMergeDataWithDedup(tblName: String, sparkSession:SparkSession, grpByCols: String, orderByCols: String): DataFrame = {

    val dropCols = orderByCols.split(",").toSeq
    // Load merge layer data into a dataframe
    val resultDf = CommonFunctions.dedupLogic(getMergeData(tblName, sparkSession), grpByCols, orderByCols).drop(dropCols: _*).dropDuplicates()

    resultDf
  }


  def generateDiagCodes(inputDf: DataFrame, diagCode: String): DataFrame = {

    // Getting only the diagnosis codes with latest run_id load
    val w1 = Window.partitionBy("claimid").orderBy(col("run_id").desc)
    val latestDiagCodesDf = inputDf.withColumn("rn", dense_rank.over(w1)).where(col("rn") === 1).drop("rn")
    // Selecting the latest 8 diagnosis codes based on timetsamp
    val w = Window.partitionBy("claimid").orderBy(col("run_id").desc, col("uah_timestamp").desc, col("diagseqnum"))
    var resultDf = latestDiagCodesDf.withColumn("rn", row_number.over(w)).where(col("rn") <= 8).groupBy("claimid","diagcodetypedesc").agg(collect_list(diagCode).as("ICD_CODE"))
    for (i <- 0 to 7) {
      resultDf = resultDf.withColumn("icd_code_"+(i+1), col("ICD_CODE").apply(i))
    }

    resultDf.drop("ICD_CODE")
  }

  def generateReasonAndRemarkCodes(inputDf: DataFrame, adjstRsnCode: String): DataFrame = {

    var resultDf = inputDf.groupBy("claimlineadjudicationid").agg(collect_list(adjstRsnCode).as("adjustmentreasoncode"))
    for (i <- 0 to 4) {
      resultDf = resultDf.withColumn("adjustmentreasoncode_" + (i + 1), col("adjustmentreasoncode").apply(i))
    }
    resultDf.drop("adjustmentreasoncode")
  }

}
