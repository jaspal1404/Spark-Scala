package com.optum.uah.function_library

/**
 * Created by docker on 8/8/17.
 */
case class NoSuchPathException(private val message: String = "",
                               private val cause: Throwable = None.orNull)
  extends Exception(message, cause)
