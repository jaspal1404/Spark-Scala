package com.optum.uah.aggregate_layer

import com.optum.uah.function_library.{CommonFunctions, GlobalContext, ReadJson}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.hadoop.fs._
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._


/**
  * Created by jsingh73 on 9/20/2017.
  */
object HCEMedicalClaims {

  val CommonFunctions = new CommonFunctions()
  val GlobalContext = new GlobalContext()
  val log: Logger = Logger.getLogger(getClass.getName)

  // Get the 39 months older timestamp
  val oldTimestamp = CommonFunctions.getPreviousDateByMonths(39)

  def main(args: Array[String]): Unit = {

    val tgtLoc = args(0)
    val tblList = List("clabenefit_std","claimheader_std","claimdiagnosisview_std","claimnote_std","claimlineinst_std","claimlineprof_std","claimprovideraddress_std","claimcobadjustment_std","claimlineadjudication_std","umauthview_std",
      "claimpricinginputdetailview_std","benefitbundleplan_std","memgroupid_std","memgroupcontractview_std","memgroupcontractplanoptextview_std","memberbenefit_std","taxonomycode_view","providertaxonomyview_std","beneplansettings_std",
      "productbenefitandtype_std","carrierlobplanview_std","memgroupcontractplanoptionvw_std","cladeny_std","dofrsched_view","cladofr_view","clabenefitprovider_std","oonpricingschednoteview_std", "oonpricingschedorderdetailview_std", "aptransactionattribsetglstring_view", "aptransactiondetailview_std", "apgenerationresponseview_std","claimevent_std", "static_inst_claims")
    val tblName = tgtLoc.split("aggregate_layer/")(1)
    val propFilePath = args(1)
    val outboundLoc = args(2)

    // Log info
    log.info("Job Name: " + tblName + " aggregate layer extract")
    log.info("Job Group: Underwriting")
    log.info("Event1: Job execution started")

    //Load json property file to get sql based on the subject area and table
    ReadJson.createJsonObject(propFilePath)

    // Load spark session for uah metastore
    val sparkSession = GlobalContext.getUAHSession("hceMedicalClaims")

    // Load the cirrus data from merge layer table1
    val clmLineProfDf = getMergeData(tblList(5)+"_cir", sparkSession)

    // Load the cirrus data from merge layer table2
    val clmLineInstDf = getMergeData(tblList(4)+"_cir", sparkSession)

    //Union the data from the 2 driving claim tables claimlineprof and claimlineinst
    val prevDate = CommonFunctions.getPreviousDateByMonths(39)
    println("39 months older date: " + prevDate)
    val clmProfInstUnionDf = CommonFunctions.unionDataframes(clmLineInstDf, clmLineProfDf).where(col("dateofservicefrom") >= prevDate)
    clmProfInstUnionDf.createOrReplaceTempView("clmprofinstunion")

    // Load the cirrus data from merge layer table3
    val clmDiagDf = generateDiagCodes(getMergeData(tblList(2)+"_cir", sparkSession), "diagnosiscode", sparkSession)
    clmDiagDf.createOrReplaceTempView("clmdiag")

    // Load the cirrus data from merge layer table4
    val claBenefitDf = getMergeData(tblList(0)+"_cir", sparkSession) //"claclaimid,claclaimlinenum", "run_id,uah_timestamp,clachangedatetime")
    claBenefitDf.createOrReplaceTempView("clabenefit")

    // Load the cirrus data from merge layer table5
    val clmHeaderDf = getMergeData(tblList(1)+"_cir", sparkSession) //"chclaimid", "run_id,uah_timestamp,chchangedatetime")
    clmHeaderDf.createOrReplaceTempView("clmheader")

    // Load the cirrus data from merge layer table6
    val clmNoteDf = getMergeData(tblList(3)+"_cir", sparkSession) //"claimid,claimlinenum", "run_id,uah_timestamp,changedatetime,claimnoteid")
    clmNoteDf.createOrReplaceTempView("clmnote")

    // Load the cirrus data from merge layer table7
    val clmProvAddrDf = getMergeData(tblList(6)+"_cir", sparkSession) //"cpclaimid,cpclaimlinenum", "run_id,uah_timestamp,cpachangedatetime")
    clmProvAddrDf.createOrReplaceTempView("clmprovaddr")

    // Load the cirrus data from merge layer table8
    val clmCobAdjustDf = getMergeData(tblList(7)+"_cir", sparkSession) //"claimid,claimlinenum", "run_id,uah_timestamp,changedatetime,claimcobadjustmentid")
    clmCobAdjustDf.createOrReplaceTempView("clmcobadjust")

    // Load the cirrus data from merge layer table9
    val clmLineAdjudDf = getMergeData(tblList(8)+"_cir", sparkSession) //"claimid,claimlinenum", "run_id,uah_timestamp,clachangedatetime")
    clmLineAdjudDf.createOrReplaceTempView("clmlineadjud")

    // Load the cirrus data from merge layer table10
    val umAuthViewDf = getMergeData(tblList(9)+"_cir", sparkSession) //"memberid", "run_id,uah_timestamp,uachangedatetime")
    umAuthViewDf.createOrReplaceTempView("umauthview")

    // Load the cirrus data from merge layer table11
    val clmPricingInputDtlDf = getMergeData(tblList(10)+"_cir", sparkSession) //"cpihclaimid", "run_id,uah_timestamp,cpihchangedatetime")
    clmPricingInputDtlDf.createOrReplaceTempView("clmpricinginputdtl")

    // Load the cirrus data from merge layer table12
    val benefitBundlePlanDf = getMergeDataWithDedup(tblList(11)+"_cir", sparkSession, "benefitbundleoptionid", "run_id,uah_timestamp,changedatetime")
    benefitBundlePlanDf.createOrReplaceTempView("benefitbundleplan")

    // Load the cirrus data from merge layer table13
    val memGrpIdDf = getMergeDataWithDedup(tblList(12)+"_cir", sparkSession, "uah_memgroupid", "run_id,uah_timestamp,memgrouptinid,memgroupexternalidid,memgroupaliasid")
    memGrpIdDf.createOrReplaceTempView("memgrpid")

    // Load the cirrus data from merge layer table14
    val memGrpCntrctViewDf = getMergeDataWithDedup(tblList(13)+"_cir", sparkSession, "uah_memgroupgid", "run_id,uah_timestamp,changedatetime")
    memGrpCntrctViewDf.createOrReplaceTempView("memgrpcntrctview")

    // Load the cirrus data from merge layer table15
    val memGrpCntrctPlnOptDf = getMergeDataWithDedup(tblList(14)+"_cir", sparkSession, "uah_memgroupid", "run_id,uah_timestamp,changedatetime")
    memGrpCntrctPlnOptDf.createOrReplaceTempView("memgrpcntrctplnopt")

    // Load the cirrus data from merge layer table16
    val mbrBenefitDf = getMergeDataWithDedup(tblList(15)+"_cir", sparkSession, "uah_memberid,memberbenefitid", "run_id,uah_timestamp,changedatetime")
    mbrBenefitDf.createOrReplaceTempView("mbrbenefit")

    // Load the cirrus data from merge layer table17
    val taxonomyCodeViewDf = getMergeDataWithDedup(tblList(16)+"_cir", sparkSession, "taxonomycode", "run_id,uah_timestamp,changedatetime")
    taxonomyCodeViewDf.createOrReplaceTempView("taxonomycodeview")

    // Load the cirrus data from merge layer table18
    val provTaxonomyViewDf = getMergeDataWithDedup(tblList(17)+"_cir", sparkSession, "taxonomycode", "run_id,uah_timestamp,providertaxonomychangedatetime")
    provTaxonomyViewDf.createOrReplaceTempView("provtaxonomyview")

    // Load the cirrus data from merge layer table19
    val benePlnSettingsDf = getMergeDataWithDedup(tblList(18)+"_cir", sparkSession, "planid", "run_id,uah_timestamp,changedatetime")
    benePlnSettingsDf.createOrReplaceTempView("beneplnsettings")

    // Load the cirrus data from merge layer table20
    val prdctBenefitAndTypeDf = getMergeDataWithDedup(tblList(19)+"_cir", sparkSession, "productid", "run_id,uah_timestamp,changedatetime")
    prdctBenefitAndTypeDf.createOrReplaceTempView("prdctbenefitandtype")

    // Load the cirrus data from merge layer table21
    val carrierLobPlnViewDf = getMergeDataWithDedup(tblList(20)+"_cir", sparkSession, "carrierlobplanid", "run_id,uah_timestamp,changedatetime")
    carrierLobPlnViewDf.createOrReplaceTempView("carrierlobplnview")

    //Load the cirrus data from table22
    val memGrpCntrctPlnOptnVwDf = getMergeDataWithDedup(tblList(21)+"_cir", sparkSession, "memgroupcontractoptid,memgroupcontractplanoptionid", "run_id,uah_timestamp,changedatetime")
    memGrpCntrctPlnOptnVwDf.createOrReplaceTempView("memgrpcntrctplnoptnvw")

    //Load the cirrus data from table23
    val clmDenyDf = generateReasonAndRemarkCodes(getMergeData(tblList(22)+"_cir", sparkSession), "adjustmentreasoncode", "denyreasoncode", "remittanceadviceremarkcode")
    clmDenyDf.createOrReplaceTempView("clmdeny")

    //Load the cirrus data from table24
    val dofrSchedDf = getMergeData(tblList(23)+"_cir", sparkSession) //, "memgroupcontractoptid,memgroupcontractplanoptionid", "run_id,uah_timestamp,changedatetime")
    dofrSchedDf.createOrReplaceTempView("dofrsched")

    //Load the cirrus data from table25
    val claDofrDf = getMergeData(tblList(24)+"_cir", sparkSession) //, "claimlineadjudicationid", "run_id,uah_timestamp,changedatetime")
    claDofrDf.createOrReplaceTempView("cladofr")

    //Load the cirrus data from table26
    val claBenefitPrvdrDf = getMergeDataWithDedup(tblList(25)+"_cir", sparkSession, "claimlineadjudicationid", "run_id,uah_timestamp,changedatetime")
    claBenefitPrvdrDf.createOrReplaceTempView("clabenefitprvdr")

    //Load the cirrus data from table27
    val oonPrcngSchedNoteViewDf = getMergeData(tblList(26)+"_cir", sparkSession) //, "claimlineadjudicationid", "run_id,uah_timestamp,changedatetime")
    oonPrcngSchedNoteViewDf.createOrReplaceTempView("oonprcngschednoteview")

    //Load the cirrus data from table28
    val oonPrcngSchedDetailViewDf = getMergeData(tblList(27)+"_cir", sparkSession) //, "claimlineadjudicationid", "run_id,uah_timestamp,changedatetime")
    oonPrcngSchedDetailViewDf.createOrReplaceTempView("oonprcngscheddetailview")
    
    //Load the cirrus data from table29
    val apTransactionAttribsetGLstringDf = getMergeData(tblList(28), sparkSession) //, "claimlineadjudicationid", "run_id,uah_timestamp,changedatetime")
    //apTransactionAttribsetGLstringDf.createOrReplaceTempView("aptransactionattribsetglstring")
    
    //Load the cirrus data from table30
    val apTransactionDetailViewDf = getMergeData(tblList(29), sparkSession) //, "claimlineadjudicationid", "run_id,uah_timestamp,changedatetime")
    //apTransactionDetailViewDf.createOrReplaceTempView("aptransactiondetailview")
	
	//Load the cirrus data from table30
     val aptransactionDetailViewCirDf = getMergeData(tblList(29)+"_cir", sparkSession) //, "claimlineadjudicationid", "run_id,uah_timestamp,changedatetime")
    aptransactionDetailViewCirDf.createOrReplaceTempView("aptransactiondetailview")
    
    //Load the cirrus data from table31
     val apgenerationResponseViewDF = getMergeData(tblList(30)+"_cir", sparkSession) //, "claimlineadjudicationid", "run_id,uah_timestamp,changedatetime")
    apgenerationResponseViewDF.createOrReplaceTempView("apgenerationresponseview")
    
    //Load the cirrus data from table32
     val claimEventDf = getMergeData(tblList(31)+"_cir", sparkSession) //, "claimlineadjudicationid", "run_id,uah_timestamp,changedatetime")
    claimEventDf.createOrReplaceTempView("claimevent")
	
    //Load the cirrus data from table33
    val staticInstClaimsDf = getMergeData(tblList(32)+"_cir", sparkSession) 
    staticInstClaimsDf.createOrReplaceTempView("static_inst_claims")  
    
    val profInstiClaimsJoinDf = sparkSession.sql("SELECT t1.chclaimid as claimid1,t1.poscode as poscode, NULL as typeofbill1, 'P' as claimtypflag from clmheader t1 UNION SELECT NULL as claimid1,t2.poscode as poscode, typeofbill as typeofbill1, 'I' as claimtypflag from static_inst_claims t2")
    	
    profInstiClaimsJoinDf.createOrReplaceTempView("joinedclaimsview")


    //Joining the benefitbundleplan, oonprcngscheddetailview, oonprcngschednoteview tables to get required attributes
    val subQueryDf = sparkSession.sql("SELECT DISTINCT a.benefitbundleoptionid,a.ucrpercentile,a.cmspct,c.pricingmethodtype from benefitbundleplan a LEFT OUTER JOIN oonprcngschednoteview b ON TRIM(a.oonpricingschedid) = TRIM(b.oonpricingschedid) LEFT OUTER JOIN oonprcngscheddetailview c ON TRIM(b.oonpricingschedoonpricingschedversionid) = TRIM(c.oonpricingschedorderoonpricingschedversionid)")
    val groupedDf = subQueryDf.groupBy("benefitbundleoptionid","ucrpercentile","cmspct").agg(sort_array(collect_list("pricingmethodtype")).as("pricingmethodtype"))
    val newGroupedDf = groupedDf.withColumn("pricingmethodtype_1", groupedDf("pricingmethodtype").apply(0)).withColumn("pricingmethodtype_2", groupedDf("pricingmethodtype").apply(1))
        .withColumn("pricingmethodtype_3", groupedDf("pricingmethodtype").apply(2)).withColumn("pricingmethodtype_4", groupedDf("pricingmethodtype").apply(3)).drop("pricingmethodtype")
    newGroupedDf.createOrReplaceTempView("joinedview")

    // Join the tables to get the final hce claims extract
    val mergedDf = sparkSession.sql(ReadJson.getProperty("hce_medical_claims"))
    
    val glstringDF = apTransactionAttribsetGLstringDf.join(apTransactionDetailViewDf, Seq("aptransactiondetailid"), "inner").join(clmHeaderDf, apTransactionDetailViewDf.col("claimID") === clmHeaderDf.col("chClaimID"), "inner").select("chClaimID", "generalLedgerString")
    val finalDf = mergedDf.join(glstringDF, Seq("chclaimid"), "left_outer").drop("chclaimid")
    
    // Save unioned data into aggregate layer
    CommonFunctions.saveDataframeAsFile(finalDf, tgtLoc, "overwrite")

    // Write a text file extract from the parquet data
    finalDf.repartition(1).write.option("delimiter", "|").mode("overwrite").option("header", "true").csv(outboundLoc)

    // Rename the text delimited file
    val sc = sparkSession.sparkContext
    val fs = FileSystem.get(sc.hadoopConfiguration)
    val fileName = fs.globStatus(new Path(outboundLoc + "/*.csv"))(0).getPath().getName()
    fs.rename(new Path(outboundLoc + "/" + fileName), new Path(outboundLoc + "/hce_medical_claims.dat"))

    log.info("Record count: " + finalDf.count())
    log.info("Event2: Job completed")

    sparkSession.close()

  }


  def getMergeData(tblName: String, sparkSession:SparkSession): DataFrame = {

    // Load merge layer data into a dataframe
    val resultDf = CommonFunctions.runSql(sparkSession, ReadJson.getProperty(tblName)).dropDuplicates()

    resultDf
  }


  def getMergeDataWithDedup(tblName: String, sparkSession:SparkSession, grpByCols: String, orderByCols: String): DataFrame = {

    val dropCols = orderByCols.split(",").toSeq
    // Load merge layer data into a dataframe
    val resultDf = CommonFunctions.dedupLogic(getMergeData(tblName, sparkSession), grpByCols, orderByCols).drop(dropCols: _*).dropDuplicates()

    resultDf
  }


  def generateDiagCodes(inputDf: DataFrame, diagCode: String, sparkSession: SparkSession): DataFrame = {


    // Getting only the diagnosis codes with latest run_id load
    val w1 = Window.partitionBy("claimid").orderBy(col("run_id").desc)
    val latestDiagCodesDf = inputDf.withColumn("rn", dense_rank.over(w1)).where(col("rn") === 1).drop("rn")
    // Loading the admitting and principal diagnosis codes
    val admitDiagCodeDf = latestDiagCodesDf.select("admittingdiagind","claimid","diagnosiscode").filter(col("admittingdiagind") === "1").withColumnRenamed("diagnosiscode","admitdiagnosiscode").drop("admittingdiagind").withColumnRenamed("claimid","claimid2")
    val prinDiagCodeDf = latestDiagCodesDf.select("principaldiagind","claimid","diagnosiscode").filter(col("principaldiagind") === "1").withColumnRenamed("diagnosiscode","principaldiagnosiscode").drop("principaldiagind").withColumnRenamed("claimid","claimid3")
    // Loading only the first 25 icd codes in ascending order of changedatetime
    val w = Window.partitionBy("claimid").orderBy(col("claimdiagnosischangedatetime"))
    var diagCodes25Df = latestDiagCodesDf.where(col("admittingdiagind") === "0" && col("principaldiagind") === "0")
    admitDiagCodeDf.createOrReplaceTempView("tempview1")
    prinDiagCodeDf.createOrReplaceTempView("tempview2")
    diagCodes25Df.createOrReplaceTempView("tempview3")
    val duplicateDiagCodesDf = sparkSession.sql("SELECT t3.* FROM tempview1 t1 JOIN tempview3 t3 ON (TRIM(t3.claimid) = TRIM(t1.claimid2) AND TRIM(t1.admitdiagnosiscode) = TRIM(t3.diagnosiscode)) UNION (SELECT t3.* FROM tempview2 t2 JOIN tempview3 t3 ON " +
      "(TRIM(t3.claimid) = TRIM(t2.claimid3) AND TRIM(t2.principaldiagnosiscode) = TRIM(t3.diagnosiscode)))")
    if (duplicateDiagCodesDf.count() != 0) {
      diagCodes25Df = diagCodes25Df.except(duplicateDiagCodesDf)
    }
    diagCodes25Df = diagCodes25Df.withColumn("rn", row_number.over(w)).where(col("rn") <= 25).groupBy("claimid").agg(collect_list(diagCode).as("ICD_CODE"))
    for (i <- 0 to 24) {
      diagCodes25Df = diagCodes25Df.withColumn("icd_code_"+(i+1), col("ICD_CODE").apply(i))
    }
    val distinctValuesDF = inputDf.select("claimid").distinct.withColumnRenamed("claimid","claimid1")
    val joinedDf1 = distinctValuesDF.join(diagCodes25Df, trim(col("claimid1")) === trim(col("claimid")), "leftouter").drop("claimid")
    val joinedDf2 = joinedDf1.join(admitDiagCodeDf,trim(col("claimid1")) === trim(col("claimid2")), "leftouter").drop("claimid2")
    val finalDf = joinedDf2.join(prinDiagCodeDf,trim(col("claimid1")) === trim(col("claimid3")), "leftouter").drop("claimid3").drop("ICD_CODE").withColumnRenamed("claimid1","claimid")

    finalDf
  }


  def generateReasonAndRemarkCodes(inputDf: DataFrame, adjstRsnCode: String, denyRsnCode: String, remarkCode: String): DataFrame = {

    var resultDf = inputDf.groupBy("claimlineadjudicationid").agg(collect_list(adjstRsnCode).as("adjustmentreasoncode"),collect_list(denyRsnCode).as("denyreasoncode"),collect_list(remarkCode).as("remittanceadviceremarkcode"))
    //var resultDf = inputDf.groupBy("claimlineadjudicationid").agg(collect_list((adjstRsnCode).distinct).as("adjustmentreasoncode"),collect_list((denyRsnCode).distinct).as("denyreasoncode"),collect_list((remarkCode).distinct).as("remittanceadviceremarkcode"))
    for (i <- 0 to 4) {
      resultDf = resultDf.withColumn("adjustmentreasoncode_" + (i + 1), col("adjustmentreasoncode").apply(i)).withColumn("denyreasoncode_" + (i + 1), col("denyreasoncode").apply(i))
        .withColumn("remittanceAdviceRemarkCode_" + (i + 1), col("remittanceadviceremarkcode").apply(i))
    }
    resultDf.drop("adjustmentreasoncode").drop("denyreasoncode").drop("remittanceadviceremarkcode")
  }

}
