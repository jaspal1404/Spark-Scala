package com.optum.uah.function_library
import org.apache.log4j
import org.apache.log4j.Level

object Logger {
 @transient lazy val log = org.apache.log4j.LogManager.getLogger("myLogger") 
  //log.setLevel(Level.ALL)
}