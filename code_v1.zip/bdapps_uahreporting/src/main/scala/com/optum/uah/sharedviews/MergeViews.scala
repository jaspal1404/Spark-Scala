package com.optum.uah.sharedviews

/**
 * Created by docker on 8/8/17.
 */
object MergeViews {
  /* Get provider data set from cirrus side*/

  def MergeHCE200providerSet1 ()  =
  {

    /*  it returns the case class .... provider_id,.....*/

 //  HCE200Provider.getProviderMerge()

  }

}