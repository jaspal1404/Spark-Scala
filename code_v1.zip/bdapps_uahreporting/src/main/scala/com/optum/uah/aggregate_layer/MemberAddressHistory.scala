package com.optum.uah.aggregate_layer

import com.optum.uah.function_library.{CommonFunctions, GlobalContext, ReadJson}
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._


object MemberAddressHistory {
  val GContext = new GlobalContext()
  val func = new CommonFunctions()
  val sparkSession = GContext.getUAHSession("MemberUAH")

  def main(args: Array[String]): Unit = {
    val sparkSession = GContext.getUAHSession("MemberUAH")
    sparkSession.sql("use uah_mergelayer")

    val propFilePath = args(1)
    ReadJson.createJsonObject(propFilePath)
    val path = "/datalake/optum/optuminsight/d_uah/dev/d_hdfs/mergelayer/";
    val memberBenefitDf = func.runSql(sparkSession, ReadJson.getProperty("memberbenefit"))
    val memberDemographicDf = func.runSql(sparkSession, ReadJson.getProperty("memberdemographic"))
    val subsaffiliationDf = func.runSql(sparkSession, ReadJson.getProperty("subsaffiliation"))
    val memberBenefitCovLevelCodeDf = func.runSql(sparkSession, ReadJson.getProperty("memberbenefitcovlevelcode"))
    val beneTierNetworkDf = func.runSql(sparkSession, ReadJson.getProperty("benetiernetwork"))
    val memGroupContractPlanOptExtviewDf = func.runSql(sparkSession, ReadJson.getProperty("memgroupcontractplanoptextview"))
    val memgroupcontractviewDf = func.runSql(sparkSession, ReadJson.getProperty("memgroupcontractview"))
    val memgroupcontractplanoptionviewDf = func.runSql(sparkSession, ReadJson.getProperty("memgroupcontractplanoptionview"))

    val memberBenefitDf1 = memberBenefitDf.distinct()
    val memberDemographicDf1 = memberDemographicDf.distinct()
    val subsaffiliationDf1 = subsaffiliationDf.distinct()
    val memberBenefitCovLevelCodeDf1 = memberBenefitCovLevelCodeDf.distinct()
    val beneTierNetworkDf1 = beneTierNetworkDf.distinct()
    val memGroupContractPlanOptExtviewDf1 = memGroupContractPlanOptExtviewDf.distinct()
    val memgroupcontractviewDf1 = memgroupcontractviewDf.distinct()
    val memgroupcontractplanoptionviewDf1 = memgroupcontractplanoptionviewDf.distinct()


    memberBenefitCovLevelCodeDf.printSchema()
    subsaffiliationDf.printSchema()
    memberBenefitDf.printSchema()
    beneTierNetworkDf.printSchema()
    memgroupcontractviewDf.printSchema()
    memGroupContractPlanOptExtviewDf.printSchema()


    //Member Address History Report
    def getmemeberAddressHistoryReport(sparkSession: SparkSession, tablepath: String) {

      val memeberAddressHistoryReport1 = memberDemographicDf1.join(memberBenefitDf1, Seq("Member_id"), "left_outer").
        join(subsaffiliationDf1, Seq("Member_id"), "left_outer").drop(subsaffiliationDf1.col("member_id")).
        join(memberBenefitCovLevelCodeDf1, Seq("Member_id"), "left_outer").drop(memberBenefitCovLevelCodeDf1.col("member_id")).
        join(beneTierNetworkDf1, Seq("Member_id"), "left_outer").drop(beneTierNetworkDf1.col("member_id")).
        join(memGroupContractPlanOptExtviewDf1, memberBenefitDf1.col("memgroupid") === memGroupContractPlanOptExtviewDf1.col("memgroupid"), "left_outer").drop(memGroupContractPlanOptExtviewDf1.col("memgroupid")).
        join(memgroupcontractviewDf1, memberBenefitDf1.col("memgroupid") === memgroupcontractviewDf1.col("group_code"), "left_outer").
        join(memgroupcontractplanoptionviewDf1, memberBenefitDf1.col("memgroupid") === memgroupcontractplanoptionviewDf1.col("memgroupid"), "left_outer").drop(memgroupcontractplanoptionviewDf1.col("memgroupid")).filter("group_code is not null").filter("group_code!='null'")


      memeberAddressHistoryReport1.printSchema()

      //Casting to Date

      val memberAddressHistoryReport = memeberAddressHistoryReport1.withColumn("date_of_birth", (col("date_of_birth").cast("date")))
        .withColumn("effective_from_date", (col("effective_from_date").cast("date")))
        .withColumn("effective_thru_date", (col("effective_thru_date").cast("date")))
        memberAddressHistoryReport.printSchema()

      val filePath = tablepath + "memeberAddressHistoryReport" + System.currentTimeMillis()
      //memberAddressHistoryReport.show()
      memberAddressHistoryReport.write.mode("overwrite").partitionBy("group_code").parquet(filePath)

      //func.createExternalTableFromParquetWithPartition(sparkSession, filePath+"/", "mahr_report", "uah_aggregatelayer", "group_code", "String")
    }
    val memeberAddressHistoryReportDS = getmemeberAddressHistoryReport(sparkSession, args(0))
    sparkSession.close()
  }

}

