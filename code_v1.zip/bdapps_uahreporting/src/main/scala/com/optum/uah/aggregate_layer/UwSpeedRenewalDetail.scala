package com.optum.uah.aggregate_layer

import com.optum.uah.function_library.{CommonFunctions, GlobalContext, ReadJson}
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * Created by sbandar8 on 8/8/2017.
  */
object UwSpeedRenewalDetail {
  val CommonFunctions = new CommonFunctions()
  val GlobalContext = new GlobalContext()

  def main(args: Array[String]): Unit = {

    val tgtLoc1 = args(0)
    val tgtLoc2 = args(1)
    val tblList = List("memberbenefit_std","productbenefitandtype_std","subsaffiliation_std","billingsched_view","memberbenefitcovlevelcode_std","memgroupaddress_std","memgroupcontractoptcontributvw_std","memgroupcontractoptinsruleview_std","memgroupcontractplanattrsetvw_std","memgroupcontractplanoptextview_std","memgroupcontractplanoptionview_std","memgroupcontractproducerview_std","memgroupcontractview_std","memgrpctrtbillprefcontact_std","supportteamphoneview_std","memgroupsupportteam_view","benecodeadj_std","benefitbundleplan_std","clabenefit_std","benetier_view","memgroupcontractplanoptionvw_std","produceraddressview_std","benefitbundleplanproduct_std","memgroupid_std","beneplansettings_std","memgroupcontractplanyrbillrt_view","benedeductibleperiod_view","benecodeservicetypecode_view","benestoplossoop_std")
    //val tblName = tgtLoc.split("aggregate_layer/")(1)
    val propFilePath = args(2)
    //val outboundLoc = args(2)

    //Load json property file to get sql based on the subject area and table
    ReadJson.createJsonObject(propFilePath)

    // Load spark session for uah metastore
    val sparkSession = GlobalContext.getUAHSession("encountersLabClaims")

    val mbrBenefitDf = getMergeDataWithDedup(tblList(0)+"_cir", sparkSession, "uah_memgroupid,memgroupcontractoptid,memgroupcontractplanoptionid,memgroupcontractid", "run_id,uah_timestamp")
    mbrBenefitDf.createOrReplaceTempView("mbrbenefit")

    val prdctBenefitAndTypeDf = getMergeDataWithDedup(tblList(1)+"_cir", sparkSession, "productid", "run_id,uah_timestamp")
    prdctBenefitAndTypeDf.createOrReplaceTempView("prdctbenefitandtype")

    val subsAffDf = getMergeDataWithDedup(tblList(2)+"_cir", sparkSession, "memgroupid", "run_id,uah_timestamp")
    subsAffDf.createOrReplaceTempView("subsaff")

    val billingSchedViewDf = getMergeDataWithDedup(tblList(3)+"_cir", sparkSession, "billingschedid", "run_id,uah_timestamp")
    billingSchedViewDf.createOrReplaceTempView("billingschedview")

    val mbrBnftCovLvlCdDf = getMergeDataWithDedup(tblList(4)+"_cir", sparkSession, "uah_memberid,memberbenefitcovlevelcodememberbenefitid", "run_id,uah_timestamp,effectivedate,expirationdate")
    mbrBnftCovLvlCdDf.createOrReplaceTempView("mbrbnftcovlvlcd")

    val memGrpAddrDf = getMergeDataWithDedup(tblList(5)+"_cir", sparkSession, "uah_memgroupid", "run_id,uah_timestamp,address_order")
    memGrpAddrDf.createOrReplaceTempView("memgrpaddr")

    val memGrpCntrctOptContribVwDf = getMergeDataWithDedup(tblList(6)+"_cir", sparkSession, "memgroupid,mgcomemgroupcontractoptid,memgroupcontractid", "run_id,uah_timestamp")
    memGrpCntrctOptContribVwDf.createOrReplaceTempView("memgrpcntrctoptcontribvw")

    val memGrpCntrctOptInsRuleViewDf = getMergeDataWithDedup(tblList(7)+"_cir", sparkSession, "uah_memgroupid", "run_id,uah_timestamp,effectivedate")
    memGrpCntrctOptInsRuleViewDf.createOrReplaceTempView("memgrpcntrctoptinsruleview")

    val memGrpCntrctPlnAttrSetVwDf = getMergeDataWithDedup(tblList(8)+"_cir", sparkSession, "uah_memgroupid,memgroupcontractoptid,memgroupcontractplanoptionid,memgroupcontractid", "run_id,uah_timestamp")
    memGrpCntrctPlnAttrSetVwDf.createOrReplaceTempView("memgrpcntrctplnattrsetvw")

    val memGrpCntrctPlnOptExtViewDf = getMergeDataWithDedup(tblList(9)+"_cir", sparkSession, "uah_memgroupid,memgroupcontractoptid,memgroupcontractplanoptionid,memgroupcontractid", "run_id,uah_timestamp")
    memGrpCntrctPlnOptExtViewDf.createOrReplaceTempView("memgrpcntrctplnoptextview")

    val memGrpCntrctPlnOptionViewDf = getMergeDataWithDedup(tblList(10)+"_cir", sparkSession, "uah_memgroupid,memgroupcontractoptid,memgroupcontractplanoptionid,memgroupcontractid", "run_id,uah_timestamp")
    memGrpCntrctPlnOptionViewDf.createOrReplaceTempView("memgrpcntrctplnoptionview")

    val memGrpCntrctProducerViewDf = getMergeDataWithDedup(tblList(11)+"_cir", sparkSession, "memgroupid", "run_id,uah_timestamp")
    memGrpCntrctProducerViewDf.createOrReplaceTempView("memgrpcntrctproducerview")

    val memGrpCntrctViewDf = getMergeDataWithDedup(tblList(12)+"_cir", sparkSession, "uah_memgroupgid,uah_memgroupcontractgcid", "run_id,uah_timestamp")
    memGrpCntrctViewDf.createOrReplaceTempView("memgrpcntrctview")

    val memGrpCtrtBillPrefCntctDf = getMergeDataWithDedup(tblList(13)+"_cir", sparkSession, "memgroupcontactrolememgroupid", "run_id,uah_timestamp")
    memGrpCtrtBillPrefCntctDf.createOrReplaceTempView("memgrpctrtbillprefcntct")

    val supportTeamPhoneViewDf = getMergeDataWithDedup(tblList(14)+"_cir", sparkSession, "stsupportteamid", "run_id,uah_timestamp")
    supportTeamPhoneViewDf.createOrReplaceTempView("supportteamphoneview")

    val memGrpSupportTeamViewDf = getMergeDataWithDedup(tblList(15)+"_cir", sparkSession, "memgroupid", "run_id,uah_timestamp")
    memGrpSupportTeamViewDf.createOrReplaceTempView("memgrpsupportteamview")

    val beneCodeAdjDf = getMergeDataWithDedup(tblList(16)+"_cir", sparkSession, "benefitplanversionid,tiernumber", "run_id,uah_timestamp")
    beneCodeAdjDf.createOrReplaceTempView("benecodeadj")

    val benefitBundlePlanDf = getMergeDataWithDedup(tblList(17)+"_cir", sparkSession, "benefitbundleid", "run_id,uah_timestamp")
    benefitBundlePlanDf.createOrReplaceTempView("benefitbundleplan")

    val claBenefitDf = getMergeDataWithDedup(tblList(18)+"_cir", sparkSession, "benefitplanversionid", "run_id,uah_timestamp")
    claBenefitDf.createOrReplaceTempView("clabenefit")

    val beneTierViewDf = getMergeDataWithDedup(tblList(19)+"_cir", sparkSession, "benefitplanversionid,tiernumber", "run_id,uah_timestamp")
    beneTierViewDf.createOrReplaceTempView("benetierview")

    val memGrpCntrctPlnOptionVwDf = getMergeDataWithDedup(tblList(20)+"_cir", sparkSession, "uah_memgroupid,memgroupcontractid,memgroupcontractoptid,memgroupcontractplanoptionid", "run_id,uah_timestamp")
    memGrpCntrctPlnOptionVwDf.createOrReplaceTempView("memgrpcntrctplnoptionvw")

    val producerAddrViewDf = getMergeDataWithDedup(tblList(21)+"_cir", sparkSession, "prodproducerid", "run_id,uah_timestamp")
    producerAddrViewDf.createOrReplaceTempView("produceraddrview")

    val benefitBundlePlanPrdctDf = getMergeDataWithDedup(tblList(22)+"_cir", sparkSession, "benefitbundleplanid", "run_id,uah_timestamp")
    benefitBundlePlanPrdctDf.createOrReplaceTempView("benefitbundleplanprdct")

    val memGrpIdDf = getMergeData(tblList(23)+"_cir", sparkSession)
    memGrpIdDf.createOrReplaceTempView("memgrpid")

    val benePlnSettingsDf = getMergeData(tblList(24)+"_cir", sparkSession)
    benePlnSettingsDf.createOrReplaceTempView("beneplnsettings")

    val memGrpCntrctPlnYrBillRtDf = getMergeDataWithDedup(tblList(25)+"_cir", sparkSession, "uah_memgroupid,memgroupcontractoptid,memgroupcontractplanoptionid,memgroupcontractid", "run_id,uah_timestamp")
    memGrpCntrctPlnYrBillRtDf.createOrReplaceTempView("memgrpcntrctplnyrbillrt")

    val beneDeductPeriodDf = getMergeDataWithDedup(tblList(26)+"_cir", sparkSession, "benefitplanversionid", "run_id,uah_timestamp")
    beneDeductPeriodDf.createOrReplaceTempView("benedeductperiod")

    val beneCodeSrvcTypeViewDf = getMergeDataWithDedup(tblList(27)+"_cir", sparkSession, "benefitplanversionid", "run_id,uah_timestamp")
    beneCodeSrvcTypeViewDf.createOrReplaceTempView("benecodesrvctypeview")

    val beneStopLossOopDf = getMergeDataWithDedup(tblList(28)+"_cir", sparkSession, "benefitplanversionid", "run_id,uah_timestamp")
    beneStopLossOopDf.createOrReplaceTempView("benestoplossoop")

    // Join the tables to get the 1st extract
    val genAccntInfoDf = sparkSession.sql(ReadJson.getProperty("spdrendtl_general_account_info"))
    genAccntInfoDf.createOrReplaceTempView("genaccntinfo")

    // Generate BO extract from the general accnt info aggregate layer dataframe
    val genAccntInfoBoreportDf = sparkSession.sql(ReadJson.getProperty("spdrendtl_general_account_info_boreport"))
    CommonFunctions.saveDataframeAsFile(genAccntInfoBoreportDf, tgtLoc1, "overwrite")

    // Join the tables to get the 2nd extract
    val renewalSummDf = sparkSession.sql(ReadJson.getProperty("spdrendtl_renewal_summary"))
    renewalSummDf.createOrReplaceTempView("renewalsumm")

    // Generate the inplan and outplan dataframes
    val renewalSummOutplanDf = sparkSession.sql(ReadJson.getProperty("spdrendtl_renewal_summary_outplan"))
    val renewalSummInplanDf = sparkSession.sql(ReadJson.getProperty("spdrendtl_renewal_summary_inplan"))

    // Generate BO extract from the renewal summary aggregate layer dataframe
    val renewalSummBoreportDf = CommonFunctions.unionDataframes(renewalSummOutplanDf,renewalSummInplanDf)
    CommonFunctions.saveDataframeAsFile(renewalSummBoreportDf, tgtLoc2, "overwrite")

  }


  def getMergeDataWithDedup(tblName: String, sparkSession:SparkSession, grpByCols: String, orderByCols: String): DataFrame = {

    val dropCols = orderByCols.split(",").toSeq
    // Load merge layer data into a dataframe
    val resultDf = CommonFunctions.dedupLogic(getMergeData(tblName, sparkSession), grpByCols, orderByCols).drop(dropCols: _*).dropDuplicates()

    resultDf
  }


  def getMergeData(tblName: String, sparkSession:SparkSession): DataFrame = {

    // Load merge layer data into a dataframe
    val resultDf = CommonFunctions.runSql(sparkSession, ReadJson.getProperty(tblName)).dropDuplicates()

    resultDf
  }

}