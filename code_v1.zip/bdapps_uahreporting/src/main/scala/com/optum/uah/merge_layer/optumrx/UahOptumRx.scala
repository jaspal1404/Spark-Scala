package com.optum.uah.merge_layer.optumrx

import com.optum.uah.function_library.{CommonFunctions, GlobalContext, ReadJson}
import com.optum.uah.function_library.CrossRefUtility
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

/**
  * Created by mkadiyal on 10/20/2017.
  */
object UahOptumRx {
  def main(args: Array[String]): Unit = {
    val tgtLoc =args(0)            //"/datalake/optum/optuminsight/d_uah/developer/mkadiyal/tables/rcex1p"         //
    val propFilePath = args(1)
    val subjArea = args(2) //clmp02extg_rcex1p
    val tblName = tgtLoc.split("mergelayer/")(1)

    val workingDir =  tgtLoc.split("/"+tblName).head+ "/working/" +  tblName
    //    val dbName = "df2_rx2_odfr2tst"               //args(3)
    val GlobalContext = new GlobalContext()
    val CommonFunctions = new CommonFunctions()
    var jobLastRunTimestamp = "\""
    var maxLoadTimestamp = "\""
    jobLastRunTimestamp = jobLastRunTimestamp+ CommonFunctions.getHbaseMrglayerTs(tblName)+"\""
    println("Time stamp from Hbase before Loading:" + jobLastRunTimestamp)
    var sparkSession = GlobalContext.getCirrusLakeSession("Lake")
    /*
    var df = CommonFunctions.runSql(sparkSession, "select \nCLTDUEAMT,\nMEMBERID,\nCARRIERID,\nSRVPROVID,\nCLAIMSTS,\nDTEFILLED,\nDAYSSUPPLY,\nCLTATRDED,\nCLTDISPFEE,\nMNTDRUGCDE ,\nCLTCOPAY,\nSRVPROVID,\nCLTDUEAMT,\nRXCLAIMNBR,\nMULTSRCCDE,\nTIERVALUE ,\nPSC,\nMULTSRCCDE ,\nDATESBM,\nCLTSLSTAX,\nRXCLAIMNBR \nfrom df2_rx2_odfr2tst.clmp02extg_rcex1p_v1")
    var df_temp = sparkSession.createDataFrame(df.rdd, df.schema)
    CommonFunctions.runSql(sparkSession, "use "+dbName)
    val verCount = CommonFunctions.runSql(sparkSession, "show tables 'CLMP02EXTG_RCEX1P_v*'").count()
    //    var df_temp = sparkSession.emptyDataFrame
    for (a <- 1 to verCount.toInt) {
      println("Value of a: " + a)

      if (a > 1) {
        df = CommonFunctions.runSql(sparkSession, "select \nCLTDUEAMT,\nMEMBERID,\nCARRIERID,\nSRVPROVID,\nCLAIMSTS,\nDTEFILLED,\nDAYSSUPPLY,\nCLTATRDED,\nCLTDISPFEE,\nMNTDRUGCDE ,\nCLTCOPAY,\nSRVPROVID,\nCLTDUEAMT,\nRXCLAIMNBR,\nMULTSRCCDE,\nTIERVALUE ,\nPSC,\nMULTSRCCDE ,\nDATESBM,\nCLTSLSTAX,\nRXCLAIMNBR \nfrom df2_rx2_odfr2tst.clmp02extg_rcex1p_v" + a)
        df_temp = df_temp.union(df)

      }

    }
    */
    ReadJson.createJsonObject(propFilePath)
    val extractSql = ReadJson.getProperty(subjArea)
    val dfData = CommonFunctions.runSql(sparkSession,extractSql)
    val dfDelta = dfData.filter("uah_timestamp >= " + jobLastRunTimestamp)
    if (dfDelta.count() != 0){
      if(CommonFunctions.getListOfFiles("/mapr" + tgtLoc+"/source_cd=ORX").isEmpty){
        maxLoadTimestamp = dfDelta.agg(max("uah_timestamp")).first()(0).toString
        CommonFunctions.updateHbaseMrglayerTs(tblName, maxLoadTimestamp)
        CommonFunctions.saveDataframeAsFile(dfDelta,tgtLoc+"/source_cd=ORX","overwrite")
      } else{
        val mergeLayerDf = sparkSession.read.parquet(tgtLoc)
        val unionedDf = mergeLayerDf.union(dfDelta)
        val dedupDf=CommonFunctions.dedupLogic(unionedDf,"key","uah_timestamp")
        /* CommonFunctions.dedupLogic taken care here
         val rank_df = unionedDf.withColumn("rank", row_number.over(Window.partitionBy("key").orderBy(col("uah_timestamp").desc)))
         val temp_df = rank_df.filter("rank = '1'")
         val write_df = temp_df.drop("rank")
         */
        maxLoadTimestamp = dedupDf.agg(max("uah_timestamp")).first()(0).toString
        CommonFunctions.updateHbaseMrglayerTs(tblName, maxLoadTimestamp)
        CommonFunctions.saveDataframeOverwriteAsFile(sparkSession, dedupDf, tgtLoc+"/source_cd=ORX", workingDir)

      }
    }
  }
}
