package com.optum.uah.function_library

import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import com.optum.uah.function_library._
import org.apache.hadoop.fs.{ FileSystem, Path }
import org.apache.hadoop.hbase.HBaseConfiguration
import org.apache.hadoop.hbase.client.{ Get, HBaseAdmin, HTable, Put }
import org.apache.hadoop.hbase.mapreduce.TableInputFormat
import org.apache.hadoop.hbase.util.Bytes
import org.apache.hadoop.fs.Path
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{ DataFrame, Dataset, SparkSession }
import com.optum.uah.function_library.Logger.log
import org.apache.spark.sql.SaveMode
import org.apache.commons.io.FileUtils

/**
  * <h1>Common Functions</h1>
  * Reusable functions across the project realetd to dataframes,datasets, hive table utilities
  * <p>
  * Only generic functions should be added here
  *
  * @author dbhatta3
  * @version 1.0
  */
class CommonFunctions {
  val GContext = new GlobalContext()
  def createDataFrame(sparkSession: SparkSession, path: String, fileFormat: String): DataFrame = {
    if (path == null || path.isEmpty()) {
      throw NoSuchPathException("Path is empty")
    }
    sparkSession.read.format(fileFormat).load(path)
  }

  def readPropertiesFile(path: String): java.util.Properties = {
    if (path == null || path.isEmpty()) {
      throw NoSuchPathException("Path is empty")
    }
    var hadoopConf = new org.apache.hadoop.conf.Configuration()
    var fileSystem = FileSystem.get(hadoopConf)
    var Path = new Path(path)
    val inputStream = fileSystem.open(Path)
    var Properties = new java.util.Properties
    Properties.load(inputStream)
    Properties
  }

  def extractIncrementalCirrus(df: DataFrame): DataFrame = { null }

  def createView(df: DataFrame, viewName: String): Unit = {
    df.createOrReplaceTempView(viewName)
  }

  def createViewFromDataset[T](df: Dataset[T], viewName: String): Unit = {
    df.createOrReplaceTempView(viewName)
  }

  def repartionDataFrame(df: DataFrame, partionKey: String, numPartitions: Integer): Unit = {
    df.repartition(numPartitions, df.col(partionKey))

  }

  def runSql(sparkSession: SparkSession, sqlQuery: String): DataFrame = {
    println("Execution query : \n" + sqlQuery)
    val query = replaceDatabaseFromProp(sparkSession, sqlQuery)
    sparkSession.sql("set spark.sql.caseSensitive=false")
    sparkSession.sql(query)
  }

  def replaceDatabaseFromProp(sparkSession: SparkSession, sqlQuery: String): String = {

    println("**************************************Calling replace*********************************")
    var query: String = sqlQuery
    if (sqlQuery.contains("RNACIRRUSDB")) {
      println("************rna database is*****************" + sparkSession.conf.get("spark.database.cirrus.rnatenant"))
      query = query.replaceAll("RNACIRRUSDB", sparkSession.conf.get("spark.database.cirrus.rnatenant"))
    }
    if (sqlQuery.contains("DATALAKECIRRUSDB")) {
      query = query.replaceAll("DATALAKECIRRUSDB", sparkSession.conf.get("spark.database.cirrus.datalake"))
    }
    if (sqlQuery.contains("UAHCDWDB")) {
      println("************cdw database is*****************" + sparkSession.conf.get("spark.database.legacy.cdw"))
      query = query.replaceAll("UAHCDWDB", sparkSession.conf.get("spark.database.legacy.cdw"))
    }
    if (sqlQuery.contains("ADDDB")) {
      query = query.replaceAll("ADDDB", sparkSession.conf.get("spark.database.cirrus.additional"))
    }
    if (sqlQuery.contains("MDMDB")) {
      query = query.replaceAll("MDMDB", sparkSession.conf.get("spark.database.cirrus.mdm"))
    }
    if (sqlQuery.contains("DEFAULT")) {
      query = query.replaceAll("DEFAULT", sparkSession.conf.get("spark.database.default"))
    }
    if (sqlQuery.contains("MERGEDB.")) {
      query = query.replaceAll("MERGEDB", sparkSession.conf.get("spark.database.uah.merge"))
    }
    if (sqlQuery.contains("MERGEDBDLY.")) {
      query = query.replaceAll("MERGEDBDLY", sparkSession.conf.get("spark.database.uah.merge_dly"))
    }
    if (sqlQuery.contains("MERGEDBMTH.")) {
      query = query.replaceAll("MERGEDBMTH", sparkSession.conf.get("spark.database.uah.merge_mth"))
    }
    if (sqlQuery.contains("RX2LAKEDB")) {
      query = query.replaceAll("RX2LAKEDB", sparkSession.conf.get("spark.database.lake.rx2"))
    }
    query
  }

  def saveAsFile(df: DataFrame, format: String, path: String) {
    log.info("Saving the dataframe" + df.rdd.name + " to the path" + path)
    if (null == format)
      df.write.save(path)
    else
      df.write.format(format).save(path)
  }

  def saveAsFileforDataset[T](df: Dataset[T], format: String, path: String) {
    log.info("Saving the dataset" + df.rdd.name + " to the path" + path)
    if (null == format)
      df.write.save(path)
    else
      df.write.format(format).save(path)

  }

  def saveAsTable(df: DataFrame, hiveTablePath: String, format: String, tableName: String) {
    val options = Map("HIVE_CONF_DIR" -> hiveTablePath)
    df.write.format(format).option("hive.metastore.warehouse.dir", "/mapr/datalake/optum/optuminsight/d_uah/hive/warehouse").saveAsTable(tableName)
  }

  def createExternalTableFromParquet(sparkSession: SparkSession, path: String, tableName: String, databaseName: String) {
    log.info("Saving the table " + tableName + " as external table with path " + path + " to database " + databaseName)
    val df = sparkSession.read.parquet(path)
    val cols = df.dtypes
    var drop = "DROP TABLE IF EXISTS " + databaseName + "." + tableName
    var dd = "CREATE EXTERNAL TABLE IF NOT EXISTS " + databaseName + "." + tableName + " ("
    //looks at the datatypes and columns names and puts them into a string
    val colCreate = (for (c <- cols) yield (c._1 + " " + c._2.replace("Type", ""))).mkString(", ")
    dd += colCreate + ") STORED AS PARQUET LOCATION '" + path + "'"
    sparkSession.sql(drop)
    sparkSession.sql(dd)

  }

  def writeToParquet(df: DataFrame, path: String) {
    df.write.mode("overwrite").parquet(path)
  }

  //Below lines of code being addeed as part of the master branch merge

  def unionDataframes(df1: DataFrame, df2: DataFrame): DataFrame = {

    val unionedDf = df1.union(df2)
    unionedDf

  }

  // Overloaded dedup function which takes Array of columns instead of a single column,
  // This dedup function is required when we identify the records based on the columns other than key columns,
  // columns can be passed as an arguments

  def dedupLogic(inputDf: DataFrame, grpByCols: String, orderByCols: String): DataFrame = {

    val grpByColSeq = grpByCols.split(";").toSeq.map(x => col(x))
    val orderByColSeq = orderByCols.split(",").toSeq.map(x => col(x).desc)

    val w = Window.partitionBy(grpByColSeq: _*).orderBy(orderByColSeq: _*)
    val dedupDf = inputDf.withColumn("rn", dense_rank.over(w)).where(col("rn") === 1).drop("rn")

    dedupDf
  }

  def dedupLogic(inputDf: DataFrame): DataFrame = {
    println("Doing dedup")
    val tempDf = inputDf.groupBy("key").agg(max("uah_timestamp").alias("r_uah_timestamp")).withColumnRenamed("key", "r_key")
    val dedupDf = inputDf.join(tempDf, inputDf("key") === tempDf("r_key") && inputDf("uah_timestamp") === tempDf("r_uah_timestamp")).drop("r_key").drop("r_uah_timestamp")

    dedupDf
  }

  /* def dedupLogic(inputDf: DataFrame, flag: Boolean): DataFrame = {
     if (!flag) {
       return dedupLogic(inputDf)
     }
     val tempDf = inputDf.groupBy("key").agg(max("uah_timestamp").alias("r_uah_timestamp"), max("run_id").alias("r_run_id")).withColumnRenamed("key", "r_key")
     val dedupDf = inputDf.join(tempDf, inputDf("key") === tempDf("r_key") && inputDf("uah_timestamp") === tempDf("r_uah_timestamp") && inputDf("run_id") === tempDf("r_run_id")).drop("r_key").drop("r_uah_timestamp").drop("r_run_id")

     dedupDf
   }*/

  def getListOfFiles(dir: String): List[File] = {
    val d = new File(dir)
    if (d.exists && d.isDirectory) {
      d.listFiles.filter(_.isFile).toList
    } else {
      List[File]()
    }
  }

  def deleteListOfFiles(dir: String): Unit = {
    val d = new File(dir)
    if (d.exists && d.isDirectory) {
      //      d.listFiles.filter(_.delete())
      d.delete()
    }
  }

  def getPreviousDateByMonths(months: Int): String = {

    val cal = Calendar.getInstance()
    val currDay = Calendar.getInstance().get(5) - 1
    cal.add(Calendar.DAY_OF_MONTH, -currDay)
    cal.add(Calendar.MONTH, -months)

    val outDate = new SimpleDateFormat("yyyy-MM-dd").format(cal.getTime())

    outDate

  }

  def saveDataframeAsFile(srcDataframe: DataFrame, path: String, mode: String): Unit = {

    if (mode == "append") {
      //      println("count is append"+srcDataframe.count())
      //      println("path in append"+path)
      srcDataframe.write.mode("append").save(path)
    } else {
      //println("count is overwrite"+srcDataframe.count())
      println("path in overwrite" + path)
      srcDataframe.write.mode("overwrite").save(path)
    }

  }
  def getMergeTblData(tgtLoc: String, sparkSession: SparkSession): DataFrame = {
    val resultDf = sparkSession.read.parquet(tgtLoc)
    resultDf
  }

  // This function not need as we are not using partitionBy clause, please use saveDataframeAsFile function instead.
  /*
  def saveDataframeAsFileWithPartition(srcDataframe: DataFrame, path: String, mode: String): Unit = {

    if (mode == "append") {
      srcDataframe.repartition(1).write.mode("append").partitionBy("source_cd").save(path)
    }
    else {
      srcDataframe.repartition(1).write.mode("overwrite").partitionBy("source_cd").save(path)
    }
  }
*/

  /*Below coede login is to write a dataset to a temporary location and read and write
  * This is required when reading and writing back to same location
  */
  def saveDataframeOverwriteAsFile(sparkSession: SparkSession, srcDataframe: DataFrame, path: String, workingDir: String): Unit = {

    srcDataframe.write.mode("overwrite").save(workingDir)
    val tempDf = sparkSession.read.parquet(workingDir)
    println("Record Count from temmporary dataframe before writes to final DF: ")

    //tempDf.createOrReplaceTempView("tempDFTable")
    //val finalWriteDF = sparkSession.sql("select * from tempDFTable")
    //println("Final record Count from dataframe to write the final result: " + finalWriteDF.count())
    tempDf.write.mode("overwrite").save(path)

  }

  def Datatype_Matching(srcDataframe: DataFrame, tgtDataframe: DataFrame): DataFrame = {

    // arg1: legacy dataframe
    // arg2: cirrus dataframe

    var tmp_df = srcDataframe
    if (tgtDataframe == "Null") {
      for (cir_field <- srcDataframe.schema.fields) {
        val cir_field_datatype = cir_field.dataType.toString()
        if ((cir_field_datatype.startsWith("Decimal")) && (cir_field_datatype.endsWith(",0)"))) {
          tmp_df = tmp_df.withColumn(cir_field.name, tmp_df(cir_field.name).cast("BIGINT"))
        } else if (cir_field_datatype.startsWith("Decimal")) {
          tmp_df = tmp_df.withColumn(cir_field.name, tmp_df(cir_field.name).cast("Double"))
        }

      }
    } else {
      for ((leg_field, cir_field) <- (srcDataframe.schema.fields zip tgtDataframe.schema.fields)) {

        val leg_field_datatype = leg_field.dataType.toString()
        val cir_field_datatype = cir_field.dataType.toString()

        tmp_df = tmp_df.withColumnRenamed(leg_field.name, cir_field.name)

        if (leg_field_datatype != cir_field_datatype) {
          tmp_df = tmp_df.withColumn(cir_field.name, tmp_df(cir_field.name).cast(cir_field_datatype.split("Type")(0)))

        }

      }
    }

    tmp_df
  }

  /* Below section is to get the Hbase timestamp
   *
   */

  def getHbaseMrglayerTs(mergeTable: String): String = {

    val conf = HBaseConfiguration.create()
    val hbaseTrkTblname = GContext.hbaseTblLocation
    conf.addResource(new Path(GContext.hbaseHbaseSiteLocation))
    conf.set(TableInputFormat.INPUT_TABLE, hbaseTrkTblname)
    val admin = new HBaseAdmin(conf)
    val myTable = new HTable(conf, hbaseTrkTblname)

    val theGet = new Get(Bytes.toBytes(mergeTable))
    val result = myTable.get(theGet)
    val crntTs = result.value()
    var tsVlue = Bytes.toString(crntTs)
    println(tsVlue)
    tsVlue
  }

  def getHbaseMrglayerTs(sparkSession: SparkSession, mergeTable: String, freq: String): String = {
    var colName = ""
    if (freq == "daily") {
      colName=sparkSession.conf.get("spark.hbase.colname.daily")
    }
    else if (freq == "monthly") {
      colName=sparkSession.conf.get("spark.hbase.colname.monthly")
    }
    else {
      println("Please specify correct frequency daily/monthly")
    }

    val conf = HBaseConfiguration.create()
    val hbaseTrkTblname = GContext.hbaseTblLocation
    conf.addResource(new Path(GContext.hbaseHbaseSiteLocation))
    conf.set(TableInputFormat.INPUT_TABLE, hbaseTrkTblname)
    val admin = new HBaseAdmin(conf)
    val myTable = new HTable(conf, hbaseTrkTblname)

    val theGet = new Get(Bytes.toBytes(mergeTable))
    val result = myTable.get(theGet)
    import org.apache.hadoop.hbase.util.Bytes
    //Column Family is hardcoded to "pi"

    val value = result.getValue(Bytes.toBytes("pi"), Bytes.toBytes(colName))
    var tsVlue = Bytes.toString(value)
    println(tsVlue)
    tsVlue
  }

  def updateHbaseMrglayerTs(mergeTable: String, maxLoadTimestamp: String): Unit = {

    val conf = HBaseConfiguration.create()
    val hbaseTrkTblname = GContext.hbaseTblLocation
    conf.addResource(new Path(GContext.hbaseHbaseSiteLocation))
    conf.set(TableInputFormat.INPUT_TABLE, hbaseTrkTblname)
    val admin = new HBaseAdmin(conf)
    val myTable = new HTable(conf, hbaseTrkTblname)
    //Update hbase table with current timestamp
    var p = new Put(mergeTable.getBytes())
    p.add("pi".getBytes(), "load_ts".getBytes(), maxLoadTimestamp.getBytes())
    myTable.put(p);

    myTable.flushCommits();
  }

  def updateHbaseMrglayerTs(sparkSession: SparkSession, mergeTable: String, maxLoadTimestamp: String, freq: String): Unit = {
    var colName = ""
    if (freq == "daily") {
      colName=sparkSession.conf.get("spark.hbase.colname.daily")
    }
    else if (freq == "monthly") {
      colName=sparkSession.conf.get("spark.hbase.colname.monthly")
    }
    else {
      println("Please specify correct frequency daily/monthly")
    }
    val conf = HBaseConfiguration.create()
    val hbaseTrkTblname = GContext.hbaseTblLocation
    conf.addResource(new Path(GContext.hbaseHbaseSiteLocation))
    conf.set(TableInputFormat.INPUT_TABLE, hbaseTrkTblname)
    val admin = new HBaseAdmin(conf)
    val myTable = new HTable(conf, hbaseTrkTblname)
    //Update hbase table with current timestamp
    var p = new Put(mergeTable.getBytes())
    p.add("pi".getBytes(), colName.getBytes(), maxLoadTimestamp.getBytes())
    myTable.put(p);

    myTable.flushCommits();
  }

  def updateHbaseMrglayerTs(mergeTable: String): String = {

    val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:sss")
    var currentTime = format.format(java.lang.System.currentTimeMillis())
    val conf = HBaseConfiguration.create()
    val hbaseTrkTblname = GContext.hbaseTblLocation //sparkUAH.conf.get("spark.connection.thrift.uah.cdw")
    conf.addResource(new Path(GContext.hbaseHbaseSiteLocation)) //sparkUAH.conf.get("spark.connection.thrift.uah.cdw")
    conf.set(TableInputFormat.INPUT_TABLE, hbaseTrkTblname)
    val admin = new HBaseAdmin(conf)
    val myTable = new HTable(conf, hbaseTrkTblname)
    //Update hbase table with current timestamp
    var p = new Put(mergeTable.getBytes())
    p.add("pi".getBytes(), "load_ts".getBytes(), currentTime.toString.getBytes())
    myTable.put(p);

    myTable.flushCommits();
    currentTime
  }

  def dedupLogicLegacy(inputDf: DataFrame, dedupID: String): DataFrame = {

    val tempDf = inputDf.groupBy(dedupID).agg(max("uah_timestamp") as "r_uah_timestamp").withColumnRenamed(dedupID, "r_" + dedupID)
    val dedupDf = inputDf.join(tempDf, inputDf(dedupID) === tempDf("r_" + dedupID) && inputDf("uah_timestamp") === tempDf("r_uah_timestamp")).drop("r_" + dedupID).drop("r_uah_timestamp")

    dedupDf
  }
  def legacyMemGroupdentitfier(sparkSession: SparkSession, lgcyMemGrpIden: DataFrame, memGrpIdColName: String, dbName: String): DataFrame =
  {

    // select memgroupid,originalSourceSystemID  from memGroupExternalID
    //where originalSourceSystemType = 'PUL' and
    //originalSourceSystemID = <Pulse ID>(pulse_group_code(priot) or pulse goupid)
    val uahMemMerLayer = "UAH_" + memGrpIdColName
    val extsrcId = memGrpIdColName + "_EXT_SRC"

    // val lgcyMemGrpIden = inputDS.toDF()
    import sparkSession.implicits._

    createView(lgcyMemGrpIden, "lgcyMemGrpIden")
    val memGrpExt = runSql(sparkSession, "select memgroupid,originalSourceSystemID  from " + dbName + ".memgroupid_std where trim(originalSourceSystemType) = 'PUL'")

    createView(memGrpExt, "memGrpExt")

    val joinedRefPul = runSql(sparkSession, "select input.*, ref.memgroupid as " + extsrcId + " ,coalesce(ref.memgroupid , input." + memGrpIdColName + ") as " + uahMemMerLayer + "  from lgcyMemGrpIden input left join memGrpExt ref on trim(input." + memGrpIdColName + ") = trim(ref.originalSourceSystemID)")

    //joinedRefPul.withColumn("Ext_src_cd", when((col(extsrcId) isNotNull), lit("CRS")))
    joinedRefPul.withColumn("Ext_src_cd", lit("CRS"))
  }

  def saveAsFileWithPartition(df: DataFrame, format: String, path: String, partCol: String) {
    log.info("Saving the dataframe" + df.rdd.name + " to the path" + path + " with parttition column " + partCol)
    if (null == format)
      df.write.mode(SaveMode.Overwrite).partitionBy(partCol).save(path)
    else
      df.write.mode(SaveMode.Overwrite).format(format).partitionBy(partCol).save(path)
  }

  def createExternalTableFromParquetWithPartition(sparkSession: SparkSession, path: String, tableName: String, databaseName: String, colName: String, colType: String) {
    log.info("Saving the table " + tableName + " as external table with path " + path + " to database " + databaseName)
    val df = sparkSession.read.parquet(path)
    val cols = df.dtypes
    var drop = "DROP TABLE IF EXISTS " + databaseName + "." + tableName
    var dd = "CREATE EXTERNAL TABLE IF NOT EXISTS " + databaseName + "." + tableName + " ("
    //looks at the datatypes and columns names and puts them into a string
    val colCreate = (for { c <- cols if (!(c._1.equals(colName))) } yield (c._1 + " " + c._2.replace("Type", ""))).mkString(", ")
    dd += colCreate + ") PARTITIONED BY (" + colName + " " + colType + ") STORED AS PARQUET LOCATION '" + path + "'"
    sparkSession.sql(drop)

    log.info("Create statement query " + dd)
    sparkSession.sql(dd)
    log.info("starting the Repair")
    sparkSession.sql("MSCK REPAIR TABLE " + databaseName + "." + tableName);
    log.info("Completed Table Repair")

  }
  def incrDataLoad(tablename: String, cirrusDataFrame: DataFrame, path: String, sparkSession: org.apache.spark.sql.SparkSession): DataFrame = {
    incrDataLoad(tablename, cirrusDataFrame, path, sparkSession, true)
  }
  def incrDataLoad(tablename: String, cirrusDataFrame: DataFrame, path: String, sparkSession: org.apache.spark.sql.SparkSession, flag: Boolean): DataFrame = {
    var filteredDataFrame = sparkSession.emptyDataFrame
    var dedupDf = sparkSession.emptyDataFrame
    var maxLoadTimestamp = getHbaseMrglayerTs(tablename)
    println("max load timestamp" + maxLoadTimestamp)
    //println("Total count original" + cirrusDataFrame.count())
    if (maxLoadTimestamp != null) {
      println("1st loop")
      filteredDataFrame = cirrusDataFrame.filter("uah_timestamp > \"" + maxLoadTimestamp + "\"")
    } else {
      println("2st loop")
      filteredDataFrame = cirrusDataFrame
    }
    //TODO no need to rewriting the dataframe make this only incremental and full load create one more function where you check till CRS
    // println("count is more than zero")
    /*var newmaxLoadTimestamp = filteredDataFrame.agg(max("uah_timestamp")).first()(0).toString //this dataframe has either full or incr
      println("new max load timestamp"+newmaxLoadTimestamp)*/

    import sparkSession.implicits._
    log.info("Getting attributes for" + tablename + "cirrus table from RnA tenant")
    if (getListOfFiles("/mapr" + path).isEmpty) {
      println("full load")
      saveDataframeAsFile(filteredDataFrame, path, "overwrite")
    } else {
      println("incr load")
      val mergeFullDf = getMergeTblData(path, sparkSession)
      //println("Old data count" + mergeFullDf.count())
      val unionedDf = unionDataframes(mergeFullDf, filteredDataFrame)
      //println("union data count" + unionedDf.count())
      if(flag)
        dedupDf = dedupLogic(unionedDf, "key", "run_id,uah_timestamp")
      else
        dedupDf = dedupLogic(unionedDf)
      // println("dedupDf data count" + dedupDf.count())
      val temppath = path.replaceFirst("source_cd=CRS", "temp")
      println("temp path is " + temppath)
      saveDataframeAsFile(dedupDf, temppath, "overwrite")

      deletePath("/mapr" + path)
      FileUtils.copyDirectory(new File("/mapr" + temppath), new File("/mapr" + path))
      deletePath("/mapr" + temppath)
    }
    //updateHbaseMrglayerTs(tablename, newmaxLoadTimestamp)
    filteredDataFrame
  }
  def incrDataLoad(tablename: String, cirrusDataFrame: DataFrame, path: String, sparkSession: org.apache.spark.sql.SparkSession, flag: Boolean,feq: String): DataFrame = {
   
    var filteredDataFrame = sparkSession.emptyDataFrame
    var dedupDf = sparkSession.emptyDataFrame
    var maxLoadTimestamp = getHbaseMrglayerTs(sparkSession,tablename,feq)
    println("max load timestamp" + maxLoadTimestamp)
    //println("Total count original" + cirrusDataFrame.count())
    if (maxLoadTimestamp != null) {
      println("1st loop")
      filteredDataFrame = cirrusDataFrame.filter("uah_timestamp > \"" + maxLoadTimestamp + "\"")
    } else {
      println("2st loop")
      filteredDataFrame = cirrusDataFrame
    }
    //TODO no need to rewriting the dataframe make this only incremental and full load create one more function where you check till CRS
    // println("count is more than zero")
    /*var newmaxLoadTimestamp = filteredDataFrame.agg(max("uah_timestamp")).first()(0).toString //this dataframe has either full or incr
      println("new max load timestamp"+newmaxLoadTimestamp)*/

    import sparkSession.implicits._
    log.info("Getting attributes for" + tablename + "cirrus table from RnA tenant")
    if (getListOfFiles("/mapr" + path).isEmpty) {
      println("full load")
      saveDataframeAsFile(filteredDataFrame, path, "overwrite")
    } else {
      println("incr load")
      val mergeFullDf = getMergeTblData(path, sparkSession)
      //println("Old data count" + mergeFullDf.count())
      val unionedDf = unionDataframes(mergeFullDf, filteredDataFrame)
      //println("union data count" + unionedDf.count())
      if(flag)
        dedupDf = dedupLogic(unionedDf, "key", "run_id,uah_timestamp")
      else
        dedupDf = dedupLogic(unionedDf)
      // println("dedupDf data count" + dedupDf.count())
      val temppath = path.replaceFirst("source_cd=CRS", "temp")
      println("temp path is " + temppath)
      saveDataframeAsFile(dedupDf, temppath, "overwrite")

      deletePath("/mapr" + path)
      FileUtils.copyDirectory(new File("/mapr" + temppath), new File("/mapr" + path))
      deletePath("/mapr" + temppath)
    }
    //updateHbaseMrglayerTs(tablename, newmaxLoadTimestamp)
    filteredDataFrame
  }
  def deletePath(path: String): Unit = {
    println("Path to be deleted: " + path)

    val d = new File(path)
    FileUtils.deleteDirectory(d)

    if (d.exists() || d.isDirectory()) {
      println("delete directory " + d + " did not went successfully!")
    }

  }

  def renameDir(sc : org.apache.spark.SparkContext ,from: String,to: String): Unit = {
    println("dir to be renamed: " + from +" to "+to)
    val fs = FileSystem.get(sc.hadoopConfiguration)
    val fromdir = new File(from)
    val todir = new File(to)
    val res : Boolean = fs.rename(new Path(from) , new Path(to))
    if(res)
    { println("rename successfull")}else{ println("rename unsuccessfull")}
    if (todir.exists() || todir.isDirectory()) {
      println("rename directory " +todir + " did  went successfully!")
    }

  }
}