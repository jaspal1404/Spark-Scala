package com.optum.uah.aggregate_layer

import com.optum.uah.aggregate_layer.HCEMedicalClaims.{CommonFunctions, getMergeData}
import com.optum.uah.function_library.{CommonFunctions, GlobalContext, ReadJson}
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.log4j.Logger
import org.apache.spark.sql.functions.{col, collect_list}
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * Created by Team Falcons as part of UAH 10/26/2017.
  */
object EncountersCustomer {

  val CommonFunctions = new CommonFunctions()
  val GlobalContext = new GlobalContext()
  val log: Logger = Logger.getLogger(getClass.getName)


  def main(args: Array[String]): Unit = {

    val tgtLoc = args(0)
    val tblList = List("memgroupaddress_std", "memgroupid_std", "memgroupcontractview_std")
    val tblName = tgtLoc.split("aggregate_layer/")(1)
    val propFilePath = args(1)
    val outboundLoc = args(2)

    // Log info
    log.info("Job Name: " + tblName + " aggregate layer extract")
    log.info("Job Group: Underwriting")
    log.info("Event1: Job execution started")

    //Load json property file to get sql based on the subject area and table
    ReadJson.createJsonObject(propFilePath)

    // Load spark session for uah metastore
    val sparkSession = GlobalContext.getUAHSession("encountersCustomer")

    // Load the cirrus data from merge layer table1
    val mbrGrpAddress = getMergeData(tblList(0) + "_cir", sparkSession).dropDuplicates()

    // Load the cirrus data from merge layer table2
    //val mbrgrpId = getMergeData(tblList(1)+"_cir", sparkSession).dropDuplicates()
    val mbrgrpId = CommonFunctions.dedupLogic(getMergeData(tblList(1) + "_cir", sparkSession), "uah_memgroupid,originalsourcesystemid", "run_id,uah_timestamp,uah_memgroupid,memgrouptinid,memgroupexternalidid,memgroupaliasid").drop("uah_timestamp", "memgrouptinid", "memgroupexternalidid", "memgroupaliasid").dropDuplicates()

    // Load the cirrus data from merge layer table3
    //val mbrGrpCntrct = getMergeData(tblList(2)+"_cir", sparkSession).dropDuplicates()
    val mbrGrpCntrct = CommonFunctions.dedupLogic(getMergeData(tblList(2) + "_cir", sparkSession), "uah_memgroupgid,uah_memgroupcontractgcid", "run_id,uah_timestamp,changedatetime").drop("uah_timestamp", "run_id", "changedatetime").dropDuplicates()


    // Join the tables to
    val joinedDf1 = mbrGrpAddress.join(mbrgrpId, mbrGrpAddress("uah_memgroupid") === mbrgrpId("uah_memgroupid"), "leftouter").drop(mbrgrpId("uah_memgroupid"))
    val finalDf = joinedDf1.join(mbrGrpCntrct, col("uah_memgroupid") === col("uah_memgroupgid"), "leftouter").drop(mbrGrpCntrct("uah_memgroupgid")).drop(mbrGrpAddress("uah_memgroupid"))

    // Save unioned data into aggregate layer
    CommonFunctions.saveDataframeAsFile(finalDf, tgtLoc, "overwrite")

    // Write a text file extract from the parquet data
    finalDf.repartition(1).write.option("delimiter", "|").mode("overwrite").option("header", "true").csv(outboundLoc)

    // Rename the text delimited file
    val sc = sparkSession.sparkContext
    val fs = FileSystem.get(sc.hadoopConfiguration)
    val fileName = fs.globStatus(new Path(outboundLoc + "/*.csv"))(0).getPath().getName()
    fs.rename(new Path(outboundLoc + "/" + fileName), new Path(outboundLoc + "/encounters_customer.dat"))

    log.info("Record count: " + finalDf.count())
    log.info("Event2: Job completed")

    sparkSession.close()

  }


  def getMergeData(tblName: String, sparkSession: SparkSession): DataFrame = {

    // Load merge layer data into a dataframe
    val resultDf = CommonFunctions.runSql(sparkSession, ReadJson.getProperty(tblName).stripPrefix("List(").stripSuffix(")"))

    resultDf
  }


  def generateDiagCodes(tblName: String, sparkSession: SparkSession, colName: String): DataFrame = {

    val df1 = CommonFunctions.runSql(sparkSession, ReadJson.getProperty(tblName))
    var df2 = df1.groupBy("claimid").agg(collect_list(colName).as("ICD_CODE"))
    for (i <- 0 to 24) {
      df2 = df2.withColumn("icd_code_" + (i + 1), col("ICD_CODE").apply(i))
    }
    df2 = df2.drop("ICD_CODE")

    df2
  }

}
