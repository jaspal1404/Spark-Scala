  package com.optum.uah.merge_layer.customereligibility;
  import org.apache.hadoop.fs._
  import com.optum.uah.function_library.{ CommonFunctions, GlobalContext, ReadJson }
  import org.apache.spark.sql.Dataset
  import org.apache.spark.sql.DataFrame
  import org.apache.spark.sql.SparkSession
  import com.optum.uah.function_library.Logger.log
  import org.apache.spark.sql.functions._
  import org.apache.hadoop.fs.{ FileStatus, Path, FileSystem }
  import java.util.Properties
  import java.util.Scanner
  import java.io.File
  import java.io.FileInputStream
  
  object UAHCirCustomerEligibility {
    val GContext = new GlobalContext()
    val func = new CommonFunctions()
  
    val sparkUAH = GContext.getUAHSession("CustomerEligibilityUAH")
    val sparkRNA = GContext.getRnASession("CERnA")
    
      def main(args: Array[String]): Unit = {
  
       var properties=  new Properties()
       properties.load(new FileInputStream(new File(args(0))))
       
       val jsonLoc = properties.getProperty("spark.hdfs.jsonpath")
       val tgtLoc = properties.getProperty("spark.hdfs.tgtpath")
       val memgroupcontractrenewalPath = properties.getProperty("spark.hdfs.memgroupcontractrenewalpath")
       val memgroupcontractrenewalTbl  = properties.getProperty("spark.database.memgroupcontractrenewaltablename")
       val oonpricingschednoteviewPath = properties.getProperty("spark.hdfs.oonpricingschednoteviewpath")
       val oonpricingschednoteviewTbl  = properties.getProperty("spark.database.oonpricingschednoteviewtablename")
       
       val oonpricingschedorderdetailviewPath = properties.getProperty("spark.hdfs.oonpricingschedorderdetailviewpath")
       val oonpricingschedorderdetailviewTbl  = properties.getProperty("spark.database.oonpricingschedorderdetailviewtablename")
                                                                                       
       
       val memgroupctrctplnoptnetwklistvwPath = properties.getProperty("spark.hdfs.memgroupctrctplnoptnetwklistvwpath")
       val memgroupctrctplnoptnetwklistvwTbl  = properties.getProperty("spark.database.memgroupctrctplnoptnetwklistvwtablename")
       
       log.info("memgroupcontractrenewalPath" + memgroupcontractrenewalPath)
       log.info("jsonLoc ::" + properties.getProperty("spark.hdfs.jsonpath"))
       log.info("tgtLoc ::" + properties.getProperty("spark.hdfs.tgtpath"))
       
       val CirrusCustomerEligibilityDF = this.getCirrusCustomerEligibilitymemgroupcontractrenewal_view(jsonLoc, memgroupcontractrenewalPath, memgroupcontractrenewalTbl)
       val CirrusCustomerEligibilitymemgroupctrctplnoptnetwklistvwTblDF=this.getCirrusCustomerEligibilitymemgroupctrctplnoptnetwklistvw_std(jsonLoc, memgroupctrctplnoptnetwklistvwPath, memgroupctrctplnoptnetwklistvwTbl)
       val CirrusCustomerEligibilityOonpricingschednoteviewDF=this.getCirrusCustomerEligibilityOonpricingschednoteview_std(jsonLoc, oonpricingschednoteviewPath, oonpricingschednoteviewTbl)
  
      val CirrusCustomerEligibilityOonpricingschedorderdetailviewDF=this.getCirrusCustomerEligibilityOonpricingschedorderdetailview_std(jsonLoc, oonpricingschedorderdetailviewPath, oonpricingschedorderdetailviewTbl)
      GContext.stop()
    }
  
    /* Defining  the main entry for a Spark submit . We normally use it for testing
  * */
  
    //Incremental Load
    def appendCirrusData(sparkRNA: SparkSession, targetLoc: String, tblName: String, jsonLoc: String, tgtDF: DataFrame) {
    var maxLoadTimestamp = func.getHbaseMrglayerTs(tblName)
      //var maxLoadTimestamp = "2017-10-18 00:00:00"
      ReadJson.createJsonObject(jsonLoc)
      log.info("Incremental Load")
      log.info("maxLoadTimestamp :" + maxLoadTimestamp)
    val fs = FileSystem.get(sparkRNA.sparkContext.hadoopConfiguration)
    val cirDeltaDf = tgtDF.filter("uah_timestamp > \"" + maxLoadTimestamp + "\"").dropDuplicates("key", "uah_timestamp")
      //log.info("cirDeltaDf Count::" + cirDeltaDf.count)
    if(cirDeltaDf.count()!=0){               
    val parquetDf = sparkRNA.read.option("inferSchema", "true").parquet(targetLoc)
    //val parquetDf = sparkRNA.read.parquet(targetLoc)
    //log.info("parquetDf Count::" + parquetDf.count)
    
    val cirrusDf = parquetDf.filter(col("source_cd") === "CRS").dropDuplicates
    val unionedCirrusDf = cirrusDf.union(cirDeltaDf)
      //log.info("unionedCirrusDf Count::" + unionedCirrusDf.count)
      //unionedCirrusDf.show()
  
    val dedupDf = func.dedupLogic(unionedCirrusDf).dropDuplicates
      //log.info("dedupDf Count :" + dedupDf.count)
   
      maxLoadTimestamp = dedupDf.agg(max("uah_timestamp")).first()(0).toString
      func.updateHbaseMrglayerTs(tblName, maxLoadTimestamp)
  
      dedupDf.write.mode("overwrite").partitionBy("source_cd").parquet(targetLoc+"_temp")
      fs.delete(new Path(targetLoc), true)
      fs.rename(new Path(targetLoc+"_temp"), new Path(targetLoc))
      }
      //else log.info("No New Records Exist as the Record Count is " + dedupDf.count)
    }
  
    //Load memgroupcontractrenewal_view table data into Merge Layer
    def getCirrusCustomerEligibilitymemgroupcontractrenewal_view(jsonLoc: String, memgroupcontractrenewalPath: String, memgroupcontractrenewalTbl: String) {
      //val sparkSession = GContext.getRnASession("CERnA")
      ReadJson.createJsonObject(jsonLoc)
      log.info("Getting attributes for memgroupcontractrenewal_view cirrus table from RnA tenant")
      val memgroupcontractrenewalDF = func.runSql(sparkRNA, ReadJson.getProperty("memgroupcontractrenewal_view"))
  
      if (!new java.io.File("/mapr" + memgroupcontractrenewalPath+ "/source_cd=CRS").exists) {
        log.info("Target Location Doesn't Exists :" + !new java.io.File("/mapr" + memgroupcontractrenewalPath+ "/source_cd=CRS").exists)
        memgroupcontractrenewalDF.write.format("parquet").save(memgroupcontractrenewalPath + "/source_cd=CRS")
        val maxLoadTimestamp = memgroupcontractrenewalDF.agg(max("uah_timestamp")).first()(0).toString
        func.updateHbaseMrglayerTs(memgroupcontractrenewalTbl, maxLoadTimestamp)
        log.info("Update maxLoadTimestamp in Hbase Table::" + maxLoadTimestamp)
      } else {
        //log.info("In Else Loop")
        log.info("Starting Incremental Load ")
        this.appendCirrusData(sparkRNA, memgroupcontractrenewalPath, memgroupcontractrenewalTbl, jsonLoc, memgroupcontractrenewalDF)
        log.info("Done with appendCirrusData")
      }
      log.info("memgroupcontractrenewalDF.printSchema()")
    }
    
     //Load Oonpricingschednoteview_std table data into Merge Layer
    def getCirrusCustomerEligibilityOonpricingschednoteview_std(jsonLoc: String, oonpricingschednoteviewPath: String, oonpricingschednoteviewTbl: String) {
      //val sparkSession = GContext.getRnASession("CERnA")
      ReadJson.createJsonObject(jsonLoc)
      log.info("Getting attributes for Oonpricingschednoteview_std cirrus table from RnA tenant")
      val onpricingschednoteviewDF = func.runSql(sparkRNA, ReadJson.getProperty("oonpricingschednoteview_std"))
  
      if (!new java.io.File("/mapr" + oonpricingschednoteviewPath+ "/source_cd=CRS").exists) {
        log.info("Target Location Doesn't Exists :" + !new java.io.File("/mapr" + oonpricingschednoteviewPath+ "/source_cd=CRS").exists)
        onpricingschednoteviewDF.write.format("parquet").save(oonpricingschednoteviewPath + "/source_cd=CRS")
        val maxLoadTimestamp = onpricingschednoteviewDF.agg(max("uah_timestamp")).first()(0).toString
        func.updateHbaseMrglayerTs(oonpricingschednoteviewTbl, maxLoadTimestamp)
        log.info("Update maxLoadTimestamp in Hbase Table::" + maxLoadTimestamp)
      } else {
        //log.info("In Else Loop")
        log.info("Starting Incremental Load ")
        this.appendCirrusData(sparkRNA, oonpricingschednoteviewPath, oonpricingschednoteviewTbl, jsonLoc, onpricingschednoteviewDF)
        log.info("Done with appendCirrusData")
      }
      log.info("onpricingschednoteviewDF.printSchema()")
    }
     
     
        //Load memgroupctrctplnoptnetwklistvw_std table data into Merge Layer
     def getCirrusCustomerEligibilitymemgroupctrctplnoptnetwklistvw_std(jsonLoc: String, memgroupctrctplnoptnetwklistvwPath: String, memgroupctrctplnoptnetwklistvwTbl: String) {
      //val sparkSession = GContext.getRnASession("CERnA")
      ReadJson.createJsonObject(jsonLoc)
      log.info("Getting attributes for memgroupctrctplnoptnetwklistvw_std cirrus table from RnA tenant")
      val memgroupctrctplnoptnetwklistvwDF = func.runSql(sparkRNA, ReadJson.getProperty("memgroupctrctplnoptnetwklistvw_std"))
                                                                                                        
      if (!new java.io.File("/mapr" + memgroupctrctplnoptnetwklistvwPath+ "/source_cd=CRS").exists) {
        log.info("Target Location Doesn't Exists :" + !new java.io.File("/mapr" + memgroupctrctplnoptnetwklistvwPath+ "/source_cd=CRS").exists)
        memgroupctrctplnoptnetwklistvwDF.write.format("parquet").save(memgroupctrctplnoptnetwklistvwPath + "/source_cd=CRS")
        val maxLoadTimestamp = memgroupctrctplnoptnetwklistvwDF.agg(max("uah_timestamp")).first()(0).toString
        func.updateHbaseMrglayerTs(memgroupctrctplnoptnetwklistvwTbl, maxLoadTimestamp)
        log.info("Update maxLoadTimestamp in Hbase Table::" + maxLoadTimestamp)
      } else {
        //log.info("In Else Loop")
        log.info("Starting Incremental Load ")
        this.appendCirrusData(sparkRNA, memgroupctrctplnoptnetwklistvwPath, memgroupctrctplnoptnetwklistvwTbl, jsonLoc, memgroupctrctplnoptnetwklistvwDF)
        log.info("Done with appendCirrusData")
      }
      log.info("memgroupctrctplnoptnetwklistvwDF.printSchema()")
    }
    
      //Load oonpricingschedorderdetailview_std table data into Merge Layer
     def getCirrusCustomerEligibilityOonpricingschedorderdetailview_std(jsonLoc: String, oonpricingschedorderdetailviewPath: String,oonpricingschedorderdetailviewTbl: String) {
      //val sparkSession = GContext.getRnASession("CERnA")
      ReadJson.createJsonObject(jsonLoc)
      log.info("Getting attributes for Oonpricingschednoteview_std cirrus table from RnA tenant")
      val oonpricingschedorderdetailviewDF = func.runSql(sparkRNA, ReadJson.getProperty("oonpricingschedorderdetailview_std"))
  
      if (!new java.io.File("/mapr" + oonpricingschedorderdetailviewPath+ "/source_cd=CRS").exists) {
        log.info("Target Location Doesn't Exists :" + !new java.io.File("/mapr" + oonpricingschedorderdetailviewPath+ "/source_cd=CRS").exists)
        oonpricingschedorderdetailviewDF.write.format("parquet").save(oonpricingschedorderdetailviewPath + "/source_cd=CRS")
        val maxLoadTimestamp = oonpricingschedorderdetailviewDF.agg(max("uah_timestamp")).first()(0).toString
        func.updateHbaseMrglayerTs(oonpricingschedorderdetailviewTbl, maxLoadTimestamp)
        log.info("Update maxLoadTimestamp in Hbase Table::" + maxLoadTimestamp)
      } else {
        //log.info("In Else Loop")
        log.info("Starting Incremental Load ")
        this.appendCirrusData(sparkRNA, oonpricingschedorderdetailviewPath, oonpricingschedorderdetailviewTbl, jsonLoc, oonpricingschedorderdetailviewDF)
        log.info("Done with appendCirrusData")
      }
      log.info("oonpricingschedorderdetailviewDF.printSchema()")
    }
  }

