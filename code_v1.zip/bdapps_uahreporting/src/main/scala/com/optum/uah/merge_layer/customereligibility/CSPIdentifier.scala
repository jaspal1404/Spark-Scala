package com.optum.uah.merge_layer.customereligibility

import com.optum.uah.function_library.{CommonFunctions, GlobalContext, ReadJson }
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.SparkSession
import com.optum.uah.function_library.Logger.log
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions.Window
import java.util.Properties
import java.io.File
import java.io.FileInputStream

  
/** <h1>CustomerCSPCrosswalk</h1>
  *   * @author  tshasank
  * @version 1.0
  */
object CSPIdentifier {
  
  val GContext = new GlobalContext()
  val func = new CommonFunctions()
  
  val sparkUAH = GContext.getUAHSession("CSPXwalkUAH")
  val sparkRNA = GContext.getRnASession("CSPXwalkRNA")
  
    def main(args: Array[String]): Unit = {
    
    var properties=  new Properties()
    properties.load(new FileInputStream(new File(args(0))))
     
    val jsonLoc = properties.getProperty("spark.hdfs.jsonpath")
    val lookUpTablePath = properties.getProperty("spark.hdfs.cspLookUpTablePath")
    val mergeDB=properties.getProperty("spark.database.mergeDB")
    val cspLookUpTableName=properties.getProperty("spark.database.cspLookUpTableName")

    val pulseCSPIdentitfier = this.getPulseCSPIdentitfier(jsonLoc, lookUpTablePath, mergeDB, cspLookUpTableName)
    log.info("CSP Crosswalk Lookup Table is refreshed in Merge Layer")
    GContext.stop()
  }
   
//Create a Crosswalk Lookup Table in Merge Layer
  def getPulseCSPIdentitfier( jsonLoc: String, lookUpTablePath: String, tgtDBName: String, lookUpTableName: String)
  {
   import sparkUAH.implicits._
   
   ReadJson.createJsonObject(jsonLoc)

   val groupcontract_lookupDF =func.runSql(sparkUAH, ReadJson.getProperty("groupcontract_lookup_std"))
   val contract_specific_packageDF =func.runSql(sparkUAH, ReadJson.getProperty("csp_xwalk"))
   //val memgroupidDF =func.runSql(sparkRNA, ReadJson.getProperty("memgroupid_xwalk"))
   val memgroupcontractplanoptextviewDF =func.runSql(sparkRNA, ReadJson.getProperty("memgroupcontractplanoptextview_xwalk"))

   log.info("groupcontract_lookupDF.printSchema() ::" + groupcontract_lookupDF.printSchema())
   log.info("contract_specific_packageDF.printSchema() ::" + contract_specific_packageDF.printSchema())
   //log.info("memgroupidDF.printSchema() ::" + memgroupidDF.printSchema())
   log.info("memgroupcontractplanoptextviewDF.printSchema() ::" + memgroupcontractplanoptextviewDF.printSchema())
   
   //val df1 = groupcontract_lookupDF.join(memgroupidDF, groupcontract_lookupDF.col("source_groupid") === memgroupidDF.col("originalsourcesystemid"), "inner")
  // df1.select("memgroupid").dropDuplicates()
   //log.info(df1.count()+" df1.printSchema() ::" + df1.printSchema())
   val df2 = groupcontract_lookupDF.join(memgroupcontractplanoptextviewDF, Seq("memgroupid"), "inner").dropDuplicates()
   
   println(df2.count +" df2.printSchema() ::" + df2.printSchema())
   val df3 = df2.join(contract_specific_packageDF, df2.col("source_contractid") === contract_specific_packageDF.col("contract_id") && df2.col("originalsourcesystemid") === contract_specific_packageDF.col("contract_spec_pkg_code"), "inner").drop(contract_specific_packageDF.col("contract_id")).dropDuplicates().withColumn("groupplanopt_lookup_identifier", row_number.over(Window.orderBy(col("memgroupid"))))
       //.withColumn("groupplanopt_lookup_identifier",monotonically_increasing_id())
   log.info(df3.count +" df3.printSchema() ::" + df3.printSchema())
   
   df3.createOrReplaceTempView("lookUp_Table")
   val df4 = sparkUAH.sql("select groupplanopt_lookup_identifier, memgroupid, memgroupcontractid, memgroupcontractoptid, memgroupcontractplanoptionid, source_groupid, source_contractid, contract_specific_pkg_id as source_groupcontractoptid, contract_spec_pkg_code as source_groupcontractplanoptid, current_timestamp as row_timestamp, 'PUL' as source_code, 'A' as active_flag  from lookUp_Table")
   df4.write.mode("overwrite").parquet(lookUpTablePath)
   log.info("lookUpTableName ::"+lookUpTableName + "tgtDBName ::"+tgtDBName)
   func.createExternalTableFromParquet(sparkUAH, lookUpTablePath, lookUpTableName, tgtDBName)

  }
  
  

}