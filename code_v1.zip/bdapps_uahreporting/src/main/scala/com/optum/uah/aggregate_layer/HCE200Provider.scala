
package com.optum.uah.aggregate_layer
import com.optum.uah.function_library.{ CommonFunctions, GlobalContext, ReadJson }
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{ DataFrame, Dataset, SparkSession }
import org.apache.spark.sql.SaveMode
object HCE200Provider {
  val GContext = new GlobalContext()
  val func = new CommonFunctions()

  def main(args: Array[String]): Unit = {
   val sparkSession = GContext.getUAHSession("Provider")
   val path = args(0)
   val propFilePath = args(1)
   ReadJson.createJsonObject(propFilePath)   
   val providerDataSet = createHce200Providerdf(sparkSession, path)    
   //val serviceDataSet = createHce200Servicedf(sparkSession)  
   //val df = providerDataSet.join(broadcast(serviceDataSet), Seq("poaproviderorgid"), "left_outer")
   func.saveDataframeAsFile( providerDataSet , path, "overwrite")
   sparkSession.close()
   GContext.stop()
  }

  def createHce200Providerdf(sparkSession: SparkSession, path: String): DataFrame = {
    import sparkSession.implicits._
    println("Starting provider aggregation")
    val provider_name = func.runSql(sparkSession, ReadJson.getProperty("provider_name")) 
    val provider_service = func.runSql(sparkSession, ReadJson.getProperty("provider_service")) 
    val provider_billing = func.runSql(sparkSession, ReadJson.getProperty("provider_billing"))
    val groupcod = func.runSql(sparkSession, ReadJson.getProperty("groupcod"))//.repartition(col("poaproviderorgid"))
    val provider_network = func.runSql(sparkSession, ReadJson.getProperty("provider_network")).repartition(col("uah_providerid")) //2617935
    val taxonomy_class_org = func.runSql(sparkSession, ReadJson.getProperty("taxonomy_class_org")).repartition(col("uah_providerid")) //REMOVE THESE BEFORE COMMITTING
    val taxonomy_class_prof = func.runSql(sparkSession, ReadJson.getProperty("taxonomy_class_prof")).repartition(col("uah_providerid"))
    val taxonomy_class = taxonomy_class_prof.union(taxonomy_class_org).dropDuplicates().repartition(col("uah_providerid"))
    val county_name_prof = func.runSql(sparkSession, ReadJson.getProperty("county_name_prof")).repartition(col("uah_providerid"))
    val county_name_org = func.runSql(sparkSession, ReadJson.getProperty("county_name_org")).repartition(col("uah_providerid"))
    val county_name = county_name_prof.union(county_name_org).dropDuplicates().repartition(col("uah_providerid"))
    val providerIDText = func.runSql(sparkSession, ReadJson.getProperty("provideridtext")).repartition(col("uah_providerid"))
    val license_type = func.runSql(sparkSession, ReadJson.getProperty("license_type")).repartition(col("uah_providerid"))
    val providerviewmasterDF = func.runSql(sparkSession, ReadJson.getProperty("driver")).repartition(col("uah_providerid"))
    val providerParStatusType = broadcast(func.runSql(sparkSession, ReadJson.getProperty("providerparstatustype")).repartition(col("uah_providerid"))) //124 //TODO Dynamically
    
   val prov_namebilling = (provider_name.join(provider_billing, Seq("provtinid")).drop("provtinid").dropDuplicates())//.repartition(col("poaproviderorgid"))
   val prov_namebillingGroupcod = prov_namebilling.join(provider_service, Seq("poaproviderorgid"), "left_outer").join(broadcast(groupcod), Seq("poaproviderorgid"), "left_outer").repartition(col("uah_providerid")) //TODO: check without it
    val provideraggDF = providerviewmasterDF.join(prov_namebillingGroupcod, Seq("uah_providerid"), "left_outer")
      .join(providerIDText, Seq("uah_providerid"), "left_outer")
      .join(provider_network, Seq("uah_providerid"), "left_outer").join(taxonomy_class, Seq("uah_providerid"), "left_outer").join(county_name, Seq("uah_providerid"), "left_outer")
      .join(license_type, Seq("uah_providerid"), "left_outer")
      .join(providerParStatusType, Seq("uah_providerid"), "left_outer")

    provideraggDF.dropDuplicates()
      
  }

}