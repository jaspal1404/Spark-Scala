//package uah_repo.Merge_Layer
package com.optum.uah.merge_layer.member
import com.optum.uah.function_library.{CommonFunctions, GlobalContext, ReadJson}
//import org.apache.spark.sql
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import java.time.LocalDate;
/**
  * Created by psahota on 9/6/2017.
  */
object UahCdwMemberEligibility {
  //  var hist_leg_df: DataFrame = sc.emptyDataFrame
  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .enableHiveSupport()
      .getOrCreate()
    import spark.implicits._
    val tgtLoc = args(0)
    val tblName = args(1)
    val propFilePath = args(2)
    val crossWalkTable = args(3) // crossWalkTable="df2_rso_mast_odfr2tst.subsaffiliationexternalid_snapshot"
    //val test = tgtLoc.split("mergelayer/")(1)
    val test = tgtLoc.split("/")(8)
    val workingDir =  tgtLoc.split("/"+test).head+ "/working/" +  tblName

    val GlobalContext = new GlobalContext()

    val CommonFunctions = new CommonFunctions()

    var sparkSession = GlobalContext.getUAHSession("MemberUAH")
    if (CommonFunctions.getListOfFiles("/mapr" + tgtLoc).isEmpty) {
      println("******************************************************************************")
      println("**Target location(Merge Layer) doesnt have any records (is empty), starting the initial load **")
      ReadJson.createJsonObject(propFilePath)
      sparkSession = GlobalContext.getUAHSession("MemberUAH")
      // val sqlQry="SELECT DISTINCT mem_code, addr1, addr2, city, state, zip, county_name, to_date(dob) as dob, first_name,phone_number, last_name, sex, social_security_number, '' as key, ' ' as uah_timestamp,'active' as record_status,\"CDW\" as source_cd from uah_cdw_prod.uah_cdw_dss_i_members"
      println(ReadJson.getProperty(tblName))        // Read legacy data in to data frame

      val lgcy_df = CommonFunctions.runSql(sparkSession, ReadJson.getProperty(tblName))

      val reqDate = LocalDate.now().plusYears(-3).toString();
      val filter_df = lgcy_df.filter($"benplaneffdate" > reqDate)

      sparkSession = GlobalContext.getCirrusLakeSession("MemberLake")
      val subsaffiliation_df = sparkSession.read.table(crossWalkTable).select("affiliationexternalid", "memberid")
      val joined_df = filter_df.join(subsaffiliation_df, col("source_memberid") === col("affiliationexternalid"), "leftouter")
     // val crossWalk_df = joined_df.withColumn("membermemberid", expr("case when memberid is null then source_memberid else memberid end"))
      val crossWalk_df = joined_df.withColumn("uah_memberid", expr("case when memberid is null then source_memberid else memberid end"))
      val temp=ReadJson.getProperty("merge_memberelig_columns")
      //      val fields=temp.split(','):+"key":+"uah_timestamp":+"record_status":+"source_cd"
      val fields=temp.split(',')
      //    # Array(memberid, address1, address2, city, state, postalcode, countyfipsdesc, birthDate, namefirst, phone, namelast, gender, memberExternalID)
      val final_df = crossWalk_df.select(fields.head, fields.tail: _*)
      CommonFunctions.saveDataframeAsFile(final_df, tgtLoc,"overwrite")
    }
    else {

      println("******************************************************************************")
      println("**Target location (Merge Layer) already has some records**")
      val merge_df=sparkSession.read.parquet(tgtLoc)
      println("Merge Layer record count from before starting the job *************" + merge_df.count())
      sparkSession = GlobalContext.getUAHSession("MemberUAH")
      ReadJson.createJsonObject(propFilePath)
      // val sqlQry="SELECT DISTINCT mem_code, addr1, addr2, city, state, zip, county_name, to_date(dob) as dob, first_name,phone_number, last_name, sex, social_security_number, '' as key, ' ' as uah_timestamp,'active' as record_status,\"CDW\" as source_cd from uah_cdw_prod.uah_cdw_dss_i_members"
      println(ReadJson.getProperty(tblName))
      // Read legacy data in to data frame
      val lgcy_df = CommonFunctions.runSql(sparkSession, ReadJson.getProperty(tblName))

      // Logic to get last 3 years of data

      val reqDate = LocalDate.now().plusYears(-3).toString();
      val filter_df = lgcy_df.filter($"benplaneffdate" > reqDate)

      sparkSession = GlobalContext.getCirrusLakeSession("MemberLake")
      val subsaffiliation_df = sparkSession.read.table(crossWalkTable).select("affiliationexternalid", "memberid")
      val joined_df = filter_df.join(subsaffiliation_df, col("source_memberid") === col("affiliationexternalid"), "leftouter")

      //val crossWalk_df = joined_df.withColumn("membermemberid", expr("case when memberid is null then source_memberid else memberid end"))
      val crossWalk_df = joined_df.withColumn("uah_memberid", expr("case when memberid is null then source_memberid else memberid end"))

      //these columns are pulled from Properties file
      //      ReadJson.createJsonObject(propFilePath)
      //      ReadJson.getProperty("hce200_extract_member")
      val temp=ReadJson.getProperty("merge_memberelig_columns")
      //      val fields=temp.split(','):+"key":+"uah_timestamp":+"record_status":+"source_cd"
      val fields=temp.split(',')
      //    # Array(memberid, address1, address2, city, state, postalcode, countyfipsdesc, birthDate, namefirst, phone, namelast, gender, memberExternalID)
      val final_df = crossWalk_df.select(fields.head, fields.tail: _*)
      //val final_df = crossWalk_df.select("memberid", "source_memberid", "pulse_member_card_code", "address1", "address2", "city", "state", "postalcode", "countyfipsdesc", "birthdate", "namefirst", "phone", "namelast", "gender", "sourcegender", "memberexternalid", "key", "uah_timestamp", "record_status", "source_cd")
      val union_df=merge_df.union(final_df)

      //Rank Logic is not required for this case we need all the records
      //val rank_df = union_df.withColumn("rank", rank.over(Window.partitionBy("membermemberid","benplaneffdate","benplanexpdate" ,"source_cd").orderBy($"uah_timestamp".desc)))
      val rank_df = union_df.withColumn("rank", rank.over(Window.partitionBy("uah_memberid","benplaneffdate","benplanexpdate" ,"source_cd").orderBy($"uah_timestamp".desc)))
      val temp_df = rank_df.filter("rank = '1'")
      val write_df=temp_df.drop("rank")

      sparkSession = GlobalContext.getUAHSession("MemberUAH")
      println("Merge Layer record count after the job *************" + write_df.count())
     // CommonFunctions.saveTempDataframeAsFile(sparkSession, write_df, tgtLoc, workingDir)
    }
  }
}
