package com.optum.uah.merge_layer.benefits

import com.optum.uah.function_library.{ CommonFunctions, GlobalContext, ReadJson }
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.SparkSession
import com.optum.uah.function_library.Logger.log
import org.apache.spark.sql.functions._
import org.apache.hadoop.fs.{ FileStatus, Path, FileSystem }
import java.util.Properties
import java.util.Scanner
import java.io.File
import java.io.FileInputStream
import org.apache.hadoop.fs.{ FileStatus, Path, FileSystem }

/**
* @author TeamTitan, Nagababu
*/
object UAHCirrusBenefits {

  val GContext = new GlobalContext()
  val func = new CommonFunctions()

  val sparkUAH = GContext.getUAHSession("UAHCirrusBenefits")
  val sparkRNA = GContext.getRnASession("UAHCirBenefits")

  def main(args: Array[String]): Unit = {

    val jsonLocation = args(0)
    val extTableLocation = args(1)
    val tableName = args(2)
    this.getMergeData(jsonLocation, extTableLocation, tableName,args )
    GContext.stop()
  }

  /**
   * Defining  the main entry for a Spark submit . We normally use it for testing
   */

//Incremental Load
  def appendIncrementData(sparkRNA: SparkSession, targetLoc: String, tblName: String, jsonLoc: String, tgtDF: DataFrame, args: Array[String]) {
  var maxLoadTimestamp = ""
  if (args.length == 4)  maxLoadTimestamp = func.getHbaseMrglayerTs(sparkUAH,tblName, args(3))
  else  maxLoadTimestamp = func.getHbaseMrglayerTs(tblName)
    //var maxLoadTimestamp = "2017-10-18 00:00:00"
    ReadJson.createJsonObject(jsonLoc)
    log.info("Incremental Load")
    log.info("maxLoadTimestamp :" + maxLoadTimestamp)
  val fs = FileSystem.get(sparkRNA.sparkContext.hadoopConfiguration)
  val cirDeltaDf = tgtDF.filter("uah_timestamp > \"" + maxLoadTimestamp + "\"").dropDuplicates("key", "uah_timestamp")
    //log.info("cirDeltaDf Count::" + cirDeltaDf.count)
  if(cirDeltaDf.count()!=0){                                                                                                    
  val parquetDf = sparkRNA.read.option("inferSchema", "true").parquet(targetLoc)
   //val parquetDf = sparkRNA.read.parquet(targetLoc)
   //log.info("parquetDf Count::" + parquetDf.count)
                                                                                                                     
   val cirrusDf = parquetDf.filter(col("source_cd") === "CRS").dropDuplicates
   val unionedCirrusDf = cirrusDf.union(cirDeltaDf);
    //log.info("unionedCirrusDf Count::" + unionedCirrusDf.count)
    //unionedCirrusDf.show()

   val dedupDf = func.dedupLogic(unionedCirrusDf).dropDuplicates
    //log.info("dedupDf Count :" + dedupDf.count)
    
    maxLoadTimestamp = dedupDf.agg(max("uah_timestamp")).first()(0).toString
    
    if (args.length == 4)
        func.updateHbaseMrglayerTs(sparkUAH,tblName, maxLoadTimestamp, args(3))
else 
    func.updateHbaseMrglayerTs(tblName, maxLoadTimestamp)

    dedupDf.write.mode("overwrite").partitionBy("source_cd").parquet(targetLoc+"_temp")
    fs.delete(new Path(targetLoc), true)
    fs.rename(new Path(targetLoc+"_temp"), new Path(targetLoc))
    }
    //else log.info("No New Records Exist as the Record Count is " + dedupDf.count)
    GContext.stop()
  }

  //Load table data into Merge Layer
  def getMergeData(jsonLoc: String, extTableLocation: String, tableName: String, args: Array[String]) {

    ReadJson.createJsonObject(jsonLoc)
    println("Getting attributes for " + tableName + " cirrus table from RnA tenant")
    val mergeDF = func.runSql(sparkRNA, ReadJson.getProperty(tableName))

    if (!new java.io.File("/mapr" + extTableLocation+ "/source_cd=CRS").exists) {
      println("Target Location Doesn't Exists :" + !new java.io.File("/mapr" + extTableLocation+ "/source_cd=CRS").exists)
      mergeDF.write.format("parquet").save(extTableLocation + "/source_cd=CRS")
      val maxLoadTimestamp = mergeDF.agg(max("uah_timestamp")).first()(0).toString
      if (args.length == 4)
        func.updateHbaseMrglayerTs(sparkUAH,tableName, maxLoadTimestamp, args(3))

      else func.updateHbaseMrglayerTs(tableName, maxLoadTimestamp)

      println("Update maxLoadTimestamp in Hbase Table::" + maxLoadTimestamp)
    } else {
      //println("In Else Loop")
      println("Starting Incremental Load ")
      this.appendIncrementData(sparkRNA, extTableLocation, tableName, jsonLoc, mergeDF, args)
      println("Done with appendCirrusData")
    }
  }
}

