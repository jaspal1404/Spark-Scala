
package com.optum.uah.merge_layer.provider

import com.optum.uah.function_library.{ CommonFunctions, GlobalContext, ReadJson }
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.DataFrame
import com.optum.uah.function_library.Logger.log
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType


/** <h1>Provider</h1>
  * Provider has the logic to create data sets for HCE200 provider attributes. This has implementation for
  * both cirrus and legacy.The legacy tables are from medmart. The required api's are exposed through @class shared_views
  * <p>
  * Also have the class definations for Provider, ProverAdress etc
  * @author  dbhatta3
  * @version 1.0
  * ACTION ITEM: Next time when we are working on Customer please merge the 'UAHCirProvider_merge' into this class UAHCirProvider
  */

object UAHCirProvider {

  /* Initializing Context and config reading*/
  /* the variable GContext.runHome build from environment variable UAH_RUNTIME
  * that you should populate from you Spark submit script
  * like:
  *
  * export UAH_RUNTIME=/datalake/optum/optuminsight/d_uah/dev/developer/debraj
  * */

  val GContext = new GlobalContext()
  val func = new CommonFunctions()
  //val rJson = new ReadJson(GContext.runHome + "/hce200Provider.json")
  //ReadJson.createJsonObject(GContext.runHome + "/hce200Provider.json")

  /* Defining  the main entry for a Spark submit . We normally use it for testing
 * */

  def main(args: Array[String]): Unit = {

    val sparkSession = GContext.getUAHSession("ProviderUAH")
    val propFilePath = args(1)
    val dbName = sparkSession.conf.get("spark.database.uah.merge")
    //Load json property file to get sql based on the subject area and table
    ReadJson.createJsonObject(propFilePath)
    if(args.length > 2){
      val tablenames : String = args(2)
      tablenames.split(",").foreach { x => call(x,args) }
      return
    }
    
    var path = getCirrusProviderorglocationphnview_std(args)
    path = getCirrusProvtinaddressesview_std(args)
    path = getCirrusprovidertaxonomyview_std(args)
    path = getCirrusProviderMDM_proforc(args)
    path = getCirrusZipcode_view(args)
    path = getCirrusProvideridentifiersearchview_std(args)
    path = getCirrusProviderorgaffiliationtinview_std(args)
    path = getCirrusProviderorgidview_std(args)
    path = getCirrusProviderid_view(args)   
    /*path = getCirrusClaimpricinginputdetailview_std(args)       //this is a dependency
    func.createExternalTableFromParquet(sparkSession, path, "claimpricinginputdetailview_std_new", dbName)
    path = getClaimProviderAddress_std(args)      //this is a dependency
    func.createExternalTableFromParquet(sparkSession, path, "claimprovideraddress_std_new", dbName)*/
    path = getCirrusTaxonomycode_view(args)      //this is a dependency
    path = getCirrusproviderorgaffilview_std(args)
    path = getCirrusprovcontractnetworkheaderview_std(args)
    path =  getCirrusNetworkidquerysearchview_std(args)
    path = getCirrusprovidermdm_orgorc(args)
    path =  getCirrusprovider_view(args)
    GContext.stop()
  }

  /* the functions related to a Provider itself*/

  def getCirrusProviderorglocationphnview_std(args: Array[String]): String = {
    val sparkSession = GContext.getRnASession("ProviderRnA")
    var cirrusProviderorglocationphnview: DataFrame = sparkSession.emptyDataFrame
    var tableName = "providerorglocationphnview_std"
    cirrusProviderorglocationphnview = func.runSql(sparkSession, ReadJson.getProperty(tableName))
    val cirrusProviderorglocationphnviewfinal = cirrusProviderorglocationphnview//.withColumn("providerid_ext_src", lit(null).cast(StringType)).withColumn("ext_src_cd", lit(null).cast(StringType))
    import sparkSession.implicits._
    log.info("Getting attributes for " + tableName + " cirrus table from RnA tenant")
    var path = args(0) + "/" + tableName + "/source_cd=CRS"
    cirrusProviderorglocationphnview = func.incrDataLoad(tableName, cirrusProviderorglocationphnviewfinal, path, sparkSession)
    if (cirrusProviderorglocationphnview.count.!=(0)) {
      var newmaxLoadTimestamp = cirrusProviderorglocationphnview.agg(max("uah_timestamp")).first()(0).toString
      println("new max load timestamp" + newmaxLoadTimestamp)
      func.updateHbaseMrglayerTs(tableName, newmaxLoadTimestamp)
    }
    path
  }
  
  def getCirrusProvtinaddressesview_std(args: Array[String]): String = {
    val sparkSession = GContext.getRnASession("ProviderRnA")
    var cirrusProvtinaddressesview: DataFrame = sparkSession.emptyDataFrame
    var tableName = "provtinaddressesview_std"
    cirrusProvtinaddressesview = func.runSql(sparkSession, ReadJson.getProperty(tableName))
    val cirrusProvtinaddressesviewfinal = cirrusProvtinaddressesview //.withColumn("providerid_ext_src", lit(null).cast(StringType)).withColumn("ext_src_cd", lit(null).cast(StringType))
    log.info("Getting attributes for " + tableName + " cirrus table from RnA tenant")
    import sparkSession.implicits._
    var path = args(0) + "/" + tableName + "/source_cd=CRS"
    cirrusProvtinaddressesview = func.incrDataLoad(tableName, cirrusProvtinaddressesviewfinal, path, sparkSession)
    if (cirrusProvtinaddressesview.count.!=(0)) {
      var newmaxLoadTimestamp = cirrusProvtinaddressesview.agg(max("uah_timestamp")).first()(0).toString
      println("new max load timestamp" + newmaxLoadTimestamp)
      func.updateHbaseMrglayerTs(tableName, newmaxLoadTimestamp)
    }
    path
  }
  
 /* def getCirrusProvidersnapshotview(args: Array[String]): String = {
    val sparkSession = GContext.getRnASession("ProviderRnA")
    var cirrusProvidersnapshotview: DataFrame = sparkSession.emptyDataFrame
    var tableName = "provider_snapshot_view"
    cirrusProvidersnapshotview = func.runSql(sparkSession, ReadJson.getProperty(tableName))
    val cirrusProvidersnapshotviewfinal = cirrusProvidersnapshotview.withColumn("uah_providerid",cirrusProvidersnapshotview.col("providerid"))//.withColumn("providerid_ext_src", lit(null).cast(StringType)).withColumn("ext_src_cd", lit(null).cast(StringType))
    import sparkSession.implicits._
    log.info("Getting attributes for " + tableName + " cirrus table from RnA tenant")
    var path = args(0) + "/" + tableName + "/source_cd=CRS"
    cirrusProvidersnapshotview = func.incrDataLoad(tableName, cirrusProvidersnapshotviewfinal, path, sparkSession)
    if (cirrusProvidersnapshotview.count.!=(0)) {
      var newmaxLoadTimestamp = cirrusProvidersnapshotview.agg(max("uah_timestamp")).first()(0).toString
      println("new max load timestamp" + newmaxLoadTimestamp)
      func.updateHbaseMrglayerTs(tableName, newmaxLoadTimestamp)
    }
    path
  }*/
  
  def getCirrusprovidertaxonomyview_std(args: Array[String]): String = {
    val sparkSession = GContext.getRnASession("ProviderRnA")
    var cirrusProviderTaxonomyview: DataFrame = sparkSession.emptyDataFrame
    var tableName = "providertaxonomyview_std"
    cirrusProviderTaxonomyview = func.runSql(sparkSession, ReadJson.getProperty(tableName))
    val cirrusProviderTaxonomyviewfinal = cirrusProviderTaxonomyview.withColumn("uah_providerid", cirrusProviderTaxonomyview.col("providertaxonomyproviderid"))//.withColumn("providerid_ext_src", lit(null).cast(StringType)).withColumn("ext_src_cd", lit(null).cast(StringType))
    log.info("Getting attributes for " + tableName + " cirrus table from Data Lake")
    import sparkSession.implicits._
    var path = args(0) + "/" + tableName + "/source_cd=CRS"
    cirrusProviderTaxonomyview = func.incrDataLoad(tableName, cirrusProviderTaxonomyviewfinal, path, sparkSession)
    if (cirrusProviderTaxonomyview.count.!=(0)) {
      var newmaxLoadTimestamp = cirrusProviderTaxonomyview.agg(max("uah_timestamp")).first()(0).toString
      println("new max load timestamp" + newmaxLoadTimestamp)
      func.updateHbaseMrglayerTs(tableName, newmaxLoadTimestamp)
    }
    path
  }

  def getCirrusProviderMDM_proforc(args: Array[String]): String = {
    val sparkSession = GContext.getRnASession("ProviderRnA")
    var df: DataFrame = sparkSession.emptyDataFrame
    var tableName = "providermdm_proforc"
    df = func.runSql(sparkSession, ReadJson.getProperty(tableName))
    //val dffinal = df.withColumn("providerid_ext_src", lit(null).cast(StringType)).withColumn("ext_src_cd", lit(null).cast(StringType))
    log.info("Getting attributes for " + tableName + "cirrus table from Data Lake")
    import sparkSession.implicits._
    var path = args(0) + "/" + tableName + "/source_cd=CRS"
    func.saveDataframeAsFile(df, path, "overwrite")
    path
  }

  def getCirrusZipcode_view(args: Array[String]): String = {
    
   
    val sparkSession = GContext.getRnASession("ProviderRnA")
    var cirrusZipcodeview: DataFrame = sparkSession.emptyDataFrame
    var tableName = "zipcode_view"
    cirrusZipcodeview = func.runSql(sparkSession, ReadJson.getProperty(tableName))
    //cirrusZipcodeview = cirrusZipcodeview.withColumn("providerid_ext_src", lit(null).cast(StringType)).withColumn("ext_src_cd", lit(null).cast(StringType))
    log.info("Getting attributes for " + tableName + " cirrus table from Data Lake")
    import sparkSession.implicits._
    var path = args(0) + "/" + tableName + "/source_cd=CRS"
   
    if (args.length==4) cirrusZipcodeview = func.incrDataLoad(tableName, cirrusZipcodeview, path, sparkSession,true,args(3))
    else
    cirrusZipcodeview = func.incrDataLoad(tableName, cirrusZipcodeview, path, sparkSession)
    if (cirrusZipcodeview.count.!=(0)) {
      var newmaxLoadTimestamp = cirrusZipcodeview.agg(max("uah_timestamp")).first()(0).toString
      println("new max load timestamp" + newmaxLoadTimestamp)
       if (args.length==4) func.updateHbaseMrglayerTs(sparkSession,tableName, newmaxLoadTimestamp,args(3))
       else
      func.updateHbaseMrglayerTs(tableName, newmaxLoadTimestamp)
    }
    path
  }

  def getCirrusProvideridentifiersearchview_std(args: Array[String]): String = {
    val sparkSession = GContext.getRnASession("ProviderRnA")
    var cirrusProvideridentifiersearchview: DataFrame = sparkSession.emptyDataFrame
    var tableName = "provideridentifiersearchview_std"
    cirrusProvideridentifiersearchview = func.runSql(sparkSession, ReadJson.getProperty(tableName))
    val cirrusProvideridentifiersearchviewfinal = cirrusProvideridentifiersearchview.withColumn("uah_providerid",cirrusProvideridentifiersearchview.col("providerproviderid"))//.withColumn("providerid_ext_src", lit(null).cast(StringType)).withColumn("ext_src_cd", lit(null).cast(StringType))
    log.info("Getting attributes for " + tableName + " cirrus table from RnA tenant")
    import sparkSession.implicits._
    var path = args(0) + "/" + tableName + "/source_cd=CRS"
    cirrusProvideridentifiersearchview = func.incrDataLoad(tableName, cirrusProvideridentifiersearchviewfinal, path, sparkSession)
    if (cirrusProvideridentifiersearchview.count.!=(0)) {
      var newmaxLoadTimestamp = cirrusProvideridentifiersearchview.agg(max("uah_timestamp")).first()(0).toString
      println("new max load timestamp" + newmaxLoadTimestamp)
      func.updateHbaseMrglayerTs(tableName, newmaxLoadTimestamp)
    }
    path
  }

  def getCirrusProviderorgaffiliationtinview_std(args: Array[String]): String = {
    val sparkSession = GContext.getRnASession("ProviderRnA")
    var cirrusProviderorgaffiliationtinview: DataFrame = sparkSession.emptyDataFrame
    var tableName = "providerorgaffiliationtinview_std"
    cirrusProviderorgaffiliationtinview = func.runSql(sparkSession, ReadJson.getProperty(tableName))
    val cirrusProviderorgaffiliationtinviewfinal = cirrusProviderorgaffiliationtinview.withColumn("uah_providerid",cirrusProviderorgaffiliationtinview.col("pproviderid"))//.withColumn("providerid_ext_src", lit(null).cast(StringType)).withColumn("ext_src_cd", lit(null).cast(StringType))
    log.info("Getting attributes for " + tableName + " cirrus table from RnA tenant")
    import sparkSession.implicits._
    var path = args(0) + "/" + tableName + "/source_cd=CRS"
    cirrusProviderorgaffiliationtinview = func.incrDataLoad(tableName, cirrusProviderorgaffiliationtinviewfinal, path, sparkSession)
    if (cirrusProviderorgaffiliationtinview.count.!=(0)) {
      var newmaxLoadTimestamp = cirrusProviderorgaffiliationtinview.agg(max("uah_timestamp")).first()(0).toString
      println("new max load timestamp" + newmaxLoadTimestamp)
      func.updateHbaseMrglayerTs(tableName, newmaxLoadTimestamp)
    }
    path
  }

  def getCirrusProviderorgidview_std(args: Array[String]): String = {
    val sparkSession = GContext.getRnASession("ProviderRnA")
    var cirrusProviderorgidview: DataFrame = sparkSession.emptyDataFrame
    var tableName = "providerorgidview_std"
    cirrusProviderorgidview = func.runSql(sparkSession, ReadJson.getProperty(tableName))
    val cirrusProviderorgidviewfinal = cirrusProviderorgidview//.withColumn("providerid_ext_src", lit(null).cast(StringType)).withColumn("ext_src_cd", lit(null).cast(StringType))
    log.info("Getting attributes for " + tableName + " cirrus table from RnA tenant")
    import sparkSession.implicits._
    var path = args(0) + "/" + tableName + "/source_cd=CRS"
    cirrusProviderorgidview = func.incrDataLoad(tableName, cirrusProviderorgidviewfinal, path, sparkSession)
    if (cirrusProviderorgidview.count.!=(0)) {
      var newmaxLoadTimestamp = cirrusProviderorgidview.agg(max("uah_timestamp")).first()(0).toString
      println("new max load timestamp" + newmaxLoadTimestamp)
      func.updateHbaseMrglayerTs(tableName, newmaxLoadTimestamp)
    }
    path
  }

  def getCirrusProviderid_view(args: Array[String]): String = {
    val sparkSession = GContext.getRnASession("ProviderRnA")
    var cirrusProvideridview: DataFrame = sparkSession.emptyDataFrame
    var tableName = "providerid_view"
    cirrusProvideridview = func.runSql(sparkSession, ReadJson.getProperty(tableName))
    val cirrusProvideridviewfinal = cirrusProvideridview.withColumn("uah_providerid",cirrusProvideridview.col("providerid"))//.withColumn("providerid_ext_src", lit(null).cast(StringType)).withColumn("ext_src_cd", lit(null).cast(StringType))
    log.info("Getting attributes for " + tableName + " cirrus table from RnA tenant")
    import sparkSession.implicits._
    var path = args(0) + "/" + tableName + "/source_cd=CRS"
    cirrusProvideridview = func.incrDataLoad(tableName, cirrusProvideridviewfinal, path, sparkSession)
    if (cirrusProvideridview.count.!=(0)) {
      var newmaxLoadTimestamp = cirrusProvideridview.agg(max("uah_timestamp")).first()(0).toString
      println("new max load timestamp" + newmaxLoadTimestamp)
      func.updateHbaseMrglayerTs(tableName, newmaxLoadTimestamp)
    }
    path
  }


  def getCirrusTaxonomycode_view(args: Array[String]): String = {
    val sparkSession = GContext.getRnASession("ProviderRnA")
    var df: DataFrame = sparkSession.emptyDataFrame
    var tableName = "taxonomycode_view"
    df = func.runSql(sparkSession, ReadJson.getProperty(tableName))
    //val dffinal = df.withColumn("providerid_ext_src", lit(null).cast(StringType)).withColumn("ext_src_cd", lit(null).cast(StringType))
    log.info("Getting attributes for " + tableName + " cirrus table from RnA tenant")
    import sparkSession.implicits._
    var path = args(0) + "/" + tableName + "/source_cd=CRS"
    df = func.incrDataLoad(tableName, df, path, sparkSession)
    if (df.count.!=(0)) {
      var newmaxLoadTimestamp = df.agg(max("uah_timestamp")).first()(0).toString
      println("new max load timestamp" + newmaxLoadTimestamp)
      func.updateHbaseMrglayerTs(tableName, newmaxLoadTimestamp)
    }
    path
  }
  

  def getCirrusproviderorgaffilview_std(args: Array[String]): String = {
    val sparkSession = GContext.getRnASession("ProviderRnA")
    var cirrusProviderorgaffilview: DataFrame = sparkSession.emptyDataFrame
    var tableName = "providerorgaffilview_std"
    cirrusProviderorgaffilview = func.runSql(sparkSession, ReadJson.getProperty(tableName))
    val cirrusProviderorgaffilviewfinal = cirrusProviderorgaffilview.withColumn("uah_providerid",cirrusProviderorgaffilview.col("providerorgaffiliationproviderid"))
    log.info("Getting attributes for " + tableName + " cirrus table from DataLake")
    import sparkSession.implicits._
    var path = args(0) + "/" + tableName + "/source_cd=CRS"
    cirrusProviderorgaffilview = func.incrDataLoad(tableName, cirrusProviderorgaffilviewfinal, path, sparkSession)
    if (cirrusProviderorgaffilview.count.!=(0)) {
      var newmaxLoadTimestamp = cirrusProviderorgaffilview.agg(max("uah_timestamp")).first()(0).toString
      println("new max load timestamp" + newmaxLoadTimestamp)
      func.updateHbaseMrglayerTs(tableName, newmaxLoadTimestamp)
    }
    path
  }

  def getCirrusprovcontractnetworkheaderview_std(args: Array[String]): String = {
    val sparkSession = GContext.getRnASession("ProviderRnA")
    var df: DataFrame = sparkSession.emptyDataFrame
    var tableName = "provcontractnetworkheaderview_std"
    df = func.runSql(sparkSession, ReadJson.getProperty(tableName))
    //val dffinal = df.withColumn("providerid_ext_src", lit(null).cast(StringType)).withColumn("ext_src_cd", lit(null).cast(StringType))
    log.info("Getting attributes for " + tableName + " cirrus table from RnA tenant")
    import sparkSession.implicits._
    var path = args(0) + "/" + tableName + "/source_cd=CRS"
    df = func.incrDataLoad(tableName, df, path, sparkSession)
    if (df.count.!=(0)) {
      var newmaxLoadTimestamp = df.agg(max("uah_timestamp")).first()(0).toString
      println("new max load timestamp" + newmaxLoadTimestamp)
      func.updateHbaseMrglayerTs(tableName, newmaxLoadTimestamp)
    }
    path
  }

  def getCirrusNetworkidquerysearchview_std(args: Array[String]): String = {
    val sparkSession = GContext.getRnASession("ProviderRnA")
    var df: DataFrame = sparkSession.emptyDataFrame
    var tableName = "networkidquerysearchview_std"
    df = func.runSql(sparkSession, ReadJson.getProperty(tableName))
    //val dffinal = df.withColumn("providerid_ext_src", lit(null).cast(StringType)).withColumn("ext_src_cd", lit(null).cast(StringType))
    log.info("Getting attributes for " + tableName + " cirrus table from RnA tenant")
    import sparkSession.implicits._
    var path = args(0) + "/" + tableName + "/source_cd=CRS"
    df = func.incrDataLoad(tableName, df, path, sparkSession)
    if (df.count.!=(0)) {
      var newmaxLoadTimestamp = df.agg(max("uah_timestamp")).first()(0).toString
      println("new max load timestamp" + newmaxLoadTimestamp)
      func.updateHbaseMrglayerTs(tableName, newmaxLoadTimestamp)
    }
    path
  } 
  
  def getCirrusprovidermdm_orgorc(args: Array[String]): String = {
    val sparkSession = GContext.getRnASession("ProviderRnA")
    var df: DataFrame = sparkSession.emptyDataFrame
    var tableName = "providermdm_orgorc"
    df = func.runSql(sparkSession, ReadJson.getProperty(tableName))
    //val dffinal = df.withColumn("providerid_ext_src", lit(null).cast(StringType)).withColumn("ext_src_cd", lit(null).cast(StringType))
    log.info("Getting attributes for " + tableName + "cirrus table from Data Lake")
    import sparkSession.implicits._
    var path = args(0) + "/" + tableName + "/source_cd=CRS"
    func.saveDataframeAsFile(df, path, "overwrite")
    path
  }

  def getCirrusprovider_view(args: Array[String]): String = {
    val sparkSession = GContext.getRnASession("ProviderRnA")
    var df: DataFrame = sparkSession.emptyDataFrame
    var tableName = "provider_view"
    df = func.runSql(sparkSession, ReadJson.getProperty(tableName))
    //val dffinal = df.withColumn("providerid_ext_src", lit(null).cast(StringType)).withColumn("ext_src_cd", lit(null).cast(StringType))
    log.info("Getting attributes for " + tableName + " cirrus table from RnA tenant")
    import sparkSession.implicits._
    var path = args(0) + "/" + tableName + "/source_cd=CRS"
    df = func.incrDataLoad(tableName, df, path, sparkSession)
    if (df.count.!=(0)) {
      var newmaxLoadTimestamp = df.agg(max("uah_timestamp")).first()(0).toString
      println("new max load timestamp" + newmaxLoadTimestamp)
      func.updateHbaseMrglayerTs(tableName, newmaxLoadTimestamp)
    }
    path
  } 
  
  
  def call(method : String,args: Array[String]) ={
   val sparkSession = GContext.getUAHSession("ProviderUAH")  
  method match {
  case "providerorglocationphnview_std"  => getCirrusProviderorglocationphnview_std(args)
  case "provtinaddressesview_std"  => getCirrusProvtinaddressesview_std(args)
  case "providerid_view" =>  getCirrusProviderid_view(args) 
  case "providertaxonomyview_std"  => getCirrusprovidertaxonomyview_std(args)
  case "providermdm_proforc"  => getCirrusProviderMDM_proforc(args)
  case "zipcode_view"  => getCirrusZipcode_view(args)
  case "provideridentifiersearchview_std"  => getCirrusProvideridentifiersearchview_std(args)
  case "providerorgaffiliationtinview_std"  => getCirrusProviderorgaffiliationtinview_std(args)
  case "providerorgidview_std"  => getCirrusProviderorgidview_std(args)
  case "providerid_view"  => getCirrusProviderid_view(args) 
  case "taxonomycode_view" => getCirrusTaxonomycode_view(args) 
  case "providerorgaffilview_std" =>getCirrusproviderorgaffilview_std(args)
  case "provcontractnetworkheaderview_std" => getCirrusprovcontractnetworkheaderview_std(args)
  case "networkidquerysearchview_std" => getCirrusNetworkidquerysearchview_std(args)
  case "providermdm_orgorc" => getCirrusprovidermdm_orgorc(args) 
  case "provider_snapshot_view" =>getCirrusprovider_view(args)
  case whoa  => println("Unexpected case " + whoa.toString)
}
 
  }
  /*  def getCirrusClaimpricinginputdetailview_std(args: Array[String]): String= {
    val sparkSession = GContext.getRnASession("ProviderRnA")
    var df: DataFrame = sparkSession.emptyDataFrame
    var tableName = "claimpricinginputdetailview_std_new"
    import sparkSession.implicits._
    df = func.runSql(sparkSession, ReadJson.getProperty(tableName))
    //dffinal = df.withColumn("providerid_ext_src", lit(null).cast(StringType)).withColumn("ext_src_cd", lit(null).cast(StringType))
    log.info("Getting attributes for " + tableName + " cirrus table from RnA tenant")
    var path = args(0) + "/" + tableName + "/source_cd=CRS"
    df = func.incrDataLoad(tableName, df, path, sparkSession)
    if (df.count.!=(0)) {
      var newmaxLoadTimestamp = df.agg(max("uah_timestamp")).first()(0).toString
      println("new max load timestamp" + newmaxLoadTimestamp)
      func.updateHbaseMrglayerTs(tableName, newmaxLoadTimestamp)
    }
    path
  }

  def getClaimProviderAddress_std(args: Array[String]): String = {
    val sparkSession = GContext.getRnASession("ProviderRnA")
    var claimProviderAddress: DataFrame = sparkSession.emptyDataFrame
    var tableName = "claimprovideraddress_std_new"
    claimProviderAddress = func.runSql(sparkSession, ReadJson.getProperty(tableName))
    val claimProviderAddressfinal = claimProviderAddress.withColumn("uah_providerid",claimProviderAddress.col("providerid"))//.withColumn("providerid_ext_src", lit(null).cast(StringType)).withColumn("ext_src_cd", lit(null).cast(StringType))
    log.info("Getting attributes for " + tableName + " cirrus table from RnA tenant")
    import sparkSession.implicits._
    var path = args(0) + "/" + tableName + "/source_cd=CRS"
    claimProviderAddress = func.incrDataLoad(tableName, claimProviderAddressfinal, path, sparkSession)
    if (claimProviderAddress.count.!=(0)) {
      var newmaxLoadTimestamp = claimProviderAddress.agg(max("uah_timestamp")).first()(0).toString
      println("new max load timestamp" + newmaxLoadTimestamp)
      func.updateHbaseMrglayerTs(tableName, newmaxLoadTimestamp)
    }
    path
  }
*/
  
  /* case class Providerorglocationphnview_std(providerorglocationProviderOrgID: String,
    servicingAddressAddress1: String,
    servicingAddressAddress2: String,
    servicingAddressAddress3: String,
    servicingAddressAddress4: String,
    servicingAddressAddress5: String,
    servicingAddressCity: String,
    servicingAddressState: String,
    servicingAddressPostalCode: String,
    providerFullPhoneNumber: String,key: String,record_status: String,uah_timestamp: String,source_cd: String)

  case class Provtinaddressesview_std(ptProvTINID: String,
    billingAddressAddress1: String,
    billingAddressAddress2: String,
    billingAddressAddress3: String,
    billingAddressAddress4: String,
    billingAddressAddress5: String,
    billingAddressCity: String,
    billingAddressState: String,
    billingAddressPostalCode: String,
    providerTaxID: String,key: String,record_status: String,uah_timestamp: String,source_cd: String)

  case class Providerorgfacility_snapshotorc(
    providerorgid: String,
    countyInd: String,
    referenceDesc: String,key: String,record_status: String,uah_timestamp: String,source_cd: String)

  case class Provideridentifiersearchview_std(
    providerProviderID: String,
    providerDEA: String,
    licenseTypeDesc: String,key: String,record_status: String,uah_timestamp: String,source_cd: String)

  case class Providerorgaffiliationtinview_std(
    providernameFirst: String,
    providernameLast: String,
    providerType: String,
    provTINID: String,
    pProviderID: String,
    GROUPNAM: String,key: String,record_status: String,uah_timestamp: String,source_cd: String)

  case class Providerorgidview_std(
    providerorgidProviderOrgID: String,
    GROUPCOD: String,key: String,record_status: String,uah_timestamp: String,source_cd: String)

  case class Provideridlocationview_std(
    providerID: String,
    providerIDText: String,key: String,record_status: String,uah_timestamp: String,source_cd: String)

  case class Claimpricinginputdetailview_std(
    providerID: String,
    providerParStatusType: String,key: String,record_status: String,uah_timestamp: String,source_cd: String)

  case class Taxonomycode_snapshotorc(
    taxonomyclass: String,
    providerID: String,key: String,record_status: String,uah_timestamp: String,source_cd: String)*/

  /* case class ProviderLegacy(PRVADDR1: String,
    PRVADDR2: String,
    PRVADDR3: String,
    PRVCITY: String,
    PRVSTATE: String,
    PRVZIP: String,
    PRVCNTY: String,
    PRVADTYP: String,
    MDDEA: String,
    PRVFNAME: String,
    PRVPHONE: String,
    PRVLNAME: String,
    UHC_MPIN: String,
    PRVPARST: String,
    PRVPAREF: String,
    PRVPARTH: String,
    NETWORK: String,
    NETNAME: String,
    SOCIAL_SECURITY_NUMBER: String,
    PRVSPEC1: String,
    PRVSPEC2: String,
    PRVSPEC3: String,
    PRVSPEC4: String,
    PRVTAXID: String,
    PRVTYPE: String,
    NATIONAL_PROVIDER_ID: String)

  case class GroupAffliliationLegacy(PRVCODE: String,
    PRVLNAME: String,
    PRVFNAME: String,
    GROUPCOD: String,
    GROUPNAM: String,
    PRVTAXID: String)
*/
}