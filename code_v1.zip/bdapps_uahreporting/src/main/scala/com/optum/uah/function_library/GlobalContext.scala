package com.optum.uah.function_library

import org.apache.spark.sql.SparkSession
import scala.util.Properties

/**
  * <h1>Global Context</h1>
  * For creating the spark global context
  *
  * @author Team Falcons, Appolo
  * @version 1.0 - Created a initial version
  * @version 2.0 - Added spark property file conf
  */
class GlobalContext {
  val runHome = ""
  var defaultSession: SparkSession = createDefaultSession("default")
  val hbaseTblLocation = defaultSession.conf.get("spark.hbase.location")
  val hbaseHbaseSiteLocation = defaultSession.conf.get("spark.hbase.site.location")
   var sparkCirrus: SparkSession = _
  var sparkRnA: SparkSession = _
  var sparkUAH: SparkSession = _

  def createDefaultSession(appName: String): SparkSession = {
    val sparkSession = SparkSession.builder().appName(appName).getOrCreate()
    sparkSession.conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    sparkSession.sqlContext.setConf("spark.sql.parquet.writeLegacyFormat","true")
    sparkSession
  }

  def getCirrusLakeSession(appName: String): SparkSession = {
    if (this.sparkCirrus == null) {
      SparkSession.clearDefaultSession()
      SparkSession.clearActiveSession()
      sparkCirrus = createCirrusSparkSession(appName, defaultSession.conf.get("spark.connection.thrift.datalake.cirrus")).newSession()
    }
    sparkCirrus
  }

  def getRnASession(appName: String): SparkSession = {
    if (this.sparkRnA == null) {
      SparkSession.clearDefaultSession()
      SparkSession.clearActiveSession()
      sparkRnA = createCirrusSparkSession(appName, defaultSession.conf.get("spark.connection.thrift.rna.cirrus")).newSession()
    }
    sparkRnA
  }

  def getUAHSession(appName: String): SparkSession = {
    if (this.sparkUAH == null) {
      SparkSession.clearDefaultSession()
      SparkSession.clearActiveSession()
      sparkUAH = createCirrusSparkSession(appName, defaultSession.conf.get("spark.connection.thrift.uah")).newSession()
    }
    sparkUAH
  }

  def createCirrusSparkSession(appName: String, metastoreUri: String): SparkSession = {
    val sparkSession = SparkSession.builder().appName(appName).config("hive.metastore.uris", metastoreUri).enableHiveSupport().getOrCreate()
    sparkSession.conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    sparkSession
  }

  def stop() {
    if (sparkCirrus != null) sparkCirrus.stop()
    if (sparkRnA != null) sparkRnA.stop()
    if (sparkUAH != null) sparkUAH.stop()
    if (defaultSession != null) defaultSession.stop()
  }
}
