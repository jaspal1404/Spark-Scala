package com.optum.uah.merge_layer.membereligibility

import org.apache.spark.sql.{ DataFrame, SparkSession }
import com.optum.uah.function_library.{ CommonFunctions, GlobalContext, ReadJson }
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

/**
	* Created by sbandar8 on 8/8/2017.
	*/
object UahCirrusMemberEligibility {

	val CommonFunctions = new CommonFunctions()

	val GlobalContext = new GlobalContext()

	def main(args: Array[String]): Unit = {

		val tgtLoc = args(0)
		val propFilePath = args(1)
		//			val tblName = tgtLoc.split("mergelayer/")(1)
		val tblName = tgtLoc.split("/")(tgtLoc.split("/").size - 1)
		print("This is the target table name:" + tblName)
		//val workingDir =  tgtLoc.split("/"+tblName).head+ "/working/" +  tblName
		val workingDir = tgtLoc.split("/" + tblName).head + "/working/" + tblName
		/* var grpByCols, orderByCols = ""
              if (args.length > 2) {
                grpByCols = args(2)
                orderByCols = args(3)
              }*/

		//    ReadJson.setProperties(propFilePath)
		ReadJson.createJsonObject(propFilePath)
		print("This is a table name from Json read: " + ReadJson.getProperty(tblName))

		val sparkSession = GlobalContext.getRnASession("MemberRnA")

		// Read job last run timrestamp from staging file/table
		//	var maxLoadTimestamp = CommonFunctions.getHbaseMrglayerTs(tblName)
		var maxLoadTimestamp = "\""

		var jobLastRunTimestamp = "\""
		if (args.length == 3) {
			jobLastRunTimestamp = jobLastRunTimestamp + CommonFunctions.getHbaseMrglayerTs(sparkSession, tblName, args(2)) + "\""
		} else {
			jobLastRunTimestamp = jobLastRunTimestamp + CommonFunctions.getHbaseMrglayerTs(tblName) + "\""
		}



		// Call function to load Cirrus data
		val cirDeltaDf = getCirrusData(jobLastRunTimestamp, tblName, sparkSession)
		println("Delta file records count from a dataframe*************" + cirDeltaDf.count())

		// Run the dedup process only if we have incremental records
		if (cirDeltaDf.count() != 0) {

			// Load spark session for uah metastore
			val sparkSession = GlobalContext.getUAHSession("MemberUAH")

			if (CommonFunctions.getListOfFiles("/mapr" + tgtLoc + "/source_cd=CRS").isEmpty) {
				// Update Hbase table with max load timestamp of the record
				val dedupDf = CommonFunctions.dedupLogic(cirDeltaDf)
				maxLoadTimestamp = dedupDf.agg(max("uah_timestamp")).first()(0).toString
				//    CommonFunctions.updateHbaseMrglayerTs(tblName, maxLoadTimestamp)

				// Save dedup records into the merge layer *****
				CommonFunctions.saveDataframeAsFile(dedupDf, tgtLoc + "/source_cd=CRS", "overwrite")
			} else {

				// Load the history records in merge layer from previous run
				val mergeFullDf = getMergeTblData(tgtLoc, sparkSession)
				//        println("Record count for the records already presnet in merge layer DF Count*************: " + mergeFullDf.count())

				// Union Cirrus and merge layer dataframes
				val unionedDf = CommonFunctions.unionDataframes(mergeFullDf, cirDeltaDf)

				val dedupDf = CommonFunctions.dedupLogic(unionedDf)
				maxLoadTimestamp = dedupDf.agg(max("uah_timestamp")).first()(0).toString
				//  CommonFunctions.updateHbaseMrglayerTs(tblName, maxLoadTimestamp)

				// Save dedup records into the merge layer *****
				CommonFunctions.saveDataframeOverwriteAsFile(sparkSession, dedupDf, tgtLoc + "/source_cd=CRS", workingDir)
			}
			if (args.length ==3) {
				CommonFunctions.updateHbaseMrglayerTs(sparkSession, tblName, maxLoadTimestamp, args(2))
			}
			else {
				CommonFunctions.updateHbaseMrglayerTs(tblName, maxLoadTimestamp)
			}
		}

		sparkSession.close()
	}

	def getCirrusData(maxLoadTimestamp: String, tblName: String, sparkSession: SparkSession): DataFrame = {

		var resultDf: DataFrame = sparkSession.emptyDataFrame

		// Load data from cirrus table into a dataframe with incremental data
		print("This is the target table name from jason before if" + ReadJson.getProperty(tblName))
		println("This is a string for result DF: " + ReadJson.getProperty(tblName))

		if (maxLoadTimestamp == "Null") {
			resultDf = CommonFunctions.runSql(sparkSession, ReadJson.getProperty(tblName)).filter(col("record_status") === "active")

			print("This is the target table name from jason" + ReadJson.getProperty(tblName))

		} else {
			resultDf = CommonFunctions.runSql(sparkSession, ReadJson.getProperty(tblName)).filter("uah_timestamp > " + maxLoadTimestamp).filter(col("record_status") === "active")
		}
		print("This is the target table name from jason outside if" + ReadJson.getProperty(tblName))
		resultDf
	}

	def getMergeTblData(tgtLoc: String, sparkSession: SparkSession): DataFrame = {

		// Load the history records in merge layer from previous run
		val resultDf = sparkSession.read.parquet(tgtLoc)

		resultDf
	}
}
