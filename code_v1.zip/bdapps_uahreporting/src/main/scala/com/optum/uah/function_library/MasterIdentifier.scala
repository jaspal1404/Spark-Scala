package com.optum.uah.function_library

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType


/**
  * This function can be used to apply cross reference.
  *
  * @author  rgupta59
  * @version 1.0
  */
class MasterIdentifier() {

  val utility = new CommonFunctions()

  /**
    * @param -  Dataframe
    * @param  - MemberId_Column_Name
    * @param dbname
    * @return dataframe with column -  UAH_<Memberid_Column_Name>,source_<MemberId_Column_Name>
    */

  def legacyMemberdentitfier(sparkSession: SparkSession, lgcyMastIden: DataFrame, membIdColName: String, dbName: String): DataFrame =
  {
    val uahMemMerLayer = "uah_" + membIdColName
    val srcId = "source_" + membIdColName
    val newId = "pulse_member_card_code"

    //val lgcyMastIden = inputDS.toDF()
    import sparkSession.implicits._

    utility.createView(lgcyMastIden, "lgcyMastIden")
    val lgcySubAffl = utility.runSql(sparkSession, "Select affiliationExternalID,subsaffiliationmemberid from " + dbName + ".subsAffiliationExternalID_std where trim(externalIDType) = 'PS'")

    utility.createView(lgcySubAffl, "lgcySubAffl")

    val joinedRefPul = utility.runSql(sparkSession, "select input.*, "+membIdColName+" as " + srcId + " ,coalesce(ref.subsaffiliationmemberid ,input. " + membIdColName + ") as " + uahMemMerLayer + "  from lgcyMastIden input left join lgcySubAffl ref on trim(input." + newId + ") = trim(ref.affiliationExternalID)")

    //joinedRefPul.withColumn("External_src_cd", when((col(extsrcId) isNotNull), lit("CRS")))
    joinedRefPul.drop(membIdColName)
  }

  /**
    * @param -  Dataframe
    * @param  - MemberGrpId_Column_Name
    * @param dbname
    * @return dataframe with column -  UAH_<memberid>,source_<memberid>
    */

  def legacyMemGroupdentitfier(sparkSession: SparkSession, lgcyMemGrpIden: DataFrame, memGrpIdColName: String, dbName: String): DataFrame =
  {

    // select memgroupid,originalSourceSystemID  from memGroupExternalID
    //where originalSourceSystemType = 'PUL' and
    //originalSourceSystemID = <Pulse ID>(pulse_group_code(priot) or pulse goupid)
    val uahMemMerLayer = "UAH_" + memGrpIdColName
    val srcId = "source_" + memGrpIdColName

    // val lgcyMemGrpIden = inputDS.toDF()
    import sparkSession.implicits._

    utility.createView(lgcyMemGrpIden, "lgcyMemGrpIden")
    val memGrpExt = utility.runSql(sparkSession, "select memgroupid,originalSourceSystemID  from " + dbName + ".memgroupid_std where trim(originalSourceSystemType) = 'PUL'")

    utility.createView(memGrpExt, "memGrpExt")

    val joinedRefPul = utility.runSql(sparkSession, "select input.*, "+memGrpIdColName+" as " + srcId + " ,coalesce(ref.memgroupid , input." + memGrpIdColName + ") as " + uahMemMerLayer + "  from lgcyMemGrpIden input left join memGrpExt ref on trim(input." + memGrpIdColName + ") = trim(ref.originalSourceSystemID)")

    //joinedRefPul.withColumn("Ext_src_cd", when((col(extsrcId) isNotNull), lit("CRS")))
    joinedRefPul.drop(memGrpIdColName)
  }

  /*  */
  /**
    * @param -  Dataframe
    * @param  - CSPCD_Column_Name
    * @param - CSP_ID  (Target column name)
    * @param dbname
    *
    * @return dataframe with column - <MemberGrpId_Column_Name>_EXT_SRC , UAH_<MemberGrpId_Column_Name>,EXT_Src_Cd  (override if column exist)
    */

  def legacyCSPIdentitfier(sparkSession: SparkSession, lgcyCSPIden: DataFrame, cspCdColName: String,targetColName : String, dbName: String): DataFrame =
  {

    val uahCSPMerLayer = "UAH_" + targetColName
    val extsrcId = targetColName + "_EXT_SRC"
    //val lgcyCSPIden = inputDS.toDF()
    import sparkSession.implicits._

    utility.createView(lgcyCSPIden, "lgcyCSPIden")
    val refCSP = utility.runSql(sparkSession, "Select memGroupContractPlanOptionID,originalSourceSystemID from " + dbName + ".memGroupContractPlanOptExtView_std where trim(originalSourceSystemType) = 'PUL'")

    utility.createView(refCSP, "refCSP")

    val joinedRefPul = utility.runSql(sparkSession, "select input.*, ref.memGroupContractPlanOptionID as " + extsrcId + ",coalesce(ref.memGroupContractPlanOptionID ,input. " + targetColName + ") as " + uahCSPMerLayer + " from lgcyCSPIden input left join refCSP ref on trim(input." + cspCdColName + ") = trim(ref.originalSourceSystemID)")

    // joinedRefPul.withColumn("Ext_src_cd", when((col(extsrcId) isNotNull), lit("CRS")))
    joinedRefPul.withColumn("Ext_src_cd", lit("CRS"))
  }


  // COPIED FROM DEBRAJ'S CODE AS PART OF UAH_APOLLO_MASTER BRANCH CREATION - DILEEP
  def legacyidentitfierMerge(sparkSession: SparkSession, lgcyMastIden: DataFrame, lgcyIdColName: String, crossWalkDataSet: DataFrame, crossWalkRefIdentifier: String, cirrusIdentifier: String): DataFrame =
  {
    val uahMemMerLayer = "UAH_" + lgcyIdColName
    val extsrcId = lgcyIdColName + "_EXT_SRC"
    import sparkSession.implicits._


    val combinedresult = lgcyMastIden.alias("input").join(
      crossWalkDataSet.alias("ref"),(trim(lgcyMastIden(lgcyIdColName))).cast(StringType) === (trim(crossWalkDataSet(crossWalkRefIdentifier)).cast(StringType)), "left_outer").select(col("input.*"), col("ref." + cirrusIdentifier).alias(extsrcId), coalesce(col("ref." + cirrusIdentifier), col("input." + lgcyIdColName)).alias(uahMemMerLayer))
    // combinedresult.select(col(lgcyIdColName),col(cirrusIdentifier)+ "where" +col(lgcyIdColName) ===  '1004063' ).show(100)
    combinedresult.withColumn("Ext_src_cd", lit("CRS"))
  }

}

