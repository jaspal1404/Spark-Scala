package com.optum.uah.function_library

import scala.collection.JavaConverters._
import scala.collection.mutable.Map

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.Path
import org.apache.hadoop.hbase.CellUtil
import org.apache.hadoop.hbase.HBaseConfiguration
import org.apache.hadoop.hbase.TableName
import org.apache.hadoop.hbase.client.ConnectionFactory
import org.apache.hadoop.hbase.client.Scan
import org.apache.hadoop.hbase.filter._
import org.apache.hadoop.hbase.util.Bytes
import org.apache.spark.sql._
import org.apache.spark.sql.functions._

class CrossRefUtility(hbaseTable: String, hbaseColName: String) extends Serializable {

  /**
    * This function can be used to apply cross reference.
    *
    * @author rgupta59
    * @version 1.0
    */

  var hashMap = Map[String, Map[String, String]]()

  def refDataLoader(referenceTypeArr: Seq[String]) = {
    val conf = HBaseConfiguration.create();
    conf.addResource(new Path("/eds/servers//hbase-1.0.1.1/conf/hbase-site.xml"));
    val connection = ConnectionFactory.createConnection(conf)
    val con = connection.getTable(TableName.valueOf(Bytes.toBytes(hbaseTable)))

    referenceTypeArr.foreach { referenceType =>

      var scanObj = new Scan()
      var allFilters = new FilterList(FilterList.Operator.MUST_PASS_ONE);
      allFilters.addFilter(new PrefixFilter(Bytes.toBytes(referenceType.toLowerCase())));
      scanObj.setFilter(allFilters)
      val scan = con.getScanner(scanObj)

      val map2 = Map[String, String]()
      var keyOne = ""
      scan.asScala.foreach(result => {
        //val keyArr = Bytes.toString(result.getRow)
        val keyArr = Bytes.toString(result.getRow).split("~")
        keyOne = keyArr(0) + "~" + keyArr(1)
        val keyTwo = keyArr(2)
        val cells = result.rawCells();
        val cellMap = Map[String, String]()
        var cell1 = new String
        for (cell <- cells) {
          val col_name = Bytes.toString(CellUtil.cloneQualifier(cell))
          val col_value = Bytes.toString(CellUtil.cloneValue(cell))
          cellMap += (col_name -> col_value)
          if (col_name.equals(hbaseColName)) {
            cell1 = Bytes.toString(CellUtil.cloneValue(cell))
          }
        }
        map2 += (keyTwo -> cell1)
      })
      hashMap += (keyOne -> map2)

    }
  }

  lazy val lookUpVal: ((String, String, String) => String) = (referenceType: String, dataSource: String, value: String) => {

    try {

      hashMap.get(referenceType.toLowerCase() + "~" + dataSource.toLowerCase()).get(value.toLowerCase)

    } catch {
      case e: Exception => value
    }

  }
  lazy val crsRefLkp = udf(lookUpVal)

}
