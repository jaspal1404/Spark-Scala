package com.optum.uah.aggregate_layer

import com.optum.uah.function_library.GlobalContext
import com.optum.uah.function_library.CommonFunctions
import com.optum.uah.function_library.ReadJson
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.SparkSession
import java.io.IOException
import org.apache.spark.SparkContext
import org.apache.spark.sql.functions._

/**
 * @author TeamTitan
 */
object HCE200Customer {

  val gContext = new GlobalContext()
  val func = new CommonFunctions()

  val sparkSession = gContext.getUAHSession("Customer")
  println("### app_id ### :" + sparkSession.sparkContext.applicationId)

  def main(args: Array[String]): Unit = {
    
    val length = 3;
    if (args.length != length) {
      throw new IOException("Arguments mismatch! Expected arguments are : " + length + " , But actual arguments are : " + args.length);
    }

    //Loading json
    ReadJson.createJsonObject(args(0).trim());
    val opPath = args(1).trim();
    val tableName = args(2).trim();
    //val aggDB = sparkSession.conf.get("spark.database.uah.aggregate")
    val mergeDB = sparkSession.conf.get("spark.database.uah.merge")

    //Created dataframes based on the sqls mentioned in json.
    //val memGroupContractPlanOptExtview_stdDF = this.getDataFrame(sparkSession, "memGroupContractPlanOptExtview_std", mergeDB)
    val memGroupContractPlanOptionView_stdDF = this.getDataFrame(sparkSession, "memgroupcontractplanoptionview_std", mergeDB)
    val memGroupAddress_stdDF = this.getDataFrame(sparkSession, "memGroupAddress_std", mergeDB)
    val zipCode_viewDF = this.getDataFrame(sparkSession, "zipCode_view", mergeDB)
    val memGroupContractView_stdDF=this.getDataFrame(sparkSession, "memgroupcontractview_std", mergeDB)
    val memgroupreportingcode_viewDF=this.getDataFrame(sparkSession, "memgroupreportingcode_view", mergeDB)
    val memgroupinsuringrule_viewDF = this.getDataFrame(sparkSession, "memgroupinsuringrule_view", mergeDB)
    
    //Aggregate the data
    val aggDF = this.aggCustomer(memGroupAddress_stdDF, memGroupContractPlanOptionView_stdDF, zipCode_viewDF,memGroupContractView_stdDF,memgroupreportingcode_viewDF,memgroupinsuringrule_viewDF)

    func.writeToParquet(aggDF.distinct(), opPath)
    //func.createExternalTableFromParquet(sparkSession, opPath, tableName, aggDB)
  }

  /**
   * aggCustomer function reads the source dataframes as inputs arguments and do the necessary joins/aggregations and returns final aggregated dataframe.
   */
  def aggCustomer(memGroupAddress_stdDF: DataFrame, memGroupContractPlanOptionView_stdDF: DataFrame, zipCode_viewDF: DataFrame, memGroupContractView_stdDF:DataFrame, memgroupreportingcode_viewDF:DataFrame, memgroupinsuringrule_viewDF:DataFrame): DataFrame = {
    
    //Left Join memgroupid_stdDF with memgroupcontractview_stdDF
    val aggDF = memGroupAddress_stdDF.join(memGroupContractPlanOptionView_stdDF, memGroupAddress_stdDF.col("source_memgroupid").equalTo(memGroupContractPlanOptionView_stdDF.col("source_memgroupid")), "inner").drop(memGroupContractPlanOptionView_stdDF.col("uah_memgroupid")).drop(memGroupContractPlanOptionView_stdDF.col("source_memgroupid"))
    
    //Left Join aggDF with zipCode_viewDF
    val aggDFNew = aggDF.join(zipCode_viewDF, aggDF.col("source_memgroupid").equalTo(zipCode_viewDF.col("source_memgroupid")), "inner").drop(zipCode_viewDF.col("source_memgroupid"))
    
    //Left Join aggDFNew with memGroupContractView_stdDF
    val aggDFNewFinal = aggDFNew.join(memGroupContractView_stdDF,aggDFNew.col("source_memgroupid").equalTo(memGroupContractView_stdDF.col("source_memgroupid")),"inner").drop(memGroupContractView_stdDF.col("source_memgroupid"))
    
    //Left Join aggDFNewFinal with memgroupreportingcode_viewDF
    val aggDFNewFinalUpdated = aggDFNewFinal.join(memgroupreportingcode_viewDF,aggDFNewFinal.col("source_memgroupid").equalTo(memgroupreportingcode_viewDF.col("source_memgroupid")),"inner").drop(memgroupreportingcode_viewDF.col("source_memgroupid"))
    
    //Left Join aggDFNewFinalUpdated with memgroupinsuringrule_viewDF
    val Final_joinDF = aggDFNewFinalUpdated.join(memgroupinsuringrule_viewDF,aggDFNewFinalUpdated.col("source_memgroupid").equalTo(memgroupinsuringrule_viewDF.col("source_memgroupid")),"inner").drop(memgroupinsuringrule_viewDF.col("source_memgroupid"))
    
    Final_joinDF.createOrReplaceTempView("CE_View")
    
    val CustomerDF = sparkSession.sql("SELECT address1, address2, city, state, postalcode , memgroupname , phoneext , phonenum , industryclasscode , source_memgroupid , uah_memgroupid , source_cd , addresstype  ,uah_memgroupcontractplanoptionid, uah_memgroupcontractoptid ,countyname  , uah_memgroupcontractid , reportingcodetype , referencedesc , IF(insurancecontinuationtype='01', 'Y', 'N') as insurancecontinuationtype from CE_View").dropDuplicates
 // val CustomerDF = sparkSession.sql("SELECT address1, address2, city, state, postalcode , memgroupname , phoneext , phonenum , industryclasscode , source_memgroupid , uah_memgroupid , source_cd , addresstype , memgroupcontractplanoptionid , memgroupcontractoptid , countyname , source_memgroupcontractgcid , uah_memgroupcontractgcid , reportingcodetype , referencedesc , IF(insurancecontinuationtype='01', 'Y', 'N') as insurancecontinuationtype from CE_View").dropDuplicates
    CustomerDF
  }

  /**
   * getDataFrame returns a DataFrame by using SparkSession and json propertyKey as inputs
   */
  def getDataFrame(sparkSession: SparkSession, propertyKey: String, mergeDB: String): DataFrame = {
    if (null != mergeDB)
      sparkSession.sql("use " + mergeDB);
    func.runSql(sparkSession, ReadJson.getProperty(propertyKey))
  }

}