package com.optum.uah.merge_layer.history

import com.optum.uah.function_library.{CommonFunctions, GlobalContext, ReadJson}
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, max, row_number}

/**
  * Created by jsingh73 on 11/6/2017.
  */
object UAHCirHistory {

  val CommonFunctions = new CommonFunctions()
  val GlobalContext = new GlobalContext()
  val log: Logger = Logger.getLogger(getClass.getName)

  def main(args: Array[String]): Unit = {

    val tgtLoc = args(0)
    val propFilePath = args(1)
    val tblName = tgtLoc.split("mergelayer/")(1)
    val colList = args(2)
    val workingDir =  tgtLoc.split("/"+tblName).head+ "/working/" +  tblName

    // Log info
    log.info("Job Name: " + tblName + " Cirrus merge layer extract")
    log.info("Job Group: Underwriting")
    log.info("Event1: Job execution started")

    //Load json property file to get sql based on the subject area and table
    ReadJson.createJsonObject(propFilePath)

    // Save timestamp 39 months older than current
    var maxLoadTimestamp = CommonFunctions.getHbaseMrglayerTs(tblName)

    val sparkSession = GlobalContext.getRnASession("RnASession")

    // Call function to load Cirrus data
    val cirDeltaDf = getCirrusData(maxLoadTimestamp, tblName, sparkSession).sort()

    println("**********************: " + cirDeltaDf.count())

    // Removing attribute level duplicates
    val grpByCols = cirDeltaDf.columns.slice(0, cirDeltaDf.schema.fieldIndex("key")).toSeq.map(x => col(x))
    val orderByCols = colList.split(",").toSeq.map(x => col(x).desc)
    val w = Window.partitionBy(grpByCols: _*).orderBy(orderByCols: _*)
    val cirDf = cirDeltaDf.withColumn("rn", row_number.over(w)).where(col("rn") === 1).drop("rn")

    // Run the load process only if we have incremental records
    if (cirDf.count() != 0) {

      // Load spark session for uah metastore
      val sparkSession = GlobalContext.getUAHSession("UAHSession")

      // Update Hbase table with max load timestamp of the record
      maxLoadTimestamp = cirDeltaDf.agg(max("uah_timestamp")).first()(0).toString
      CommonFunctions.updateHbaseMrglayerTs(tblName, maxLoadTimestamp)

      // Save records into the merge layer *****
      CommonFunctions.saveDataframeAsFile(cirDf, tgtLoc+"/source_cd=CRS", "append")

    }

    log.info("Record count: " + cirDf.count())
    log.info("Event2: Job completed")

    sparkSession.close()
  }


  def getCirrusData(maxLoadTimestamp: String, tblName: String, sparkSession: SparkSession): DataFrame = {


    var resultDf: DataFrame = sparkSession.emptyDataFrame

    // Load data from cirrus table into a dataframe with incremental data
    if ( maxLoadTimestamp == "Null") {
      resultDf = CommonFunctions.runSql(sparkSession, ReadJson.getProperty(tblName)).filter(col("record_status") === "active")
    }
    else {
      resultDf = CommonFunctions.runSql(sparkSession, ReadJson.getProperty(tblName)).filter("uah_timestamp > \"" + maxLoadTimestamp + "\"").filter(col("record_status") === "active")
    }

    resultDf
  }

}
