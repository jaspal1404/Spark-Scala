package com.optum.uah.merge_layer.provider
import com.optum.uah.function_library.{ CommonFunctions, GlobalContext, ReadJson }
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.DataFrame

object NetworkCrosswalk {
  val GContext = new GlobalContext()
  val func = new CommonFunctions()

  def getPulseNetwork(): DataFrame = {
    val sparkSession = GContext.getUAHSession("NetworkUAH")
    import sparkSession.implicits._
    //val networkidquerysrchview_std = func.runSql(sparkSession, "select network_id,network,network_name from uah_cdw_prod.uah_cdw_dss_i_network")
    val legacyNetork = func.runSql(sparkSession, ReadJson.getProperty("legacyNetwork"))

    legacyNetork
  }

  def getFileNetwork(sparkSession: SparkSession, networkunique: DataFrame, csvPath: String): DataFrame = {
    val spreadSheet = sparkSession.read.format("csv").option("header", "true").option("header", "true").option("delimiter", ",").option("multiLine", "true").option("parserLib", "univocity").load(csvPath)
    val cirrusSpreadsheet = spreadSheet.join(networkunique, networkunique.col("networkDesc") === spreadSheet.col("Cirrus Network Object Name"), "inner")
    cirrusSpreadsheet

  }

  def loadNetworkLookup(csvPath: String): DataFrame = {
    val sparkSession = GContext.getRnASession("NetowrkRnA")
    import sparkSession.implicits._

    //val networkidquerysrchview_std = func.runSql(sparkSession, "select trim(networkdesc) as networkdesc,networknetworkID,networkidoriginalsourcesystemid,cast(trim(run_id) as decimal) as run_id,cast(trim(load_timestamp) as date) as load_timestamp,trim(record_status) as record_status,trim(key) as key from RNACIRRUSDB.networkidquerysrchview_std where trim(networkidoriginalsourcesystemtype) = 'PUL'")
    val networkidquerysrchview_std = func.runSql(sparkSession, ReadJson.getProperty("cirrusNetwork"))

    val network = Window.partitionBy('key).orderBy('load_timestamp.desc, 'run_id.desc)
    val seqNumber = Window.orderBy('Source_Network_Business_Code)

    val networkunique = networkidquerysrchview_std.withColumn("row", rank().over(network)).filter('row === 1).drop("row")

    val networkMig = networkunique.filter(trim(col("networkidoriginalsourcesystemtype")) === "PUL")

    val spreadSheetLookup = getFileNetwork(sparkSession, networkunique, csvPath).dropDuplicates()

    val pulNetwork = getPulseNetwork()

    val spreadSheetColumns = spreadSheetLookup.join(pulNetwork, trim(spreadSheetLookup.col("PULSE Network code")) === trim(pulNetwork.col("network")), "inner")

    val spreadlookup = spreadSheetColumns.select('network_id.alias("Source_Network_Identifier"), 'networknetworkID.alias("cirrus_network_identifier"), 'network.alias("Source_Network_Business_Code")).dropDuplicates()

    val cirrusMigrated = networkMig.select("networknetworkID", "networkidoriginalsourcesystemid")

    val cirrusMigLookup = cirrusMigrated.join(pulNetwork, trim(cirrusMigrated.col("networkidoriginalsourcesystemid")) === trim(pulNetwork.col("network_id")), "inner").select('network_id.alias("Source_Network_Identifier"), 'networknetworkID.alias("cirrus_network_identifier"), 'network.alias("Source_Network_Business_Code"))
    val finalLookup = cirrusMigLookup.union(spreadlookup).dropDuplicates()

    cirrusMigLookup.union(spreadlookup).withColumn("network_lookup_identifier", row_number().over(seqNumber)).withColumn("row_timestamp", from_unixtime(unix_timestamp())).withColumn("Source_code", lit("PUL")).withColumn("active_flag", lit("Active"))

  }
  def main(args: Array[String]): Unit = {
    var csvPath = args(2)
    val path = args(0) + "/network_lookup_std"
    val propFilePath = args(1)
    ReadJson.createJsonObject(propFilePath)

    val columns = Seq("network_lookup_identifier", "Cirrus_Network_Identifier", "Source_Network_Identifier", "Source_Network_Business_Code", "Row_Timestamp", "Source_code", "active_flag")

    val finalcrossWalk = loadNetworkLookup(csvPath).select(columns.map(c => col(c)): _*)

    //finalcrossWalk.write.mode("overwrite").parquet(path)
    func.saveDataframeAsFile(finalcrossWalk, path, "overwrite")
    
    //Temp Table creation
    val sparkSession = GContext.getUAHSession("network_crosswalk")
    //func.createExternalTableFromParquet(sparkSession, path, "network_lookup_std", sparkSession.conf.get("spark.database.uah.merge"))

    GContext.stop()
  }

}