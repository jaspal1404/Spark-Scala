/*
*******Commenting due to unresolved compilation errors

package com.optum.uah.merge_layer.member
import com.optum.uah.function_library.{CommonFunctions, GlobalContext, MasterIdentifier, ReadJson, Logger, CrossRefUtility}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}

import com.optum.uah.function_library.{CommonFunctions, GlobalContext, ReadJson, CrossRefUtility, MasterIdentifier, Logger}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.DataFrame

/**
  * Created by sbandar8 on 10/13/2017.
  */
object UahCdwMember_MAH {

//  @transient lazy val log = Logger.getLogger(getClass.getName)

  val context = new GlobalContext()
  val func = new CommonFunctions()

  val crossRef = new CrossRefUtility("/datalake/optum/optuminsight/d_uah/dev/d_mtables/datacrosswalk", "uah_code")
  val crossWalk = new MasterIdentifier()

  //Main()
  def main(args: Array[String]): Unit = {

    val spark_uah = context.getUAHSession("MemberUAH_cdw")
    spark_uah.sql("set spark.sql.caseSensitive=false")
    spark_uah.sql("set spark.sql.parquet.writeLegacyFormat=true")
    spark_uah.sql("use uah_cdw_prod")

    val spark_rna = context.getRnASession("MemberRnA")
    spark_rna.sql("set spark.sql.caseSensitive=false")
    spark_rna.sql("set spark.sql.parquet.writeLegacyFormat=true")
    spark_rna.sql("use uhc_pfv_tst")


    val tgtLoc = args(0)
    val propFilePath = args(1)

    ReadJson.createJsonObject(propFilePath)

    val memberBenefitPath = tgtLoc + "/memberbenefit_std"
    val memGroupContractPlanOptExtViewPath = tgtLoc + "/memgroupcontractplanoptextview_std"
    val memberBenefitCovLevelCodePath = tgtLoc + "/memberbenefitcovlevelcode_std"
    val subsaffiliationPath = tgtLoc + "/subsaffiliationview_std"

    val memberBenefitTbl = memberBenefitPath.split("mergelayer/")(1)
    val memGroupContractPlanOptExtviewTbl = memGroupContractPlanOptExtViewPath.split("mergelayer/")(1)
    val memberBenefitCovLevelCodeTbl = memberBenefitCovLevelCodePath.split("mergelayer/")(1)
    val subsaffiliationTbl = subsaffiliationPath.split("mergelayer/")(1)


    println("creating DataFrames and Parquet Files")

    val memberBenefitdf = getcdw_MemberBenefit(spark_uah, spark_rna).distinct()
    memberBenefitdf.write.mode("overwrite").parquet(memberBenefitPath + "/source_cd=PUL")

    val memGroupContractPlanOptExtViewDF = getcdw_memGroupContractPlanOptExtviewdf(spark_uah, spark_rna)
    memGroupContractPlanOptExtViewDF.write.mode("overwrite").parquet(memGroupContractPlanOptExtViewPath + "/source_cd=PUL")

    val memberBenefitCovLevelCodedf = getcdw_memberBenefitCovLevelCode_std(spark_uah, spark_rna)
    memberBenefitCovLevelCodedf.write.mode("overwrite").parquet(memberBenefitCovLevelCodePath + "/source_cd=PUL")

    val subsaffiliationdf = getcdw_subsaffiliationdf(spark_uah, spark_rna)
    subsaffiliationdf.write.mode("overwrite").parquet(subsaffiliationPath + "/source_cd=PUL")


  }

  /**
    * populate memGroupContractPlanOptExtview_std table attributes with Cross Walk
    *
    * @param spark_uah
    * @return
    */

  def getcdw_memGroupContractPlanOptExtviewdf(spark_uah: SparkSession, spark_rna: SparkSession) = {
    val memGroupContractPlanOptExtviewCDWDF = func.runSql(spark_uah, ReadJson.getProperty("memGroupContractPlanOptExtview_std_cdw"))
    val cdwDF = spark_rna.createDataFrame(memGroupContractPlanOptExtviewCDWDF.rdd, memGroupContractPlanOptExtviewCDWDF.schema)

    /* Applying cross walk */
    val resDF = crossWalk.legacyCSPIdentitfier(spark_rna, cdwDF, "contract_spec_pkg_code", "contract_specific_pkg_id", "uhc_pfv_tst")
    resDF
  }

  /**
    * populate subsaffiliation_std table attributes with Cross Walk and Cross Reference
    *
    * @param spark_uah
    * @return DataFrame
    */
  def getcdw_subsaffiliationdf(spark_uah: SparkSession, spark_rna: SparkSession) = {

    val subsaffiliation_std_cdw = func.runSql(spark_uah, ReadJson.getProperty("subsaffiliation_std_cdw"))
    val subsaffiliation_std_cdwDF = subsaffiliation_std_cdw.select("member_id", "relationship_type", "key", "uah_timestamp", "record_status", "source_cd").distinct()

    /* Applying cross reference */
    val seq = Seq("relationship_type~Oxford")
    val res_seq = crossRef.refDataLoader(seq)
    val subsaffiliation_Xref = subsaffiliation_std_cdwDF.withColumn("relationship_type2", crossRef.crsRefLkp(lit("relationship_type"), lit("Oxford"), col("relationship_type")))
    val subsaffiliation_Xref2 = subsaffiliation_Xref.drop("relationship_type").withColumnRenamed("relationship_typ2", "relationship_type").select("member_id", "relationship_type2", "key", "uah_timestamp", "record_status", "source_cd")
    subsaffiliation_Xref2.printSchema()

    /* Applying cross walk */
    val cdwDF = spark_rna.createDataFrame(subsaffiliation_Xref2.rdd, subsaffiliation_Xref2.schema)
    val resDF = crossWalk.legacyMemberdentitfier(spark_rna, cdwDF, "member_id", "uhc_pfv_tst")
    resDF

  }


  /**
    * populate memberbenefit_std table attributes with Cross Walk and Cross Reference
    *
    * @param spark_uah
    * @return DataFrame
    */
  def getcdw_memberBenefitCovLevelCode_std(spark_uah: SparkSession, spark_rna: SparkSession): DataFrame = {
    val memberBenefitCovLevelCode_std_cdw = func.runSql(spark_uah, ReadJson.getProperty("memberBenefitCovLevelCode_std_cdw"))
    val cdwDF = memberBenefitCovLevelCode_std_cdw.select("member_id", "contract_type", "contract_type2", "key", "uah_timestamp", "record_status", "source_cd").distinct()

    /* Applying cross reference */
    val seq = Seq("contract_type~Oxford")
    val res_seq = crossRef.refDataLoader(seq)
    val cdw_benefit_ref = cdwDF.withColumn("contract_type3", crossRef.crsRefLkp(lit("contract_type"), lit("Oxford"), col("contract_type")))
    cdw_benefit_ref.printSchema()

    val cdw_benefit_ref3 = cdw_benefit_ref.drop(col("contract_type")).withColumnRenamed("contract_type3", "contract_type").select("member_id", "contract_type", "key", "uah_timestamp", "record_status", "source_cd")

    /* Applying cross walk */
    val df2 = spark_rna.createDataFrame(cdw_benefit_ref3.rdd, cdw_benefit_ref3.schema)
    val resDF = crossWalk.legacyMemberdentitfier(spark_rna, df2, "member_id", "uhc_pfv_tst")
    resDF
  }
  /**
    * populate memberbenefit_std table attributes with Cross walk data
    *
    * @param spark_uah
    * @param spark_rna
    * @return DataFrame
    */
  def getcdw_MemberBenefit(spark_uah: SparkSession, spark_rna: SparkSession): DataFrame = {
    println("printing dfc ::" + ReadJson.getProperty("memberbenefit_std_cdw"))

    val memberbenefit_std_cdw = func.runSql(spark_uah, ReadJson.getProperty("memberbenefit_std_cdw")).select("member_id", "group_code", "effective_from_date", "effective_thru_date", "product", "pick_member", "member_id_subscr", "key", "uah_timestamp", "record_status", "source_cd")
    val cdwDF = spark_rna.createDataFrame(memberbenefit_std_cdw.rdd, memberbenefit_std_cdw.schema)

    /* Applying cross walk */
    val resDF = crossWalk.legacyMemberdentitfier(spark_rna, cdwDF, "member_id", "uhc_pfv_tst")
    resDF
  }
}
*/