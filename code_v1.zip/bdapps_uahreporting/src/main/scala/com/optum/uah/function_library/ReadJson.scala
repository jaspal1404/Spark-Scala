package com.optum.uah.function_library

import org.json4s.JValue
import org.json4s.JsonAST.JValue
import org.json4s._
import org.json4s.jackson.JsonMethods._


object ReadJson {

  var js: JValue = _

  def main(args: Array[String]): Unit = {

    println("***Read json Class")
  }


  def createJsonObject(Path: String): JValue = {
    implicit val formats = DefaultFormats
    val source = scala.io.Source.fromFile(Path)
    val lines = try
      source.getLines mkString
    catch {
      case e: Exception => { e.printStackTrace(); e.toString() }
    } finally source.close()
    js = parse(lines)

    js
  }

  def getProperty(prop: String): String ={
    val p = getElem(prop)
    if ( p != null && !p.isEmpty ) p(0) else ""

  }

  def getElem(elem: String) = for {
    JObject(child) <- js
    JField(`elem`, JString(value)) <- child
  } yield value


}
