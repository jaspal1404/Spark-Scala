package com.optum.uah.merge_layer.provider
import com.optum.uah.function_library.{ CommonFunctions, GlobalContext, ReadJson }
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.DataFrame
import org.apache.log4j.Level
import com.optum.uah.function_library.Logger.log
import org.apache.spark.sql.functions._
import com.optum.uah.function_library.MasterIdentifier
import org.apache.spark.storage.StorageLevel

object UAHProviderTransformLegacy {
  val GContext = new GlobalContext()
  val func = new CommonFunctions()
//  val rJson = new ReadJson(GContext.runHome + "/hce200Provider.json")
  ReadJson.createJsonObject(GContext.runHome + "/hce200Provider.json")

  /* Defining  the main entry for a Spark submit . We normally use it for testing
* */

  def main(args: Array[String]): Unit = {
    val sparkSession = GContext.getUAHSession("ProviderUAH")
    val CrossWalkDF = ProviderCrosswalk.getProviderCrosswalk().toDF()
    val legacyPostCross = getLegacyCrosswalked(CrossWalkDF)
    log.info("Getting results afterCrossWalk")
    var path = args(0) + "/providerlegacycrosswalked" + "/" + System.currentTimeMillis()
    func.saveAsFileforDataset(legacyPostCross, "parquet", path)
    // func.createExternalTableFromParquet(sparkSession, path, "uah_e_cdw_crossdatapostwalk", args(2))
    //  groupaffDataSet.printSchema()

    val groupAffDataPostCross = getLegacyCrosswalked(CrossWalkDF)
    val pathgrpaff = args(0) + "/provideraffiliation" + "/" + System.currentTimeMillis()
    func.saveAsFileforDataset(groupAffDataPostCross, "parquet", pathgrpaff)
    //func.createExternalTableFromParquet(sparkSession, pathgrpaff, "uah_e_cdw_crossgrpAff", args(2))
    /*******Code Ends for Group Affiliation****/
    GContext.stop()
  }

  def getLegacyCrosswalked(CrossWalkDF: DataFrame):  DataFrame={
    log.info("CrossWalk=============================================================")
    val sparkSessionRnA = GContext.getRnASession("ProviderRnA")
    val legacyDataSet = UAHCdwProvider.getProviderLegacy()
    val legacyDataSetDF = sparkSessionRnA.createDataFrame(legacyDataSet.rdd, legacyDataSet.schema)
    log.info("CrossWalk show after=============================================================")
    val MasterIdentifier = new MasterIdentifier()
    val providerlegacycrosswalked = (MasterIdentifier.legacyidentitfierMerge(sparkSessionRnA, legacyDataSetDF, "providerid", CrossWalkDF, "sourceprovideridentifier", "cirrusprovideridentifier")).persist(StorageLevel.MEMORY_ONLY_SER)
    providerlegacycrosswalked
    /*******Code starts for Group Affiliation****/

  }
  
   def getNetworkCrosswalked(providerLegacy: DataFrame,CrossWalkDF: DataFrame):  DataFrame={
    log.info("CrossWalk   Network=============================================================")
    val sparkSessionRnA = GContext.getRnASession("ProviderRnA")
    val legacyDataSetDF = sparkSessionRnA.createDataFrame(providerLegacy.rdd, providerLegacy.schema)
    log.info("CrossWalk show after=============================================================")
    val MasterIdentifier = new MasterIdentifier()
    val providerlegacycrosswalked = (MasterIdentifier.legacyidentitfierMerge(sparkSessionRnA, legacyDataSetDF, "networkID", CrossWalkDF, "source_network_business_code", "cirrus_network_identifier")).persist(StorageLevel.MEMORY_ONLY_SER)
    providerlegacycrosswalked
    /*******Code starts for Group Affiliation****/

  }
  def getProviderGroupAffiliationCrosswalked(CrossWalkDF: DataFrame):  DataFrame ={
    val sparkSessionRnA = GContext.getRnASession("ProviderRnA")
    val groupAffDataSet = UAHCdwProvider.getGroupAffiliationLegacy()
    val groupAffDataSetDF = sparkSessionRnA.createDataFrame(groupAffDataSet.rdd, groupAffDataSet.schema)
    val MasterIdentifier = new MasterIdentifier()
    val providergroupaffiliationcrosswalked = (MasterIdentifier.legacyidentitfierMerge(sparkSessionRnA, groupAffDataSetDF, "providerid", CrossWalkDF, "sourceprovideridentifier", "cirrusprovideridentifier")).persist(StorageLevel.MEMORY_ONLY_SER)
    log.info("Getting results afterCrossWalk")
    providergroupaffiliationcrosswalked
  }

}