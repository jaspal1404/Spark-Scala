package com.optum.uah.aggregate_layer
import com.optum.uah.function_library.{ CommonFunctions, GlobalContext, ReadJson }
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.DataFrame
import com.optum.uah.function_library.Logger.log
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType
object test {
  def main(args: Array[String]): Unit = {
    val GContext = new GlobalContext()
    val func = new CommonFunctions()
    val sparkSession = GContext.getUAHSession("ProviderUAH")
    var path = "/datalake/optum/optuminsight/d_uah/dev/d_hdfs/mergelayer"
    func.createExternalTableFromParquet(sparkSession, path+"/produceraddressview_std/source_cd=CRS", "produceraddressview_std", args(1))
  func.createExternalTableFromParquet(sparkSession, path+"/memgroupcontractproducerview_std/source_cd=CRS", "memgroupcontractproducerview_std", args(1))
      
  }
}
