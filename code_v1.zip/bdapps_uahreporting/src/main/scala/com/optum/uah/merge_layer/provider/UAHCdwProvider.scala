package com.optum.uah.merge_layer.provider

import com.optum.uah.function_library.{CommonFunctions, GlobalContext, ReadJson }
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.DataFrame
import com.optum.uah.function_library.Logger.log
import org.apache.spark.sql.functions._

object UAHCdwProvider {
   val GContext = new GlobalContext()
  val func = new CommonFunctions()
//  val rJson = new ReadJson(GContext.runHome + "/hce200Provider.json")
  ReadJson.createJsonObject(GContext.runHome + "/hce200Provider.json")

  /* Defining  the main entry for a Spark submit . We normally use it for testing
 * */

  def main(args: Array[String]): Unit = {
   
    val providerDataSet = getGroupAffiliationLegacy()
    val sparkSession = GContext.getUAHSession("ProviderUAH")
    var path = args(0)+ "/uah_e_cdw_groupAffiliationLegacy" +  "/" + System.currentTimeMillis()
    func.saveAsFileforDataset(providerDataSet, "parquet", path)
    func.createExternalTableFromParquet(sparkSession, path, "uah_e_cdw_groupAffiliationLegacy", args(1)) //test it with a small file
    providerDataSet.printSchema()
    val groupaffDataSet = getProviderLegacy()
    path = args(0)+ "/uah_e_cdw_providerLegacyUAH" +  "/" +  System.currentTimeMillis()
    func.saveAsFileforDataset(groupaffDataSet, "parquet", path)
    func.createExternalTableFromParquet(sparkSession, path, "uah_e_cdw_providerLegacyUAH", args(1))
    groupaffDataSet.printSchema()
    GContext.stop()
   
    
  }
   
   def getProviderLegacy(): DataFrame = {
    val sparkSession = GContext.getUAHSession("ProviderUAH")
    import sparkSession.implicits._
    func.runSql(sparkSession, ReadJson.getProperty("ProviderLegacyAll"))
  }

  def getGroupAffiliationLegacy(): DataFrame = {
    val sparkSession = GContext.getUAHSession("ProviderUAH")
    import sparkSession.implicits._
    val providerDataset1 = func.runSql(sparkSession, ReadJson.getProperty("ProviderAffiliation"))
    val providerDataset2 = func.runSql(sparkSession, ReadJson.getProperty("ProviderLegacySet1"))
    val providerDataset3 = providerDataset2.join(providerDataset1, Seq("provider_id"), "left_outer").select(col("provider_id"),col("provider_code"),coalesce(col("last_name"),col("facility_name")).alias("LAST_NAME"),col("first_name"), col("federal_tax_id"),col("affil_provider_id"),col("provider_type")).filter(col("provider_type").notEqual("GRP"))
    val providerDataset4 =  providerDataset2.alias("a").join(providerDataset3.alias("b"), providerDataset2("provider_id") === providerDataset3("affil_provider_id"),"inner").select(col("a.provider_id").alias("providerid"),col("b.provider_code").alias("PROVCODE"),col("b.LAST_NAME").alias("PRVLNAME"),col("b.first_name").alias("PRVFNAME"),col("a.provider_code").alias("GROUPCOD"), col("a.facility_name").alias("GROUPNAM"),col("a.federal_tax_id")
        .alias("PRVTAXID"),col("a.provider_type"))
    providerDataset4 
  }
  
}