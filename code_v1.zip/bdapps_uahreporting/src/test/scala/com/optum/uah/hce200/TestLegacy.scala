/*
package com.optum.uah.hce200
import org.apache.log4j.PropertyConfigurator
import com.optum.uah.function_library.{CommonFunctions, GlobalContext, ReadJson }
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.DataFrame
import org.apache.log4j.Level
import com.optum.uah.function_library.Logger.log
import com.optum.uah.merge_layer.provider.UAHCdwProvider
import org.apache.spark.sql.functions._
object TestLegacy {
    val GContext = new GlobalContext()
    val func = new CommonFunctions()
    val rJson = new ReadJson(GContext.runHome + "/HCE200Provider.json")
    def main(args: Array[String]): Unit = {
   
    val providerDataSet = UAHCdwProvider.getGroupAffiliationLegacy()
    val sparkSession = GContext.getUAHSession("ProviderUAH")
    var path = args(0)+ "/uah_e_cdw_groupAffiliationLegacy" +  "/" + System.currentTimeMillis()
    func.saveAsFileforDataset(providerDataSet, "parquet", path)
    func.createExternalTableFromParquet(sparkSession, path, "uah_e_cdw_groupAffiliationLegacy", args(2)) //test it with a small file
    providerDataSet.printSchema()
    val groupaffDataSet = UAHCdwProvider.getGroupAffiliationLegacy()
    path = args(0)+ "/uah_e_cdw_providerLegacyUAH" +  "/" +  System.currentTimeMillis()
    func.saveAsFileforDataset(groupaffDataSet, "parquet", path)
    func.createExternalTableFromParquet(sparkSession, path, "uah_e_cdw_providerLegacyUAH", args(2))
    groupaffDataSet.printSchema()
    GContext.stop()
  }
}

*/