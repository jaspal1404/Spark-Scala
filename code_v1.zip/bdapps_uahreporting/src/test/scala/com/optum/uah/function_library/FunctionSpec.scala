/*
package com.optum.uah.function_library

import org.apache.spark.sql.SparkSession



class FunctionSpec extends CommonSpec {
  //def mockSparkContext[T]: org.apache.spark.sql.SparkSession = null
  //val sparkContext = mockSparkContext

  var sparkSession: SparkSession = _

  override def beforeEach() {
    sparkSession = SparkSession.builder().appName("unit tests")
      .master("local")
      .config("", "")
      .getOrCreate()
  }

  "The read properties" should "take a path" in {
    val func = new CommonFunctions()
    val grandParent = getClass.getResource("../../../../").toString()
    println(grandParent)
    val prop = func.readPropertiesFile(grandParent + "/" + "HCE200Provider.json")
    assert(prop != null)
  }

  it should "throw NoSuchPathException if the path is empty" in {
    val func = new CommonFunctions()
    val grandParent = getClass.getResource("../../../../").toString()
    assertThrows[NoSuchPathException] {
      func.readPropertiesFile("")
    }
    assertThrows[NoSuchPathException] {
      func.createDataFrame(sparkSession, "", "")
    }
  }


 it should "create a dataframe from a text file" in {
    val func = new CommonFunctions()
    val grandParent = getClass.getResource("../../../../").toString()
    func.createDataFrame(sparkSession, grandParent + "/" + "HCE200Provider.json", "text")
  }

  //DS for tab 1
  it should "compare  a dataframe created  from a text file with the one created thru api" in {
    val func = new CommonFunctions()
    val grandParent = getClass.getResource("../../").toString()
    val dt = func.createDataFrame(sparkSession, "C:\\uah\\provider.dat", "csv")//TODO: to point to jenkins setup
    val df = sparkSession.read.option("header", "false").csv("C:\\uah\\provider.dat")
    // val db=sparkSession.read.option("header", "false").csv("C:\\Users\\vkoul\\git\\bdapps_uahreporting\\src\\test\\scala\\resources\\memberAccount_snapshotorc.dat")
    val columns = df.schema.fields.map(_.name)
    val selectiveDifferences = columns.map(col => df.select(col).except(dt.select(col)))
    var tt = 100
    selectiveDifferences.map(diff => { if (diff.count > 0) tt = diff.count().toInt })

    assert(tt == 100)

  }

  //DS for tab 2
  it should "compare negative scenario a dataframe created  from a text file with the one created thru api" in {
    val func = new CommonFunctions()
    val grandParent = getClass.getResource("../../").toString()
    val dt = func.createDataFrame(sparkSession, "C:\\uah\\provider.dat", "csv")//TODO: to point to jenkins setup
    val df = sparkSession.read.option("header", "false").csv("C:\\uah\\provider1.dat")//TODO: to point to jenkins setup
    // val db=sparkSession.read.option("header", "false").csv("C:\\Users\\vkoul\\git\\bdapps_uahreporting\\src\\test\\scala\\resources\\memberAccount_snapshotorc.dat")
    val columns = df.schema.fields.map(_.name)
    val selectiveDifferences = columns.map(col => dt.select(col).except(df.select(col)))
    var tt = 100
    selectiveDifferences.map(diff => { if (diff.count > 0) tt = diff.count().toInt })

    assert(tt != 100)

  }
  override def afterEach() {
    sparkSession.stop()
  }
}

*/