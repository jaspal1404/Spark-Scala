package com.optum.uah.aggregate_layer

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.SparkSession
import org.scalatest.FunSuite

import com.optum.uah.function_library.CommonFunctions
import com.optum.uah.function_library.GlobalContext

class HCE200CustomerTest extends FunSuite {
  val gContext = new GlobalContext()
  val func = new CommonFunctions()

  val sparkLocal = SparkSession.builder().master("local").appName("Customer").getOrCreate()

  def loadCsv(sparkSession: SparkSession, path: String, columnSeparatorN: String): DataFrame = {
    val df = sparkSession.read.format("csv").option("header", "true").option("mode", "DROPMALFORMED").option("inferSchema", "true").option("delimiter", columnSeparatorN).load(path);
    df
  }

  test("Customer :comparing Aggregate Layer DF Count") {

    val expected_df = this.loadCsv(sparkLocal, "target/test-classes/customer_expected_df.csv", ",")

    val memGroupContrctPanOPtExtviewDF = this.loadCsv(sparkLocal, "target/test-classes/memGroupContractPlanOptExtview_std2.csv", ",")
    val memGroupAddress_stdDF = this.loadCsv(sparkLocal, "target/test-classes/memGroupAddress_std.csv", ",")
    val zipCode_viewDF = this.loadCsv(sparkLocal, "target/test-classes/zipCode_view.csv", ",")

    val aggDF = memGroupAddress_stdDF.join(memGroupContrctPanOPtExtviewDF, memGroupAddress_stdDF.col("source_memgroupid").equalTo(memGroupContrctPanOPtExtviewDF.col("PICK_GROUP_CODE")), "left_outer").drop(memGroupAddress_stdDF.col("source_memgroupid"))

    aggDF.join(zipCode_viewDF, aggDF.col("PICK_GROUP_CODE").equalTo(zipCode_viewDF.col("source_memgroupid")), "left_outer").drop("source_memgroupid")
    aggDF.show()

    println("Record Count :" + aggDF.count)

    println("Actual DF Count::" + aggDF.count)

    assert(expected_df.count() == aggDF.count())
  }

}