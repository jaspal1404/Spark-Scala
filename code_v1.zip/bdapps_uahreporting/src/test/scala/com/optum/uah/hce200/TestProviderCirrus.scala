/*
package com.optum.uah.cirrus
import com.optum.uah.function_library.{CommonFunctions,GlobalContext,ReadJson}
import com.optum.uah.SVIEWS.SharedViewsHCE200
import org.apache.spark.sql.Dataset
import org.apache.log4j.Level
import com.optum.uah.function_library.Logger.log
object TestProviderCirrus {
  val GContext = new GlobalContext()
  val func = new CommonFunctions()
  val rJson = new ReadJson(GContext.runHome + "/HCE200Provider.json")  
  log.setLevel(Level.ALL)
  def main(args: Array[String]): Unit = {
    println("arguement 1" + args(0))
    println("arguement 2" + args(1))
    val path = args(0) + "/" + System.currentTimeMillis()
    val databasename = args(1)
    log.info("In the driver: Arguements are"+args(0)+"  "+args(1))
    save(SharedViewsHCE200.getCirrusProviderorglocationphnview_std(),path,"Providerorglocationphnview_std",databasename)
    save(SharedViewsHCE200.getCirrusProvtinaddressesview_std(),path,"Provtinaddressesview_std",databasename)
    save(SharedViewsHCE200.getCirrusProviderorgfacility_snapshotorc(),path,"Providerorgfacility_snapshotorc",databasename)
    save(SharedViewsHCE200.getCirrusProvideridentifiersearchview_std(),path,"Provideridentifiersearchview_std",databasename)
    save(SharedViewsHCE200.getCirrusProviderorgaffiliationtinview_std(),path,"Providerorgaffiliationtinview_std",databasename)
    save(SharedViewsHCE200.getCirrusProviderorgidview_std(),path,"Providerorgidview_std",databasename)
    save(SharedViewsHCE200.getCirrusProvideridlocationview_std(),path,"Provideridlocationview_std",databasename)
    save(SharedViewsHCE200.getCirrusClaimpricinginputdetailview_std(),path,"Claimpricinginputdetailview_std",databasename)
    save(SharedViewsHCE200.getCirrusTaxonomycode_snapshotorc(),path,"Taxonomycode_snapshotorc",databasename)
    save(SharedViewsHCE200.getCirrusNetcontractnetworkview_std(),path,"Netcontractnetworkview_std",databasename)
    GContext.stop()
  }

  def save[T](providerDataSet: Dataset[T],path: String, tablename: String, databasename: String): Unit = {
    val sparkSession = GContext.getUAHSession("ProviderUAH")
    var pt =  path+"/"+tablename
    func.saveAsFileforDataset(providerDataSet, "parquet",pt)
    func.createExternalTableFromParquet(sparkSession, pt, tablename, databasename) //test it with a small file
  }
}

*/