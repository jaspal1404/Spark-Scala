/*
package com.optum.uah.hce200


import com.optum.uah.merge_layer.provider.UAHCdwProvider;

import com.optum.uah.function_library.{CommonFunctions,GlobalContext,ReadJson}


/**
  * <h1>TestProvider</h1>
  * Integration tests for the hce200 provider module
 *
  * @author  dbhatta3
  * @version 1.0
  */
object TestHCE200Provider {


  val GContext = new GlobalContext()
  val func = new CommonFunctions()
  val rJson  = new ReadJson(GContext.runHome+ "/HCE200Provider.json")

   val sparkSession = GContext.getUAHSession("ProviderUAH")
  def main(args: Array[String]): Unit = {
    val dfProvider = UAHCdwProvider.getProviderLegacy()
    val dfGroupAffiliation = UAHCdwProvider.getGroupAffiliationLegacy()
    UAHCdwProvider.func.createViewFromDataset(dfProvider, "uah_medmart_e_provider")
    UAHCdwProvider.func.createViewFromDataset(dfGroupAffiliation, "uah_medmart_e_group_affiliation")
    if (args != null && args.length > 0) {
      if (args(0).equals("--help")) {
        println("COMMAND : spark-submit --class com.uah.legacy.ProviderLegacy --master local --deploy-mode client --executor-memory 1g --name ProviderLegacyEnriched --conf \"spark.app.id=ProviderLegacyEnriched\" /mapr/datalake/optum/optuminsight/d_uah/dev/developer/debraj/provider-0.0.1-SNAPSHOT.jar  [args]")
        println("--schema")
        println("--show limit [number]")
        println("--show all")
        println("--saveToFile [format] [path] ")
        println("--sql [query] <view names: uah_medmart_e_provider,uah_medmart_e_group_affiliation>")
        println("By default creates a external table uah_medmart_i_provider_erh,uah_medmart_i_group_affiliation_erh in uah_cdw_prod database")
        println("--help")
      }


      if (args(0).startsWith("--schema")) {
        dfProvider.printSchema()
        dfGroupAffiliation.printSchema()
      }
      if (args(0).startsWith("--show")) {
        if (args(1).startsWith("limit")) {
          dfProvider.show(Integer.parseInt(args(2)))
          dfGroupAffiliation.show(Integer.parseInt(args(2)))
        }
        if (args(1).startsWith("all")) {
          dfProvider.show()
          dfGroupAffiliation.show()
        }
      }

      if (args(0).startsWith("--sql")) {
        val res = UAHCdwProvider.func.runSql(sparkSession,args(1))
        res.show()
      }
    } else {
      var pathprovider = "/datalake/optum/optuminsight/d_uah/dev/d_hdfs/enriched/legacy/provider/" + System.currentTimeMillis()
      var pathgrpaffiliation = "/datalake/optum/optuminsight/d_uah/dev/d_hdfs/enriched/legacy/groupaffiliation/" + System.currentTimeMillis()
      UAHCdwProvider.func.saveAsFileforDataset(dfProvider, "parquet", pathprovider)
      UAHCdwProvider.func.saveAsFileforDataset(dfGroupAffiliation, "parquet", pathgrpaffiliation)
      UAHCdwProvider.func.createExternalTableFromParquet(sparkSession,pathprovider, "uah_medmart_e_provider", "uah_medmart_prod")
      UAHCdwProvider.func.createExternalTableFromParquet(sparkSession,pathgrpaffiliation, "uah_medmart_e_groupaffiliation", "uah_medmart_prod")
    }
  }
}
*/