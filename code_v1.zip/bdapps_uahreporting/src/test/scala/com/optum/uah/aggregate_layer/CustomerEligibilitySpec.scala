package com.optum.uah.aggregate_layer;


import org.scalatest._
import org.apache.spark.sql.{SparkSession, DataFrame, Dataset}

import com.optum.uah.function_library.{ CommonFunctions, GlobalContext, ReadJson}

class CustomerEligibilitySpec extends FunSuite  {
  
  val gContext    = new GlobalContext()
  val func        = new CommonFunctions() 
  //ReadJson.createJsonObject("target/test-classes/aggrCustomerEligibility.json")
  val sparkLocal  = SparkSession.builder().master("local").appName("CustomerEligibility").getOrCreate()
  
  def loadCsv(sparkSession: SparkSession, path: String, columnSeparatorN: String) : DataFrame = {
    val df = sparkSession.read.format("csv").option("header", "true").option("mode", "DROPMALFORMED").option("inferSchema", "true").option("delimiter", columnSeparatorN).load(path);
    df
  }
  
   test("Customer Eligibility:comparing Aggregate Layer DF Count") {
    
    val expected_df = sparkLocal.read.option("header",true).csv("target/test-classes/expected_df.csv")
    //val actual_df = sparkLocal.read.option("header",true).option("inferSchema", true).csv("target/test-classes/expected_memberBenefitCovLevelCode_std.dat")
         
    
    val memgroupContrctView_stdDF = this.loadCsv(sparkLocal, "target/test-classes/memgroupcontractview_std.csv", ",")
    
    val memgroupid_stdDF = this.loadCsv(sparkLocal,"target/test-classes/memgroupid_std.csv",",")
    val memGroupContrctPanOPtExtviewDF = this.loadCsv(sparkLocal,"target/test-classes/memGroupContractPlanOptExtview_std.csv",",")
    val memGroupContractRenewalDF = this.loadCsv(sparkLocal,"target/test-classes/memgroupcontractrenewal_view.csv",",")
    
    
    
    memgroupContrctView_stdDF.registerTempTable("memgroupcontractview_std")
    memgroupid_stdDF.registerTempTable("memgroupid_std")
    memGroupContrctPanOPtExtviewDF.registerTempTable("memGroupContractPlanOptExtview_std")
    memGroupContractRenewalDF.registerTempTable("memgroupcontractrenewal_view")
    
    memgroupid_stdDF.printSchema()
    memgroupContrctView_stdDF.printSchema()
    
    val aggDF = memgroupid_stdDF.join(memgroupContrctView_stdDF, memgroupid_stdDF.col("GROUP_CODE").equalTo(memgroupContrctView_stdDF.col("source_memgroupgid")), "left_outer").drop(memgroupContrctView_stdDF.col("source_memgroupgid"))
    
     //Left Join memgroupid_stdDF with memgroupcontractview_stdDF
     val aggWithCPOEDF = aggDF.join(memGroupContrctPanOPtExtviewDF, aggDF.col("GROUP_CODE").equalTo(memGroupContrctPanOPtExtviewDF.col("PICK_GROUP_CODE")), "left_outer")
     
     //adding renewal code 
     val aggWithCPOEDFREnew=aggWithCPOEDF.join(memGroupContractRenewalDF,aggWithCPOEDF.col("GROUP_CODE").equalTo(memGroupContractRenewalDF.col("memgroupid")),"left_outer").drop(memGroupContractRenewalDF.col("memgroupid")).distinct()
    
    println("Record Count :"+aggWithCPOEDFREnew.count)
    //aggWithCPOEDFREnew.show()
    //actual_df.rdd.map { x => x.mkString(",") }.foreach { println }
    aggWithCPOEDFREnew.rdd.map { x => x.mkString(",") }.foreach { println }
    /*actual_df.rdd.map { x => x.mkString(",") }.foreach { println }
    println("expected " + expected_df.count())
    println("actual " + actual_df.count())*/
    //assert(expected_df.count() == actual_df.count())
    println("Expected DF Count::"+expected_df.count)
    println("Actual DF Count::"+aggWithCPOEDFREnew.count)

    assert(expected_df.count() == aggWithCPOEDFREnew.count())
  }
  
  
}