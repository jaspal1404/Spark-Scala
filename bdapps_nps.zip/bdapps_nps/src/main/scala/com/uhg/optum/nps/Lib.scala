package com.uhg.optum.nps

import java.io.InputStream

import org.apache.hadoop.hbase.filter._
import java.text.SimpleDateFormat
import java.util.Calendar
import jcifs.smb.{NtlmPasswordAuthentication, SmbFile, SmbFileOutputStream}
import org.apache.hadoop.fs.{FileSystem, FileUtil, Path}
import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp
import org.apache.hadoop.hbase.{CellUtil, TableName}
import org.apache.hadoop.hbase.util.Bytes
import org.apache.hadoop.hbase.client.{Get, Put, Result, Scan}
import org.apache.spark.SparkContext
import org.apache.spark.sql.types._
import org.apache.spark.sql.{Row, SaveMode}
import java.io.{File, PrintWriter}
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec
import org.apache.commons.codec.binary.Base64
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, concat_ws, lit, row_number, date_format}

import scala.collection.mutable.ListBuffer

/**
  * Created by rkodur on 12/25/2017.
  */

object Lib {
  val globalContext = new GlobalContext()

  def getCurrentTimeFormat: String = getCurrentDateTime("yyyy-MM-dd HH:mm:ss")

  def getCurrentTsFormat: String = getCurrentDateTime("yyyyMMddHHmmssSS").substring(0, 16)

  def getCurrentDateTime(dateTimeFormat: String): String = {
    val dateFormat = new SimpleDateFormat(dateTimeFormat)
    val cal = Calendar.getInstance()
    dateFormat.format(cal.getTime)
  }

  def getTimestamp(DateFormat: String): Long = {
    try {
      val timestampformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
      timestampformat.parse(DateFormat).getTime
    } catch {
      case e: Exception => Logger.log.info("Exception while getting current date/time" :+ e.getMessage)
        0
    }
  }

  def filterList(filters: Filter*) = new FilterList(FilterList.Operator.MUST_PASS_ALL, filters: _*)

  def getEppTabSchm(patnrCd: String, srcCd: String, entNm: String): org.apache.spark.rdd.RDD[(String, String)] = {
    try {
      //val eppTableName = "/datalake/uhclake/prd/p_mtables/entity_partner_profile"
      val eppTab = globalContext.spark.getConf.get("spark.eppTab")
      Logger.log.info(s"Scanning EPP HBase Table $eppTab for Entity: $entNm")
      val rdd = globalContext.spark.parallelize(Array(Bytes.toBytes(s"${patnrCd}-${srcCd}-${entNm}")))
      val getRdd = globalContext.hbaseContext.bulkGet[Array[Byte], List[(String, String)]](
        TableName.valueOf(eppTab),
        2,
        rdd,
        record => {
          val get = new Get(record)
          get.setMaxVersions(99)
        },
        (result: Result) => {
          val it = result.listCells().iterator()
          var schver = new ListBuffer[String]()
          var schm = new ListBuffer[String]()
          while (it.hasNext) {
            val cell = it.next()
            val q = Bytes.toString(CellUtil.cloneQualifier(cell))
            if (q.equals("schmVer"))
              schver += Bytes.toString(CellUtil.cloneValue(cell))
            else if (q.equals("schm"))
              schm += Bytes.toString(CellUtil.cloneValue(cell))
          }
          (schver zip schm).toList
        })
      getRdd.flatMap(x => x)
    } catch {
      case e: Exception => Logger.log.info("Exception at saveDFversionTables" :+ e.getMessage)
        throw e
    }
  }

  val sqlContext = globalContext.createSparkSession("IHRIncremental").sqlContext

  def saveDataFrame(patnrCd: String, srcCd: String, eitRowKey: String, schmVer: String, schm: String, fileList: String, entNm: String, sparkConfig: SparkContext): Unit = {
    try {
      val jsonFile = schm.split("(?<=\\}),(?=\\{)")
      val jsonRddSchm = globalContext.spark.parallelize(jsonFile)
      val jsonRdd = sqlContext.read.json(jsonRddSchm).rdd.map(x => (x(1).toString)).collect.toList
      val fields = jsonRdd.map(fieldName => StructField(fieldName, StringType, nullable = true))
      val schema = StructType(fields)
      val loadFiles = sparkConfig.textFile(fileList).map(_.split("\u0001", -1)).map(x => Row(x: _*))
      val verDf = sqlContext.createDataFrame(loadFiles, schema)
      val workingDir = globalContext.spark.getConf.get("spark.workingDir")
      verDf.withColumn("partition_date", date_format(col("cdc_ts"), "yyyyMMdd")).write.mode(SaveMode.Append).partitionBy("partition_date").parquet(s"$workingDir/${entNm.toUpperCase()}")

      // additional code
      /*val snapRDD = Lib.getPkTs(patnrCd, srcCd, entNm).cache()
      if (!snapRDD.isEmpty()) {
        val cdc_ts = snapRDD.map(_._1).collect.mkString
        Logger.log.info(s"CDC_TS Column for $entNm: $cdc_ts")
        val primaryKeys = snapRDD.map(_._2.split(";")).collect.flatten
        Logger.log.info(s"Primary Key Columns for $entNm: ${primaryKeys.mkString}")
        snapRDD.unpersist()
        val userWindow = Window.partitionBy(concat_ws("-", primaryKeys.map(c => col(c)): _*), lit("")).orderBy(col(s"$cdc_ts").desc)
        val dedupDF = verDf.withColumn("rank", row_number().over(userWindow)).where(col("rank") === 1).drop("rank").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
        //val dedupCnt = dedupDF.count()
        //Logger.log.info(s"Number of Records Extracted for $entNm to Current Date with Dedup Logic:" + dedupCnt)
        dedupDF.createOrReplaceTempView(s"${entNm}")
        Logger.log.info(s"Created Temp Table for $entNm: ${entNm} for Select Query")
        dedupDF.unpersist()
      }
      else {
        Logger.log.info("Snapshot PrimaryKeys / CDC Timestamp not found, Please Check HBase Snapshot_config Table")
        Lib.hbaseEitPut(eitRowKey, "eri", "errCd", " Snapshot Primary / Timestamp")
        Lib.hbaseEitPut(eitRowKey, "eri", "errDesc", "Snapshot PrimaryKeys / CDC Timestamp not found, Please Check HBase Snapshot_config Table")
        Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Failure")
        val prcEndTm = Lib.getCurrentTimeFormat
        Lib.hbaseEitPut(eitRowKey, "pi", "prcEndTm", prcEndTm)
        Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
        globalContext.spark.stop()
      } */
    }
    catch {
      case e: Exception => Logger.log.info("Exception at saveDFversionTables" :+ e.getMessage)
        throw e
    }
  }

  def eitTabScan(patnrCd: String, srcCd: String, entNm: String, incStTime: String, incEndTs: String, isCustDelim: String, eitRowKey: String): Boolean = {
    try {
      val eitTable = globalContext.spark.getConf.get("spark.eitTab")
      val ptnr = s"${patnrCd}".toUpperCase
      val src = s"${srcCd}".toUpperCase
      val mountPath = globalContext.spark.getConf.get("spark.mountPath")
      val raw_path = s"maprfs://$mountPath/${ptnr.toLowerCase}/raw/standard_access/${src.toLowerCase}/data/"
      val entName = s"${entNm}".toUpperCase
      Logger.log.info(s"Retrieving Files for $entName from Raw: $raw_path")
      Logger.log.info(s"Processing Entity:${entName} with patnrCd:${ptnr} srcCd:${src}")
      Logger.log.info(s"Scanning Eit HBase Table: $eitTable")
      val startTime = s"$incStTime"
      val endTime = s"$incEndTs"
      Logger.log.info(s"Capturing if any Changes reflected for $entName from $startTime to $endTime")
      val rowKey = s"${ptnr}-${src}-${entName}"
      if (!isCustDelim.equalsIgnoreCase("Yes")) {
        try {
          Logger.log.info(s"Processing ${entName} Files with Row Delimiter: \\n")
          val scan = new Scan()
          val filter = new PrefixFilter(Bytes.toBytes(s"${ptnr}-${src}-${entName}-"))
          val filter1 = new SingleColumnValueFilter(Bytes.toBytes("exi"), Bytes.toBytes("ingProcLogSts"), CompareOp.EQUAL, Bytes.toBytes("Success"));
          //val filter2 = new SingleColumnValueFilter(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"), CompareOp.EQUAL, Bytes.toBytes("No"));
          scan.setCaching(10000)
          scan.setCacheBlocks(false)
          filter1.setFilterIfMissing(true)
          //filter2.setFilterIfMissing(true)
          //scan.setFilter(filterList(filter1, filter2, filter))
          scan.setFilter(filterList(filter1, filter))
          scan.setTimeRange(getTimestamp(startTime), getTimestamp(endTime))
          val eitVal = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(eitTable), scan).cache
          val eitInfo = eitVal.map(tuple => {
            val result = tuple._2
            (Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))),
              Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("srcFileNm"))),
              Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))))
          })
          Logger.log.info(s"Number of Entries Captured for $entName from EIT SCAN b/w $startTime and $endTime :" + eitVal.count())
          if (!eitInfo.isEmpty) {
            //  val eitFileList: List[(String, String)] = eitInfo.collect.toList.map(x => (x, s"${raw_path}${entName}/${entName}.v${x}//*"))
            val eitFileList = eitInfo.map(x => (x._1, x._2, x._3)).collect.toList.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._3}/${x._2}"))
            val eitRawFileList = eitFileList.filter(x => filterRawFileExist(x._2))
            Logger.log.info(s"Number of Files exist in Raw with \\n record delim for $entName from EIT SCAN b/w $startTime and $endTime :" + eitRawFileList.length)
            Logger.log.info(s"List of Files from Raw with \\n record delim: ${eitRawFileList.mkString}")
            val eitRdd = globalContext.spark.parallelize(eitRawFileList)
            val eitFileRdd = eitRdd.groupByKey.mapValues(_.mkString(","))
            val eppRdd: org.apache.spark.rdd.RDD[(String, String)] = getEppTabSchm(ptnr, src, entName).cache
            Logger.log.info(s"Number of Schema Versions for ${entName} retrieved from EPP HBase Table:" + eppRdd.count())
            val sparkConfig = globalContext.spark
            eppRdd.join(eitFileRdd).collect.foreach { case (schmVer, (schm, fileList)) =>
              saveDataFrame(patnrCd, srcCd, eitRowKey, schmVer, schm, fileList, entName, sparkConfig)
            }
            eitVal.unpersist()
            eppRdd.unpersist()
            true
          } else {
            Logger.log.info(s"Since, No Changes Captured for $entName from $startTime to $endTime, datasets will not be generated")
            false
          }
        }
        catch {
          case e: Exception => Logger.log.info(s"Exception while Scanning Files from EIT for $entName" :+ e.getMessage)
            Lib.hbaseEitPut(eitRowKey, "eri", "errCd", "While Scanning EIT")
            Lib.hbaseEitPut(eitRowKey, "eri", "errDesc", e.getMessage)
            Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Failure")
            throw e
        }
      }
      else {
        try {
          Logger.log.info(s"Processing ${entName} Files with Row Delimiter: \\u0002 & \\u0002\\u000A")
          val scan = new Scan()
          val filter = new PrefixFilter(Bytes.toBytes(s"${ptnr}-${src}-${entName}-"))
          val filter1 = new SingleColumnValueFilter(Bytes.toBytes("exi"), Bytes.toBytes("ingProcLogSts"), CompareOp.EQUAL, Bytes.toBytes("Success"))
          //val filter2 = new SingleColumnValueFilter(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"), CompareOp.EQUAL, Bytes.toBytes("Yes"))
          scan.setCaching(100000)
          scan.setCacheBlocks(false)
          filter1.setFilterIfMissing(true)
          //filter2.setFilterIfMissing(true)
          scan.setFilter(filterList(filter1, filter))
          scan.setTimeRange(getTimestamp(startTime), getTimestamp(endTime))
          val eitVal = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(eitTable), scan).cache
          val eitInfo = eitVal.map(tuple => {
            val result = tuple._2
            (Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))),
              Bytes.toHex(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("rowdelim"))),
              Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("srcFileNm"))),
              Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))))
          })
          Logger.log.info(s"Number of Files Captured for $entName from EIT SCAN b/w $startTime and $endTime :" + eitVal.count())
          if (!eitInfo.isEmpty()) {
            val eitFileListCtlB: List[(String, String)] = eitInfo.filter(x => x._2 == "2" || x._2 == "5c7530303032").map(x => (x._1, x._3, x._4)).collect.toList.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._3}/${x._2}"))
            val eitRawFileListCtlB = eitFileListCtlB.filter(x => filterRawFileExist(x._2))
            Logger.log.info(s"Number of Files exist in Raw with \\u0002 record delim for $entName from EIT SCAN b/w $startTime and $endTime :" + eitRawFileListCtlB.length)
            Logger.log.info(s"List of Files from Raw with \\u0002 record delim: ${eitRawFileListCtlB.mkString}")
            val rddCtlB = globalContext.spark.parallelize(eitRawFileListCtlB)
            val eitFileRddCtlB = rddCtlB.groupByKey.mapValues(_.mkString(","))
            val eppRdd: org.apache.spark.rdd.RDD[(String, String)] = getEppTabSchm(ptnr, src, entName).cache
            Logger.log.info(s"Number of Schema Versions for ${entName} retrieved from EPP HBase Table:" + eppRdd.count())
            val sparkConfigCtlB = globalContext.spark
            sparkConfigCtlB.hadoopConfiguration.set("textinputformat.record.delimiter", "\u0002")
            eppRdd.join(eitFileRddCtlB).collect.foreach { case (schmVer, (schm, fileList)) =>
              saveDataFrame(patnrCd, srcCd, eitRowKey, schmVer, schm, fileList, entName, sparkConfigCtlB)
            }
            val eitFileListCtlBNL: List[(String, String)] = eitInfo.filter(x => x._2 == "25c6e" || x._2 == "20a").map(x => (x._1, x._3, x._4)).collect.toList.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._3}/${x._2}"))
            val eitRawFileListCtlBNL = eitFileListCtlBNL.filter(x => filterRawFileExist(x._2))
            Logger.log.info(s"Number of Files exist in Raw with \\u0002\\u000A record delim for $entName from EIT SCAN b/w $startTime and $endTime :" + eitRawFileListCtlBNL.length)
            Logger.log.info(s"List of Files from Raw with \\u0002\\u000A record delim: ${eitRawFileListCtlBNL.mkString}")
            val rddCtlBNL = globalContext.spark.parallelize(eitRawFileListCtlBNL)
            val eitFileRddCtlBNL = rddCtlBNL.groupByKey.mapValues(_.mkString(","))
            val sparkConfigCtlBNL = globalContext.spark
            sparkConfigCtlBNL.hadoopConfiguration.set("textinputformat.record.delimiter", "\u0002\u000A")
            eppRdd.join(eitFileRddCtlBNL).collect.foreach { case (schmVer, (schm, fileList)) =>
              saveDataFrame(patnrCd, srcCd, eitRowKey, schmVer, schm, fileList, entName, sparkConfigCtlBNL)
              eppRdd.unpersist()
            }
            eitVal.unpersist()
            true
          }
          else {
            Logger.log.info(s"Number of Files Captured for $entName from EIT SCAN b/w $startTime and $endTime :" + 0)
            Logger.log.info(s"Since, No Changes Captured for $entName from $startTime to $endTime,datasets will not be generated")
            false
          }
        }
        catch {
          case e: Exception => Logger.log.info(s"Exception while Scanning Files from EIT for $entName" :+ e.getStackTrace.mkString)
            Lib.hbaseEitPut(eitRowKey, "eri", "errCd", "Error Occured While Scanning EIT")
            Lib.hbaseEitPut(eitRowKey, "eri", "errDesc", e.getMessage)
            Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Failure")
            throw e
        }
      }
    }
    catch {
      case e: Exception => Logger.log.info(s"Exception while Scanning Files from EIT for $entNm" :+ e.getStackTrace.mkString)
        Lib.hbaseEitPut(eitRowKey, "eri", "errCd", "Error Occured While Scanning EIT")
        Lib.hbaseEitPut(eitRowKey, "eri", "errDesc", e.getMessage)
        Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Failure")
        throw e
    }
  }

  def getPkTs(patnrCd: String, srcCd: String, entNm: String): org.apache.spark.rdd.RDD[(String, String)] = {
    try {
      // val snapTab = "/datalake/uhclake/prd/p_mtables/snapshot_config"
      val snapTab = globalContext.spark.getConf.get("spark.snapTab")
      Logger.log.info(s"Scanning SnapshotConfig HBase Table $snapTab for Entity : $entNm for Primary Keys/CDC_TS")
      val scanner = new Scan()
      scanner.setCacheBlocks(false)
      scanner.setCaching(10000)
      val filter1 = new RowFilter(CompareOp.EQUAL, new BinaryComparator(Bytes.toBytes(s"${patnrCd.toUpperCase}-${srcCd.toUpperCase}-${entNm.toUpperCase}")))
      val filter2 = new SingleColumnValueFilter(Bytes.toBytes("ec"), Bytes.toBytes("activeflag"), CompareOp.EQUAL, Bytes.toBytes("Y"));
      scanner.setFilter(filterList(filter1, filter2))
      val snapInfo = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(snapTab), scanner)
      val snapRDD = snapInfo.map(tuple => {
        val result = tuple._2
        (Bytes.toString(result.getValue(Bytes.toBytes("ec"), Bytes.toBytes("modtscol"))),
          Bytes.toString(result.getValue(Bytes.toBytes("ec"), Bytes.toBytes("prikeycols"))))
      })
      snapRDD
    } catch {
      case e: Exception => Logger.log.error(s"Exception while retriving Pk's from Snapshot Config Tab for $entNm" :+ e.getMessage)
        throw e
    }
  }

  def getEntityInfo(rowKey: String): Array[(String, String, String, String, String, String, String)] = {
    try {
      val npsTab = globalContext.spark.getConf.get("spark.npsCtlTab")
      Logger.log.info(s"npsCtlTab nps_ent_cfg: $npsTab")
      val scanner = new Scan()
      scanner.setCaching(1000)
      scanner.setCacheBlocks(false)
      val filter1 = new RowFilter(CompareOp.EQUAL, new BinaryComparator(Bytes.toBytes(s"$rowKey")))
      scanner.setFilter(filter1)
      val npsInfo = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(npsTab), scanner).cache()
      val npsEntRDD = npsInfo.map(tuple => {
        val result = tuple._2
        (Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("prtnrCd"))),
          Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("srcCd"))),
          Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("entNm"))),
          Bytes.toString(result.getValue(Bytes.toBytes("is"), Bytes.toBytes("lastRnTs"))),
          Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("isCustDelim"))),
          //Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("outFileDelim"))),
          Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("outEntNm"))),
          //Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("outFileExt"))),
          //Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("nasLoc"))),
          //Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("quoteCol"))),
          Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("isJoin"))))
          //Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("isNasLoc"))))
      })

      if (npsEntRDD.isEmpty()) {
        Logger.log.info(s"Please Provide Appropriate RowKey / Check nps_ent_cfg table Properties for $rowKey properly")
        npsEntRDD.collect()
      }
      else {
        npsEntRDD.collect()
      }
    } catch {
      case e: Exception => Logger.log.error(s"Exception while getting Configuration from nps_entity_info Tab" :+ e.getMessage)
        throw e
    }
  }


  def getSqlQry(rowKey: String): String = {
    try {
      //  val ihrTab = "/datalake/uhclake/prd/developer/rkodur/ihr/ihr_entity_info"
      val npsTab = globalContext.spark.getConf.get("spark.npsCtlTab")
      Logger.log.info(s"Scanning npsCtlTab:$npsTab")
      val scanner = new Scan()
      scanner.setCaching(10000)
      scanner.setCacheBlocks(false)
      val filter1 = new RowFilter(CompareOp.EQUAL, new BinaryComparator(Bytes.toBytes(s"$rowKey")))
      scanner.setFilter(filter1)
      val npsInfo = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(npsTab), scanner)
      val eitRDD = npsInfo.map(tuple => {
        val result = tuple._2
        (Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("sqlQry"))))
      })
      eitRDD.collect.mkString
    } catch {
      case e: Exception => Logger.log.error(s"Exception while getting SqlQry from nps_entity_info Tab" :+ e.getStackTrace.toString)
        throw e
    }
  }


  def hbasePut(rowKey: String, colFm: String, colNm: String, value: String): Unit = {
    try {
      val p = new Put(s"$rowKey".getBytes())
      p.addColumn(s"$colFm".getBytes(), s"$colNm".getBytes(), s"$value".getBytes())
      globalContext.npsCtlTab.put(p)
    } catch {
      case e: Exception => Logger.log.info("Exception at HBase Put Commands at IHR_enttiy_info" :+ e.getStackTrace.toString)
        throw e
    }
  }


  def hbaseEitPut(eitRowKey: String, colFm: String, colNm: String, value: String): Unit = {
    try {
      val p = new Put(s"$eitRowKey".getBytes())
      p.addColumn(s"$colFm".getBytes(), s"$colNm".getBytes(), s"$value".getBytes())
      globalContext.npsEitTab.put(p)
    } catch {
      case e: Exception => Logger.log.info("Exception at HBase EIT Put Commands at IHR_enttiy_info IHR_ADT_DTL" :+ e.getStackTrace.mkString)
        throw e
    }
  }

  def rmDirIfExist(dir: String): Unit = {
    try {
      if (globalContext.fs.exists(new Path(s"$dir"))) {
        globalContext.fs.delete(new Path(dir), true)
      }
      else {
        Logger.log.info(s"Working Dir: $dir doesn't exist, Please check for Errors.")
      }
    } catch {
      case e: Exception => Logger.log.info("Exception at HBase Put Commands at IHR_enttiy_info" :+ e.getStackTrace.toString)
        throw e
    }
  }

  def filterRawFileExist(filePath: String): Boolean = {
    globalContext.fs.exists(new Path(s"$filePath"))
  }

  def merge(srcPath: String, dstPath: String): Boolean = {
    val hdfs = FileSystem.get(globalContext.spark.hadoopConfiguration)
    FileUtil.copyMerge(hdfs, new Path(srcPath), hdfs, new Path(dstPath), false, globalContext.spark.hadoopConfiguration, null)
  }



  def getType(lastRnTime: String, currTime: String): String = {
    val format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val days: Long = ((format.parse(lastRnTime).getTime - format.parse(currTime).getTime) / 86400000)
    if (days > 31) {
      "FULL"
    }
    else {
      "INCR"
    }
  }



  def processFrmWrk(srcCd: String, patnrCd: String, ent: String, workingDir: String, eitRowKey: String, lastRunSts: String): Unit = {
    try {
      Logger.log.info(s"Captured Incremental Extract for ${ent}")
      Logger.log.info(s"Working Directory path for Incremental extract: $workingDir")
      Logger.log.info(s"Merging Schema for $ent from $workingDir/$ent")
      val mergeDF = sqlContext.read.option("mergeSchema", true).parquet(s"$workingDir/$ent").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
      Logger.log.info(s"Merge Schema Record Count for $ent from $lastRunSts to Current Date:" + mergeDF.count)
      Logger.log.info(s"Retrieving Primary Keys/CDC_TS Cols from Snapshot Config Table")
      val snapRDD = Lib.getPkTs(patnrCd, srcCd, ent).cache()
      if (!snapRDD.isEmpty()) {
        val cdc_ts = snapRDD.map(_._1).collect.mkString
        Logger.log.info(s"CDC_TS Column for $ent: $cdc_ts")
        val primaryKeys = snapRDD.map(_._2.split(";")).collect.flatten
        Logger.log.info(s"Primary Key Columns for $ent: ${primaryKeys.mkString}")
        snapRDD.unpersist()
        val userWindow = Window.partitionBy(concat_ws("-", primaryKeys.map(c => col(c)): _*), lit("")).orderBy(col(s"$cdc_ts").desc)
        val dedupDF = mergeDF.withColumn("rank", row_number().over(userWindow)).where(col("rank") === 1).drop("rank")//.persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
        //val dedupCnt = dedupDF.count()
        //Logger.log.info(s"Number of Records Extracted for $ent from $lastRunSts to Current Date with Dedup Logic:" + dedupCnt)
        dedupDF.createOrReplaceTempView(s"${ent}")
        Logger.log.info(s"Created Temp Table for $ent: ${ent} for Select Query")
        mergeDF.unpersist()
      }
      else {
        Logger.log.info("Snapshot PrimaryKeys / CDC Timestamp not found, Please Check HBase Snapshot_config Table")
        Lib.hbaseEitPut(eitRowKey, "eri", "errCd", " Snapshot Primary / Timestamp")
        Lib.hbaseEitPut(eitRowKey, "eri", "errDesc", "Snapshot PrimaryKeys / CDC Timestamp not found, Please Check HBase Snapshot_config Table")
        Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Failure")
        val prcEndTm = Lib.getCurrentTimeFormat
        Lib.hbaseEitPut(eitRowKey, "pi", "prcEndTm", prcEndTm)
        Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
        globalContext.spark.stop()
      }
    } catch {
      case e: Exception => Logger.log.info("Exception while processing working Area" + e.getMessage)
        throw e
    }
  }
}
