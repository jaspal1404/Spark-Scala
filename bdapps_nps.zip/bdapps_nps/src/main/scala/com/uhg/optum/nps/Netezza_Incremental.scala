package com.uhg.optum.nps

import com.uhg.optum.nps.{GlobalContext, Lib}
import org.apache.spark.sql.functions._


/**
  * Created by jsingh73 on 3/9/2018.
  */
object Netezza_Incremental {

  val globalContext = new GlobalContext()

  val sqlContext = globalContext.createSparkSession("NpsIncremental").sqlContext

  def main(args: Array[String]): Unit = {

    val rowKey = args(0)
    //val patnrCd = args(1)
    //val srcCd = args(2)
    //val entNm = args(3)
    //val lastRunSts = args(4)
    //val isCustDelim = "No"
    //val outEntNm = "cdb_extract_nps"
    //val isJoin = "Yes"


    try {

      val eitRowKey = s"$rowKey-${java.util.UUID.randomUUID.toString}"
      val prcStTm = Lib.getCurrentTimeFormat
      val incEndTs = Lib.getCurrentTimeFormat
      Lib.hbaseEitPut(eitRowKey, "pi", "prcStTm", prcStTm)
      Logger.log.info(s"Scanning nps_ent_cfg Table for rowKey provided:$rowKey")
      val rptCfgScan = Lib.getEntityInfo(rowKey)
      //val rptCfgScan: Array[(String, String, String, String, String, String, String)] = Array((patnrCd, srcCd, entNm, lastRunSts, isCustDelim, outEntNm, isJoin))
      Logger.log.info(s"Entity Config for ${rowKey} from ihr_ent_cfg Table: " + rptCfgScan.mkString)
      rptCfgScan.foreach { case (patnrCd, srcCd, entNm, lastRunSts, isCustDelim, outEntNm, isJoin) =>
        Logger.log.info(s"==========> Triggering Incremental Extract Process for $outEntNm <===========")
        Logger.log.info(s"Incremental Extract Process Start Time: $prcStTm")
        Logger.log.info(s"EIT Tracking ID for ${entNm.toUpperCase}: $eitRowKey")
        if (isJoin.equalsIgnoreCase("Yes")) {
          //val tableList = args(1).toUpperCase.split(';')
          //Fetching cdb tables info
          val cdbTableList = entNm.toUpperCase.split('|')(0).split(';')
          val cdbPtnrCd = s"${patnrCd.toUpperCase().split('|')(0)}"
          val cdbSrcCd = s"${srcCd.toUpperCase().split('|')(0)}"
          val cdbCustDelim = isCustDelim.split('|')(0)
          //Fetching cdb tables info
          val bosTableList = entNm.toUpperCase.split('|')(1).split(';')
          val bosPtnrCd = s"${patnrCd.toUpperCase().split('|')(1)}"
          val bosSrcCd = s"${srcCd.toUpperCase().split('|')(1)}"
          val bosCustDelim = isCustDelim.split('|')(1)
          Lib.hbaseEitPut(eitRowKey, "pi", "entNm", outEntNm)
          // Load the cdb extract
          sqlContext.read.parquet("/datalake/optum/optuminsight/p_edh/prd/uhg/nps/prd/developer/outbound/mdm_cdb_extract").createOrReplaceTempView("cdb")
          //val sourceDf = sqlContext.read.parquet("/datalake/optum/optuminsight/p_edh/prd/uhg/nps/prd/developer/inbound/mdm/netezza_matched").select(col("entity_id").cast("string"), col("sourcesystemcode"), col("sourceindividulid"), col("survey_date").cast("string")).distinct()
          val sourceDf = sqlContext.read.parquet("/datalake/optum/optuminsight/p_edh/prd/uhg/nps/prd/developer/dss/netezza_consolidated_layer").
            withColumn("entity_id1", col("entity_id").cast("string")).drop("entity_id").withColumnRenamed("entity_id1", "entity_id").drop("survey_date") // Check if any incremental records got loaded for source Netezza/Fin360
          sourceDf.createOrReplaceTempView("ntz_src_cons1")
          if (sourceDf.count() != 0) {
            val cdbWorkingDir = s"${globalContext.spark.getConf.get("spark.cdbWorkingDir")}"
            /*cdbTableList.foreach { ent =>
              val result: Boolean = Lib.eitTabScan(cdbPtnrCd, cdbSrcCd, ent, lastRunSts, incEndTs, cdbCustDelim, eitRowKey)
            }
            bosTableList.foreach { ent =>
              val result: Boolean = Lib.eitTabScan(bosPtnrCd, bosSrcCd, ent, lastRunSts, incEndTs, bosCustDelim, eitRowKey)

            }

            cdbTableList.foreach { ent =>
              Lib.processFrmWrk(cdbSrcCd, cdbPtnrCd, ent, cdbWorkingDir, eitRowKey, lastRunSts)
            }
            bosTableList.foreach { ent =>
              Lib.processFrmWrk(bosSrcCd, bosPtnrCd, ent, workingDir, eitRowKey, lastRunSts)
            }*/
            //val sqlQry = Lib.getSqlQry(s"$rowKey")
            //Logger.log.info(s"Sql Query provided for $outEntNm from ihr_enity_infor Table: $sqlQry")
            val resultDfJ = sqlContext.sql(args(1))//.persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
            //val incExtCnt = resultDfJ.count.toString
            //Logger.log.info(s"Record Count for $outEntNm with provided Sql Query:" + incExtCnt)
            val outLoc = globalContext.spark.getConf.get("spark.resultLoc")
            resultDfJ.write.mode("Overwrite").parquet(outLoc+"/ntz_cdb_extract")
            resultDfJ.repartition(1).write.option("delimiter", "|").mode("overwrite").option("header", "true").csv(outLoc+"/ntz_cdb_csv")
            Logger.log.info("Updating RecordCount in to nps audit table")
            //Lib.hbaseEitPut(eitRowKey, "pi", "reccnt", incExtCnt.toString)

            //Logger.log.info(s"Updating lastRnTs as ${incEndTs} in nps_entity_info HBase Table for EntNm:$outEntNm")
            //Lib.hbasePut(rowKey, "is", "lastRnTs", incEndTs)
            //resultDfJ.unpersist()

          }
          else {
            Logger.log.info(s"Since No Changes reflected for the $outEntNm from $lastRunSts to Till Date, Updating Record Count as 0")
            Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Success")
            Lib.hbaseEitPut(eitRowKey, "pi", "reccnt", "0")
            Logger.log.info(s"Updating lastRnTs as ${incEndTs} in nps_entity_info HBase Table for EntNm:$outEntNm")
            Lib.hbasePut(rowKey, "is", "lastRnTs", incEndTs)

          }
          val prcEndTm = Lib.getCurrentTimeFormat
          Lib.hbaseEitPut(eitRowKey, "pi", "prcEndTm", prcEndTm)
          Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
        }
      }

    }
    catch {
      case e: Exception => Logger.log.info("Exception at Main IncrementalMain Object" :+ e.getMessage)
        throw e
    }
  }
}
