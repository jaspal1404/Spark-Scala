package com.optum.dl.speed.model;

import java.util.Arrays;

public class FormattedRecord {
	String htable;
	String key;
	String sourceMD5;
	String transactionID;
	String sourceCode;
	String sourceTable;

	String schemaName;
	String partnCode;	

	String[] keys;
	String[] values;
	long ts;

	
	@Override
	public String toString() {
		return "FormattedRecord [htable=" + htable + ", key=" + key + ", sourceMD5=" + sourceMD5 + ", transactionID="
				+ transactionID + ", sourceCode=" + sourceCode + ", schemaName=" + schemaName + ", partnCode="
				+ partnCode + ", keys=" + Arrays.toString(keys) + ", values=" + Arrays.toString(values) + ", ts=" + ts
				+ "]";
	}

	public FormattedRecord(String htable, String key, String[] keys, String[] values, long ts) {
		super();
		this.htable = htable;
		this.key = key;
		this.keys = keys;
		this.values = values;
		this.ts = ts;
	}
	public String getSourceTable() {
		return sourceTable;
	}

	public void setSourceTable(String sourceTable) {
		this.sourceTable = sourceTable;
	}

	public long getTs() {
		return ts;
	}

	public void setTs(long ts) {
		this.ts = ts;
	}

	public String getHtable() {
		return htable;
	}

	public void setHtable(String htable) {
		this.htable = htable;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String[] getKeys() {
		return keys;
	}

	public void setKeys(String[] keys) {
		this.keys = keys;
	}

	public String[] getValues() {
		return values;
	}

	public void setValues(String[] values) {
		this.values = values;
	}

	public FormattedRecord() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public String getSourceMD5() {
		return sourceMD5;
	}

	public void setSourceMD5(String sourceMD5) {
		this.sourceMD5 = sourceMD5;
	}
	
	public String getTransactionID() {
		return transactionID;
	}

	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}
	
	public String getSourceCode() {
		return sourceCode;
	}

	public void setSourceCode(String sourceCode) {
		this.sourceCode = sourceCode;
	}

	public String getSchemaName() {
		return schemaName;
	}

	public void setSchemaName(String schemaName) {
		this.schemaName = schemaName;
	}

	public String getPartnCode() {
		return partnCode;
	}

	public void setPartnCode(String partnCode) {
		this.partnCode = partnCode;
	}

}