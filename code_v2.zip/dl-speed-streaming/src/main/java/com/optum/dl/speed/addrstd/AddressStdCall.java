package com.optum.dl.speed.addrstd;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

import org.w3c.dom.NodeList;

public class AddressStdCall {
	private SOAPConnection soapConnection;
	private SOAPMessage soapResponse;
	private String url;
	private MessageDigest md;

	public AddressStdCall() {
		url = "http://10.185.72.157:8088/mockaddstdSoapBinding";
		try {
			md = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}

	}// end of constructor.

	public String[] callAddStdService(String[] add) {
		String address[] = new String[6];
		try {

			String md5_add = add[0] + add[1] + add[2] + add[3] + add[4];
			// System.out.println("Before MD5:"+ md5_add);
			byte[] thedigest = md.digest(md5_add.getBytes());
			// System.out.println("After MD5:"+ thedigest.toString());
			soapConnection = createConnection();
			soapResponse = soapConnection.call(createSOAPRequest(add[0], "", "", add[1], add[2], add[3], add[4]), url);
			address = getSOAPResponse(soapResponse, thedigest.toString());
		} catch (Exception e) {
			System.err.println("Error occurred while sending SOAP Request to Server");
			e.printStackTrace();
		} // end of catch.
		return address;
	}// end of method.

	private SOAPMessage createSOAPRequest(String addline1, String addline2, String addline3, String city, String state,
			String country, String zip) throws Exception {
		MessageFactory messageFactory = MessageFactory.newInstance();
		SOAPMessage soapMessage = messageFactory.createMessage();
		SOAPPart soapPart = soapMessage.getSOAPPart();

		SOAPEnvelope envelope = soapPart.getEnvelope();
		envelope.addNamespaceDeclaration("soapenv", "http://schemas.xmlsoap.org/soap/envelope/");
		envelope.addNamespaceDeclaration("add", "http://example.com/addstd.xsd");

		// SOAP Body
		SOAPBody soapBody = envelope.getBody();
		SOAPElement soapBodyElemAddStdReq = soapBody.addChildElement("AddressStdRequest", "add");
		SOAPElement soapBodyElemadd1 = soapBodyElemAddStdReq.addChildElement("addressline1");
		SOAPElement soapBodyElemadd2 = soapBodyElemAddStdReq.addChildElement("addressline2");
		SOAPElement soapBodyElemcity = soapBodyElemAddStdReq.addChildElement("city");
		SOAPElement soapBodyElemstate = soapBodyElemAddStdReq.addChildElement("state");
		SOAPElement soapBodyElezip = soapBodyElemAddStdReq.addChildElement("zip");
		soapBodyElemadd1.addTextNode(addline1);
		soapBodyElemadd2.addTextNode(addline2);
		soapBodyElemcity.addTextNode(city);
		soapBodyElemstate.addTextNode(state);
		soapBodyElezip.addTextNode(zip);

		MimeHeaders headers = soapMessage.getMimeHeaders();
		headers.addHeader("SOAPAction", "http://example.com/AddStdAction");

		soapMessage.saveChanges();
		return soapMessage;
	}

	/**
	 * Creates a SOAP connection to the SOAP server
	 * 
	 * @return the SOAPconnection object
	 * @throws SOAPException
	 *             if unable to create connection
	 */
	private SOAPConnection createConnection() throws SOAPException {
		SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
		SOAPConnection connection = soapConnectionFactory.createConnection();
		return connection;
	}

	/**
	 * Method used to print the SOAP Response
	 */
	private String[] getSOAPResponse(SOAPMessage soapResponse, String md5_key) throws Exception {
		// Process the SOAP Response
		String[] add_std = new String[6];
		SOAPPart soapPart = soapResponse.getSOAPPart();
		SOAPEnvelope envelope = soapPart.getEnvelope();
		SOAPBody soapBody = envelope.getBody();
		NodeList list = soapBody.getElementsByTagName("add:AddressStdReply");
		NodeList innerList = list.item(0).getChildNodes();
		add_std[0] = innerList.item(1).getTextContent();
		add_std[1] = innerList.item(5).getTextContent();
		add_std[2] = innerList.item(7).getTextContent();
		add_std[3] = innerList.item(9).getTextContent();
		add_std[4] = "UNITED STATES";
		add_std[5] = md5_key;

		return add_std;
	}// end of method.

	private void closeSOAP() {
		try {
			soapConnection.close();
		} catch (SOAPException e) {
			e.printStackTrace();
		} // end of try.
	}// end of method.

}
