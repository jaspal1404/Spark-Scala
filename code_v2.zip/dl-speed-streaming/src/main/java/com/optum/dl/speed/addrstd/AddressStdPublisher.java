package com.optum.dl.speed.addrstd;

import java.io.IOException;

import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.json.JSONArray;
import org.json.JSONException;
import com.sun.jmx.snmp.Timestamp;
//import org.codehaus.jettison.json.JSONArray;
import org.json.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.dl.speed.dao.AddStdDao;
import com.optum.dl.speed.logging.LoggingProducer;
import com.optum.dl.speed.model.AddStdMeta;
import com.optum.dl.speed.model.FormattedRecord;
import com.optum.dl.speed.addrstd.AddressStdCall;;

public class AddressStdPublisher {
	
	public static void main(String[] args) {
		String [] keys;
		String [] values;
		String [] address_std_ws = new String[6];
		String transactionID = null;
		String sourceCode = null;
		String sourceTable = null;
		String schemaName = null;
		String partnCode = null;
		int i = 0; int j = 0;
		ObjectMapper mapper = new ObjectMapper();
		JSONObject jsonObj;
		LoggingProducer log = new LoggingProducer();
		final String TOPIC_ADDRESS_STD_P = "/datalake/uhclake/tst/developer/DL_SPEEDLAYER/streams/optum-datalake-address:optum.datalake.speed.cdc.adrsrt";
		final String TOPIC_ADDRESS_STD_S = "/datalake/uhclake/tst/developer/DL_SPEEDLAYER/streams/optum-datalake-address:optum.datalake.speed.cdc.adrsrt.std";
		final String HBASE_ADD_TABLE     = "/datalake/uhclake/tst/developer/DL_SPEEDLAYER/mtables/address_std_lookup";
		final String[] target_column_names = {"addr_line1","city","statecd","postcd","country","addr_md5"};
		
		AddressStdCall webservice = new AddressStdCall();		
		HashMap<String, AddStdMeta> AddStdmetaData = new HashMap<String,AddStdMeta>();
		
		try {
			AddStdDao dao = new AddStdDao();
			AddStdmetaData=dao.getAll("/datalake/uhclake/tst/developer/DL_SPEEDLAYER/mtables/address_std_src_mapping");
		} catch (IOException e) {
			e.printStackTrace();
		}//end of catch.
		HashMap<String, AddStdMeta> add_meta = AddStdmetaData;
				
		KafkaConsumer<String, String> consumer = getKafkaConsumer();
		KafkaProducer<String, String> producer = getKafkaProducer();
	    consumer.subscribe(Arrays.asList(TOPIC_ADDRESS_STD_P));	    
	    
	    System.out.println("Started..... Connected to Kafka");
	    while (true) {
	    	// read records with a short timeout. If we time out, we don't really care.
	    	ConsumerRecords<String, String> formatRecords = consumer.poll(2000);
	    	for (ConsumerRecord<String, String> record : formatRecords) {
	    		try {
	    			//Get all the information from message.
	    			JsonNode msg = mapper.readTree(record.value());		
	    			jsonObj = new JSONObject(msg.toString());
	    			keys = getKeysValues("keys", jsonObj);
	    			values = getKeysValues("values", jsonObj);
	    			sourceCode = msg.get("sourceCode").toString().replace("\"", "").trim();
	    			transactionID = msg.get("transactionID").toString().replace("\"", "").trim();
	    			schemaName = msg.get("schemaName").toString().replace("\"", "").trim();
	    			partnCode = msg.get("partnCode").toString().replace("\"", "").trim();
	    			sourceTable = msg.get("sourceTable").toString().replace("\"", "").trim();
	    			
	    			//System.out.println("Received the message:" + partnCode + ", " + sourceCode + ", " + schemaName+ ", "+ sourceTable +","+ transactionID );
	    			String[] address = getAddressValues(add_meta, sourceCode, schemaName, sourceTable, keys, values);
	    			//System.out.println("Address:"+address[0] +", " + address[1]+", " + address[2] + ", "+ address[3]);
	    			
	    			if(address[0].toString().equals("none"))
	    				System.out.println("No entity found...");	    				
	    			else
	    				address_std_ws = webservice.callAddStdService(address);	    				
	    			
	    			//System.out.println("Publishing the : "+address_std_ws[0] + "," + address_std_ws[1] + " " + address_std_ws[2] + ", " + address_std_ws[3] 
	    			//		+ " " + address_std_ws[4] +" " + address_std_ws[5]);
	    			publishSTDAddress(partnCode, sourceCode, schemaName, transactionID, HBASE_ADD_TABLE,
	    					address_std_ws, target_column_names, producer, TOPIC_ADDRESS_STD_S, mapper);
	    			
	    			//Send the log info.
	    			log.sendLog("INFO", "AddressStdPublisher", transactionID, partnCode, sourceCode, sourceTable, "Address strandarized and sent to sub-topic.");
	    			
	    			//Counter print
	    			j++;i++;
	    			if(i == 1000){
	    				System.out.println("Published:"+j+" @ "+new Timestamp(System.currentTimeMillis()));
	    				i = 0;
	    			}//end of if.
	    			
	    		} catch (IOException e) {
	    			log.sendLog("ERROR", "AddressStdPublisher", transactionID, partnCode, sourceCode, sourceTable, e.getMessage());
	    		} catch (JSONException e) {
	    			log.sendLog("ERROR", "AddressStdPublisher", transactionID, partnCode, sourceCode, sourceTable, e.getMessage());
	    		}//end of catch.	    		
	    	}//end of for.
	    	producer.flush();
	    }//end of while.
	}//end of main.
	
	
	/**
	 * 
	 * @param partnCode
	 * @param sourceCode
	 * @param schemaName
	 * @param transactionID
	 * @param HBASE_ADD_TABLE
	 * @param address_std_ws
	 * @param target_column_names
	 * @param producer
	 * @param TOPIC_ADDRESS_STD_S
	 * @param mapper
	 */
	private static void publishSTDAddress(String partnCode, String sourceCode, String schemaName, String transactionID, 
			String HBASE_ADD_TABLE, String[] address_std_ws, String[] target_column_names, 
			KafkaProducer<String, String> producer, String TOPIC_ADDRESS_STD_S, ObjectMapper mapper){
		FormattedRecord record_p = new FormattedRecord();
		// Setup the Message record.
		record_p.setKey(address_std_ws[5]);
		record_p.setKeys(target_column_names);
		record_p.setValues(address_std_ws);
		record_p.setPartnCode(partnCode);
		record_p.setSchemaName(schemaName);
		record_p.setSourceCode(sourceCode);
		record_p.setTransactionID(transactionID);
		record_p.setHtable(HBASE_ADD_TABLE);					
		Date myDate = new Date();		 					
		record_p.setTs(myDate.getTime());
		
		try {
			producer.send(new ProducerRecord<String, String>(TOPIC_ADDRESS_STD_S, mapper.writeValueAsString(record_p)));
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}//end of method.
	
	/**
	 * 
	 * @param add_meta
	 * @param sourceCode
	 * @param schemaName
	 * @param keys
	 * @param values
	 * @return
	 */
	private static String[] getAddressValues(HashMap<String, AddStdMeta> add_meta,
			String sourceCode, String schemaName, String sourceTable, String[] keys, String[] values){
		// Set the Address #
		int ADDRESS_LINE	= 0; int CITY 			= 1;
		int STATE			= 2; int COUNTRY		= 3;
		int ZIP				= 4;
		String[] address_values = new String[5];
		//System.out.println("Key Gen:  "+sourceCode +"-"+ schemaName+"_"+sourceTable);
		AddStdMeta addStdMeta = add_meta.get(sourceCode +"-"+ schemaName+"_"+sourceTable);
		if (addStdMeta == null){
			address_values[0] = "none";
			//System.out.println("no value found.....");			
		}//end of if.		
		else{				
			//System.out.println("HashMeta - Address Fields :" + addStdMeta.getAddline1() + ", " + addStdMeta.getCity() + ", " + addStdMeta.getState()+ ", " + addStdMeta.getCountry() );
			// Collect all the Fields name for Address Std HBase Table.
			String[] epp_hbase_column = { addStdMeta.getAddline1(), addStdMeta.getCity(),
					addStdMeta.getState(), addStdMeta.getCountry(),
					addStdMeta.getZip()};
			
			// Find the Columns from the request.
			for(int j=0; j<keys.length; j++){
				//Get Address Line 1
				if (keys[j].equals(epp_hbase_column[ADDRESS_LINE].toString()))
					address_values[ADDRESS_LINE] =  values[j].trim();
				//Get City information
				if (keys[j].equals(epp_hbase_column[CITY].toString()))
					address_values[CITY] =  values[j].trim();
				//Get State information
				if (keys[j].equals(epp_hbase_column[STATE].toString()))
					address_values[STATE] =  values[j].trim();
				//Get Country Information.
				if (keys[j].equals(epp_hbase_column[COUNTRY].toString()))
					address_values[COUNTRY] =  values[j].trim();
				//Get Zip Code.
				if (keys[j].equals(epp_hbase_column[ZIP].toString()))
					address_values[ZIP] =  values[j].trim();
			}//end of for.
		}//end of else.
		
		return address_values;
	}//end of method.
	
	
	/**
	 * 
	 * @param nodeName
	 * @param jsonObj
	 * @return
	 * @throws JSONException
	 */
	public static String[] getKeysValues (String nodeName, JSONObject jsonObj) throws JSONException {
		String val = "";
		JSONArray jnode = jsonObj.getJSONArray(nodeName);
		int length = jnode.length();
		String [] values = new String[length];
		
		if (length > 0) {			    
		    for (int i = 0; i < length; i++){
		    	if(jnode.getString(i) == null)
		    		val = "";
		    	else
		    		val = jnode.getString(i);
		    	values[i] = val;
		    }//end of for.
		}//end of if.	
		return values;
    }//end of function.
	
	/**
	 * 
	 * @return
	 */
	public static KafkaConsumer<String, String> getKafkaConsumer() {
		Properties properties = new Properties();
		properties.setProperty("enable.auto.commit","false");
		properties.setProperty("auto.offset.reset","earliest");
		properties.setProperty("key.deserializer","org.apache.kafka.common.serialization.StringDeserializer");
		properties.setProperty("value.deserializer","org.apache.kafka.common.serialization.StringDeserializer");
		properties.setProperty("group.id", "AddressStd-R");
		properties.setProperty("max.partition.fetch.bytes", "2097152");
		properties.setProperty("fetch.min.bytes", "50000");	    
		return new KafkaConsumer<String, String>(properties);
	}//end of method.
	
	/**
	 * 
	 * @return
	 */
	public static KafkaProducer<String, String> getKafkaProducer() {
		Properties properties = new Properties();
		properties.setProperty("batch.size","16384");
		properties.setProperty("auto.offset.reset","earliest");
		properties.setProperty("key.serializer","org.apache.kafka.common.serialization.StringSerializer");
		properties.setProperty("value.serializer","org.apache.kafka.common.serialization.StringSerializer");		
		properties.setProperty("block.on.buffer.full", "true");	    
		return new KafkaProducer<String, String>(properties);
	}//end of method.

}//end of class.
