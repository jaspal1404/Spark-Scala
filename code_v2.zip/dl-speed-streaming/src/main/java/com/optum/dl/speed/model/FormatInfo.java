package com.optum.dl.speed.model;

import java.io.Serializable;

public class FormatInfo implements Serializable {

	private static final long serialVersionUID = 1L;
	String format;
	Option option;

	public FormatInfo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FormatInfo(String format, Option option) {
		super();
		this.format = format;
		this.option = option;
	}

	@Override
	public String toString() {
		return "FormatInfo [format=" + format + ", options=" + option + "]";
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public Option getOptions() {
		return option;
	}

	public void setOptions(Option option) {
		this.option = option;
	}

}
