package com.optum.dl.speed.model;

import java.io.Serializable;

public class Meta implements Serializable {

	private static final long serialVersionUID = 1L;
	String adrind;
	String location;
	String partner;
	String rowkey;
	String schema;

	public Meta() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Meta(String adrind, String location, String partner, String rowkey, String schema, String schversion,
			String source) {
		super();
		this.adrind = adrind;
		this.location = location;
		this.partner = partner;
		this.rowkey = rowkey;
		this.schema = schema;

		this.source = source;
	}

	@Override
	public String toString() {
		return "Meta [adrind=" + adrind + ", location=" + location + ", partner=" + partner + ", rowkey=" + rowkey
				+ ", schema=" + schema + ", source=" + source + "]";
	}

	public String getAdrind() {
		return adrind;
	}

	public void setAdrind(String adrind) {
		this.adrind = adrind;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getPartner() {
		return partner;
	}

	public void setPartner(String partner) {
		this.partner = partner;
	}

	public String getRowkey() {
		return rowkey;
	}

	public void setRowkey(String rowkey) {
		this.rowkey = rowkey;
	}

	public String getSchema() {
		return schema;
	}

	public void setSchema(String schema) {
		this.schema = schema;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	String source;
}
