package com.optum.dl.speed.addrstd;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.Put;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.Function0;
import org.apache.spark.api.java.function.VoidFunction;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaPairInputDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.apache.spark.streaming.kafka.v09.KafkaUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.dl.speed.dao.RecordFormatterDAO;
import com.optum.dl.speed.model.FormattedRecord;

import scala.Tuple2;

public class AddressStdSubscriber {

	@SuppressWarnings("serial")
	public static void main(String[] args) {
		if (args.length < 2) {
			System.err.println("Usage: CDCUpdateMaprDB <brokers> <topics>\n"
					+ "  <brokers> is a list of one or more Kafka brokers\n"
					+ "  <topics> is a list of one or more kafka topics to consume from\n"
					+ "  <poll time> time, in milliseconds, spent waiting in Kafka consumer poll if data is not available\n\n");
			System.exit(1);
		}

		final String brokers = args[0];
		final String topics = args[1];
		final String pollTime = args[2];
		final String checkpointDirectory = (args.length > 3) ? args[3]
				: "/datalake/corporate/ses_dlpoc/cdc/checkpoint_2";

		Function0<JavaStreamingContext> createContextFunc = new Function0<JavaStreamingContext>() {
			@Override
			public JavaStreamingContext call() {
				return createContext(brokers, topics, pollTime, checkpointDirectory);
			}
		};
		JavaStreamingContext jssc = JavaStreamingContext.getOrCreate(checkpointDirectory, createContextFunc);
		jssc.start();
		jssc.awaitTermination();

	}// end of main.

	@SuppressWarnings("serial")
	protected static JavaStreamingContext createContext(String brokers, String topics, String pollTime,
			String checkpointDirectory) {
		// Create context with a 2 seconds batch interval
		SparkConf sparkConf = new SparkConf().setAppName("AddressStd-Sub");
		JavaStreamingContext jssc = new JavaStreamingContext(sparkConf, Durations.seconds(2));
		HashSet<String> topicsSet = new HashSet<String>(Arrays.asList(topics.split(",")));
		HashMap<String, String> kafkaParams = new HashMap<String, String>();
		kafkaParams.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, brokers);
		kafkaParams.put(ConsumerConfig.GROUP_ID_CONFIG, "testGroup");
		kafkaParams.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,
				"org.apache.kafka.common.serialization.StringDeserializer");
		kafkaParams.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
				"org.apache.kafka.common.serialization.StringDeserializer");
		kafkaParams.put("spark.kafka.poll.time", pollTime);
		kafkaParams.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
		kafkaParams.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
		// Create direct kafka stream with brokers and topics
		JavaPairInputDStream<String, String> messages = KafkaUtils.createDirectStream(jssc, String.class, String.class,
				kafkaParams, topicsSet);

		JavaDStream<String> lines = messages.map(new Function<Tuple2<String, String>, String>() {
			@Override
			public String call(Tuple2<String, String> tuple2) {
				return tuple2._2();
			}
		});
		JavaDStream<FormattedRecord> record = lines.map(new Function<String, FormattedRecord>() {
			ObjectMapper mapper = new ObjectMapper();

			@Override
			public FormattedRecord call(String json) throws Exception {
				return mapper.readValue(json, FormattedRecord.class);
			}
		});

		record.foreachRDD(new VoidFunction<JavaRDD<FormattedRecord>>() {
			@Override
			public void call(JavaRDD<FormattedRecord> rdd) throws Exception {
				rdd.foreachPartition(new VoidFunction<Iterator<FormattedRecord>>() {
					@Override
					public void call(Iterator<FormattedRecord> fr) throws Exception {
						Configuration conf = HBaseConfiguration.create();
						RecordFormatterDAO dao = new RecordFormatterDAO();
						HashMap<String, ArrayList<Put>> puts = new HashMap<String, ArrayList<Put>>();
						while (fr != null && fr.hasNext()) {
							FormattedRecord formatRecord = fr.next();
							String table = formatRecord.getHtable();
							if (puts.get(table) == null)
								puts.put(table, new ArrayList<Put>());
							ArrayList<Put> records = puts.get(table);
							records.add(dao.mkPut(formatRecord));
							puts.put(table, records);
						} // end of while.
						dao.makeBatchPut(conf, puts);
					}// end of call.

				});

			}// end of call.

		});
		jssc.checkpoint(checkpointDirectory);
		return jssc;
	}
}
