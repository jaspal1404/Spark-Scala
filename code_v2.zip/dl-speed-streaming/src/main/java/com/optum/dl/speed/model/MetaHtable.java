package com.optum.dl.speed.model;

import java.io.IOException;
import java.util.HashMap;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;

import com.optum.dl.speed.dao.CDCDao;

public class MetaHtable {

	private static volatile Broadcast<HashMap<String, Meta>> instance = null;

	public static Broadcast<HashMap<String, Meta>> getInstance(JavaSparkContext jsc) {
		if (instance == null) {
			synchronized (MetaHtable.class) {
				if (instance == null) {
					HashMap<String, Meta> metaData = new HashMap<String, Meta>();
					Configuration conf = HBaseConfiguration.create();
					try {
						CDCDao dao = new CDCDao();

						metaData = dao.getAll("/datalake/uhclake/tst/developer/DL_SPEEDLAYER/mtables/spp_hbase");
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					instance = jsc.broadcast(metaData);
				}
			}
		}
		return instance;
	}
}
