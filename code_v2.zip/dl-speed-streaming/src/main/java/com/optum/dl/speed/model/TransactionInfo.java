package com.optum.dl.speed.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TransactionInfo implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@JsonProperty("transactionTimestamp")
	String TransactionTimestamp;
	String content;

	public TransactionInfo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TransactionInfo(String transactionTimestamp, String content) {
		super();
		TransactionTimestamp = transactionTimestamp;
		this.content = content;
	}

	public String getTransactionTimestamp() {
		return TransactionTimestamp;
	}

	public void setTransactionTimestamp(String transactionTimestamp) {
		TransactionTimestamp = transactionTimestamp;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	@Override
	public String toString() {
		return "TransactionInfo [TransactionTimestamp=" + TransactionTimestamp + ", content=" + content + "]";
	}
}
