package com.optum.dl.speed;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.spark.Accumulator;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.Function0;
import org.apache.spark.api.java.function.VoidFunction;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaPairInputDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.apache.spark.streaming.kafka.v09.KafkaUtils;

import scala.Tuple2;

public class CDCRouterTest {

	static class MessageCounAccumlator {

		private static volatile Accumulator<Integer> instance = null;

		public static Accumulator<Integer> getInstance(JavaSparkContext jsc) {
			if (instance == null) {
				synchronized (MessageCounAccumlator.class) {
					if (instance == null) {
						instance = jsc.accumulator(0, "MessageCounAccumlator");
					}
				}
			}
			return instance;
		}
	}

	static class MapBroadCast {

		private static volatile Broadcast<Map<String, String>> instance = null;

		public static Broadcast<Map<String, String>> getInstance(JavaSparkContext jsc) {
			if (instance == null) {
				synchronized (MapBroadCast.class) {
					if (instance == null) {
						Map<String, String> tableMap = new HashMap<>();
						tableMap.put("name", "BDPAAS");
						instance = jsc.broadcast(tableMap);
					}
				}
			}
			return instance;
		}
	}

	@SuppressWarnings("serial")
	public static void main(String[] args) {

		if (args.length < 2) {
			System.err.println("Usage: CDCRouter <brokers> <topics>\n"
					+ "  <brokers> is a list of one or more Kafka brokers\n"
					+ "  <topics> is a list of one or more kafka topics to consume from\n"
					+ "  <poll time> time, in milliseconds, spent waiting in Kafka consumer poll if data is not available\n\n");
			System.exit(1);
		}

		final String groupId = args[0];
		final String topics = args[1];
		final String checkpointDirectory = (args.length > 2) ? args[2]
				: "/datalake/corporate/ses_dlpoc/poc/tenant_retry/checkpoint_tenant";
		final String writetopic = (args.length > 3) ? args[3]
				: "/datalake/uhclake/tst/developer/DL_SPEEDLAYER/streams/optum-datalake-services:optum.datalake.speed.cdc.snapshot";
		final String duration = (args.length > 4) ? args[4] : "5";

		JavaStreamingContext jssc = JavaStreamingContext.getOrCreate(checkpointDirectory,
				new Function0<JavaStreamingContext>() {
					@Override
					public JavaStreamingContext call() {
						return createContext("apsrd4191:9092", topics, checkpointDirectory, groupId, duration,
								writetopic);
					}
				});

		jssc.start();
		jssc.awaitTermination();

	}

	@SuppressWarnings("serial")
	protected static JavaStreamingContext createContext(final String broker, String topics, String checkpointDirectory,
			String groupId, String duration, final String writetopic) {

		SparkConf sparkConf = new SparkConf().setAppName("CDCRouterTest");
		JavaStreamingContext jssc = new JavaStreamingContext(sparkConf, Durations.seconds(Integer.valueOf(duration)));

		HashSet<String> topicsSet = new HashSet<String>(Arrays.asList(topics.split(",")));
		HashMap<String, String> kafkaParams = new HashMap<String, String>();
		kafkaParams.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, broker);
		kafkaParams.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
		kafkaParams.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,
				"org.apache.kafka.common.serialization.StringDeserializer");
		kafkaParams.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
				"org.apache.kafka.common.serialization.StringDeserializer");
		kafkaParams.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
		kafkaParams.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");

		JavaPairInputDStream<String, String> messages = KafkaUtils.createDirectStream(jssc, String.class, String.class,
				kafkaParams, topicsSet);

		JavaDStream<String> lines = messages.map(new Function<Tuple2<String, String>, String>() {
			@Override
			public String call(Tuple2<String, String> tuple2) {
				return tuple2._2();
			}
		});

		lines.foreachRDD(new VoidFunction<JavaRDD<String>>() {
			@Override
			public void call(JavaRDD<String> rdd) throws Exception {
				final Accumulator<Integer> counter = MessageCounAccumlator
						.getInstance(new JavaSparkContext(rdd.context()));
				final Broadcast<Map<String, String>> tableMap = MapBroadCast
						.getInstance(new JavaSparkContext(rdd.context()));
				System.out.println("Broadcast name: " + tableMap.getValue().get("name"));
				System.out.println("Message Counter: " + counter.value());
				rdd.foreachPartition(new VoidFunction<Iterator<String>>() {
					@Override
					public void call(Iterator<String> cdc) throws Exception {
						Producer<String, String> producer = getKafkaProducer();
						while (cdc != null && cdc.hasNext()) {
							counter.add(1);
							String cdcs = cdc.next();
							producer.send(new ProducerRecord<String, String>(writetopic, cdcs));
						}
						producer.flush();
						producer.close();
					}
				});

			}

			public Producer<String, String> getKafkaProducer() {
				Properties props = new Properties();
				props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, broker);
				props.put(ProducerConfig.ACKS_CONFIG, "all");
				props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,
						"org.apache.kafka.common.serialization.StringSerializer");
				props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
						"org.apache.kafka.common.serialization.StringSerializer");

				return new KafkaProducer<>(props);
			}

		});

		jssc.checkpoint(checkpointDirectory);
		return jssc;
	}

}
