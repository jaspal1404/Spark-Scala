package com.optum.dl.speed.model;

import java.io.Serializable;

public class Column implements Serializable {

	private static final long serialVersionUID = 1L;
	int oridnal;
	String name;
	String type;
	int width;
	int scale;
	int primaryKeyPos;

	public Column() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Column(int oridnal, String name, String type, int width, int scale, int primaryKeyPos) {
		super();
		this.oridnal = oridnal;
		this.name = name;
		this.type = type;
		this.width = width;
		this.scale = scale;
		this.primaryKeyPos = primaryKeyPos;
	}

	@Override
	public String toString() {
		return "Columns [oridnal=" + oridnal + ", name=" + name + ", type=" + type + ", width=" + width + ", scale="
				+ scale + ", primaryKeyPos=" + primaryKeyPos + "]";
	}

	public int getOridnal() {
		return oridnal;
	}

	public void setOridnal(int oridnal) {
		this.oridnal = oridnal;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getScale() {
		return scale;
	}

	public void setScale(int scale) {
		this.scale = scale;
	}

	public int getPrimaryKeyPos() {
		return primaryKeyPos;
	}

	public void setPrimaryKeyPos(int primaryKeyPos) {
		this.primaryKeyPos = primaryKeyPos;
	}
}
