
package com.optum.dl.speed.logging;

import java.util.Properties;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;


public class LoggingProducer {

	final String TOPIC_LOG_MESSAGES_P = "/datalake/uhclake/tst/developer/DL_SPEEDLAYER/streams/optum-datalake-utilities:optum.datalake.speed.logging";
	private static KafkaProducer<String, String> producer;
	
	
	public LoggingProducer(){
		getKafkaProducer();
	}//end of constructor.

	public void sendLog(String type, String appName, String transactionID, String partnCode, String sourceCode, String sourceTable, String msg){
		//try {
			// send lots of messages
			producer.send(new ProducerRecord<String, String>(TOPIC_LOG_MESSAGES_P,
			String.format(
					"{\"type\":\"%s\",\"appName\":\"%s\",\"transactionID\":\"%s\",\"partnCode\":\"%s\",\"sourceCode\":\"%s\",\"sourceTable\":\"%s\",\"msg\":\"%s\"}",
					type, appName, transactionID, partnCode, sourceCode, sourceTable, msg))
			);
			producer.flush();
	}// end of main.
	
	/* Set the value for a configuration parameter.
    This configuration parameter specifies which class
    to use to serialize the value of each message.*/
	/**
	 * 
	 * @return
	 */
	public static void getKafkaProducer() {
		Properties properties = new Properties();
		properties.setProperty("batch.size","16384");
		properties.setProperty("auto.offset.reset","earliest");
		properties.setProperty("key.serializer","org.apache.kafka.common.serialization.StringSerializer");
		properties.setProperty("value.serializer","org.apache.kafka.common.serialization.StringSerializer");		
		properties.setProperty("block.on.buffer.full", "true");	    
		producer = new KafkaProducer<String, String>(properties);
	}//end of method.

}// end of class.
