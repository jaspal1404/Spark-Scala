// THis is a prodcuer code
package com.optum.dl.speed;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.json.JSONException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.dl.speed.model.CDC;
import com.optum.dl.speed.model.Column;
import com.optum.dl.speed.model.FormatInfo;
import com.optum.dl.speed.model.Option;
import com.optum.dl.speed.model.Schema;
import com.optum.dl.speed.model.TransactionInfo;

public class ProducerTest {

	// Set the number of messages to send.
	public static int numMessages = 60;
	public static ObjectMapper mapper;
	public static ProducerRecord<String, String> rec;
	public static KafkaProducer<String, String> producer;

	public static void main(String[] args) throws IOException, JSONException {

		Long start = System.nanoTime();
		System.out.println("Starting time: " + start);
		
		String filePath = "/mapr/datalake/corporate/ses_dlpoc/streams/data/";
		if (args.length > 0) {
			filePath = args[0];
		}
		
		String metaFileName = "RX1_CLMPRDFIL_RCMBRP_20170301T105200.meta";
		if (args.length > 1) {
			metaFileName = args[1];
		}
		
		String dataFileName = "RX1_CLMPRDFIL_RCMBRP_20170301T105200.dat";
		if (args.length > 2) {
			dataFileName = args[2];
		}
		
		int numOfMsg = 1000000;
		if (args.length > 3) {
			numOfMsg = Integer.parseInt(args[3]);
		}

		String topic = "/datalake/corporate/ses_dlpoc/streams/lakepoc/bdptstsrc2:srctopic";
		if (args.length > 4) {
			topic = args[4];
		}

		Long numberOfLines = 0L;

		configureProducer();

		File metaFile = new File(filePath + metaFileName);
		File dataFile = new File(filePath + dataFileName);

		CDC message = getMetaInformation(metaFile);

		mapper = new ObjectMapper();
		
		for (int i = 0; i < numOfMsg; i++){
			message.setData("I2016-06-15 01:00:00.000100368364         ACUNYM   ACUNYMFL       ACUNYMFLC      LIDEL II                 ADAM           AM19920530508 FLORIDA RD                                                                                                          SYRACUSE            NY13211      USA 3154545591           0 89801695  100368364         1                                0ENG 00                                                                                                   ELIGMQPRF 1130601730RXELGLOD  ELIGMQPRF 1130727113255RXELGLOD  " + i);
			//message.setData("Message - " + i);
			rec = new ProducerRecord<String, String>(topic, mapper.writeValueAsString(message));
			producer.send(rec);
			numberOfLines++;
		}
		
		producer.close();

		Long end = System.nanoTime();
		System.out.println("Ending Time: " + end);

		System.out.println(
				String.format("All %s Messages done in %s Milli Seconds", numberOfLines, (end - start) / 1000000));

		System.exit(1);

	}

	public static CDC getMetaInformation(File file) throws IOException, JSONException {

		CDC message = new CDC();

		FileReader fileReader = new FileReader(file);
		BufferedReader bufferReader = new BufferedReader(fileReader);
		String line = bufferReader.readLine();

		line = bufferReader.readLine();

		boolean hasSchema = false;
		List<Column> columns = new ArrayList<Column>();
		Schema schema = new Schema();
		Option option = new Option();
		TransactionInfo transactionInfo = new TransactionInfo();
		FormatInfo formatInfo = new FormatInfo();

		transactionInfo.setContent("Changes");
		transactionInfo.setTransactionTimestamp(LocalDateTime.now().toString());

		formatInfo.setFormat("delimeted");
		option.setFieldDelimiter("\u0001");
		formatInfo.setOptions(option);

		while (line != null) {

			String[] fields = line.split("\\|");

			if (!hasSchema) {
				schema.setSource(fields[0]);
				schema.setSourceSchema(fields[1]);
				schema.setSourceTable(fields[2]);
				hasSchema = true;
			}

			Column column = new Column();

			column.setName(fields[3]);
			column.setType(fields[4]);
			column.setWidth(convertToInt(fields[5]));
			column.setScale(convertToInt(fields[6]));
			column.setOridnal(convertToInt(fields[9]));

			columns.add(column);

			line = bufferReader.readLine();
		}

		schema.setColumns(columns);

		message.setTransaction(transactionInfo);
		message.setFormat(formatInfo);
		message.setSchema(schema);

		fileReader.close();
		bufferReader.close();

		return message;
	}

	public static int convertToInt(String value) {

		String innerValue = value.trim().equals("") ? "0" : value;
		return Integer.valueOf(innerValue);
	}

	/*
	 * Set the value for a configuration parameter. This configuration parameter
	 * specifies which class to use to serialize the value of each message.
	 */
	public static void configureProducer() {
		Properties props = new Properties();
		props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");

		producer = new KafkaProducer<String, String>(props);
	}

}
