package com.optum.dl.speed.model;

import java.io.Serializable;

public class Option implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3217601190758842311L;
	String fieldDelimiter;

	public Option() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Option(String fieldDelimiter) {
		super();
		this.fieldDelimiter = fieldDelimiter;
	}

	@Override
	public String toString() {
		return "Options [fieldDelimiter=" + fieldDelimiter + "]";
	}

	public String getFieldDelimiter() {
		return fieldDelimiter;
	}

	public void setFieldDelimiter(String fieldDelimiter) {
		this.fieldDelimiter = fieldDelimiter;
	}
}
