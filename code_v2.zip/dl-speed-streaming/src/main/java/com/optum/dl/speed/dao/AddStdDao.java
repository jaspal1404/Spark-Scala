package com.optum.dl.speed.dao;

import java.io.IOException;
import java.util.HashMap;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.util.Bytes;

import com.optum.dl.speed.model.AddStdMeta;

public class AddStdDao {
	public boolean validate(String[] variables, String[] values) {
		Boolean validate = false;
		if (variables.length == values.length) {
			validate = true;
		} // end of if.
		return validate;
	}// end of method.

	/**
	 * 
	 * @param spp
	 * @param rowkeys
	 * @param variables
	 * @param values
	 * @return
	 */
	public String rowkey(String[] rowkeys, String[] variables, String[] values) {
		String rowkey = "";
		HashMap<String, String> map = new HashMap<String, String>();

		for (int i = 0; i < rowkeys.length; i++) {
			map.put(rowkeys[i], "");
		} // end of for.

		for (int j = 0; j < variables.length; j++) {
			for (int k = 0; k < rowkeys.length; k++) {
				if (variables[j].equalsIgnoreCase(rowkeys[k])) {
					map.put(rowkeys[k], values[j]);
					break;
				} // end of if.
			} // end of for.
		} // end of for.

		for (int z = 0; z < rowkeys.length; z++) {
			if (z == 0) {
				rowkey = map.get(z);
			} // end of if.
			else {
				rowkey += "-" + map.get(z);
			} // end of else
		} // end of for.
		return rowkey;
	}// end of method.

	/**
	 * Creating a connection with HBase table and loading all the values.
	 * 
	 * @param table
	 * @return
	 * @throws IOException
	 */
	// @SuppressWarnings("deprecation")
	public HashMap<String, AddStdMeta> getAll(String table) throws IOException {
		Configuration conf = HBaseConfiguration.create();
		@SuppressWarnings({ "deprecation", "resource" })
		HBaseAdmin hba = new HBaseAdmin(conf);

		if (hba.tableExists(table) == false) {
			@SuppressWarnings("deprecation")
			HTableDescriptor tableDescriptor = new HTableDescriptor(table);
			HColumnDescriptor columnDescriptor = new HColumnDescriptor("info");
			tableDescriptor.addFamily(columnDescriptor);

			hba.createTable(tableDescriptor);
		} // end of if.

		@SuppressWarnings("deprecation")
		HTable htable = new HTable(conf, Bytes.toBytes(table));
		HashMap<String, AddStdMeta> results = new HashMap<String, AddStdMeta>();

		Scan s = new Scan();
		ResultScanner ss = htable.getScanner(s);
		if (ss != null) {
			for (Result result : ss) {
				String rowkey = new String(result.getRow());
				results.put(rowkey, populateFromResult(result));
			} // end of for.
		} // end of if.
		htable.close();
		return results;
	}// end of getAll method.

	/**
	 * Load all fields from SPP config - HBase table.
	 * 
	 * @param result
	 * @return
	 */
	public AddStdMeta populateFromResult(Result result) {
		AddStdMeta m = new AddStdMeta();
		final byte[] cf_si = Bytes.toBytes("si");
		m.setAddline1(replaceNullWithEmpty(result.getValue(cf_si, Bytes.toBytes("addrLineOneMapping"))));
		m.setAddline2(replaceNullWithEmpty(result.getValue(cf_si, Bytes.toBytes("addrLineTwoMapping"))));
		m.setAddline3(replaceNullWithEmpty(result.getValue(cf_si, Bytes.toBytes("addrLineThreeMapping"))));
		m.setCity(replaceNullWithEmpty(result.getValue(cf_si, Bytes.toBytes("cityMapping"))));
		m.setState(replaceNullWithEmpty(result.getValue(cf_si, Bytes.toBytes("stateMapping"))));
		m.setCountry(replaceNullWithEmpty(result.getValue(cf_si, Bytes.toBytes("countryMapping"))));
		m.setZip(replaceNullWithEmpty(result.getValue(cf_si, Bytes.toBytes("postalCodeMapping"))));

		m.setSource(replaceNullWithEmpty(result.getValue(cf_si, Bytes.toBytes("entNm"))));
		m.setPrtnrCd(replaceNullWithEmpty(result.getValue(cf_si, Bytes.toBytes("prtnrCd"))));
		m.setSrcCd(replaceNullWithEmpty(result.getValue(cf_si, Bytes.toBytes("srcCd"))));
		return m;
	}// end of method.

	/**
	 * 
	 * @param value
	 * @return
	 */
	public static String replaceNullWithEmpty(byte[] value) {
		return value != null ? new String(value) : "";
	}// end of method.
}// end of class.
