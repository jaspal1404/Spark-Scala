package com.optum.dl.speed;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicReference;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.TopicPartition;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.Function0;
import org.apache.spark.api.java.function.VoidFunction;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaInputDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.apache.spark.streaming.kafka.v09.HasOffsetRanges;
import org.apache.spark.streaming.kafka.v09.KafkaUtils;
import org.apache.spark.streaming.kafka.v09.OffsetRange;
import org.ojai.Document;
import org.ojai.json.Json;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mapr.db.MapRDB;
import com.mapr.db.Table;
import com.optum.dl.speed.dao.CDCDao;
import com.optum.dl.speed.model.CDC;
import com.optum.dl.speed.model.Column;
import com.optum.dl.speed.model.FormattedRecord;
import com.optum.dl.speed.model.Meta;

public class CDCRouterMapRDBJSon {

	@SuppressWarnings("serial")
	public static void main(String[] args) {
		if (args.length < 2) {
			System.err.println("Usage: CDCUpdateMaprDB <brokers> <topics>\n"
					+ "  <brokers> is a list of one or more Kafka brokers\n"
					+ "  <topics> is a list of one or more kafka topics to consume from\n"
					+ "  <poll time> time, in milliseconds, spent waiting in Kafka consumer poll if data is not available\n\n");
			System.exit(1);
		}

		final String brokers = args[0];
		final String topics = args[1];
		final String pollTime = args[2];
		final Map<TopicPartition, Long> fromOffsets = new HashMap<TopicPartition, Long>();
		final String offsetTable = "/datalake/uhclake/tst/developer/DL_SPEEDLAYER/mtables/speed_meta";
		final int partitions = 6;
		final int cpduration = 5;
		if (MapRDB.tableExists(offsetTable)) {

			for (int i = 0; i < partitions; i++) {
				try (Table tableCheck = MapRDB.getTable(offsetTable)) {
					System.out.println("Partition Table: " + tableCheck.getName());
					System.out.println(topics + ":" + "partition." + i);

					String OffsetLocation = "";
					try {
						OffsetLocation = tableCheck.findById(topics + ":" + "partition." + i, "offset")
								.getString("offset").toString();
					} catch (NullPointerException e) {
						System.out.println("Creating New document with offset 0");
						Document name = Json.newDocument();
						name.setId(topics + ":partition." + i);
						name.set("offset", Long.toString(0));
						tableCheck.insertOrReplace(name);

						OffsetLocation = tableCheck.findById(topics + ":" + "partition." + i, "offset")
								.getString("offset").toString();

					}
					Long offsetLong = Long.parseLong(OffsetLocation);
					System.out.println("offset location:" + offsetLong);
					fromOffsets.putAll(getOffsets(topics, i, offsetLong));
				}
			}

			HashMap<String, Meta> metaData = new HashMap<String, Meta>();
			try {
				CDCDao dao = new CDCDao();

				metaData = dao.getAll("/datalake/uhclake/tst/developer/DL_SPEEDLAYER/mtables/spp_hbase");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			final HashMap<String, Meta> meta = metaData;

			JavaStreamingContext jssc = JavaStreamingContext.getOrCreate(offsetTable,
					new Function0<JavaStreamingContext>() {
						@Override
						public JavaStreamingContext call() {
							return createContext(fromOffsets, topics, pollTime, meta, cpduration);
						}
					});
			jssc.start();
			jssc.awaitTermination();

		}
	}

	@SuppressWarnings("serial")
	protected static JavaStreamingContext createContext(Map<TopicPartition, Long> fromOffsets, String topics,
			String pollTime, final HashMap<String, Meta> meta, int cpduration) {

		SparkConf sparkConf = new SparkConf().setAppName("CDCRouterMapRDBJSON");//
		JavaStreamingContext jssc = new JavaStreamingContext(sparkConf, Durations.seconds(2));
		HashMap<String, String> kafkaParams = new HashMap<String, String>();
		kafkaParams.put(ConsumerConfig.GROUP_ID_CONFIG, "testGroup");
		kafkaParams.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,
				"org.apache.kafka.common.serialization.StringDeserializer");
		kafkaParams.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
				"org.apache.kafka.common.serialization.StringDeserializer");
		//kafkaParams.put("spark.kafka.poll.time", pollTime);
		kafkaParams.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
		kafkaParams.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
		// Create direct kafka stream with brokers and topics
		JavaInputDStream<String> messages = KafkaUtils.createDirectStream(jssc, String.class, String.class,
				String.class, kafkaParams, fromOffsets, new Function<ConsumerRecord<String, String>, String>() {
					public String call(ConsumerRecord<String, String> v1) throws Exception {
						return v1.value();
					}
				});
		final AtomicReference<OffsetRange[]> offsetRanges = new AtomicReference<OffsetRange[]>();
		JavaDStream<String> lines = messages.transform(new Function<JavaRDD<String>, JavaRDD<String>>() {
			public JavaRDD<String> call(JavaRDD<String> rdd) throws Exception {
				OffsetRange[] offsets = ((HasOffsetRanges) rdd.rdd()).offsetRanges();
				for (OffsetRange offset : offsets) {
					String topic = offset.topic();
					int part = offset.partition();
					long offsetUpdate = offset.fromOffset();

					offsetRanges.set(offsets);
					if (MapRDB.tableExists("/datalake/uhclake/tst/developer/DL_SPEEDLAYER/mtables/speed_meta")) {
						Table tableCheck = MapRDB
								.getTable("/datalake/uhclake/tst/developer/DL_SPEEDLAYER/mtables/speed_meta");
						Document name = Json.newDocument();
						name.setId(topic + ":partition." + part);
						name.set("offset", Long.toString(offsetUpdate));
						tableCheck.insertOrReplace(name);
						tableCheck.close();
					}
				}
				return rdd;
			}
		});
		JavaDStream<CDC> cdc = lines.map(new Function<String, CDC>() {
			ObjectMapper mapper = new ObjectMapper();

			@Override
			public CDC call(String json) throws Exception {
				return mapper.readValue(json, CDC.class);
			}
		});

		cdc.foreachRDD(new VoidFunction<JavaRDD<CDC>>() {

			@Override
			public void call(JavaRDD<CDC> rdd) throws Exception {
				// final Broadcast<HashMap<String, Meta>> meta =
				// MetaHtable.getInstance(new JavaSparkContext(rdd.context()));
				rdd.foreachPartition(new VoidFunction<Iterator<CDC>>() {
					@Override
					public void call(Iterator<CDC> cdc) throws Exception {

						Producer<String, String> producer = getKafkaProducer();
						CDCDao dao = new CDCDao();
						ObjectMapper mapper = new ObjectMapper();

						while (cdc != null && cdc.hasNext()) {
							CDC cdcs = cdc.next();
							Meta recordMeta = meta.get(cdcs.getSchema().getSource() + "-"
									+ cdcs.getSchema().getSourceSchema() + "_" + cdcs.getSchema().getSourceTable());
							String rowkey = recordMeta.getRowkey();
							List<Column> columns = cdcs.getSchema().getColumns();
							String[] column = new String[columns.size()];
							for (int i = 0; i < columns.size(); i++) {
								column[i] = columns.get(i).getName();
							}
							FormattedRecord record = new FormattedRecord();
							record.setKeys(column);
							String[] data = cdcs.getData().split("\u0001");
							record.setValues(data);
							String[] rowkeys = rowkey.split("\\;");
							record.setHtable(recordMeta.getLocation());
							record.setKey(dao.rowkey(cdcs, rowkeys, column, data));
							record.setSourceMD5(cdcs.getSchema().getSchmd5());
							record.setTransactionID(cdcs.getTransactionID());
							record.setSchemaName(cdcs.getSchema().getSourceSchema());
							record.setPartnCode(recordMeta.getPartner());
							record.setSourceCode(cdcs.getSchema().getSource());	
							record.setSourceTable(cdcs.getSchema().getSourceTable());
							/*String cdc_ts = cdcs.getTransaction().getTransactionTimestamp();
							SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
							Date myDate = df.parse(cdc_ts);
							record.setTs(myDate.getTime());*/
							// if(dao.validate(cdcs, column, data)){
							producer.send(new ProducerRecord<String, String>(
									"/datalake/uhclake/tst/developer/DL_SPEEDLAYER/streams/optum-datalake-services:optum.datalake.speed.cdc.snapshot",
									mapper.writeValueAsString(record)));
							if (recordMeta.getAdrind().equals("Y")) {
								producer.send(new ProducerRecord<String, String>(
										"/datalake/uhclake/tst/developer/DL_SPEEDLAYER/streams/optum-datalake-address:optum.datalake.speed.cdc.adrsrt",
										mapper.writeValueAsString(record)));
								// }
							}

						}

						producer.flush();
						// dao.putCDCBatch(puts);
						producer.close();
					}

				});

			}

			public Producer<String, String> getKafkaProducer() {
				Properties props = new Properties();
				props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "apsrd4190:9092");
				props.put(ProducerConfig.ACKS_CONFIG, "all");
				// props.put(ProducerConfig.RETRIES_CONFIG, 2);
				// props.put(ProducerConfig.BATCH_SIZE_CONFIG, 16384);
				// props.put(ProducerConfig.LINGER_MS_CONFIG, 1);
				// props.put(ProducerConfig.BUFFER_MEMORY_CONFIG, 33554432);
				props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,
						"org.apache.kafka.common.serialization.StringSerializer");
				props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
						"org.apache.kafka.common.serialization.StringSerializer");

				return new KafkaProducer<>(props);
			}

		});

		// jssc.checkpoint(checkpointDirectory);
		return jssc;
	}

	public static Map<TopicPartition, Long> getOffsets(String topic, int partition, Long offsetLong) {
		TopicPartition TopicPartition = new TopicPartition(topic, partition);
		Map<TopicPartition, Long> requestInfo = new HashMap<TopicPartition, Long>();
		requestInfo.put(TopicPartition, offsetLong);

		System.out.println("Request Info: " + requestInfo);
		return requestInfo;
	}
}
