package com.optum.dl.speed;


import java.io.ObjectOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.spark.Accumulator;
import org.apache.spark.SparkConf;
import org.apache.spark.SparkEnv;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.Function0;
import org.apache.spark.api.java.function.VoidFunction;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaPairInputDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.apache.spark.streaming.kafka.v09.KafkaUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.dl.speed.CDCRouterTest.MessageCounAccumlator;
import com.optum.dl.speed.dao.RecordFormatterDAO;
import com.optum.dl.speed.model.FormattedRecord;

//import akka.util.Collections;
import scala.Tuple2;

public class raw_consumer {

	public static final byte[] cfInfoBytes = Bytes.toBytes("info");

	@SuppressWarnings("serial")
	public static void main(String[] args) {
		if (args.length < 2) {
			System.err.println("Usage: CDCUpdateMaprDB <brokers> <topics>\n"
					+ "  <brokers> is a list of one or more Kafka brokers\n"
					+ "  <topics> is a list of one or more kafka topics to consume from\n"
					+ "  <poll time> time, in milliseconds, spent waiting in Kafka consumer l if data is not available\n\n");
			System.exit(1);
		}

		final String brokers = args[0];
		final String topics = args[1];
		final String pollTime = args[2];
		final String checkpointDirectory = (args.length > 3) ? args[3]
				: "/datalake/corporate/ses_dlpoc/cdc/checkpoint_4";

		Function0<JavaStreamingContext> createContextFunc = new Function0<JavaStreamingContext>() {
			@Override
			public JavaStreamingContext call() {
				return createContext(brokers, topics, pollTime, checkpointDirectory);
			}
		};
		JavaStreamingContext jssc = JavaStreamingContext.getOrCreate(checkpointDirectory, createContextFunc);
		jssc.start();
		jssc.awaitTermination();

	}

	@SuppressWarnings("serial")
	protected static JavaStreamingContext createContext(String brokers, String topics, String pollTime,
			String checkpointDirectory) {

		final String table = "/datalake/uhclake/tst/developer/DL_SPEEDLAYER/mtables/epp_schema_mapping";
		// Create context with a 2 seconds batch interval
		SparkConf sparkConf = new SparkConf().setAppName("CONSUMERRAW");// .setMaster("local[2]");
		JavaStreamingContext jssc = new JavaStreamingContext(sparkConf, Durations.seconds(2));
		HashSet<String> topicsSet = new HashSet<String>(Arrays.asList(topics.split(",")));
		HashMap<String, String> kafkaParams = new HashMap<String, String>();
		kafkaParams.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, brokers);
		kafkaParams.put(ConsumerConfig.GROUP_ID_CONFIG, "testGroup");
		kafkaParams.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,
				"org.apache.kafka.common.serialization.StringDeserializer");
		kafkaParams.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
				"org.apache.kafka.common.serialization.StringDeserializer");
		// kafkaParams.put("spark.kafka.poll.time", pollTime);
		kafkaParams.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
		kafkaParams.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
		// Create direct kafka stream with brokers and topics
		JavaPairInputDStream<String, String> messages = KafkaUtils.createDirectStream(jssc, String.class, String.class,
				kafkaParams, topicsSet);

		JavaDStream<String> lines = messages.map(new Function<Tuple2<String, String>, String>() {
			@Override
			public String call(Tuple2<String, String> tuple2) {
				return tuple2._2();
			}
		});
		JavaDStream<FormattedRecord> record = lines.map(new Function<String, FormattedRecord>() {
			ObjectMapper mapper = new ObjectMapper();

			@Override
			public FormattedRecord call(String json) throws Exception {
				return mapper.readValue(json, FormattedRecord.class);
			}
		});

		record.foreachRDD(new VoidFunction<JavaRDD<FormattedRecord>>() {
			@Override
			public void call(JavaRDD<FormattedRecord> rdd) throws Exception {
				final Accumulator<Integer> counter = MessageCounAccumlator
						.getInstance(new JavaSparkContext(rdd.context()));

				SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
				System.out.println("Message Counter: " + counter.value() + " Time: " + ft.format(new Date()));
				rdd.foreachPartition(new VoidFunction<Iterator<FormattedRecord>>() {
					@SuppressWarnings("deprecation")
					@Override
					public void call(Iterator<FormattedRecord> fr) throws Exception {
						HashMap<String, ArrayList<String>> writes = new HashMap<String, ArrayList<String>>();
						HashMap<String, ArrayList<Put>> puts = new HashMap<String, ArrayList<Put>>();
						Configuration conf = HBaseConfiguration.create();
						RecordFormatterDAO dao = new RecordFormatterDAO();
						FileSystem fs = FileSystem.get(new Configuration());
						while (fr != null && fr.hasNext()) {
							counter.add(1);
							FormattedRecord formatRecord = fr.next();

							String rowKey = formatRecord.getSourceCode() + "-" + formatRecord.getSourceTable();
							Integer version = 0;
							if (puts.get(rowKey) == null) {
								puts.put(rowKey, new ArrayList<Put>());
								version = 1;
								ArrayList<Put> mdVr = puts.get(rowKey);
//								mdVr.add(dao.eppSchemaPut(formatRecord, version, rowKey));
//								puts.put(rowKey, mdVr);
							}

							else {
								ArrayList<Put> mdVr = puts.get(rowKey);

								for (int i = 0; i < mdVr.size(); i++) {
									if (mdVr.get(i).has(cfInfoBytes, Bytes.toBytes(formatRecord.getSourceMD5()))) {
										byte[] temp = mdVr.get(i)
												.get(cfInfoBytes, Bytes.toBytes(formatRecord.getSourceMD5())).get(0)
												.getValue();
										version = java.nio.ByteBuffer.wrap(temp).getInt();
										break;
									}
								}

								if (version == 0) {
									version = mdVr.size() + 1;
//									mdVr.add(dao.eppSchemaPut(formatRecord, version, rowKey));
//									puts.put(rowKey, mdVr);
								}
							}

							String pt = "/datalake/uhclake/tst/developer/DL_SPEEDLAYER/raw/"
									+ formatRecord.getPartnCode() + "/" + formatRecord.getSourceCode() + "/"
									+ formatRecord.getSourceTable() + "/" + formatRecord.getSourceTable() + "_v"
									+ version
							 + "/" + formatRecord.getSourceTable() + "_" +
							 formatRecord.getTs();

							String databuf = "";
							for (int i = 0; i < formatRecord.getValues().length; i++) {
								databuf = databuf + formatRecord.getValues()[i] + '\u0001';
							}

							databuf = databuf.substring(0, (databuf.length() - 1));
							databuf += "\n";
							if (writes.get(pt) == null) {
								writes.put(pt, new ArrayList<String>());
							}

							ArrayList<String> msgList = writes.get(pt);
							msgList.add(databuf);
							writes.put(pt, msgList);

						}

						Set<String> pathSet = writes.keySet();
						ArrayList<String> pathList = new ArrayList<String>(pathSet);
						String execId = SparkEnv.get().executorId(); 
						for (int i = 0; i < pathList.size(); i++) {
							
							Path pt1 = new Path(pathList.get(i) + "_" + execId + ".dat");
							if (!fs.exists(pt1)) {
								fs.createNewFile(pt1);
							}

							FSDataOutputStream ostr = fs.append(pt1);
							ObjectOutputStream oos = new ObjectOutputStream(ostr);
							oos.writeObject(writes.get(pathList.get(i)));
							oos.close();
							ostr.close();
						}

						dao.eppSchemaBatchPut(conf, puts, table);
					}
				});

			}
		});
		jssc.checkpoint(checkpointDirectory);
		return jssc;
	}

}
