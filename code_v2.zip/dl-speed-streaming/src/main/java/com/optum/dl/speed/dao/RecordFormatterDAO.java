package com.optum.dl.speed.dao;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.hbase.util.Bytes;

import com.optum.dl.speed.model.CDC;
import com.optum.dl.speed.model.FormattedRecord;

public class RecordFormatterDAO {
	List<HTable> htables = new ArrayList<HTable>();
	int i = 0;
	public static final byte[] cfInfoBytes = Bytes.toBytes("info");

	public RecordFormatterDAO() {
	}

	public void makeBatchPut(Configuration conf, HashMap<String, ArrayList<Put>> map) throws IOException {

		String[] tableName = new String[map.size()];
		for (int i = 0; i < map.keySet().size(); i++) {
			tableName[i] = map.keySet().iterator().next();
		}

		for (int j = 0; j < tableName.length; j++) {
			HBaseAdmin hba = new HBaseAdmin(conf);
			if (hba.tableExists(tableName[j]) == false) {
				HTableDescriptor tableDescriptor = new HTableDescriptor(tableName[j]);
				HColumnDescriptor columnDescriptor = new HColumnDescriptor("info");
				tableDescriptor.addFamily(columnDescriptor);

				hba.createTable(tableDescriptor);
			}
			htables.add(new HTable(conf, Bytes.toBytes(tableName[j])));
			ArrayList<Put> put = map.get(tableName[j]);
			if (put != null) {

				Object[] results = new Object[put.size()];
				try {
					htables.get(j).batch(put, results);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			htables.get(j).close();
		}
	}

	@SuppressWarnings("deprecation")
	public void eppSchemaBatchPut(Configuration conf, HashMap<String, ArrayList<Put>> map, String table)
			throws IOException {

		Set<String> srcEnt = map.keySet();
		ArrayList<String> srcEntList = new ArrayList<String>(srcEnt);

		HBaseAdmin hba = new HBaseAdmin(conf);
		if (hba.tableExists(table) == false) {
			HTableDescriptor tableDescriptor = new HTableDescriptor(table);
			HColumnDescriptor columnDescriptor = new HColumnDescriptor("info");
			tableDescriptor.addFamily(columnDescriptor);

			hba.createTable(tableDescriptor);
		}

		htables.add(new HTable(conf, Bytes.toBytes(table)));
		
		for (int j = 0; j < srcEntList.size(); j++) {

			ArrayList<Put> put = map.get(srcEntList.get(j));
			if (put != null) {

				Object[] results = new Object[put.size()];
				try {
					htables.get(0).batch(put, results);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}
		htables.get(0).close();
	}
	
	
	public HashMap<String, ArrayList<Put>> getAll(String table, byte[] cf) throws IOException {
		Configuration conf = HBaseConfiguration.create();
		RecordFormatterDAO dao = new RecordFormatterDAO();
		@SuppressWarnings({ "deprecation", "resource" })
		HBaseAdmin hba = new HBaseAdmin(conf);
        
		if (hba.tableExists(table) == false) {
        	@SuppressWarnings("deprecation")
			HTableDescriptor tableDescriptor= new HTableDescriptor(table);
        	HColumnDescriptor columnDescriptor= new HColumnDescriptor("info");
        	tableDescriptor.addFamily(columnDescriptor);
        	
        	hba.createTable(tableDescriptor);
        }//end of if.
        
        @SuppressWarnings("deprecation")
		HTable htable = new HTable(conf, Bytes.toBytes(table));
        HashMap<String, ArrayList<Put>> results = new HashMap<String, ArrayList<Put>>();
        
		
		Scan s = new Scan();
		ResultScanner ss = htable.getScanner(s);
		if (ss != null) {
			for (Result result : ss) {
				String rowKey = new String(result.getRow());	
				ArrayList<Put> mdVr = new ArrayList<>();
				Map<byte[], byte[]> cell = result.getFamilyMap(Bytes.toBytes("info"));
				for (Map.Entry<byte[], byte[]> entry : cell.entrySet()) {
					String md5 = new String(entry.getKey());
					Integer version = java.nio.ByteBuffer.wrap(entry.getValue()).getInt();
					try {
						mdVr.add(dao.eppSchemaPut(md5, version, rowKey));
		        	}
		        	catch (ParseException p){

		        	}
					
				}
				
				results.put(rowKey, mdVr);
			}//end of for.
		}//end of if.
		htable.close();
		return results;
	}//end of getAll method.
	
	

	public void makePut(Configuration conf, String Table, ArrayList<Put> put) throws IOException {

		String tableName = Table;

		HBaseAdmin hba = new HBaseAdmin(conf);
		if (hba.tableExists(tableName) == false) {
			HTableDescriptor tableDescriptor = new HTableDescriptor(tableName);
			HColumnDescriptor columnDescriptor = new HColumnDescriptor("info");
			tableDescriptor.addFamily(columnDescriptor);

			hba.createTable(tableDescriptor);
		}
		Table myTable = new HTable(conf, Bytes.toBytes(tableName));
		if (put != null) {

			Object[] results = new Object[put.size()];
			try {
				myTable.batch(put, results);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		myTable.close();
	}

	@SuppressWarnings("null")
	public Put mkPut(FormattedRecord format) throws IOException, ParseException {
		// create a composite row key: sensorid_date time

		String rowkey = format.getKey();
		String[] variables = format.getKeys();
		String[] values = format.getValues();
		long cdc_ts = format.getTs();
		Put put = new Put(Bytes.toBytes(rowkey));
		for (int i = 0; i < variables.length; i++) {
			String variable = variables[i];
			String value = values[i];
			if (value != null && variable != null)
				put.addColumn(cfInfoBytes, Bytes.toBytes(variable), cdc_ts, Bytes.toBytes(value));
		}
		i++;

		return put;
	}

	
	public Put eppSchemaPut(String md5, Integer version, String rowKey) throws IOException, ParseException {
        // create a composite row key: sensorid_date time

        Long cdc_ts = System.nanoTime();
        Put put = new Put(Bytes.toBytes(rowKey));

        if (version != null && md5 != null) {
            put.addColumn(cfInfoBytes, Bytes.toBytes(md5), cdc_ts, Bytes.toBytes(version));
//            put.addColumn(cfInfoBytes, Bytes.to, cdc_ts, Bytes.toBytes(value));
        }

//        htables.add(new HTable(conf, Bytes.toBytes(table)));
//        if (put != null) {
//			Object[] results = new Object[put.size()];
//            htables.get(0).put(put);
//        }

        return put;
    }
}
