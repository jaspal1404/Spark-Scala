package com.optum.dl.speed.common;

import org.apache.kafka.common.serialization.Serializer;
import org.apache.spark.rdd.RDD;
import org.apache.spark.streaming.kafka.producer.ProducerConf;
import org.apache.spark.streaming.kafka.producer.RDDFunctions;

import scala.reflect.ClassTag;

public class KafkaRDDFunctions<T> {

	public final RDD<T> rdd;
	public final RDDFunctions<T> rddFunctions;

	public KafkaRDDFunctions(RDD<T> rdd) {
		this.rdd = rdd;
		ClassTag<T> classTag = rdd.toJavaRDD().classTag();
		this.rddFunctions = new RDDFunctions<T>(rdd, classTag);
	}

	public void sendToKafa(String topic, ProducerConf conf,	ClassTag<Serializer<T>> ser) {
		rddFunctions.sendToKafka(topic, conf, ser);
	}
}
