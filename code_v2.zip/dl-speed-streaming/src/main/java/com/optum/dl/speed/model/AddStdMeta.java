package com.optum.dl.speed.model;

import java.io.Serializable;

public class AddStdMeta implements Serializable {
	private static final long serialVersionUID = 1L;

	String prtnrCd;
	String srcCd;
	String entNm;
	String addline1;
	String addline2;
	String addline3;
	String city;
	String state;
	String country;
	String zip;
	String source;

	public AddStdMeta() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AddStdMeta(String prtnrCd, String srcCd, String entNm, String addline1, String addline2, String addline3,
			String city, String state, String country, String zip) {
		super();
		this.prtnrCd = prtnrCd;
		this.srcCd = srcCd;
		this.entNm = entNm;
		this.addline1 = addline1;
		this.addline2 = addline2;
		this.addline3 = addline3;
		this.city = city;
		this.state = state;
		this.country = country;
		this.zip = zip;
	}

	public String getPrtnrCd() {
		return prtnrCd;
	}

	public void setPrtnrCd(String prtnrCd) {
		this.prtnrCd = prtnrCd;
	}

	public String getSrcCd() {
		return srcCd;
	}

	public void setSrcCd(String srcCd) {
		this.srcCd = srcCd;
	}

	public String getEntNm() {
		return entNm;
	}

	public void setEntNm(String entNm) {
		this.entNm = entNm;
	}

	public String getAddline1() {
		return addline1;
	}

	public void setAddline1(String addline1) {
		this.addline1 = addline1;
	}

	public String getAddline2() {
		return addline2;
	}

	public void setAddline2(String addline2) {
		this.addline2 = addline2;
	}

	public String getAddline3() {
		return addline3;
	}

	public void setAddline3(String addline3) {
		this.addline3 = addline3;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	@Override
	public String toString() {
		return "Meta [prtnrCd=" + prtnrCd + ", srcCd=" + srcCd + ", entNm=" + entNm + ", addline1Col=" + addline1
				+ ", addline2=" + addline2 + ", addline3=" + addline3 + ", city=" + city + ", state=" + state
				+ ", country=" + country + ", zip=" + zip + "]";
	}
}
