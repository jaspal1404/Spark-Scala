package com.optum.dl.speed;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
//import java.time.LocalDateTime;
//import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.json.JSONException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.dl.speed.model.CDC;
import com.optum.dl.speed.model.Column;
import com.optum.dl.speed.model.FormatInfo;
import com.optum.dl.speed.model.Option;
import com.optum.dl.speed.model.Schema;
import com.optum.dl.speed.model.TransactionInfo;
import com.optum.dl.speed.dao.RecordFormatterDAO;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.Put;

/**
 * Created by jsingh73 on 3/27/2017.
 */
public class Producer {

    // Set the number of messages to send.
    public static int numMessages = 60;
    public static ObjectMapper mapper;
    public static ProducerRecord<String, String> rec;
    public static KafkaProducer<String, String> producer;

    /*
     * The main method is where the rectangles are created.
     * @param   path   			files path where data and meta files
     * @param   metaFileName	meta file name
     * @param   dataFileName  	data file name
     * @param   topic			topic name to read messages
     * @param   numberOfRecords	number of records to produce
     * @param   batchWindow		number of minutes to wait to send next batch
     */
    public static void main(String[] args) throws IOException, JSONException, InterruptedException {

        SimpleDateFormat ft = new SimpleDateFormat ("yyyy-MM-dd HH:mm:ss.SSS");

        System.out.println("Starting time: " + ft.format(new Date()));

        String path = "/mapr/datalake/uhclake/tst/developer/DL_SPEEDLAYER/temp/";
        if (args.length > 0) {
            path = args[0];
        }

        String metaFileName = "RX1_CLMPRDFIL_RCMBRP_20170301T105200.meta";
        if (args.length > 1) {
            metaFileName = args[1];
        }

        String dataFileName = "RX1_CLMPRDFIL_RCMBRP_20170301T105200.dat";
        if (args.length > 2) {
            dataFileName = args[2];
        }

        String topic = "/datalake/uhclake/tst/developer/DL_SPEEDLAYER/streams/optum-datalake-speed:optum.datalake.speed.cdc.rx1";
        if (args.length > 3) {
            topic = args[3];
        }

        int numberOfRecords = 500000;
        if(args.length > 4){
            numberOfRecords = Integer.parseInt(args[4]);
        }

        int batchWindow = 0;
        if(args.length > 5){
            batchWindow = Integer.parseInt(args[5]);
        }

        String md5Key = "AX1BY2CZ3";
        if(args.length > 6){
            md5Key = args[6];
        }

        Long numberOfLines = 0L;

        configureProducer();


        File metaFile = new File(path + metaFileName);
        File dataFile = new File(path + dataFileName);

        CDC message = getMetaInformation(metaFile, md5Key);


        mapper = new ObjectMapper();
        FileReader fileReader = new FileReader(dataFile);
        BufferedReader bufferReader = new BufferedReader(fileReader);
        String line = bufferReader.readLine();

        while (line != null) {

            message.setTransactionID(Long.toString(System.nanoTime()));
            message.setData(line);
            rec = new ProducerRecord<String, String>(topic, mapper.writeValueAsString(message));
//            rec = new ProducerRecord<String, String>(topic, message.getData());
            producer.send(rec);
            numberOfLines++;
            line = bufferReader.readLine();

            if(batchWindow > 0 && ((numberOfLines % numberOfRecords) == 0) ){
                System.out.println(String.format("batch %s : %s records sent @ %s", (numberOfLines / numberOfRecords), numberOfRecords, System.currentTimeMillis() ));
                Thread.sleep(batchWindow * 60 * 1000);
            }
        }

        bufferReader.close();

        producer.close();

//        Long end = System.nanoTime();
        System.out.println("Ending Time: " + ft.format(new Date()));
        System.out.println(message.getSchema().getSchmd5());
        System.out.println(message.getSchema().getVersion());

        System.exit(1);

    }

    public static CDC getMetaInformation(File file, String md5Key) throws IOException, JSONException {

        CDC message = new CDC();

        FileReader fileReader = new FileReader(file);
        BufferedReader bufferReader = new BufferedReader(fileReader);
        String line = bufferReader.readLine();

        line = bufferReader.readLine();

        boolean hasSchema = false;
        List<Column> columns = new ArrayList<Column>();
        Schema schema = new Schema();
        Option option = new Option();
        TransactionInfo transactionInfo = new TransactionInfo();
        FormatInfo formatInfo = new FormatInfo();

        transactionInfo.setContent("Changes");
        SimpleDateFormat ft = new SimpleDateFormat ("yyyy-MM-dd HH:mm:ss.SSS");
        transactionInfo.setTransactionTimestamp(ft.format(new Date()));

        formatInfo.setFormat("delimited");
        option.setFieldDelimiter("\u0001");
        formatInfo.setOptions(option);

        // Check if the HBase table already exists
        String table = "/datalake/uhclake/tst/developer/DL_SPEEDLAYER/mtables/epp_schema_mapping";
        Configuration conf = HBaseConfiguration.create();
        HBaseAdmin hba = new HBaseAdmin(conf);
        if (hba.tableExists(table) == false) {
            HTableDescriptor tableDescriptor = new HTableDescriptor(table);
            HColumnDescriptor columnDescriptor = new HColumnDescriptor("info");
            tableDescriptor.addFamily(columnDescriptor);

            hba.createTable(tableDescriptor);
        }

        // identify the schema version for source-entity
        String[] fields = line.split("\\|");
        int version=0;
        boolean updateHbase = false;
        boolean schChange = false;
        RecordFormatterDAO dao = new RecordFormatterDAO();
        HashMap<String, ArrayList<Put>> puts = dao.getAll(table, Bytes.toBytes("info"));
        ArrayList<Put> mdVr = new ArrayList<>();

        HTable hbaseTable = new HTable(conf, table);
        String rowKey = fields[0] + "-" + fields[2];
        Get get = new Get(Bytes.toBytes(rowKey));
        Result rs = hbaseTable.get(get);

        if (puts.get(rowKey) == null) {
            puts.put(rowKey, mdVr);
            version = 1;
            mdVr = puts.get(rowKey);
            updateHbase = true;
            schChange = true;
            schema.setVersion(version);
        }

        else {
            mdVr = puts.get(rowKey);

            for (int i = 0; i < mdVr.size(); i++) {
                if (mdVr.get(i).has(Bytes.toBytes("info"), Bytes.toBytes(md5Key))) {
                    byte[] temp = mdVr.get(i)
                            .get(Bytes.toBytes("info"), Bytes.toBytes(md5Key)).get(0)
                            .getValue();
                    version = java.nio.ByteBuffer.wrap(temp).getInt();
                    break;
                }
            }

            if (version == 0) {
                version = mdVr.size() + 1;
				updateHbase = true;
                schChange = true;
                schema.setVersion(version);
            }
        }

        if (schChange) {
            while (line != null) {

//            String[] fields = line.split("\\|");

                if (!hasSchema) {

                    schema.setSource(fields[0]);
                    schema.setSourceSchema(fields[1]);
                    schema.setSourceTable(fields[2]);
                    schema.setSchmd5(md5Key);

                    hasSchema = true;
                }

                Column column = new Column();

                column.setName(fields[3]);
                column.setType(fields[4]);
                column.setWidth(convertToInt(fields[5]));
                column.setScale(convertToInt(fields[6]));
                column.setOridnal(convertToInt(fields[9]));

                columns.add(column);

                line = bufferReader.readLine();
            }

            schema.setColumns(columns);

            message.setTransaction(transactionInfo);
            message.setFormat(formatInfo);
            message.setSchema(schema);

            fileReader.close();
            bufferReader.close();

        }

        if (updateHbase) {

            try {
                mdVr.add(dao.eppSchemaPut(message.getSchema().getSchmd5(), version, rowKey));
                puts.put(rowKey, mdVr);
                dao.makePut(conf, table, mdVr);
            }
            catch (ParseException p){
                p.printStackTrace();
            }
        }
        return message;
    }



    public static int convertToInt(String value) {

        String innerValue = value.trim().equals("") ? "0" : value;
        return Integer.valueOf(innerValue);
    }

    /*
     * Set the value for a configuration parameter. This configuration parameter
     * specifies which class to use to serialize the value of each message.
     */
    public static void configureProducer() {
        Properties props = new Properties();
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");

        producer = new KafkaProducer<String, String>(props);
    }

}