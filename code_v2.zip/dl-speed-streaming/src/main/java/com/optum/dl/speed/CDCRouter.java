package com.optum.dl.speed;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.spark.Accumulator;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.Function0;
import org.apache.spark.api.java.function.VoidFunction;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaPairInputDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.apache.spark.streaming.kafka.v09.KafkaUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.dl.speed.CDCRouterTest.MapBroadCast;
import com.optum.dl.speed.CDCRouterTest.MessageCounAccumlator;
import com.optum.dl.speed.dao.CDCDao;
import com.optum.dl.speed.model.CDC;
import com.optum.dl.speed.model.Column;
import com.optum.dl.speed.model.FormattedRecord;
import com.optum.dl.speed.model.Meta;

import scala.Tuple2;

public class CDCRouter {
	static class MapBroadCast {

		private static volatile Broadcast<HashMap<String, Meta>> instance = null;

		public static Broadcast<HashMap<String, Meta>> getInstance(JavaSparkContext jsc) {
			if (instance == null) {
				synchronized (MapBroadCast.class) {
					if (instance == null) {
						HashMap<String, Meta> metaData = new HashMap<String, Meta>();
						Configuration conf = HBaseConfiguration.create();
						try {
							CDCDao dao = new CDCDao();

							metaData = dao.getAll("/datalake/uhclake/tst/developer/DL_SPEEDLAYER/mtables/spp_hbase");
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						instance = jsc.broadcast(metaData);
					}
				}
			}
			return instance;
		}
	}
	@SuppressWarnings("serial")
	public static void main(String[] args) {
		if (args.length < 2) {
			System.err.println("Usage: CDCUpdateMaprDB <brokers> <topics>\n"
					+ "  <brokers> is a list of one or more Kafka brokers\n"
					+ "  <topics> is a list of one or more kafka topics to consume from\n"
					+ "  <poll time> time, in milliseconds, spent waiting in Kafka consumer poll if data is not available\n\n");
			System.exit(1);
		}

		final String brokers = args[0];
		final String topics = args[1];
		final String pollTime = args[2];
		final String checkpointDirectory = (args.length > 3) ? args[3]
				: "/datalake/corporate/ses_dlpoc/cdc/checkpoint_2";

		/*HashMap<String, Meta> metaData = new HashMap<String, Meta>();
		Configuration conf = HBaseConfiguration.create();
		try {
			CDCDao dao = new CDCDao();

			metaData = dao.getAll("/datalake/uhclake/tst/developer/DL_SPEEDLAYER/mtables/spp_hbase");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		final HashMap<String, Meta> meta = metaData;
*/
		Function0<JavaStreamingContext> createContextFunc = new Function0<JavaStreamingContext>() {
			@Override
			public JavaStreamingContext call() {
				return createContext(brokers, topics, pollTime, checkpointDirectory);
			}
		};
		JavaStreamingContext jssc = JavaStreamingContext.getOrCreate(checkpointDirectory, createContextFunc);
		jssc.start();
		jssc.awaitTermination();

	}

	@SuppressWarnings("serial")
	protected static JavaStreamingContext createContext(String brokers, String topics, String pollTime,
			String checkpointDirectory) {
		// Create context with a 2 seconds batch interval
		/*
		 * HashMap<String, Meta> metaData = new HashMap<String,Meta>();
		 * Configuration conf = HBaseConfiguration.create(); try { CDCDao dao =
		 * new CDCDao();
		 * 
		 * metaData=dao.getAll(
		 * "/datalake/uhclake/tst/developer/DL_SPEEDLAYER/mtables/spp_hbase"); }
		 * catch (IOException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); } final HashMap<String, Meta> meta = metaData;
		 */
		SparkConf sparkConf = new SparkConf().setAppName("CDCRouter");// .setMaster("local[2]");
		JavaStreamingContext jssc = new JavaStreamingContext(sparkConf, Durations.seconds(2));
		// jssc.sparkContext().broadcast(meta);
		HashSet<String> topicsSet = new HashSet<String>(Arrays.asList(topics.split(",")));
		HashMap<String, String> kafkaParams = new HashMap<String, String>();
		kafkaParams.put(ConsumerConfig.GROUP_ID_CONFIG, "cdc");
		kafkaParams.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,
				"org.apache.kafka.common.serialization.StringDeserializer");
		kafkaParams.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
				"org.apache.kafka.common.serialization.StringDeserializer");
		// kafkaParams.put("spark.kafka.poll.time", pollTime);
		kafkaParams.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
		kafkaParams.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
		// Create direct kafka stream with brokers and topics
		JavaPairInputDStream<String, String> messages = KafkaUtils.createDirectStream(jssc, String.class, String.class,
				kafkaParams, topicsSet);

		JavaDStream<String> lines = messages.map(new Function<Tuple2<String, String>, String>() {
			@Override
			public String call(Tuple2<String, String> tuple2) {
				return tuple2._2();
			}
		});
		JavaDStream<CDC> cdc = lines.map(new Function<String, CDC>() {
			ObjectMapper mapper = new ObjectMapper();

			@Override
			public CDC call(String json) throws Exception {
				return mapper.readValue(json, CDC.class);
			}
		});

		cdc.foreachRDD(new VoidFunction<JavaRDD<CDC>>() {

			@Override
			public void call(JavaRDD<CDC> rdd) throws Exception {
				final Broadcast<HashMap<String, Meta>> meta = MapBroadCast
						.getInstance(new JavaSparkContext(rdd.context()));
				final Accumulator<Integer> counter = MessageCounAccumlator
						.getInstance(new JavaSparkContext(rdd.context()));
				SimpleDateFormat ft = new SimpleDateFormat ("yyyy-MM-dd HH:mm:ss.SSS");
				System.out.println("Message Counter: " + counter.value() + " Time: " + ft.format(new Date()));
				rdd.foreachPartition(new VoidFunction<Iterator<CDC>>() {
					@Override
					public void call(Iterator<CDC> cdc) throws Exception {

						Producer<String, String> producer = getKafkaProducer();
						CDCDao dao = new CDCDao();
						ObjectMapper mapper = new ObjectMapper();

						while (cdc != null && cdc.hasNext()) {
							CDC cdcs = cdc.next();
							counter.add(1);
							Meta recordMeta = meta.getValue().get(cdcs.getSchema().getSource() + "-"
									+ cdcs.getSchema().getSourceSchema() + "_" + cdcs.getSchema().getSourceTable());
							String rowkey = recordMeta.getRowkey();
							List<Column> columns = cdcs.getSchema().getColumns();
							String[] column = new String[columns.size()];
							for (int i = 0; i < columns.size(); i++) {
								column[i] = columns.get(i).getName();
							}
								FormattedRecord record = new FormattedRecord();
								record.setSourceMD5(cdcs.getSchema().getSchmd5());
								record.setTransactionID(cdcs.getTransactionID());
								record.setSchemaName(cdcs.getSchema().getSourceSchema());
								record.setPartnCode(recordMeta.getPartner());
								record.setSourceCode(cdcs.getSchema().getSource());	
								record.setSourceTable(cdcs.getSchema().getSourceTable());

							
							record.setKeys(column);
							String[] data = cdcs.getData().split(cdcs.getFormat().getOptions().getFieldDelimiter());
							record.setValues(data);
							String[] rowkeys = rowkey.split("\\;");
							record.setHtable(recordMeta.getLocation());
							record.setKey(dao.rowkey(cdcs, rowkeys, column, data));
							String cdc_ts = cdcs.getTransaction().getTransactionTimestamp();
							SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
							Date myDate = df.parse(cdc_ts);
							record.setTs(myDate.getTime());
							// if(dao.validate(cdcs, column, data)){
							producer.send(new ProducerRecord<String, String>(
									"/datalake/uhclake/tst/developer/DL_SPEEDLAYER/streams/optum-datalake-services:optum.datalake.speed.cdc.snapshot",
									mapper.writeValueAsString(record)));
							if (recordMeta.getAdrind().equals("Y")) {
								producer.send(new ProducerRecord<String, String>(
										"/datalake/uhclake/tst/developer/DL_SPEEDLAYER/streams/optum-datalake-address:optum.datalake.speed.cdc.adrsrt",
										mapper.writeValueAsString(record)));
								// }
							}

						}

						producer.flush();
						// dao.putCDCBatch(puts);
						producer.close();
					}

				});

			}

			public Producer<String, String> getKafkaProducer() {
				Properties props = new Properties();
				props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "apsrd4190:9092");
				props.put(ProducerConfig.ACKS_CONFIG, "all");
				// props.put(ProducerConfig.RETRIES_CONFIG, 2);
				// props.put(ProducerConfig.BATCH_SIZE_CONFIG, 16384);
				// props.put(ProducerConfig.LINGER_MS_CONFIG, 1);
				// props.put(ProducerConfig.BUFFER_MEMORY_CONFIG, 33554432);
				props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,
						"org.apache.kafka.common.serialization.StringSerializer");
				props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
						"org.apache.kafka.common.serialization.StringSerializer");

				return new KafkaProducer<>(props);
			}

		});

		jssc.checkpoint(checkpointDirectory);
		return jssc;
	}

}
