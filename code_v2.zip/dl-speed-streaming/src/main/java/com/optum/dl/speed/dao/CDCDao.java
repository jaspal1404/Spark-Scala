package com.optum.dl.speed.dao;

import java.io.IOException;
import java.util.HashMap;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.log4j.Logger;

import com.optum.dl.speed.model.CDC;
import com.optum.dl.speed.model.Meta;

public class CDCDao {

	// Column Family is 'alert
	public static final byte[] cfInfoBytes = Bytes.toBytes("info");

	private static final Logger log = Logger.getLogger(CDCDao.class);

	public CDCDao() {

	}

	@SuppressWarnings("null")
	public boolean validate(CDC cdc, String[] variables, String[] values) {
		Boolean validate = false;
		if (variables.length == values.length) {
			validate = true;
		}
		return validate;
	}

	@SuppressWarnings("null")
	public String rowkey(CDC cdc, String[] rowkeys, String[] variables, String[] values) {

		String rowkey = "";
		HashMap<String, String> map = new HashMap<String, String>();
		for (int i = 0; i < rowkeys.length; i++) {
			map.put(rowkeys[i], "");
		}

		for (int j = 0; j < variables.length; j++) {
			for (int k = 0; k < rowkeys.length; k++) {

				if (variables[j].equalsIgnoreCase(rowkeys[k])) {
					map.put(rowkeys[k], values[j].trim());
					break;
				}
			}

		}

		for (int z = 0; z < rowkeys.length; z++) {
			if (z == 0) {
				rowkey = map.get(rowkeys[z]);
			} else {
				rowkey += "-" + map.get(rowkeys[z]);
			}
		}

		return rowkey;
	}

	/*
	 * create Sensor Model Object from Get or Scan Result
	 */
	public HashMap<String, Meta> getAll(String table) throws IOException {
		Configuration conf = HBaseConfiguration.create();
		HBaseAdmin hba = new HBaseAdmin(conf);
		if (hba.tableExists(table) == false) {
			HTableDescriptor tableDescriptor = new HTableDescriptor(table);
			HColumnDescriptor columnDescriptor = new HColumnDescriptor("info");
			tableDescriptor.addFamily(columnDescriptor);

			hba.createTable(tableDescriptor);
		}
		HTable htable = new HTable(conf, Bytes.toBytes(table));
		HashMap<String, Meta> results = new HashMap<String, Meta>();

		Scan s = new Scan();
		ResultScanner ss = htable.getScanner(s);
		if (ss != null) {
			for (Result result : ss) {
				String rowkey = new String(result.getRow());

				results.put(rowkey, populateFromResult(result));
			}
		}
		htable.close();
		return results;
	}

	public Meta populateFromResult(Result result) {
		// TODO Auto-generated method stub
		Meta m = new Meta();
		final byte[] cf_pi = Bytes.toBytes("pi");
		m.setAdrind(replaceNullWithEmpty(result.getValue(cf_pi, Bytes.toBytes("adrind"))));
		m.setLocation(replaceNullWithEmpty(result.getValue(cf_pi, Bytes.toBytes("location"))));
		m.setPartner(replaceNullWithEmpty(result.getValue(cf_pi, Bytes.toBytes("partner"))));
		m.setRowkey(replaceNullWithEmpty(result.getValue(cf_pi, Bytes.toBytes("rowkey"))));
		m.setSchema(replaceNullWithEmpty(result.getValue(cf_pi, Bytes.toBytes("schema"))));
		m.setSource(replaceNullWithEmpty(result.getValue(cf_pi, Bytes.toBytes("source"))));
		return m;
	}

	public static String replaceNullWithEmpty(byte[] value) {
		return value != null ? new String(value) : "";
	}

}
