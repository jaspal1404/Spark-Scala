package com.optum.dl.speed.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.dl.speed.common.Auditable;

public class CDC extends Auditable implements Serializable {

	private static final long serialVersionUID = 1L;
	@JsonProperty("transactionInfo")
	TransactionInfo TransactionInfo = new TransactionInfo();
	@JsonProperty("formatInfo")
	FormatInfo formatInfo = new FormatInfo();
	Schema schema = new Schema();
	String data;
	String transactionID;
	public TransactionInfo getTransactionInfo() {
		return TransactionInfo;
	}

	public void setTransactionInfo(TransactionInfo transactionInfo) {
		TransactionInfo = transactionInfo;
	}

	public FormatInfo getFormatInfo() {
		return formatInfo;
	}

	public void setFormatInfo(FormatInfo formatInfo) {
		this.formatInfo = formatInfo;
	}

	public String getTransactionID() {
		return transactionID;
	}

	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}

	public CDC() {
		super();
	}

	public CDC(TransactionInfo transaction, FormatInfo format, Schema schema, String data) {
		super();
		this.TransactionInfo = transaction;
		this.formatInfo = format;
		this.schema = schema;
		this.data = data;
	}

	@Override
	public String toString() {
		return "CDC [transaction=" + TransactionInfo + ", format=" + formatInfo + ", schema=" + schema + ", data="
				+ data + "]";
	}

	public TransactionInfo getTransaction() {
		return TransactionInfo;
	}

	public void setTransaction(TransactionInfo TransactionInfo) {
		this.TransactionInfo = TransactionInfo;
	}

	public FormatInfo getFormat() {
		return formatInfo;
	}

	public void setFormat(FormatInfo format) {
		this.formatInfo = format;
	}

	public Schema getSchema() {
		return schema;
	}

	public void setSchema(Schema schema) {
		this.schema = schema;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}
}
