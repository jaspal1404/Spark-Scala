package com.optum.dl.speed.logging;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Properties;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.io.Resources;

public class LoggingService {
	
	static Logger logger = Logger.getLogger(LoggingService.class);

	public static void main(String[] args) throws IOException {
		String type = "";
		String sourceCode = "";
		String sourceTable = "";
		String partnCode = "";
		String appName = "";
		String transactionID = "";
		String lmsg = "";
		KafkaConsumer<String, String> consumer;		
		
		//PropertyConfigurator.configure(Resources.getResource("log4j.properties"));
		initializeLogger();
		final Logger debugLog = Logger.getLogger("debugLogger");
		final Logger repLog = Logger.getLogger("reportsLogger");
		
		ObjectMapper mapper = new ObjectMapper();
		// Set the stream and topic to publish to.
		final String TOPIC_LOG_MESSAGES_C = "/datalake/uhclake/tst/developer/DL_SPEEDLAYER/streams/optum-datalake-utilities:optum.datalake.speed.logging";
		consumer = getKafkaConsumer();		
        consumer.subscribe(Arrays.asList(TOPIC_LOG_MESSAGES_C));

        // InfiniteLoopStatement
        while (true) {
            // read records with a short timeout. If we time out, we don't really care.
            ConsumerRecords<String, String> records = consumer.poll(2000);
            for (ConsumerRecord<String, String> record : records) {
            	// the send time is encoded inside the message
            	JsonNode msg = mapper.readTree(record.value());
            	type = msg.get("type").asText().replace("\"", "").trim().toUpperCase();
            	appName = msg.get("appName").asText().replace("\"", "").trim();
            	transactionID = msg.get("transactionID").asText().replace("\"", "").trim();
            	partnCode = msg.get("partnCode").asText().replace("\"", "").trim();
            	sourceCode = msg.get("sourceCode").asText().replace("\"", "").trim();
            	sourceTable = msg.get("sourceTable").asText().replace("\"", "").trim();
            	lmsg = msg.get("msg").asText().replace("\"", "").trim();
            	
            	if(type.endsWith("INFO")){
            		//System.out.println("Message:"+type+":"+transactionID+":"+appName+":"+partnCode+"-"+sourceCode+"_"+sourceTable);
        			debugLog.debug("["+type+"][Application:"+appName+"][Transaction ID:"+transactionID+"][Source Info:"+partnCode+"-"+sourceCode+"_"+sourceTable+"] "+lmsg);
            	}//end of if.
            }//end of for.
         }//end of while.
    }//end of main.
	
	 private static void initializeLogger()
	  {
	    Properties logProperties = new Properties();

	    try
	    {
	      // load our log4j properties / configuration file
	      logProperties.load(new FileInputStream("/mapr/datalake/uhclake/tst/developer/DL_SPEEDLAYER/jars/log4j.properties"));
	      PropertyConfigurator.configure(logProperties);
	      //logger.info("Logging initialized.");
	    }
	    catch(IOException e)
	    {
	      throw new RuntimeException("Unable to load logging property log4j.properties");
	    }
	  }
	
	/**
	 * 
	 * @return
	 */
	public static KafkaConsumer<String, String> getKafkaConsumer() {
		Properties properties = new Properties();
		properties.setProperty("enable.auto.commit","false");
		properties.setProperty("auto.offset.reset","earliest");
		properties.setProperty("key.deserializer","org.apache.kafka.common.serialization.StringDeserializer");
		properties.setProperty("value.deserializer","org.apache.kafka.common.serialization.StringDeserializer");
		properties.setProperty("group.id", "AddressStd-R");
		properties.setProperty("max.partition.fetch.bytes", "2097152");
		properties.setProperty("fetch.min.bytes", "50000");	    
		return new KafkaConsumer<String, String>(properties);
	}//end of method.
}
