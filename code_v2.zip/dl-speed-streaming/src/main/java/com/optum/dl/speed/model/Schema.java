package com.optum.dl.speed.model;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Schema implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -4970357984577851397L;
	String source;

	String sourceSchema;
	String sourceTable;
	String schmd5;
	Integer version;

	List<Column> column;

	public Schema() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Schema(String sourceSchema, String sourceTable, List<Column> column) {
		super();
		this.sourceSchema = sourceSchema;
		this.sourceTable = sourceTable;
		this.column = column;
	}


	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getSourceSchema() {
		return sourceSchema;
	}

	public void setSourceSchema(String sourceSchema) {
		this.sourceSchema = sourceSchema;
	}

	public String getSourceTable() {
		return sourceTable;
	}

	public void setSourceTable(String sourceTable) {
		this.sourceTable = sourceTable;
	}

	public List<Column> getColumns() {
		return column;
	}

	public void setColumns(List<Column> column) {
		this.column = column;
	}
	
	public String getSchmd5() {
		return schmd5;
	}

	public void setSchmd5(String schmd5) {
		this.schmd5 = schmd5;
	}
	
    public Integer getVersion() { return version; }

    public void setVersion(Integer version) { this.version = version; }

}
