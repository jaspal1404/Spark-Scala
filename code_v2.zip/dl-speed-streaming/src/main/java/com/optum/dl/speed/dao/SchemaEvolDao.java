package com.optum.dl.speed.dao;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.util.Bytes;

import com.optum.dl.speed.dao.RecordFormatterDAO;

public class SchemaEvolDao {
	
	public boolean validate(String[] variables, String[] values){
    	Boolean validate = false;    
         if(variables.length==values.length){
        	 validate=true;
         }//end of if.
         return validate;
    }//end of method.
	
	/**
	 * 
	 * @param spp
	 * @param rowkeys
	 * @param variables
	 * @param values
	 * @return
	 */
	public String rowkey(String[] rowkeys, String[] variables, String[] values){
        String rowkey="";
        HashMap<String, String> map = new HashMap<String, String>();
        
        for(int i=0; i<rowkeys.length; i++){
        	map.put(rowkeys[i], "");
        }//end of for.
        
        for(int j=0; j<variables.length;j++){
        	for(int k=0; k<rowkeys.length; k++){
        		if(variables[j].equalsIgnoreCase(rowkeys[k])){
        			map.put(rowkeys[k],values[j]);
        			break;
        		}// end of if.
       	 	}//end of for.
        }//end of for.
        
        for(int z=0;z<rowkeys.length;z++){
        	if(z == 0){
        		rowkey=map.get(z);
        	}//end of if.
        	else{
        		rowkey+="-"+map.get(z);
        	}//end of else
        }//end of for.       
        return rowkey;
    }//end of method.

	/**
     * Creating a connection with HBase table and loading all the values.
     * @param table
     * @return
     * @throws IOException
     */	
	//@SuppressWarnings("deprecation")
	public HashMap<String, ArrayList<Put>> getAll(String table, byte[] cf) throws IOException {
		Configuration conf = HBaseConfiguration.create();
		RecordFormatterDAO dao = new RecordFormatterDAO();
		@SuppressWarnings({ "deprecation", "resource" })
		HBaseAdmin hba = new HBaseAdmin(conf);
        
		if (hba.tableExists(table) == false) {
        	@SuppressWarnings("deprecation")
			HTableDescriptor tableDescriptor= new HTableDescriptor(table);
        	HColumnDescriptor columnDescriptor= new HColumnDescriptor("info");
        	tableDescriptor.addFamily(columnDescriptor);
        	
        	hba.createTable(tableDescriptor);
        }//end of if.
        
        @SuppressWarnings("deprecation")
		HTable htable = new HTable(conf, Bytes.toBytes(table));
        HashMap<String, ArrayList<Put>> results = new HashMap<String, ArrayList<Put>>();
        
		
		Scan s = new Scan();
		ResultScanner ss = htable.getScanner(s);
		if (ss != null) {
			for (Result result : ss) {
				String rowKey = new String(result.getRow());	
				ArrayList<Put> mdVr = new ArrayList<>();
				Map<byte[], byte[]> cell = result.getFamilyMap(Bytes.toBytes("info"));
				for (Map.Entry<byte[], byte[]> entry : cell.entrySet()) {
					String md5 = new String(entry.getKey());
					Integer version = java.nio.ByteBuffer.wrap(entry.getValue()).getInt();
					try {
						mdVr.add(dao.eppSchemaPut(md5, version, rowKey));
		        	}
		        	catch (ParseException p){

		        	}
					
				}
				
				results.put(rowKey, mdVr);
			}//end of for.
		}//end of if.
		htable.close();
		return results;
	}//end of getAll method.
	

    
	public static String replaceNullWithEmpty(byte[] value) {
		return value != null ? new String(value) : "";
	}//end of method.

}
